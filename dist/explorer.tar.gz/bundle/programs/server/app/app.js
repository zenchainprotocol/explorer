var require = meteorInstall({"imports":{"api":{"accounts":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/accounts/server/methods.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);

const fetchFromUrl = url => {
  try {
    let res = HTTP.get(API + url);

    if (res.statusCode == 200) {
      return res;
    }

    ;
  } catch (e) {
    console.log(url);
    console.log(e);
  }
};

Meteor.methods({
  'accounts.getAccountDetail': function (address) {
    this.unblock();
    let url = API + '/auth/accounts/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        // return JSON.parse(available.content).account
        let response = JSON.parse(available.content).result;
        let account;
        if (response.type === 'cosmos-sdk/Account' || response.type === 'cosmos-sdk/BaseAccount') account = response.value;else if (response.type === 'cosmos-sdk/DelayedVestingAccount' || response.type === 'cosmos-sdk/ContinuousVestingAccount') account = response.value.BaseVestingAccount.BaseAccount;

        try {
          url = API + '/bank/balances/' + address;
          response = HTTP.get(url);
          let balances = JSON.parse(response.content).result;
          account.coins = balances;
          if (account && account.account_number != null) return account;
          return null;
        } catch (e) {
          return null;
        }
      }
    } catch (e) {
      console.log(url);
      console.log(e);
    }
  },
  'accounts.getBalance': function (address) {
    this.unblock();
    let balance = {}; // get available atoms

    let url = API + '/cosmos/bank/v1beta1/balances/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        balance.available = JSON.parse(available.content).balances;
      }
    } catch (e) {
      console.log(url);
      console.log(e);
    } // get delegated amnounts


    url = API + '/cosmos/staking/v1beta1/delegations/' + address;

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        balance.delegations = JSON.parse(delegations.content).delegation_responses;
      }
    } catch (e) {
      console.log(url);
      console.log(e);
    } // get unbonding


    url = API + '/cosmos/staking/v1beta1/delegators/' + address + '/unbonding_delegations';

    try {
      let unbonding = HTTP.get(url);

      if (unbonding.statusCode == 200) {
        balance.unbonding = JSON.parse(unbonding.content).unbonding_responses;
      }
    } catch (e) {
      console.log(url);
      console.log(e);
    } // get rewards


    url = API + '/cosmos/distribution/v1beta1/delegators/' + address + '/rewards';

    try {
      let rewards = HTTP.get(url);

      if (rewards.statusCode == 200) {
        //get seperate rewards value
        balance.rewards = JSON.parse(rewards.content).rewards; //get total rewards value

        balance.total_rewards = JSON.parse(rewards.content).total;
      }
    } catch (e) {
      console.log(url);
      console.log(e);
    } // get commission


    let validator = Validators.findOne({
      $or: [{
        operator_address: address
      }, {
        delegator_address: address
      }, {
        address: address
      }]
    });

    if (validator) {
      let url = API + '/cosmos/distribution/v1beta1/validators/' + validator.operator_address + '/commission';
      balance.operatorAddress = validator.operator_address;

      try {
        let rewards = HTTP.get(url);

        if (rewards.statusCode == 200) {
          let content = JSON.parse(rewards.content).commission;
          if (content.commission && content.commission.length > 0) balance.commission = content.commission;
        }
      } catch (e) {
        console.log(url);
        console.log(e);
      }
    }

    return balance;
  },

  'accounts.getDelegation'(address, validator) {
    this.unblock();
    let url = "/cosmos/staking/v1beta1/validators/".concat(validator, "/delegations/").concat(address);
    let delegations = fetchFromUrl(url);
    console.log(delegations);
    delegations = delegations && delegations.data.delegation_response;
    if (delegations && delegations.delegation.shares) delegations.delegation.shares = parseFloat(delegations.delegation.shares);
    url = "/cosmos/staking/v1beta1/delegators/".concat(address, "/redelegations?dst_validator_addr=").concat(validator);
    let relegations = fetchFromUrl(url);
    relegations = relegations && relegations.data.redelegation_responses;
    let completionTime;

    if (relegations) {
      relegations.forEach(relegation => {
        let entries = relegation.entries;
        let time = new Date(entries[entries.length - 1].completion_time);
        if (!completionTime || time > completionTime) completionTime = time;
      });
      delegations.redelegationCompletionTime = completionTime;
    }

    url = "/cosmos/staking/v1beta1/validators/".concat(validator, "/delegations/").concat(address, "/unbonding_delegation");
    let undelegations = fetchFromUrl(url);
    undelegations = undelegations && undelegations.data.result;

    if (undelegations) {
      delegations.unbonding = undelegations.entries.length;
      delegations.unbondingCompletionTime = undelegations.entries[0].completion_time;
    }

    return delegations;
  },

  'accounts.getAllDelegations'(address) {
    this.unblock();
    let url = API + '/cosmos/staking/v1beta1/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;

        if (delegations && delegations.length > 0) {
          delegations.forEach((delegation, i) => {
            if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
          });
        }

        return delegations;
      }

      ;
    } catch (e) {
      console.log(url);
      console.log(e);
    }
  },

  'accounts.getAllUnbondings'(address) {
    this.unblock();
    let url = API + '/cosmos/staking/v1beta1/delegators/' + address + '/unbonding_delegations';

    try {
      let unbondings = HTTP.get(url);

      if (unbondings.statusCode == 200) {
        unbondings = JSON.parse(unbondings.content).result;
        return unbondings;
      }

      ;
    } catch (e) {
      console.log(url);
      console.log(e);
    }
  },

  'accounts.getAllRedelegations'(address, validator) {
    this.unblock();
    let url = "/cosmos/staking/v1beta1/v1beta1/delegators/".concat(address, "/redelegations&src_validator_addr=").concat(validator);

    try {
      let result = fetchFromUrl(url);

      if (result && result.data) {
        let redelegations = {};
        result.data.forEach(redelegation => {
          let entries = redelegation.entries;
          redelegations[redelegation.validator_dst_address] = {
            count: entries.length,
            completionTime: entries[0].completion_time
          };
        });
        return redelegations;
      }
    } catch (e) {
      console.log(url);
      console.log(e);
    }
  },

  'accounts.getRedelegations'(address) {
    this.unblock();
    let url = API + '/cosmos/staking/v1beta1/v1beta1/delegators/' + address + '/redelegations';

    try {
      let userRedelegations = HTTP.get(url);

      if (userRedelegations.statusCode == 200) {
        userRedelegations = JSON.parse(userRedelegations.content).result;
        return userRedelegations;
      }

      ;
    } catch (e) {
      console.log(url);
      console.log(e.response.content);
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"blocks":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Blockscon;
module.link("/imports/api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
let Chain;
module.link("/imports/api/chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 3);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 5);
let ValidatorRecords, Analytics, VPDistributions;
module.link("/imports/api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 6);
let VotingPowerHistory;
module.link("/imports/api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 7);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 8);
let Evidences;
module.link("../../evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 9);
let sha256;
module.link("js-sha256", {
  sha256(v) {
    sha256 = v;
  }

}, 10);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 11);

getRemovedValidators = (prevValidators, validators) => {
  // let removeValidators = [];
  for (p in prevValidators) {
    for (v in validators) {
      if (prevValidators[p].address == validators[v].address) {
        prevValidators.splice(p, 1);
      }
    }
  }

  return prevValidators;
};

getValidatorFromConsensusKey = (validators, consensusKey) => {
  for (v in validators) {
    try {
      let pubkeyType = Meteor.settings.public.secp256k1 ? 'tendermint/PubKeySecp256k1' : 'tendermint/PubKeyEd25519';
      let pubkey = Meteor.call('bech32ToPubkey', consensusKey, pubkeyType);

      if (validators[v].pub_key.value == pubkey) {
        return validators[v];
      }
    } catch (e) {
      console.log("Error converting pubkey: %o\n%o", consensusKey, e);
    }
  }

  return null;
};

getValidatorProfileUrl = identity => {
  console.log("Get validator avatar.");

  if (identity.length == 16) {
    let response = HTTP.get("https://keybase.io/_/api/1.0/user/lookup.json?key_suffix=".concat(identity, "&fields=pictures"));

    if (response.statusCode == 200) {
      let them = response.data.them;
      return them && them.length && them[0].pictures && them[0].pictures.primary && them[0].pictures.primary.url;
    } else {
      console.log(JSON.stringify(response));
    }
  } else if (identity.indexOf("keybase.io/team/") > 0) {
    let teamPage = HTTP.get(identity);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    } else {
      console.log(JSON.stringify(teamPage));
    }
  }
};

getValidatorUptime = validatorSet => Promise.asyncApply(() => {
  // get validator uptime
  let url = "".concat(API, "/cosmos/slashing/v1beta1/params");
  let response = HTTP.get(url);
  let slashingParams = JSON.parse(response.content);
  Chain.upsert({
    chainId: Meteor.settings.public.chainId
  }, {
    $set: {
      "slashing": slashingParams
    }
  });

  for (let key in validatorSet) {
    // console.log("Getting uptime validator: %o", validatorSet[key]);
    try {
      // console.log("=== Signing Info ===: %o", signingInfo)
      url = "".concat(API, "/cosmos/slashing/v1beta1/signing_infos/").concat(validatorSet[key].bech32ValConsAddress);
      let response = HTTP.get(url);
      let signingInfo = JSON.parse(response.content).val_signing_info;

      if (signingInfo) {
        let valData = validatorSet[key];
        valData.tombstoned = signingInfo.tombstoned;
        valData.jailed_until = signingInfo.jailed_until;
        valData.index_offset = parseInt(signingInfo.index_offset);
        valData.start_height = parseInt(signingInfo.start_height);
        valData.uptime = (slashingParams.params.signed_blocks_window - parseInt(signingInfo.missed_blocks_counter)) / slashingParams.params.signed_blocks_window * 100;
        Validators.upsert({
          bech32ValConsAddress: validatorSet[key].bech32ValConsAddress
        }, {
          $set: valData
        });
      }
    } catch (e) {
      console.log(url);
      console.log("Getting signing info of %o: %o", validatorSet[key].bech32ValConsAddress, e);
    }
  }
});

calculateVPDist = (analyticsData, blockData) => Promise.asyncApply(() => {
  console.log("===== calculate voting power distribution =====");
  let activeValidators = Validators.find({
    status: 'BOND_STATUS_BONDED',
    jailed: false
  }, {
    sort: {
      voting_power: -1
    }
  }).fetch();
  let numTopTwenty = Math.ceil(activeValidators.length * 0.2);
  let numBottomEighty = activeValidators.length - numTopTwenty;
  let topTwentyPower = 0;
  let bottomEightyPower = 0;
  let numTopThirtyFour = 0;
  let numBottomSixtySix = 0;
  let topThirtyFourPercent = 0;
  let bottomSixtySixPercent = 0;

  for (v in activeValidators) {
    if (v < numTopTwenty) {
      topTwentyPower += activeValidators[v].voting_power;
    } else {
      bottomEightyPower += activeValidators[v].voting_power;
    }

    if (topThirtyFourPercent < 0.34) {
      topThirtyFourPercent += activeValidators[v].voting_power / analyticsData.voting_power;
      numTopThirtyFour++;
    }
  }

  bottomSixtySixPercent = 1 - topThirtyFourPercent;
  numBottomSixtySix = activeValidators.length - numTopThirtyFour;
  let vpDist = {
    height: blockData.height,
    numTopTwenty: numTopTwenty,
    topTwentyPower: topTwentyPower,
    numBottomEighty: numBottomEighty,
    bottomEightyPower: bottomEightyPower,
    numTopThirtyFour: numTopThirtyFour,
    topThirtyFourPercent: topThirtyFourPercent,
    numBottomSixtySix: numBottomSixtySix,
    bottomSixtySixPercent: bottomSixtySixPercent,
    numValidators: activeValidators.length,
    totalVotingPower: analyticsData.voting_power,
    blockTime: blockData.time,
    createAt: new Date()
  };
  console.log(vpDist);
  VPDistributions.insert(vpDist);
}); // var filtered = [1, 2, 3, 4, 5].filter(notContainedIn([1, 2, 3, 5]));
// console.log(filtered); // [4]


Meteor.methods({
  'blocks.averageBlockTime'(address) {
    this.unblock();
    let blocks = Blockscon.find({
      proposerAddress: address
    }).fetch();
    let heights = blocks.map(block => {
      return block.height;
    });
    let blocksStats = Analytics.find({
      height: {
        $in: heights
      }
    }).fetch(); // console.log(blocksStats);

    let totalBlockDiff = 0;

    for (b in blocksStats) {
      totalBlockDiff += blocksStats[b].timeDiff;
    }

    return totalBlockDiff / heights.length;
  },

  'blocks.getLatestHeight': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      return status.result.sync_info.latest_block_height;
    } catch (e) {
      return 0;
    }
  },
  'blocks.getCurrentHeight': function () {
    this.unblock();
    let currHeight = Blockscon.find({}, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch(); // console.log("currentHeight:"+currHeight);

    let startHeight = Meteor.settings.params.startHeight;

    if (currHeight && currHeight.length == 1) {
      let height = currHeight[0].height;
      if (height > startHeight) return height;
    }

    return startHeight;
  },
  'blocks.blocksUpdate': function () {
    return Promise.asyncApply(() => {
      this.unblock();
      if (SYNCING) return "Syncing...";else console.log("start to sync"); // Meteor.clearInterval(Meteor.timerHandle);
      // get the latest height

      let until = Meteor.call('blocks.getLatestHeight'); // console.log(until);
      // get the current height in db

      let curr = Meteor.call('blocks.getCurrentHeight');
      console.log(curr); // loop if there's update in db

      if (until > curr) {
        SYNCING = true;
        let validatorSet = []; // get latest validator candidate information

        let url = API + '/cosmos/staking/v1beta1/validators?status=BOND_STATUS_BONDED&pagination.limit=200&pagination.count_total=true';

        try {
          let response = HTTP.get(url);
          let result = JSON.parse(response.content).validators;
          result.forEach(validator => validatorSet[validator.consensus_pubkey.key] = validator);
        } catch (e) {
          console.log(url);
          console.log(e);
        }

        try {
          url = API + '/cosmos/staking/v1beta1/validators?status=BOND_STATUS_UNBONDING&pagination.limit=200&pagination.count_total=true';
          let response = HTTP.get(url);
          let result = JSON.parse(response.content).validators;
          result.forEach(validator => validatorSet[validator.consensus_pubkey.key] = validator);
        } catch (e) {
          console.log(url);
          console.log(e);
        }

        try {
          url = API + '/cosmos/staking/v1beta1/validators?status=BOND_STATUS_UNBONDED&pagination.limit=200&pagination.count_total=true';
          let response = HTTP.get(url);
          let result = JSON.parse(response.content).validators;
          result.forEach(validator => validatorSet[validator.consensus_pubkey.key] = validator);
        } catch (e) {
          console.log(url);
          console.log(e);
        } // console.log("validaotor set: %o", validatorSet);


        let totalValidators = Object.keys(validatorSet).length;
        console.log("all validators: " + totalValidators);
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            totalValidators: totalValidators
          }
        });

        for (let height = curr + 1; height <= until; height++) {
          // for (let height = curr+1 ; height <= curr+1 ; height++) {
          let startBlockTime = new Date(); // add timeout here? and outside this loop (for catched up and keep fetching)?

          this.unblock(); // let url = RPC+'/block?height=' + height;

          url = "".concat(API, "/blocks/").concat(height);
          let analyticsData = {};
          const bulkValidators = Validators.rawCollection().initializeUnorderedBulkOp();
          const bulkUpdateLastSeen = Validators.rawCollection().initializeUnorderedBulkOp();
          const bulkValidatorRecords = ValidatorRecords.rawCollection().initializeUnorderedBulkOp();
          const bulkVPHistory = VotingPowerHistory.rawCollection().initializeUnorderedBulkOp();
          const bulkTransactions = Transactions.rawCollection().initializeUnorderedBulkOp();
          console.log("Getting block at height: %o", height);

          try {
            let startGetHeightTime = new Date();
            let response = HTTP.get(url); // store height, hash, numtransaction and time in db

            let blockData = {};
            let block = JSON.parse(response.content);
            blockData.height = height;
            blockData.hash = block.block_id.hash;
            blockData.transNum = block.block.data.txs ? block.block.data.txs.length : 0;
            blockData.time = block.block.header.time;
            blockData.lastBlockHash = block.block.header.last_block_id.hash;
            blockData.proposerAddress = block.block.header.proposer_address;
            blockData.validators = []; // save txs in database

            if (block.block.data.txs && block.block.data.txs.length > 0) {
              for (t in block.block.data.txs) {
                bulkTransactions.insert({
                  // hash has to be in uppercase
                  txhash: sha256(Buffer.from(block.block.data.txs[t], 'base64')).toUpperCase(),
                  height: parseInt(height),
                  processed: false
                });
              }

              if (bulkTransactions.length > 0) {
                bulkTransactions.execute((err, result) => {
                  if (err) {
                    console.log(err);
                  }

                  if (result) {// console.log(result);
                  }
                });
              }
            } // save double sign evidences


            if (block.block.evidence.evidenceList) {
              Evidences.insert({
                height: height,
                evidence: block.block.evidence.evidenceList
              });
            } // console.log("signatures: %o", block.block.lastCommit.signaturesList)


            blockData.precommitsCount = block.block.last_commit.signatures.length;
            analyticsData.height = height;
            let endGetHeightTime = new Date();
            console.log("Get height time: " + (endGetHeightTime - startGetHeightTime) / 1000 + "seconds.");
            let startGetValidatorsTime = new Date(); // update chain status

            let validators = [];
            let page = 0; // let nextKey = 0;

            try {
              let result;

              do {
                let url = RPC + "/validators?height=".concat(height, "&page=").concat(++page, "&per_page=100");
                let response = HTTP.get(url);
                result = JSON.parse(response.content).result; // console.log("========= validator result ==========: %o", result)

                validators = [...validators, ...result.validators]; // console.log(validators.length);
                // console.log(parseInt(result.total));
              } while (validators.length < parseInt(result.total));
            } catch (e) {
              console.log("Getting validator set at height %o: %o", height, e);
            } // console.log(validators)


            ValidatorSets.insert({
              block_height: height,
              validators: validators
            });
            blockData.validatorsCount = validators.length; // temporarily add bech32 concensus keys to the validator set list

            let tempValidators = [];

            for (let v in validators) {
              // validators[v].consensus_pubkey = Meteor.call('pubkeyToBech32Old', validators[v].pub_key, Meteor.settings.public.bech32PrefixConsPub);
              // validators[v].valconsAddress = validators[v].address;
              validators[v].valconsAddress = Meteor.call('hexToBech32', validators[v].address, Meteor.settings.public.bech32PrefixConsAddr); // validators[v].address = Meteor.call('getAddressFromPubkey', validators[v].pubKey);
              // tempValidators[validators[v].pubKey.value] = validators[v];

              tempValidators[validators[v].address] = validators[v];
            }

            validators = tempValidators; // console.log("before comparing precommits: %o", validators);
            // Tendermint v0.33 start using "signatures" in last block instead of "precommits"

            let precommits = block.block.last_commit.signatures;

            if (precommits != null) {
              // console.log(precommits);
              for (let i = 0; i < precommits.length; i++) {
                if (precommits[i] != null) {
                  blockData.validators.push(precommits[i].validator_address);
                }
              }

              analyticsData.precommits = precommits.length; // record for analytics
              // PrecommitRecords.insert({height:height, precommits:precommits.length});
            }

            if (height > 1) {
              // record precommits and calculate uptime
              // only record from block 2
              console.log("Inserting precommits");

              for (i in validators) {
                let address = validators[i].address;
                let record = {
                  height: height,
                  address: address,
                  exists: false,
                  voting_power: parseInt(validators[i].voting_power)
                };

                for (j in precommits) {
                  if (precommits[j] != null) {
                    let precommitAddress = precommits[j].validator_address;

                    if (address == precommitAddress) {
                      record.exists = true;
                      bulkUpdateLastSeen.find({
                        address: precommitAddress
                      }).upsert().updateOne({
                        $set: {
                          lastSeen: blockData.time
                        }
                      });
                      precommits.splice(j, 1);
                      break;
                    }
                  }
                }

                bulkValidatorRecords.insert(record); // ValidatorRecords.update({height:height,address:record.address},record);
              }
            }

            let startBlockInsertTime = new Date();
            Blockscon.insert(blockData);
            let endBlockInsertTime = new Date();
            console.log("Block insert time: " + (endBlockInsertTime - startBlockInsertTime) / 1000 + "seconds.");
            let chainStatus = Chain.findOne({
              chainId: block.block.header.chain_id
            });
            let lastSyncedTime = chainStatus ? chainStatus.lastSyncedTime : 0;
            let timeDiff;
            let blockTime = Meteor.settings.params.defaultBlockTime;

            if (lastSyncedTime) {
              let dateLatest = new Date(blockData.time);
              let dateLast = new Date(lastSyncedTime);
              let genesisTime = new Date(Meteor.settings.public.genesisTime);
              timeDiff = Math.abs(dateLatest.getTime() - dateLast.getTime()); // blockTime = (chainStatus.blockTime * (blockData.height - 1) + timeDiff) / blockData.height;

              blockTime = (dateLatest.getTime() - genesisTime.getTime()) / blockData.height;
            }

            let endGetValidatorsTime = new Date();
            console.log("Get height validators time: " + (endGetValidatorsTime - startGetValidatorsTime) / 1000 + "seconds.");
            Chain.update({
              chainId: block.block.header.chainId
            }, {
              $set: {
                lastSyncedTime: blockData.time,
                blockTime: blockTime
              }
            });
            analyticsData.averageBlockTime = blockTime;
            analyticsData.timeDiff = timeDiff;
            analyticsData.time = blockData.time; // initialize validator data at first block
            // if (height == 1){
            //     Validators.remove({});
            // }

            analyticsData.voting_power = 0;
            let startFindValidatorsNameTime = new Date();

            for (v in validatorSet) {
              let valData = validatorSet[v];
              valData.tokens = parseInt(valData.tokens);
              valData.unbonding_height = parseInt(valData.unbonding_height);
              let valExist = Validators.findOne({
                "consensus_pubkey.key": v
              }); // console.log(valData);
              // console.log("===== voting power ======: %o", valData)

              analyticsData.voting_power += valData.voting_power; // console.log(analyticsData.voting_power);

              if (!valExist && valData.consensus_pubkey) {
                // let val = getValidatorFromConsensusKey(validators, v);
                // get the validator hex address and other bech32 addresses.
                valData.delegator_address = Meteor.call('getDelegator', valData.operator_address); // console.log("get hex address")
                // valData.address = getAddress(valData.consensusPubkey);

                console.log("get bech32 consensus pubkey");
                valData.bech32ConsensusPubKey = Meteor.call('pubkeyToBech32', valData.consensus_pubkey, Meteor.settings.public.bech32PrefixConsPub);
                valData.address = Meteor.call('getAddressFromPubkey', valData.consensus_pubkey);
                valData.bech32ValConsAddress = Meteor.call('hexToBech32', valData.address, Meteor.settings.public.bech32PrefixConsAddr); // assign back to the validator set so that we can use it to find the uptime

                if (validatorSet[v]) validatorSet[v].bech32ValConsAddress = valData.bech32ValConsAddress; // First time adding validator to the database.
                // Fetch profile picture from Keybase

                if (valData.description && valData.description.identity) {
                  try {
                    valData.profile_url = getValidatorProfileUrl(valData.description.identity);
                  } catch (e) {
                    console.log("Error fetching keybase: %o", e);
                  }
                }

                valData.accpub = Meteor.call('pubkeyToBech32', valData.consensus_pubkey, Meteor.settings.public.bech32PrefixAccPub);
                valData.operator_pubkey = Meteor.call('pubkeyToBech32', valData.consensus_pubkey, Meteor.settings.public.bech32PrefixValPub); // insert first power change history 
                // valData.voting_power = validators[valData.consensusPubkey.value]?parseInt(validators[valData.consensusPubkey.value].votingPower):0;

                valData.voting_power = validators[valData.address] ? parseInt(validators[valData.address].voting_power) : 0;
                valData.proposer_priority = validators[valData.address] ? parseInt(validators[valData.address].proposer_priority) : 0;
                console.log("Validator not found. Insert first VP change record."); // console.log("first voting power: %o", valData.voting_power);

                bulkVPHistory.insert({
                  address: valData.address,
                  prev_voting_power: 0,
                  voting_power: valData.voting_power,
                  type: 'add',
                  height: blockData.height,
                  block_time: blockData.time
                }); // }
              } else {
                // console.log(valData);
                valData.address = valExist.address; // assign to valData for getting self delegation

                valData.delegator_address = valExist.delegator_address;
                valData.bech32ValConsAddress = valExist.bech32ValConsAddress;

                if (validatorSet[v]) {
                  validatorSet[v].bech32ValConsAddress = valExist.bech32ValConsAddress;
                } // console.log(valExist);
                // console.log(validators[valExist.address])
                // if (validators[valData.consensusPubkey.value]){


                if (validators[valExist.address]) {
                  // Validator exists and is in validator set, update voitng power.
                  // If voting power is different from before, add voting power history
                  valData.voting_power = parseInt(validators[valExist.address].voting_power);
                  valData.proposer_priority = parseInt(validators[valExist.address].proposer_priority);
                  let prevVotingPower = VotingPowerHistory.findOne({
                    address: valExist.address
                  }, {
                    height: -1,
                    limit: 1
                  });
                  console.log("Validator already in DB. Check if VP changed.");

                  if (prevVotingPower) {
                    if (prevVotingPower.voting_power != valData.voting_power) {
                      let changeType = prevVotingPower.voting_power > valData.voting_power ? 'down' : 'up';
                      let changeData = {
                        address: valExist.address,
                        prev_voting_power: prevVotingPower.voting_power,
                        voting_power: valData.voting_power,
                        type: changeType,
                        height: blockData.height,
                        block_time: blockData.time
                      };
                      bulkVPHistory.insert(changeData);
                    }
                  }
                } else {
                  // Validator is not in the set and it has been removed.
                  // Set voting power to zero and add voting power history.
                  valData.address = valExist.address;
                  valData.voting_power = 0;
                  valData.proposer_priority = 0;
                  let prevVotingPower = VotingPowerHistory.findOne({
                    address: valExist.address
                  }, {
                    height: -1,
                    limit: 1
                  });

                  if (prevVotingPower && prevVotingPower.voting_power > 0) {
                    console.log("Validator is in DB but not in validator set now. Add remove VP change.");
                    bulkVPHistory.insert({
                      address: valExist.address,
                      prev_voting_power: prevVotingPower,
                      voting_power: 0,
                      type: 'remove',
                      height: blockData.height,
                      block_time: blockData.time
                    });
                  }
                }
              } // only update validator infor during start of crawling, end of crawling or every validator update window


              if (height == curr + 1 || height == Meteor.settings.params.startHeight + 1 || height == until || height % Meteor.settings.params.validatorUpdateWindow == 0) {
                if (height == Meteor.settings.params.startHeight + 1 || height % Meteor.settings.params.validatorUpdateWindow == 0) {
                  if (valData.status == 'BOND_STATUS_BONDED') {
                    url = "".concat(API, "/cosmos/staking/v1beta1/validators/").concat(valData.operator_address, "/delegations/").concat(valData.delegator_address);

                    try {
                      console.log("Getting self delegation");
                      let response = HTTP.get(url);
                      let selfDelegation = JSON.parse(response.content).delegation_response;
                      valData.self_delegation = selfDelegation.delegation && selfDelegation.delegation.shares ? parseFloat(selfDelegation.delegation.shares) / parseFloat(valData.delegator_shares) : 0;
                    } catch (e) {
                      console.log(url);
                      console.log("Getting self delegation: %o", e);
                      valData.self_delegation = 0;
                    }
                  }
                }

                console.log("Add validator upsert to bulk operations.");
                bulkValidators.find({
                  "address": valData.address
                }).upsert().updateOne({
                  $set: valData
                });
              }
            } // store valdiators exist records
            // let existingValidators = Validators.find({address:{$exists:true}}).fetch();
            // update uptime by the end of the crawl or update window


            if (height % Meteor.settings.params.validatorUpdateWindow == 0 || height == until) {
              console.log("Update validator uptime.");
              getValidatorUptime(validatorSet);
            } // fetching keybase every base on keybaseFetchingInterval settings
            // default to every 5 hours 


            if (height == curr + 1) {
              // check the last fetching time
              let now = Date.now();
              let lastKeybaseFetchTime = Date.parse(chainStatus.lastKeybaseFetchTime) || 0;
              console.log("Now: %o", now);
              console.log("Last fetch time: %o", lastKeybaseFetchTime);

              if (!lastKeybaseFetchTime || now - lastKeybaseFetchTime > Meteor.settings.params.keybaseFetchingInterval) {
                console.log('Fetching keybase...'); // eslint-disable-next-line no-loop-func

                Validators.find({}).forEach(validator => Promise.asyncApply(() => {
                  try {
                    if (validator.description && validator.description.identity) {
                      let profileUrl = getValidatorProfileUrl(validator.description.identity);

                      if (profileUrl) {
                        bulkValidators.find({
                          address: validator.address
                        }).upsert().updateOne({
                          $set: {
                            'profile_url': profileUrl
                          }
                        });
                      }
                    }
                  } catch (e) {
                    console.log("Error fetching Keybase for %o: %o", validator.address, e);
                  }
                }));
                Chain.update({
                  chainId: block.block.header.chainId
                }, {
                  $set: {
                    lastKeybaseFetchTime: new Date().toUTCString()
                  }
                });
              }
            }

            let endFindValidatorsNameTime = new Date();
            console.log("Get validators name time: " + (endFindValidatorsNameTime - startFindValidatorsNameTime) / 1000 + "seconds."); // record for analytics

            let startAnayticsInsertTime = new Date();
            Analytics.insert(analyticsData);
            let endAnalyticsInsertTime = new Date();
            console.log("Analytics insert time: " + (endAnalyticsInsertTime - startAnayticsInsertTime) / 1000 + "seconds."); // calculate voting power distribution every 60 blocks ~ 5mins

            if (height % 60 == 1) {
              calculateVPDist(analyticsData, blockData);
            }

            let startVUpTime = new Date();

            if (bulkValidators.length > 0) {
              console.log("############ Update validators ############");
              bulkValidators.execute((err, result) => {
                if (err) {
                  console.log("Error while bulk insert validators: %o", err);
                }

                if (result) {
                  bulkUpdateLastSeen.execute((err, result) => {
                    if (err) {
                      console.log("Error while bulk update validator last seen: %o", err);
                    }

                    if (result) {}
                  });
                }
              });
            }

            let endVUpTime = new Date();
            console.log("Validator update time: " + (endVUpTime - startVUpTime) / 1000 + "seconds.");
            let startVRTime = new Date();

            if (bulkValidatorRecords.length > 0) {
              bulkValidatorRecords.execute(err => {
                if (err) {
                  console.log(err);
                }
              });
            }

            let endVRTime = new Date();
            console.log("Validator records update time: " + (endVRTime - startVRTime) / 1000 + "seconds.");

            if (bulkVPHistory.length > 0) {
              bulkVPHistory.execute(err => {
                if (err) {
                  console.log(err);
                }
              });
            } // }

          } catch (e) {
            console.log("Block syncing stopped: %o", e);
            SYNCING = false;
            return "Stopped";
          }

          let endBlockTime = new Date();
          console.log("This block used: " + (endBlockTime - startBlockTime) / 1000 + "seconds.");
        }

        SYNCING = false;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastBlocksSyncedTime: new Date()
          }
        });
      }

      return until;
    });
  },
  'addLimit': function (limit) {
    // console.log(limit+10)
    return limit + 10;
  },
  'hasMore': function (limit) {
    if (limit > Meteor.call('getCurrentHeight')) {
      return false;
    } else {
      return true;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Blockscon;
module.link("../blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 3);
publishComposite('blocks.height', function (limit) {
  return {
    find() {
      return Blockscon.find({}, {
        limit: limit,
        sort: {
          height: -1
        }
      });
    },

    children: [{
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
publishComposite('blocks.findOne', function (height) {
  return {
    find() {
      return Blockscon.find({
        height: height
      });
    },

    children: [{
      find(block) {
        return Transactions.find({
          height: block.height
        });
      }

    }, {
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"blocks.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/blocks.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Blockscon: () => Blockscon
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Blockscon = new Mongo.Collection('blocks');
Blockscon.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

}); // Blockscon.helpers({
//     sorted(limit) {
//         return Blockscon.find({}, {sort: {height:-1}, limit: limit});
//     }
// });
// Meteor.setInterval(function() {
//     Meteor.call('blocksUpdate', (error, result) => {
//         console.log(result);
//     })
// }, 30000000);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/methods.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 2);
let Coin;
module.link("../../../../both/utils/coins.js", {
  default(v) {
    Coin = v;
  }

}, 3);

findVotingPower = (validator, genValidators) => {
  for (let v in genValidators) {
    if (validator.pub_key.value == genValidators[v].pub_key.value) {
      return parseInt(genValidators[v].power);
    }
  }
};

Meteor.methods({
  'chain.getConsensusState': function () {
    this.unblock();
    let url = RPC + '/dump_consensus_state';

    try {
      let response = HTTP.get(url);
      let consensus = JSON.parse(response.content);
      consensus = consensus.result;
      let height = consensus.round_state.height;
      let round = consensus.round_state.round;
      let step = consensus.round_state.step;
      let votedPower = Math.round(parseFloat(consensus.round_state.votes[round].prevotes_bit_array.split(" ")[3]) * 100);
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          votingHeight: height,
          votingRound: round,
          votingStep: step,
          votedPower: votedPower,
          proposerAddress: consensus.round_state.validators.proposer.address,
          prevotes: consensus.round_state.votes[round].prevotes,
          precommits: consensus.round_state.votes[round].precommits
        }
      });
    } catch (e) {
      console.log(url);
      console.log(e);
    }
  },
  'chain.updateStatus': function () {
    return Promise.asyncApply(() => {
      this.unblock();
      let url = "";

      try {
        url = API + '/blocks/latest';
        let response = HTTP.get(url);
        let latestBlock = JSON.parse(response.content);
        let chain = {};
        chain.chainId = latestBlock.block.header.chain_id;
        chain.latestBlockHeight = parseInt(latestBlock.block.header.height);
        chain.latestBlockTime = latestBlock.block.header.time;
        let latestState = ChainStates.findOne({}, {
          sort: {
            height: -1
          }
        });

        if (latestState && latestState.height >= chain.latestBlockHeight) {
          return "no updates (getting block ".concat(chain.latestBlockHeight, " at block ").concat(latestState.height, ")");
        } // Since Tendermint v0.33, validator page default set to return 30 validators.
        // Query latest height with page 1 and 100 validators per page.
        // validators = validators.validatorsList;
        // chain.validators = validators.length;


        let validators = [];
        let page = 0;

        do {
          url = RPC + "/validators?page=".concat(++page, "&per_page=100");
          let response = HTTP.get(url);
          result = JSON.parse(response.content).result;
          validators = [...validators, ...result.validators];
        } while (validators.length < parseInt(result.total));

        chain.validators = validators.length;
        let activeVP = 0;

        for (v in validators) {
          activeVP += parseInt(validators[v].voting_power);
        }

        chain.activeVotingPower = activeVP; // update staking params

        try {
          url = API + '/cosmos/staking/v1beta1/params';
          response = HTTP.get(url);
          chain.staking = JSON.parse(response.content);
        } catch (e) {
          console.log(e);
        } // Get chain states


        if (parseInt(chain.latestBlockHeight) > 0) {
          let chainStates = {};
          chainStates.height = parseInt(chain.latestBlockHeight);
          chainStates.time = new Date(chain.latestBlockTime);

          try {
            url = API + '/cosmos/staking/v1beta1/pool';
            let response = HTTP.get(url);
            let bonding = JSON.parse(response.content).pool;
            chainStates.bondedTokens = parseInt(bonding.bonded_tokens);
            chainStates.notBondedTokens = parseInt(bonding.not_bonded_tokens);
          } catch (e) {
            console.log(e);
          }

          if (Coin.StakingCoin.denom) {
            if (Meteor.settings.public.modules.bank) {
              try {
                url = API + '/cosmos/bank/v1beta1/supply/' + Coin.StakingCoin.denom;
                let response = HTTP.get(url);
                let supply = JSON.parse(response.content);
                chainStates.totalSupply = parseInt(supply.amount.amount);
              } catch (e) {
                console.log(e);
              } // update bank params


              try {
                url = API + '/cosmos/bank/v1beta1/params';
                response = HTTP.get(url);
                chain.bank = JSON.parse(response.content);
              } catch (e) {
                console.log(e);
              }
            }

            if (Meteor.settings.public.modules.distribution) {
              try {
                url = API + '/cosmos/distribution/v1beta1/community_pool';
                let response = HTTP.get(url);
                let pool = JSON.parse(response.content).pool;

                if (pool && pool.length > 0) {
                  chainStates.communityPool = [];
                  pool.forEach(amount => {
                    chainStates.communityPool.push({
                      denom: amount.denom,
                      amount: parseFloat(amount.amount)
                    });
                  });
                }
              } catch (e) {
                console.log(e);
              } // update distribution params


              try {
                url = API + '/cosmos/distribution/v1beta1/params';
                response = HTTP.get(url);
                chain.distribution = JSON.parse(response.content);
              } catch (e) {
                console.log(e);
              }
            }

            if (Meteor.settings.public.modules.minting) {
              try {
                url = API + '/cosmos/mint/v1beta1/inflation';
                let response = HTTP.get(url);
                let inflation = JSON.parse(response.content).inflation; // response = HTTP.get(url);
                // let inflation = JSON.parse(response.content).result;

                if (inflation) {
                  chainStates.inflation = parseFloat(inflation);
                }
              } catch (e) {
                console.log(e);
              }

              try {
                url = API + '/cosmos/mint/v1beta1/annual_provisions';
                let response = HTTP.get(url);
                let provisions = JSON.parse(response.content).annual_provisions;
                console.log(provisions);

                if (provisions) {
                  chainStates.annualProvisions = parseFloat(provisions);
                }
              } catch (e) {
                console.log(e);
              } // update mint params


              try {
                url = API + '/cosmos/mint/v1beta1/params';
                response = HTTP.get(url);
                chain.mint = JSON.parse(response.content);
              } catch (e) {
                console.log(e);
              }
            }

            if (Meteor.settings.public.modules.gov) {
              // update mint params
              try {
                url = API + '/cosmos/gov/v1beta1/params';
                response = HTTP.get(url);
                chain.gov = JSON.parse(response.content);
              } catch (e) {
                console.log(e);
              }
            }
          }

          ChainStates.insert(chainStates);
        }

        Chain.update({
          chainId: chain.chainId
        }, {
          $set: chain
        }, {
          upsert: true
        }); // chain.totalVotingPower = totalVP;
        // validators = Validators.find({}).fetch();
        // console.log(validators);

        return chain.latestBlockHeight;
      } catch (e) {
        console.log(url);
        console.log(e);
        return "Error getting chain status.";
      }
    });
  },
  'chain.getLatestStatus': function () {
    this.unblock();
    Chain.find().sort({
      created: -1
    }).limit(1);
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 1);
let CoinStats;
module.link("../../coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
Meteor.publish('chainStates.latest', function () {
  return [ChainStates.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  }), CoinStats.find({}, {
    sort: {
      last_updated_at: -1
    },
    limit: 1
  })];
});
publishComposite('chain.status', function () {
  return {
    find() {
      return Chain.find({
        chainId: Meteor.settings.public.chainId
      });
    },

    children: [{
      find(chain) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operatorAddress: 1,
            status: -1,
            jailed: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/chain.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Chain: () => Chain,
  ChainStates: () => ChainStates
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Chain = new Mongo.Collection('chain');
const ChainStates = new Mongo.Collection('chain_states');
Chain.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let CoinStats;
module.link("../coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 1);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 2);
Meteor.methods({
  'coinStats.getCoinStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      try {
        let now = new Date();
        now.setMinutes(0);
        let url = "https://api.coingecko.com/api/v3/simple/price?ids=" + coinId + "&vs_currencies=usd&include_market_cap=true&include_24hr_vol=true&include_24hr_change=true&include_last_updated_at=true";
        let response = HTTP.get(url);

        if (response.statusCode == 200) {
          // console.log(JSON.parse(response.content));
          let data = JSON.parse(response.content);
          data = data[coinId]; // console.log(coinStats);

          return CoinStats.upsert({
            last_updated_at: data.last_updated_at
          }, {
            $set: data
          });
        }
      } catch (e) {
        console.log(url);
        console.log(e);
      }
    } else {
      return "No coingecko Id provided.";
    }
  },
  'coinStats.getStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      return CoinStats.findOne({}, {
        sort: {
          last_updated_at: -1
        }
      });
    } else {
      return "No coingecko Id provided.";
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/coin-stats.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  CoinStats: () => CoinStats
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const CoinStats = new Mongo.Collection('coin_stats');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/methods.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Delegations;
module.link("../delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.methods({
  'delegations.getDelegations': function () {
    return Promise.asyncApply(() => {
      this.unblock();
      let validators = Validators.find({}).fetch();
      let delegations = [];
      console.log("=== Getting delegations ===");

      for (v in validators) {
        if (validators[v].operator_address) {
          let url = API + '/cosmos/staking/v1beta1/validators/' + validators[v].operatorAddress + "/delegations";

          try {
            let response = HTTP.get(url);

            if (response.statusCode == 200) {
              let delegation = JSON.parse(response.content).result; // console.log(delegation);

              delegations = delegations.concat(delegation);
            } else {
              console.log(response.statusCode);
            }
          } catch (e) {
            // console.log(url);
            console.log(e);
          }
        }
      }

      let data = {
        delegations: delegations,
        createdAt: new Date()
      };
      return Delegations.insert(data);
    });
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/publications.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/delegations.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Delegations: () => Delegations
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Delegations = new Mongo.Collection('delegations');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"ledger":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/ledger/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
let Validators;
module.link("../../validators/validators", {
  Validators(v) {
    Validators = v;
  }

}, 1);
Meteor.methods({
  'transaction.submit': function (txInfo) {
    this.unblock();
    const url = "".concat(API, "/txs");
    data = {
      "tx": txInfo.value,
      "mode": "sync"
    };
    const timestamp = new Date().getTime();
    console.log("submitting transaction".concat(timestamp, " ").concat(url, " with data ").concat(JSON.stringify(data)));
    let response = HTTP.post(url, {
      data
    });
    console.log("response for transaction".concat(timestamp, " ").concat(url, ": ").concat(JSON.stringify(response)));

    if (response.statusCode == 200) {
      let data = response.data;
      if (data.code) throw new Meteor.Error(data.code, JSON.parse(data.raw_log).message);
      return response.data.txhash;
    }
  },
  'transaction.execute': function (body, path) {
    this.unblock();
    const url = "".concat(API, "/").concat(path);
    data = {
      "base_req": _objectSpread(_objectSpread({}, body), {}, {
        "chain_id": Meteor.settings.public.chainId,
        "simulate": false
      })
    };
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content);
    }
  },
  'transaction.simulate': function (txMsg, from, accountNumber, sequence, path) {
    let adjustment = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : '1.2';
    this.unblock();
    const url = "".concat(API, "/").concat(path);
    console.log(txMsg);
    data = _objectSpread(_objectSpread({}, txMsg), {}, {
      "base_req": {
        "from": from,
        "chain_id": Meteor.settings.public.chainId,
        "gas_adjustment": adjustment,
        "account_number": accountNumber,
        "sequence": sequence,
        "simulate": true
      }
    });
    console.log(url);
    console.log(data);
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content).gas_estimate;
    }
  },
  'isValidator': function (address) {
    this.unblock();
    let validator = Validators.findOne({
      delegator_address: address
    });
    return validator;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"proposals":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/server/methods.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Proposals;
module.link("../proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 2);
let Chain;
module.link("../../chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 3);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 4);
Meteor.methods({
  'proposals.getProposals': function () {
    this.unblock(); // get gov tally prarams

    let url = API + '/cosmos/gov/v1beta1/params/tallying';

    try {
      let response = HTTP.get(url);
      let params = JSON.parse(response.content);
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          "gov.tallyParams": params.tally_params
        }
      });
      url = API + '/cosmos/gov/v1beta1/proposals';
      response = HTTP.get(url);
      let proposals = JSON.parse(response.content).proposals; // console.log(proposals);

      let finishedProposalIds = new Set(Proposals.find({
        "proposal_status": {
          $in: ["PROPOSAL_STATUS_PASSED", "PROPOSAL_STATUS_REJECTED", "PROPOSAL_STATUS_REMOVED"]
        }
      }).fetch().map(p => p.proposalId));
      let proposalIds = [];

      if (proposals.length > 0) {
        // Proposals.upsert()
        const bulkProposals = Proposals.rawCollection().initializeUnorderedBulkOp();

        for (let i in proposals) {
          let proposal = proposals[i];
          proposal.proposalId = parseInt(proposal.proposal_id);
          proposalIds.push(proposal.proposalId);

          if (proposal.proposalId > 0 && !finishedProposalIds.has(proposal.proposalId)) {
            try {
              // url = API + '/cosmos/gov/v1beta1/proposals/'+proposal.proposalId+'/proposer';
              // let response = HTTP.get(url);
              // if (response.statusCode == 200){
              //     let proposer = JSON.parse(response.content).result;
              //     if (proposer.proposal_id && (proposer.proposal_id == proposal.id)){
              //         proposal.proposer = proposer.proposer;
              //     }
              // }
              bulkProposals.find({
                proposalId: proposal.proposalId
              }).upsert().updateOne({
                $set: proposal
              });
            } catch (e) {
              bulkProposals.find({
                proposalId: proposal.proposalId
              }).upsert().updateOne({
                $set: proposal
              }); // proposalIds.push(proposal.proposalId);

              console.log(url);
              console.log(e.response.content);
            }
          }
        }

        bulkProposals.find({
          proposalId: {
            $nin: proposalIds
          },
          status: {
            $nin: ["PROPOSAL_STATUS_VOTING_PERIOD", "PROPOSAL_STATUS_PASSED", "PROPOSAL_STATUS_REJECTED", "PROPOSAL_STATUS_REMOVED"]
          }
        }).update({
          $set: {
            "status": "PROPOSAL_STATUS_REMOVED"
          }
        });
        bulkProposals.execute();
      }

      return true;
    } catch (e) {
      console.log(url);
      console.log(e);
    }
  },
  'proposals.getProposalResults': function () {
    this.unblock();
    let proposals = Proposals.find({
      "status": {
        $nin: ["PROPOSAL_STATUS_PASSED", "PROPOSAL_STATUS_REJECTED", "PROPOSAL_STATUS_REMOVED"]
      }
    }).fetch();

    if (proposals && proposals.length > 0) {
      for (let i in proposals) {
        if (parseInt(proposals[i].proposalId) > 0) {
          let url = "";

          try {
            // get proposal deposits
            url = API + '/cosmos/gov/v1beta1/proposals/' + proposals[i].proposalId + '/deposits?pagination.limit=2000&pagination.count_total=true';
            let response = HTTP.get(url);
            let proposal = {
              proposalId: proposals[i].proposalId
            };

            if (response.statusCode == 200) {
              let deposits = JSON.parse(response.content).deposits;
              proposal.deposits = deposits;
            }

            url = API + '/cosmos/gov/v1beta1/proposals/' + proposals[i].proposalId + '/votes?pagination.limit=2000&pagination.count_total=true';
            response = HTTP.get(url);

            if (response.statusCode == 200) {
              let votes = JSON.parse(response.content).votes;
              proposal.votes = getVoteDetail(votes);
            }

            url = API + '/cosmos/gov/v1beta1/proposals/' + proposals[i].proposalId + '/tally';
            response = HTTP.get(url);

            if (response.statusCode == 200) {
              let tally = JSON.parse(response.content).tally;
              proposal.tally = tally;
            }

            proposal.updatedAt = new Date();
            Proposals.update({
              proposalId: proposals[i].proposalId
            }, {
              $set: proposal
            });
          } catch (e) {
            console.log(url);
            console.log(e);
          }
        }
      }
    }

    return true;
  }
});

const getVoteDetail = votes => {
  if (!votes) {
    return [];
  }

  let voters = votes.map(vote => vote.voter);
  let votingPowerMap = {};
  let validatorAddressMap = {};
  Validators.find({
    delegator_address: {
      $in: voters
    }
  }).forEach(validator => {
    votingPowerMap[validator.delegator_address] = {
      moniker: validator.description.moniker,
      address: validator.address,
      tokens: parseFloat(validator.tokens),
      delegatorShares: parseFloat(validator.delegator_shares),
      deductedShares: parseFloat(validator.delegator_shares)
    };
    validatorAddressMap[validator.operator_address] = validator.delegator_address;
  });
  voters.forEach(voter => {
    if (!votingPowerMap[voter]) {
      // voter is not a validator
      let url = "".concat(API, "/cosmos/staking/v1beta1/delegations/").concat(voter);
      let delegations;
      let votingPower = 0;

      try {
        let response = HTTP.get(url);

        if (response.statusCode == 200) {
          delegations = JSON.parse(response.content).delegations_response;

          if (delegations && delegations.length > 0) {
            delegations.forEach(delegation => {
              let shares = parseFloat(delegation.delegation.shares);

              if (validatorAddressMap[delegation.delegation.validator_address]) {
                // deduct delegated shareds from validator if a delegator votes
                let validator = votingPowerMap[validatorAddressMap[delegation.validator_address]];
                validator.deductedShares -= shares;

                if (validator.delegatorShares != 0) {
                  // avoiding division by zero
                  votingPower += shares / validator.delegatorShares * validator.tokens;
                }
              } else {
                let validator = Validators.findOne({
                  operatorAddress: delegation.validator_address
                });

                if (validator && validator.delegatorShares != 0) {
                  // avoiding division by zero
                  votingPower += shares / parseFloat(validator.delegatorShares) * parseFloat(validator.tokens);
                }
              }
            });
          }
        }
      } catch (e) {
        console.log(url);
        console.log(e.response.content);
      }

      votingPowerMap[voter] = {
        votingPower: votingPower
      };
    }
  });
  return votes.map(vote => {
    let voter = votingPowerMap[vote.voter];
    let votingPower = voter.votingPower;

    if (votingPower == undefined) {
      // voter is a validator
      votingPower = voter.delegatorShares ? voter.deductedShares / voter.delegatorShares * voter.tokens : 0;
    }

    return _objectSpread(_objectSpread({}, vote), {}, {
      votingPower
    });
  });
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/server/publications.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Proposals;
module.link("../proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('proposals.list', function () {
  return Proposals.find({}, {
    sort: {
      proposalId: -1
    }
  });
});
Meteor.publish('proposals.one', function (id) {
  check(id, Number);
  return Proposals.find({
    proposalId: id
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"proposals.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/proposals.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Proposals: () => Proposals
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Proposals = new Mongo.Collection('proposals');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"records":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/methods.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let ValidatorRecords, Analytics, AverageData, AverageValidatorData;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Status;
module.link("../../status/status.js", {
  Status(v) {
    Status = v;
  }

}, 5);
let MissedBlocksStats;
module.link("../records.js", {
  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  }

}, 6);
let MissedBlocks;
module.link("../records.js", {
  MissedBlocks(v) {
    MissedBlocks = v;
  }

}, 7);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 8);
let Chain;
module.link("../../chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 9);

let _;

module.link("lodash", {
  default(v) {
    _ = v;
  }

}, 10);
const BULKUPDATEMAXSIZE = 1000;

const getBlockStats = (startHeight, latestHeight) => {
  let blockStats = {};
  const cond = {
    $and: [{
      height: {
        $gt: startHeight
      }
    }, {
      height: {
        $lte: latestHeight
      }
    }]
  };
  const options = {
    sort: {
      height: 1
    }
  };
  Blockscon.find(cond, options).forEach(block => {
    blockStats[block.height] = {
      height: block.height,
      proposerAddress: block.proposerAddress,
      precommitsCount: block.precommitsCount,
      validatorsCount: block.validatorsCount,
      validators: block.validators,
      time: block.time
    };
  });
  Analytics.find(cond, options).forEach(block => {
    if (!blockStats[block.height]) {
      blockStats[block.height] = {
        height: block.height
      };
      console.log("block ".concat(block.height, " does not have an entry"));
    }

    _.assign(blockStats[block.height], {
      precommits: block.precommits,
      averageBlockTime: block.averageBlockTime,
      timeDiff: block.timeDiff,
      voting_power: block.voting_power
    });
  });
  return blockStats;
};

const getPreviousRecord = (voterAddress, proposerAddress) => {
  let previousRecord = MissedBlocks.findOne({
    voter: voterAddress,
    proposer: proposerAddress,
    blockHeight: -1
  });
  let lastUpdatedHeight = Meteor.settings.params.startHeight;
  let prevStats = {};

  if (previousRecord) {
    prevStats = _.pick(previousRecord, ['missCount', 'totalCount']);
  } else {
    prevStats = {
      missCount: 0,
      totalCount: 0
    };
  }

  return prevStats;
};

Meteor.methods({
  'ValidatorRecords.calculateMissedBlocks': function () {
    this.unblock();

    if (!COUNTMISSEDBLOCKS) {
      try {
        let startTime = Date.now();
        COUNTMISSEDBLOCKS = true;
        console.log('calulate missed blocks count');
        this.unblock();
        let validators = Validators.find({}).fetch();
        let latestHeight = Meteor.call('blocks.getCurrentHeight');
        let explorerStatus = Status.findOne({
          chainId: Meteor.settings.public.chainId
        });
        let startHeight = explorerStatus && explorerStatus.lastProcessedMissedBlockHeight ? explorerStatus.lastProcessedMissedBlockHeight : Meteor.settings.params.startHeight;
        latestHeight = Math.min(startHeight + BULKUPDATEMAXSIZE, latestHeight);
        const bulkMissedStats = MissedBlocks.rawCollection().initializeOrderedBulkOp();
        let validatorsMap = {};
        validators.forEach(validator => validatorsMap[validator.address] = validator); // a map of block height to block stats

        let blockStats = getBlockStats(startHeight, latestHeight); // proposerVoterStats is a proposer-voter map counting numbers of proposed blocks of which voter is an active validator

        let proposerVoterStats = {};

        _.forEach(blockStats, (block, blockHeight) => {
          let proposerAddress = block.proposerAddress;
          let votedValidators = new Set(block.validators);
          let validatorSets = ValidatorSets.findOne({
            block_height: block.height
          });
          let votedVotingPower = 0;
          validatorSets.validators.forEach(activeValidator => {
            if (votedValidators.has(activeValidator.address)) votedVotingPower += parseFloat(activeValidator.voting_power);
          });
          validatorSets.validators.forEach(activeValidator => {
            let currentValidator = activeValidator.address;

            if (!_.has(proposerVoterStats, [proposerAddress, currentValidator])) {
              let prevStats = getPreviousRecord(currentValidator, proposerAddress);

              _.set(proposerVoterStats, [proposerAddress, currentValidator], prevStats);
            }

            _.update(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'], n => n + 1);

            if (!votedValidators.has(currentValidator)) {
              _.update(proposerVoterStats, [proposerAddress, currentValidator, 'missCount'], n => n + 1);

              bulkMissedStats.insert({
                voter: currentValidator,
                blockHeight: block.height,
                proposer: proposerAddress,
                precommitsCount: block.precommitsCount,
                validatorsCount: block.validatorsCount,
                time: block.time,
                precommits: block.precommits,
                averageBlockTime: block.averageBlockTime,
                timeDiff: block.timeDiff,
                votingPower: block.voting_power,
                votedVotingPower,
                updatedAt: latestHeight,
                missCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'missCount']),
                totalCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'])
              });
            }
          });
        });

        _.forEach(proposerVoterStats, (voters, proposerAddress) => {
          _.forEach(voters, (stats, voterAddress) => {
            bulkMissedStats.find({
              voter: voterAddress,
              proposer: proposerAddress,
              blockHeight: -1
            }).upsert().updateOne({
              $set: {
                voter: voterAddress,
                proposer: proposerAddress,
                blockHeight: -1,
                updatedAt: latestHeight,
                missCount: _.get(stats, 'missCount'),
                totalCount: _.get(stats, 'totalCount')
              }
            });
          });
        });

        let message = '';

        if (bulkMissedStats.length > 0) {
          const client = MissedBlocks._driver.mongo.client; // TODO: add transaction back after replica set(#146) is set up
          // let session = client.startSession();
          // session.startTransaction();

          let bulkPromise = bulkMissedStats.execute(null
          /*, {session}*/
          ).then(Meteor.bindEnvironment((result, err) => {
            if (err) {
              COUNTMISSEDBLOCKS = false; // Promise.await(session.abortTransaction());

              throw err;
            }

            if (result) {
              // Promise.await(session.commitTransaction());
              message = "(".concat(result.result.nInserted, " inserted, ") + "".concat(result.result.nUpserted, " upserted, ") + "".concat(result.result.nModified, " modified)");
            }
          }));
          Promise.await(bulkPromise);
        }

        COUNTMISSEDBLOCKS = false;
        Status.upsert({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastProcessedMissedBlockHeight: latestHeight,
            lastProcessedMissedBlockTime: new Date()
          }
        });
        return "done in ".concat(Date.now() - startTime, "ms ").concat(message);
      } catch (e) {
        COUNTMISSEDBLOCKS = false;
        throw e;
      }
    } else {
      return "updating...";
    }
  },
  'ValidatorRecords.calculateMissedBlocksStats': function () {
    this.unblock(); // TODO: deprecate this method and MissedBlocksStats collection
    // console.log("ValidatorRecords.calculateMissedBlocks: "+COUNTMISSEDBLOCKS);

    if (!COUNTMISSEDBLOCKSSTATS) {
      COUNTMISSEDBLOCKSSTATS = true;
      console.log('calulate missed blocks stats');
      this.unblock();
      let validators = Validators.find({}).fetch();
      let latestHeight = Meteor.call('blocks.getCurrentHeight');
      let explorerStatus = Status.findOne({
        chainId: Meteor.settings.public.chainId
      });
      let startHeight = explorerStatus && explorerStatus.lastMissedBlockHeight ? explorerStatus.lastMissedBlockHeight : Meteor.settings.params.startHeight; // console.log(latestHeight);
      // console.log(startHeight);

      const bulkMissedStats = MissedBlocksStats.rawCollection().initializeUnorderedBulkOp();

      for (i in validators) {
        // if ((validators[i].address == "B8552EAC0D123A6BF609123047A5181D45EE90B5") || (validators[i].address == "69D99B2C66043ACBEAA8447525C356AFC6408E0C") || (validators[i].address == "35AD7A2CD2FC71711A675830EC1158082273D457")){
        let voterAddress = validators[i].address;
        let missedRecords = ValidatorRecords.find({
          address: voterAddress,
          exists: false,
          $and: [{
            height: {
              $gt: startHeight
            }
          }, {
            height: {
              $lte: latestHeight
            }
          }]
        }).fetch();
        let counts = {}; // console.log("missedRecords to process: "+missedRecords.length);

        for (b in missedRecords) {
          let block = Blockscon.findOne({
            height: missedRecords[b].height
          });
          let existingRecord = MissedBlocksStats.findOne({
            voter: voterAddress,
            proposer: block.proposerAddress
          });

          if (typeof counts[block.proposerAddress] === 'undefined') {
            if (existingRecord) {
              counts[block.proposerAddress] = existingRecord.count + 1;
            } else {
              counts[block.proposerAddress] = 1;
            }
          } else {
            counts[block.proposerAddress]++;
          }
        }

        for (address in counts) {
          let data = {
            voter: voterAddress,
            proposer: address,
            count: counts[address]
          };
          bulkMissedStats.find({
            voter: voterAddress,
            proposer: address
          }).upsert().updateOne({
            $set: data
          });
        } // }

      }

      if (bulkMissedStats.length > 0) {
        bulkMissedStats.execute(Meteor.bindEnvironment((err, result) => {
          if (err) {
            COUNTMISSEDBLOCKSSTATS = false;
            console.log(err);
          }

          if (result) {
            Status.upsert({
              chainId: Meteor.settings.public.chainId
            }, {
              $set: {
                lastMissedBlockHeight: latestHeight,
                lastMissedBlockTime: new Date()
              }
            });
            COUNTMISSEDBLOCKSSTATS = false;
            console.log("done");
          }
        }));
      } else {
        COUNTMISSEDBLOCKSSTATS = false;
      }

      return true;
    } else {
      return "updating...";
    }
  },
  'Analytics.aggregateBlockTimeAndVotingPower': function (time) {
    this.unblock();
    let now = new Date();

    if (time == 'm') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastMinuteVotingPower: averageVotingPower,
            lastMinuteBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'h') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastHourVotingPower: averageVotingPower,
            lastHourBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'd') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastDayVotingPower: averageVotingPower,
            lastDayBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    } // return analytics.length;

  },
  'Analytics.aggregateValidatorDailyBlockTime': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let now = new Date();

    for (i in validators) {
      let averageBlockTime = 0;
      let blocks = Blockscon.find({
        proposerAddress: validators[i].address,
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }, {
        fields: {
          height: 1
        }
      }).fetch();

      if (blocks.length > 0) {
        let blockHeights = [];

        for (b in blocks) {
          blockHeights.push(blocks[b].height);
        }

        let analytics = Analytics.find({
          height: {
            $in: blockHeights
          }
        }, {
          fields: {
            height: 1,
            timeDiff: 1
          }
        }).fetch();

        for (a in analytics) {
          averageBlockTime += analytics[a].timeDiff;
        }

        averageBlockTime = averageBlockTime / analytics.length;
      }

      AverageValidatorData.insert({
        proposerAddress: validators[i].address,
        averageBlockTime: averageBlockTime,
        type: 'ValidatorDailyAverageBlockTime',
        createdAt: now
      });
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/publications.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatorRecords, Analytics, MissedBlocks, MissedBlocksStats, VPDistributions;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.publish('validator_records.all', function () {
  return ValidatorRecords.find();
});
Meteor.publish('validator_records.uptime', function (address, num) {
  return ValidatorRecords.find({
    address: address
  }, {
    limit: num,
    sort: {
      height: -1
    }
  });
});
Meteor.publish('analytics.history', function () {
  return Analytics.find({}, {
    sort: {
      height: -1
    },
    limit: 50
  });
});
Meteor.publish('vpDistribution.latest', function () {
  return VPDistributions.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  });
});
publishComposite('missedblocks.validator', function (address, type) {
  let conditions = {};

  if (type == 'voter') {
    conditions = {
      voter: address
    };
  } else {
    conditions = {
      proposer: address
    };
  }

  return {
    find() {
      return MissedBlocksStats.find(conditions);
    },

    children: [{
      find(stats) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
publishComposite('missedrecords.validator', function (address, type) {
  return {
    find() {
      return MissedBlocks.find({
        [type]: address
      }, {
        sort: {
          updatedAt: -1
        }
      });
    },

    children: [{
      find() {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operatorAddress: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"records.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/records.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorRecords: () => ValidatorRecords,
  Analytics: () => Analytics,
  MissedBlocksStats: () => MissedBlocksStats,
  MissedBlocks: () => MissedBlocks,
  VPDistributions: () => VPDistributions,
  AverageData: () => AverageData,
  AverageValidatorData: () => AverageValidatorData
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const ValidatorRecords = new Mongo.Collection('validator_records');
const Analytics = new Mongo.Collection('analytics');
const MissedBlocksStats = new Mongo.Collection('missed_blocks_stats');
const MissedBlocks = new Mongo.Collection('missed_blocks');
const VPDistributions = new Mongo.Collection('voting_power_distributions');
const AverageData = new Mongo.Collection('average_data');
const AverageValidatorData = new Mongo.Collection('average_validator_data');
MissedBlocksStats.helpers({
  proposerMoniker() {
    let validator = Validators.findOne({
      address: this.proposer
    });
    return validator.description ? validator.description.moniker : this.proposer;
  },

  voterMoniker() {
    let validator = Validators.findOne({
      address: this.voter
    });
    return validator.description ? validator.description.moniker : this.voter;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status":{"server":{"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Status;
module.link("../status.js", {
  Status(v) {
    Status = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('status.status', function () {
  return Status.find({
    chainId: Meteor.settings.public.chainId
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/status.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Status: () => Status
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Status = new Mongo.Collection('status');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/methods.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
const AddressLength = 40;
Meteor.methods({
  'Transactions.updateTransactions': function () {
    return Promise.asyncApply(() => {
      this.unblock();
      if (TXSYNCING) return "Syncing transactions...";
      const transactions = Transactions.find({
        processed: false
      }, {
        limit: 500
      }).fetch();

      try {
        TXSYNCING = true;
        const bulkTransactions = Transactions.rawCollection().initializeUnorderedBulkOp();

        for (let i in transactions) {
          let url = "";

          try {
            url = API + '/cosmos/tx/v1beta1/txs/' + transactions[i].txhash;
            let response = HTTP.get(url);
            let tx = JSON.parse(response.content);
            tx.height = parseInt(tx.tx_response.height);
            tx.processed = true;
            bulkTransactions.find({
              txhash: transactions[i].txhash
            }).updateOne({
              $set: tx
            });
          } catch (e) {
            // console.log(url);
            // console.log("tx not found: %o")
            console.log("Getting transaction %o: %o", transactions[i].txhash, e);
            bulkTransactions.find({
              txhash: transactions[i].txhash
            }).updateOne({
              $set: {
                processed: true,
                missing: true
              }
            });
          }
        }

        if (bulkTransactions.length > 0) {
          console.log("aaa: %o", bulkTransactions.length);
          bulkTransactions.execute((err, result) => {
            if (err) {
              console.log(err);
            }

            if (result) {
              console.log(result);
            }
          });
        }
      } catch (e) {
        TXSYNCING = false;
        return e;
      }

      TXSYNCING = false;
      return transactions.length;
    });
  },
  'Transactions.findDelegation': function (address, height) {
    this.unblock(); // following cosmos-sdk/x/slashing/spec/06_events.md and cosmos-sdk/x/staking/spec/06_events.md

    return Transactions.find({
      $or: [{
        $and: [{
          "tx_response.logs.events.type": "delegate"
        }, {
          "tx_response.logs.events.attributes.key": "validator"
        }, {
          "tx_response.logs.events.attributes.value": address
        }]
      }, {
        $and: [{
          "tx_response.logs.events.attributes.key": "action"
        }, {
          "tx_response.logs.events.attributes.value": "unjail"
        }, {
          "tx_response.logs.events.attributes.key": "sender"
        }, {
          "tx_response.logs.events.attributes.value": address
        }]
      }, {
        $and: [{
          "tx_response.logs.events.type": "create_validator"
        }, {
          "tx_response.logs.events.attributes.key": "validator"
        }, {
          "tx_response.logs.events.attributes.value": address
        }]
      }, {
        $and: [{
          "tx_response.logs.events.type": "unbond"
        }, {
          "tx_response.logs.events.attributes.key": "validator"
        }, {
          "tx_response.logs.events.attributes.value": address
        }]
      }, {
        $and: [{
          "tx_response.logs.events.type": "redelegate"
        }, {
          "tx_response.logs.events.attributes.key": "destination_validator"
        }, {
          "tx_response.logs.events.attributes.value": address
        }]
      }],
      "tx_response.code": 0,
      height: {
        $lt: height
      }
    }, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch();
  },
  'Transactions.findUser': function (address) {
    let fields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    this.unblock(); // address is either delegator address or validator operator address

    let validator;
    if (!fields) fields = {
      address: 1,
      description: 1,
      operator_address: 1,
      delegator_address: 1
    };

    if (address.includes(Meteor.settings.public.bech32PrefixValAddr)) {
      // validator operator address
      validator = Validators.findOne({
        operator_address: address
      }, {
        fields
      });
    } else if (address.includes(Meteor.settings.public.bech32PrefixAccAddr)) {
      // delegator address
      validator = Validators.findOne({
        delegator_address: address
      }, {
        fields
      });
    } else if (address.length === AddressLength) {
      validator = Validators.findOne({
        address: address
      }, {
        fields
      });
    }

    if (validator) {
      return validator;
    }

    return false;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
publishComposite('transactions.list', function () {
  let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 30;
  return {
    find() {
      return Transactions.find({
        height: {
          $exists: true
        },
        processed: {
          $ne: false
        }
      }, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        if (tx.height) return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.validator', function (validatorAddress, delegatorAddress) {
  let limit = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 100;
  let query = {};

  if (validatorAddress && delegatorAddress) {
    query = {
      $or: [{
        "tx_response.logs.events.attributes.value": validatorAddress
      }, {
        "tx_response.logs.events.attributes.value": delegatorAddress
      }]
    };
  }

  if (!validatorAddress && delegatorAddress) {
    query = {
      "tx_response.logs.events.attributes.value": delegatorAddress
    };
  }

  return {
    find() {
      return Transactions.find(query, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.findOne', function (hash) {
  return {
    find() {
      return Transactions.find({
        txhash: hash
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.height', function (height) {
  return {
    find() {
      return Transactions.find({
        height: height
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/transactions.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Transactions: () => Transactions
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Blockscon;
module.link("../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let TxIcon;
module.link("../../ui/components/Icons.jsx", {
  TxIcon(v) {
    TxIcon = v;
  }

}, 2);
const Transactions = new Mongo.Collection('transactions');
Transactions.helpers({
  block() {
    return Blockscon.findOne({
      height: this.height
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
Meteor.methods({
  'Validators.findCreateValidatorTime': function (address) {
    this.unblock(); // look up the create validator time to consider if the validator has never updated the commission

    let tx = Transactions.findOne({
      $and: [{
        "tx.body.messages.delegator_address": address
      }, {
        "tx.body.messages.@type": "/cosmos.staking.v1beta1.MsgCreateValidator"
      }, {
        "tx_response.code": 0
      }]
    });

    if (tx) {
      let block = Blockscon.findOne({
        height: tx.height
      });

      if (block) {
        return block.time;
      }
    } else {
      // no such create validator tx
      return false;
    }
  },

  // async 'Validators.getAllDelegations'(address){
  'Validators.getAllDelegations'(address) {
    this.unblock();
    let url = API + '/cosmos/staking/v1beta1/validators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).delegation_responses;
        delegations.forEach((delegation, i) => {
          if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
        });
        return delegations;
      }

      ;
    } catch (e) {
      console.log(url);
      console.log("Getting error: %o when fetching from %o", e, url);
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Validators;
module.link("../validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
let ValidatorRecords;
module.link("../../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 2);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 3);
Meteor.publish('validators.all', function () {
  let sort = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "description.moniker";
  let direction = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : -1;
  let fields = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return Validators.find({}, {
    sort: {
      [sort]: direction
    },
    fields: fields
  });
});
publishComposite('validators.firstSeen', {
  find() {
    return Validators.find({});
  },

  children: [{
    find(val) {
      return ValidatorRecords.find({
        address: val.address
      }, {
        sort: {
          height: 1
        },
        limit: 1
      });
    }

  }]
});
Meteor.publish('validators.voting_power', function () {
  return Validators.find({
    status: 'BOND_STATUS_BONDED',
    jailed: false
  }, {
    sort: {
      voting_power: -1
    },
    fields: {
      address: 1,
      description: 1,
      voting_power: 1,
      profile_url: 1
    }
  });
});
publishComposite('validator.details', function (address) {
  let options = {
    address: address
  };

  if (address.indexOf(Meteor.settings.public.bech32PrefixValAddr) != -1) {
    options = {
      operator_address: address
    };
  }

  return {
    find() {
      return Validators.find(options);
    },

    children: [{
      find(val) {
        return VotingPowerHistory.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: 50
        });
      }

    }, {
      find(val) {
        return ValidatorRecords.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: Meteor.settings.public.uptimeWindow
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/validators.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Validators: () => Validators
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let ValidatorRecords;
module.link("../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 1);
let VotingPowerHistory;
module.link("../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 2);
const Validators = new Mongo.Collection('validators');
Validators.helpers({
  firstSeen() {
    return ValidatorRecords.findOne({
      address: this.address
    });
  },

  history() {
    return VotingPowerHistory.find({
      address: this.address
    }, {
      sort: {
        height: -1
      },
      limit: 50
    }).fetch();
  }

}); // Validators.helpers({
//     uptime(){
//         // console.log(this.address);
//         let lastHundred = ValidatorRecords.find({address:this.address}, {sort:{height:-1}, limit:100}).fetch();
//         console.log(lastHundred);
//         let uptime = 0;
//         for (i in lastHundred){
//             if (lastHundred[i].exists){
//                 uptime+=1;
//             }
//         }
//         return uptime;
//     }
// })
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"voting-power":{"server":{"publications.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"history.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/history.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  VotingPowerHistory: () => VotingPowerHistory
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const VotingPowerHistory = new Mongo.Collection('voting_power_history');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"evidences":{"evidences.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/evidences/evidences.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Evidences: () => Evidences
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Evidences = new Mongo.Collection('evidences');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validator-sets":{"validator-sets.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validator-sets/validator-sets.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorSets: () => ValidatorSets
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const ValidatorSets = new Mongo.Collection('validator_sets');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"both":{"index.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/both/index.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Import modules used by both client and server through a single index entry point
// e.g. useraccounts configuration file.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"create-indexes.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/create-indexes.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Blockscon;
module.link("../../api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 0);
let Proposals;
module.link("../../api/proposals/proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 1);
let ValidatorRecords, Analytics, MissedBlocksStats, MissedBlocks, AverageData, AverageValidatorData;
module.link("../../api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 2);
let Transactions;
module.link("../../api/transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 3);
let ValidatorSets;
module.link("../../api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Validators;
module.link("../../api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 5);
let VotingPowerHistory;
module.link("../../api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 6);
let Evidences;
module.link("../../api/evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 7);
let CoinStats;
module.link("../../api/coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 8);
let ChainStates;
module.link("../../api/chain/chain.js", {
  ChainStates(v) {
    ChainStates = v;
  }

}, 9);
ChainStates.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  proposerAddress: 1
});
Evidences.rawCollection().createIndex({
  height: -1
});
Proposals.rawCollection().createIndex({
  proposalId: 1
}, {
  unique: true
});
ValidatorRecords.rawCollection().createIndex({
  address: 1,
  height: -1
}, {
  unique: 1
});
ValidatorRecords.rawCollection().createIndex({
  address: 1,
  exists: 1,
  height: -1
});
Analytics.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  voter: 1,
  updatedAt: -1
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  proposer: 1,
  blockHeight: -1
}, {
  unique: true
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1
});
MissedBlocksStats.rawCollection().createIndex({
  voter: 1
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1,
  voter: 1
}, {
  unique: true
});
AverageData.rawCollection().createIndex({
  type: 1,
  createdAt: -1
}, {
  unique: true
});
AverageValidatorData.rawCollection().createIndex({
  proposerAddress: 1,
  createdAt: -1
}, {
  unique: true
}); // Status.rawCollection.createIndex({})

Transactions.rawCollection().createIndex({
  txhash: 1
}, {
  unique: true
});
Transactions.rawCollection().createIndex({
  height: -1
});
Transactions.rawCollection().createIndex({
  processed: 1
}); // Transactions.rawCollection().createIndex({action:1});

Transactions.rawCollection().createIndex({
  "tx_response.logs.events.attributes.key": 1
});
Transactions.rawCollection().createIndex({
  "tx_response.logs.events.attributes.value": 1
});
Transactions.rawCollection().createIndex({
  "tx.body.messages.delegator_address": 1,
  "tx.body.messages.@type": 1,
  "tx_response.code": 1
}, {
  partialFilterExpression: {
    "tx_response.code": {
      $exists: true
    }
  }
});
ValidatorSets.rawCollection().createIndex({
  block_height: -1
});
Validators.rawCollection().createIndex({
  address: 1
}, {
  unique: true,
  partialFilterExpression: {
    address: {
      $exists: true
    }
  }
}); // Validators.rawCollection().createIndex({consensusPubkey:1},{unique:true});

Validators.rawCollection().createIndex({
  "consensusPubkey.value": 1
}, {
  unique: true,
  partialFilterExpression: {
    "consensusPubkey.value": {
      $exists: true
    }
  }
});
VotingPowerHistory.rawCollection().createIndex({
  address: 1,
  height: -1
});
VotingPowerHistory.rawCollection().createIndex({
  type: 1
});
CoinStats.rawCollection().createIndex({
  last_updated_at: -1
}, {
  unique: true
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("./util.js");
module.link("./register-api.js");
module.link("./create-indexes.js");
let onPageLoad;
module.link("meteor/server-render", {
  onPageLoad(v) {
    onPageLoad = v;
  }

}, 0);
let Helmet;
module.link("react-helmet", {
  Helmet(v) {
    Helmet = v;
  }

}, 1);
// import App from '../../ui/App.jsx';
onPageLoad(sink => {
  // const context = {};
  // const sheet = new ServerStyleSheet()
  // const html = renderToString(sheet.collectStyles(
  //     <StaticRouter location={sink.request.url} context={context}>
  //         <App />
  //     </StaticRouter>
  //   ));
  // sink.renderIntoElementById('app', html);
  const helmet = Helmet.renderStatic();
  sink.appendToHead(helmet.meta.toString());
  sink.appendToHead(helmet.title.toString()); // sink.appendToHead(sheet.getStyleTags());
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"register-api.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/register-api.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("../../api/ledger/server/methods.js");
module.link("../../api/chain/server/methods.js");
module.link("../../api/chain/server/publications.js");
module.link("../../api/blocks/server/methods.js");
module.link("../../api/blocks/server/publications.js");
module.link("../../api/validators/server/methods.js");
module.link("../../api/validators/server/publications.js");
module.link("../../api/records/server/methods.js");
module.link("../../api/records/server/publications.js");
module.link("../../api/proposals/server/methods.js");
module.link("../../api/proposals/server/publications.js");
module.link("../../api/voting-power/server/publications.js");
module.link("../../api/transactions/server/methods.js");
module.link("../../api/transactions/server/publications.js");
module.link("../../api/delegations/server/methods.js");
module.link("../../api/delegations/server/publications.js");
module.link("../../api/status/server/publications.js");
module.link("../../api/accounts/server/methods.js");
module.link("../../api/coin-stats/server/methods.js");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"util.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/util.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let bech32;
module.link("bech32", {
  default(v) {
    bech32 = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 2);
let tmhash;
module.link("tendermint/lib/hash", {
  tmhash(v) {
    tmhash = v;
  }

}, 3);
Meteor.methods({
  hexToBech32: function (address, prefix) {
    let addressBuffer = Buffer.from(address, 'hex'); // let buffer = Buffer.alloc(37)
    // addressBuffer.copy(buffer);

    return bech32.encode(prefix, bech32.toWords(addressBuffer));
  },
  pubkeyToBech32Old: function (pubkey, prefix) {
    let buffer;

    try {
      if (pubkey.type.indexOf("Ed25519") > 0) {
        // '1624DE6420' is ed25519 pubkey prefix
        let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
        buffer = Buffer.alloc(37);
        pubkeyAminoPrefix.copy(buffer, 0);
        Buffer.from(pubkey.value, 'base64').copy(buffer, pubkeyAminoPrefix.length);
      } else if (pubkey.type.indexOf("Secp256k1") > 0) {
        // 'EB5AE98721' is secp256k1 pubkey prefix
        let pubkeyAminoPrefix = Buffer.from('EB5AE98721', 'hex');
        buffer = Buffer.alloc(38);
        pubkeyAminoPrefix.copy(buffer, 0);
        Buffer.from(pubkey.value, 'base64').copy(buffer, pubkeyAminoPrefix.length);
      } else {
        console.log("Pubkey type not supported.");
        return false;
      }

      return bech32.encode(prefix, bech32.toWords(buffer));
    } catch (e) {
      console.log("Error converting from pubkey to bech32: %o\n %o", pubkey, e);
      return false;
    }
  },
  pubkeyToBech32: function (pubkey, prefix) {
    let buffer;

    try {
      if (pubkey["@type"].indexOf("ed25519") > 0) {
        // '1624DE6420' is ed25519 pubkey prefix
        let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
        buffer = Buffer.alloc(37);
        pubkeyAminoPrefix.copy(buffer, 0);
        Buffer.from(pubkey.key, 'base64').copy(buffer, pubkeyAminoPrefix.length);
      } else if (pubkey["@type"].indexOf("secp256k1") > 0) {
        // 'EB5AE98721' is secp256k1 pubkey prefix
        let pubkeyAminoPrefix = Buffer.from('EB5AE98721', 'hex');
        buffer = Buffer.alloc(38);
        pubkeyAminoPrefix.copy(buffer, 0);
        Buffer.from(pubkey.key, 'base64').copy(buffer, pubkeyAminoPrefix.length);
      } else {
        console.log("Pubkey type not supported.");
        return false;
      }

      return bech32.encode(prefix, bech32.toWords(buffer));
    } catch (e) {
      console.log("Error converting from pubkey to bech32: %o\n %o", pubkey, e);
      return false;
    }
  },
  bech32ToPubkey: function (pubkey, type) {
    // type can only be either 'tendermint/PubKeySecp256k1' or 'tendermint/PubKeyEd25519'
    let pubkeyAminoPrefix, buffer;

    try {
      if (type.indexOf("ed25519") > 0) {
        // '1624DE6420' is ed25519 pubkey prefix
        pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
        buffer = Buffer.from(bech32.fromWords(bech32.decode(pubkey).words));
      } else if (type.indexOf("secp256k1") > 0) {
        // 'EB5AE98721' is secp256k1 pubkey prefix
        pubkeyAminoPrefix = Buffer.from('EB5AE98721', 'hex');
        buffer = Buffer.from(bech32.fromWords(bech32.decode(pubkey).words));
      } else {
        console.log("Pubkey type not supported.");
        return false;
      }

      return buffer.slice(pubkeyAminoPrefix.length).toString('base64');
    } catch (e) {
      console.log("Error converting from bech32 to pubkey: %o\n %o", pubkey, e);
      return false;
    }
  },
  getAddressFromPubkey: function (pubkey) {
    var bytes = Buffer.from(pubkey.key, 'base64');
    return tmhash(bytes).slice(0, 20).toString('hex').toUpperCase();
  },
  getDelegator: function (operatorAddr) {
    let address = bech32.decode(operatorAddr);
    return bech32.encode(Meteor.settings.public.bech32PrefixAccAddr, address.words);
  },
  getKeybaseTeamPic: function (keybaseUrl) {
    let teamPage = HTTP.get(keybaseUrl);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    }
  },
  getVersion: function () {
    const version = Assets.getText('version');
    return version ? version : 'beta';
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"ui":{"components":{"Icons.jsx":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/ui/components/Icons.jsx                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  DenomSymbol: () => DenomSymbol,
  ProposalStatusIcon: () => ProposalStatusIcon,
  VoteIcon: () => VoteIcon,
  TxIcon: () => TxIcon,
  InfoIcon: () => InfoIcon
});
let React;
module.link("react", {
  default(v) {
    React = v;
  }

}, 0);
let UncontrolledTooltip;
module.link("reactstrap", {
  UncontrolledTooltip(v) {
    UncontrolledTooltip = v;
  }

}, 1);

const DenomSymbol = props => {
  switch (props.denom) {
    case "steak":
      return '🥩';

    default:
      return '🍅';
  }
};

const ProposalStatusIcon = props => {
  switch (props.status) {
    case 'PROPOSAL_STATUS_PASSED':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-check-circle text-success"
      });

    case 'PROPOSAL_STATUS_REJECTED':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-times-circle text-danger"
      });

    case 'PROPOSAL_STATUS_REMOVED':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-trash-alt text-dark"
      });

    case 'PROPOSAL_STATUS_DEPOSIT_PERIOD':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-battery-half text-warning"
      });

    case 'PROPOSAL_STATUS_VOTING_PERIOD':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-hand-paper text-info"
      });

    default:
      return /*#__PURE__*/React.createElement("i", null);
  }
};

const VoteIcon = props => {
  switch (props.vote) {
    case 'yes':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-check text-success"
      });

    case 'no':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-times text-danger"
      });

    case 'abstain':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-user-slash text-warning"
      });

    case 'no_with_veto':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-exclamation-triangle text-info"
      });

    default:
      return /*#__PURE__*/React.createElement("i", null);
  }
};

const TxIcon = props => {
  if (props.valid) {
    return /*#__PURE__*/React.createElement("span", {
      className: "text-success text-nowrap"
    }, /*#__PURE__*/React.createElement("i", {
      className: "fas fa-check-circle"
    }));
  } else {
    return /*#__PURE__*/React.createElement("span", {
      className: "text-danger text-nowrap"
    }, /*#__PURE__*/React.createElement("i", {
      className: "fas fa-times-circle"
    }));
  }
};

class InfoIcon extends React.Component {
  constructor(props) {
    super(props);
    this.ref = /*#__PURE__*/React.createRef();
  }

  render() {
    return [/*#__PURE__*/React.createElement("i", {
      key: "icon",
      className: "material-icons info-icon",
      ref: this.ref
    }, "info"), /*#__PURE__*/React.createElement(UncontrolledTooltip, {
      key: "tooltip",
      placement: "right",
      target: this.ref
    }, this.props.children ? this.props.children : this.props.tooltipText)];
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"both":{"i18n":{"en-us.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/en-us.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('en-US','',{"common":{"height":"Height","voter":"Voter","votingPower":"Voting Power","addresses":"Addresses","amounts":"Amounts","delegators":"delegators","block":"block","blocks":"blocks","precommit":"precommit","precommits":"precommits","last":"last","backToList":"Back to List","information":"Information","time":"Time","hash":"Hash","more":"More","fullStop":".","searchPlaceholder":"Search with tx hash / block height / address","cancel":"Cancel","retry":"Retry","rewards":"Rewards","bondedTokens":"Bonded Tokens"},"navbar":{"siteName":"ZenScan","version":"-","validators":"Validators","blocks":"Blocks","transactions":"Transactions","proposals":"Proposals","votingPower":"Voting Power","lang":"ENG","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","portuguese":"Português","license":"LICENSE","forkMe":"Github"},"consensus":{"consensusState":"Consensus State","round":"Round","step":"Step"},"chainStates":{"price":"Price","marketCap":"Market Cap","inflation":"Inflation","communityPool":"Community Pool"},"chainStatus":{"startMessage":"The chain is going to start in","stopWarning":"The chain appears to be stopped for <em>{$time}</em>! Feed me with new blocks 😭!","latestHeight":"Latest Block Height","averageBlockTime":"Average Block Time","all":"All","now":"Now","allTime":"All Time","lastMinute":"Last Minute","lastHour":"Last Hour","lastDay":"Last Day","seconds":"seconds","activeValidators":"Active Validators","outOfValidators":"out of {$totalValidators} validators","onlineVotingPower":"Online Voting Power","fromTotalStakes":"{$percent} from {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Block Time History","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"Random Validators","moniker":"Moniker","uptime":"Uptime","selfPercentage":"Self%","commission":"Commission","lastSeen":"Last Seen","status":"Status","jailed":"Jailed","navActive":"Active","navInactive":"Inactive","active":"Active Validators","inactive":"Inactive Validators","listOfActive":"Here is a list of active validators.","listOfInactive":"Here is a list of inactive validators.","validatorDetails":"Validator Details","lastNumBlocks":"Last {$numBlocks} blocks","validatorInfo":"Validator Info","operatorAddress":"Operator Address","selfDelegationAddress":"Self-Delegate Address","commissionRate":"Commission Rate","maxRate":"Max Rate","maxChangeRate":"Max Change Rate","selfDelegationRatio":"Self Delegation Ratio","proposerPriority":"Proposer Priority","delegatorShares":"Delegator Shares","userDelegateShares":"Shares Delegated by you","tokens":"Tokens","unbondingHeight":"Unbonding Height","unbondingTime":"Unbonding Time","jailedUntil":"Jailed Until","powerChange":"Power Change","delegations":"Delegations","transactions":"Transactions","validatorNotExists":"Validator does not exist.","backToValidator":"Back to Validator","missedBlocks":"Missed Blocks","missedPrecommits":"Missed Precommits","missedBlocksTitle":"Missed blocks of {$moniker}","totalMissed":"Total missed","block":"Block","missedCount":"Miss Count","iDontMiss":"I do not miss ","lastSyncTime":"Last sync time","delegator":"Delegator","amount":"Amount"},"blocks":{"block":"Block","proposer":"Proposer","latestBlocks":"Latest blocks","noBlock":"No block.","numOfTxs":"No. of Txs","numOfTransactions":"No. of Transactions","notFound":"No such block found."},"transactions":{"transaction":"Transaction","transactions":"Transactions","notFound":"No transaction found.","activities":"Activities","txHash":"Tx Hash","valid":"Valid","fee":"Fee","noFee":"No fee","gasUsedWanted":"Gas (used / wanted)","noTxFound":"No such transaction found.","noValidatorTxsFound":"No transaction related to this validator was found.","memo":"Memo","transfer":"Transfer","staking":"Staking","distribution":"Distribution","governance":"Governance","slashing":"Slashing"},"proposals":{"notFound":"No proposal found.","listOfProposals":"Here is a list of governance proposals.","proposer":"Proposer","proposal":"proposal","proposals":"Proposals","proposalID":"Proposal ID","title":"Title","status":"Status","submitTime":"Submit Time","depositEndTime":"Deposit End Time","votingStartTime":"Voting Start Time","votingEndTime":"End Voting Time","totalDeposit":"Total Deposit","description":"Description","proposalType":"Proposal Type","proposalStatus":"Proposal Status","notStarted":"not started","final":"final","deposit":"Deposit","tallyResult":"Tally Result","yes":"Yes","abstain":"Abstain","no":"No","noWithVeto":"No with Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> of online voting power has been voted.","validMessage":"This proposal is {$tentative}<strong>valid</strong>.","invalidMessage":"Less than {$quorum} of voting power is voted. This proposal is <strong>invalid</strong>.","moreVoteMessage":"It will be a valid proposal once <span class=\"text-info\">{$moreVotes}</span> more votes are cast.","key":"Key","value":"Value","amount":"Amount","recipient":"Recipient","changes":"Changes","subspace":"Subspace"},"votingPower":{"distribution":"Voting Power Distribution","pareto":"Pareto Principle (20/80 rule)","minValidators34":"Min no. of validators hold 34%+ power"},"accounts":{"accountDetails":"Account Details","available":"Available","delegated":"Delegated","unbonding":"Unbonding","rewards":"Rewards","total":"Total","notFound":"This account does not exist. Are you looking for a wrong address?","validators":"Validators","shares":"Shares","mature":"Mature","no":"No ","none":"No ","delegation":"Delegation","plural":"s","signOut":"Sign out","signInText":"You are signed in as ","toLoginAs":"To log in as","signInWithLedger":"Sign In With Ledger","signInWarning":"Please make sure your Ledger device is connected and <strong class=\"text-primary\">{$network} App {$version} or above</strong> is opened.","pleaseAccept":"please accept in your Ledger device.","noRewards":"No Rewards"},"activities":{"single":"A","happened":"happened.","senders":"The following sender(s)","sent":"sent","receivers":"to the following receipient(s)","received":"received","failedTo":"failed to ","to":"to","from":"from","operatingAt":"operating at","withMoniker":"with moniker","withTitle":"with title","withA":"with a","withAmount":"with <span class=\"text-info\">{$amount}</span>"},"messageTypes":{"send":"Send","multiSend":"Multi Send","createValidator":"Create Validator","editValidator":"Edit Validator","delegate":"Delegate","undelegate":"Undelegate","redelegate":"Redelegate","submitProposal":"Submit Proposal","deposit":"Deposit","vote":"Vote","withdrawComission":"Withdraw Commission","withdrawReward":"Withdraw Reward","modifyWithdrawAddress":"Modify Withdraw Address","unjail":"Unjail","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"es-es.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/es-es.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('es-ES','',{"common":{"height":"Altura","voter":"Votante","votingPower":"Poder de votación","addresses":"Direcciones","amounts":"Cantidades","delegators":"delegadores","block":"bloque","blocks":"bloques","precommit":"precommit","precommits":"precommits","last":"último","backToList":"Volver a la lista","information":"Información","time":"Tiempo","hash":"Hash","more":"Más","fullStop":".","searchPlaceholder":"Buscar con el tx hash / altura de bloque / dirección","cancel":"Cancelar","retry":"Reintentar"},"navbar":{"siteName":"BIG DIPPER","validators":"Validadores","blocks":"Bloques","transactions":"Transacciones","proposals":"Propuestas","votingPower":"Poder de voto","lang":"ES","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","portuguese":"Português","license":"LICENCIA","forkMe":"Fork me!"},"consensus":{"consensusState":"Estado de consenso","round":"Ronda","step":"Paso"},"chainStates":{"price":"Precio","marketCap":"Capitalización de mercado","inflation":"Inflación","communityPool":"Community Pool"},"chainStatus":{"startMessage":"La cadena comenzará en","stopWarning":"La cadena parece estar parada por <em>{$time}</em>! Dame de comer nuevos bloques 😭!","latestHeight":"Última altura de bloque","averageBlockTime":"Tiempo medio de bloque","all":"Todo","now":"Ahora","allTime":"Todo el tiempo","lastMinute":"Último minuto","lastHour":"Última hora","lastDay":"Último día","seconds":"segundos","activeValidators":"Validadores activos","outOfValidators":"fuera de {$totalValidators} validadores","onlineVotingPower":"Poder de voto en línea","fromTotalStakes":"{$percent} de {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Historial de tiempo de bloque","averageBlockTime":"Tiempo medio de bloque","blockInterval":"Intervalo de bloque","noOfValidators":"No. de validadores"},"validators":{"randomValidators":"Validadores aleatorios","moniker":"Moniker","uptime":"Tiempo de funcionamiento","selfPercentage":"Self%","commission":"Comisión","lastSeen":"Última vez visto","status":"Estado","jailed":"Encarcelado","navActive":"Activo","navInactive":"Inactivo","active":"Validadores activos","inactive":"Validadores inactivos","listOfActive":"Esta es una lista de los validadores activos.","listOfInactive":"Esta es una lista de los validadores inactivos.","validatorDetails":"Detalles del validador","lastNumBlocks":"Último {$numBlocks} bloques","validatorInfo":"Información del validador","operatorAddress":"Dirección de operador","selfDelegationAddress":"Dirección de autodelegación","commissionRate":"Ratio de comisión","maxRate":"Ratio máximo","maxChangeRate":"Ratio máximo de cambio","selfDelegationRatio":"Ratio de autodelegación","proposerPriority":"","delegatorShares":"Acciones del delegador","userDelegateShares":"Acciones delegadas por ti","tokens":"Tokens","unbondingHeight":"Altura ","unbondingTime":"Tiempo para desvincularse","powerChange":"Power Change","delegations":"Delegaciones","transactions":"Transacciones","validatorNotExists":"El validador no existe.","backToValidator":"Volver al validador","missedBlocks":"Bloques perdidos","missedPrecommits":"Precommits perdidos","missedBlocksTitle":"Bloques perdidos de {$moniker}","totalMissed":"Total perdido","block":"Bloque","missedCount":"Perdidos","iDontMiss":"No he perdido ","lastSyncTime":"Último tiempo de sincronización","delegator":"Delegador","amount":"Cantidad"},"blocks":{"block":"Bloque","proposer":"Proposer","latestBlocks":"Últimos bloques","noBlock":"No bloque.","numOfTxs":"No. de txs","numOfTransactions":"No. de transacciones","notFound":"No se ha encontrado tal bloque."},"transactions":{"transaction":"Transacción","transactions":"Transacciones","notFound":"No se encuentra la transacción.","activities":"Movimientos","txHash":"Tx Hash","valid":"Validez","fee":"Comisión","noFee":"No fee","gasUsedWanted":"Gas (usado / deseado)","noTxFound":"No se encontró ninguna transacción de este tipo.","noValidatorTxsFound":"No se encontró ninguna transaccion relacionada con este validador.","memo":"Memo","transfer":"Transferencia","staking":"Participación","distribution":"Distribución","governance":"Gobernanza","slashing":"Recorte"},"proposals":{"notFound":"No se ha encontrado el proposal.","listOfProposals":"Here is a list of governance proposals.","proposer":"Proposer","proposal":"propuesta","proposals":"Propuestas","proposalID":"ID de la propuesta","title":"Título","status":"Estado","submitTime":"Plazo de entrega","depositEndTime":"Final del tiempo de depósito","votingStartTime":"Hora de inicio de la votación","votingEndTime":"Fin del tiempo de votación","totalDeposit":"Depósito total","description":"Descripción","proposalType":"Tipo de propuesta","proposalStatus":"Estado de la propuesta","notStarted":"no iniciado","final":"final","deposit":"Depósito","tallyResult":"Resultado del recuento","yes":"Si","abstain":"Abstención","no":"No","none":"None","noWithVeto":"No con Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> del poder de voto online ha votado.","validMessage":"Este proposal es {$tentative}<strong>valido</strong>.","invalidMessage":"Menos del {$quorum} del poder de voto ha votado. Este proposal es <strong>invalido</strong>.","moreVoteMessage":"Será una propuesta válida una vez que <span class=\"text-info\">{$moreVotes}</span> más votos se emitan.","key":"Key","value":"Value","amount":"Amount","recipient":"Recipient","changes":"Changes","subspace":"Subspace"},"votingPower":{"distribution":"Distribución del poder de Voto","pareto":"Pareto Principle (20/80 rule)","minValidators34":"Min no. of validators hold 34%+ power"},"accounts":{"accountDetails":"Detalles de la cuenta","available":"Disponible","delegated":"Delegado","unbonding":"Unbonding","rewards":"Rewards","total":"Total","notFound":"Esta cuenta no existe. ¿Estas buscando una dirección equivocada?","validators":"Validadores","shares":"Shares","mature":"Mature","no":"No ","delegation":"Delegación","plural":"s","signOut":"Cerrar sesión","signInText":"Estas registrado como ","toLoginAs":"Para conectarse como","signInWithLedger":"Registrarse con Ledger","signInWarning":"Por favor, asegúrese de que su dispositivo Ledger esté conectado y <strong class=\"text-primary\">la App de Cosmos con la version 1.5.0 o superior</strong> esta abierta.","pleaseAccept":"por favor, acepta en tu dispositivo Ledger.","noRewards":"No Rewards"},"activities":{"single":"A","happened":"sucedió.","senders":"Los siguientes remitentes","sent":"enviado a","receivers":"al siguiente destinatario","received":"recibido","failedTo":"failed to ","to":"a","from":"desde","operatingAt":"operando en","withMoniker":"con el moniker","withTitle":"con el título","withA":"con"},"messageTypes":{"send":"Enviar","multiSend":"Multi Envío","createValidator":"Crear validador","editValidator":"Editar validador","delegate":"Delegar","undelegate":"Undelegar","redelegate":"Redelegar","submitProposal":"Enviar Proposal","deposit":"Depositar","vote":"Voto","withdrawComission":"Enviar comisión","withdrawReward":"Retirar recompensa","modifyWithdrawAddress":"Modificar la dirección de envío","unjail":"Unjail","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"it-IT.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/it-IT.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('it-IT','',{"common":{"height":"Altezza","voter":"Votante","votingPower":"Potere di voto","addresses":"Indirizzi","amounts":"Importi","delegators":"delegatori","block":"blocco","blocks":"blocchi","precommit":"precommit","precommits":"precommit","last":"ultimo","backToList":"Torna alla Lista","information":"Informazioni","time":"Tempo","hash":"Hash","more":"Di più","fullStop":".","searchPlaceholder":"Cerca hash transazione / altezza blocco / indirizzo","cancel":"Annulla","retry":"Riprova","rewards":"Reward"},"navbar":{"siteName":"BIG DIPPER","validators":"Validatori","blocks":"Blocchi","transactions":"Transazioni","proposals":"Proposte","votingPower":"Potere di Voto","lang":"IT","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","portuguese":"Português","license":"LICENZA","forkMe":"Forkami!"},"consensus":{"consensusState":"Stato del consenso","round":"Round","step":"Step"},"chainStates":{"price":"Prezzo","marketCap":"Market Cap","inflation":"Inflazione","communityPool":"Community Pool"},"chainStatus":{"startMessage":"The chain partirà tra","stopWarning":"La chain sembra essersi fermata per <em>{$time}</em>! Dammi nuovi blocchi 😭!","latestHeight":"Ultima Altezza di Blocco","averageBlockTime":"Tempo di Blocco Medio","all":"Tutti","now":"Ora","allTime":"Tutti i tempi","lastMinute":"Ultimo Minuto","lastHour":"Ultima ora","lastDay":"Ultimo giorno","seconds":"secondi","activeValidators":"Validatori Attivi","outOfValidators":"di {$totalValidators} validatori","onlineVotingPower":"Voting Power Attivo","fromTotalStakes":"{$percent} di {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Storia Tempo di Blocco","averageBlockTime":"Tempo di Blocco Medio","blockInterval":"Intervallo di Blocco","noOfValidators":"N. Validatori"},"validators":{"randomValidators":"Validatori random","moniker":"Moniker","uptime":"Uptime","selfPercentage":"% autodelegata","commission":"Commissioni","lastSeen":"Visto per ultimo","status":"Stato","jailed":"Jailato","navActive":"Attivo","navInactive":"Inattivo","active":"Tutti i Validatori","inactive":"Validatori inattivi","listOfActive":"Ecco una lista di validatori attivi.","listOfInactive":"Ecco una lista di validatori inattivi.","validatorDetails":"Dettagli validatore","lastNumBlocks":"Utlimi {$numBlocks} blocchi","validatorInfo":"Info Validatore","operatorAddress":"Indirizzo Operatore","selfDelegationAddress":"Indirizzo di Auto-Delega","commissionRate":"Tasso di commissioni","maxRate":"Tasso massima","maxChangeRate":"Cambiamento del tasso massimo","selfDelegationRatio":"Tasso di Auto Delega","proposerPriority":"Priorità del proponente","delegatorShares":"Percentuale dei delegati","userDelegateShares":"Percentuale delega personale","tokens":"Token","unbondingHeight":"Altezza di unbond","unbondingTime":"Tempo di unbond","powerChange":"Modifica del potere","delegations":"Delegazioni","transactions":"Transazioni","validatorNotExists":"Validatore inesistente","backToValidator":"Torna al validatore","missedBlocks":"Blocchi mancanti","missedPrecommits":"Precommit mancati","missedBlocksTitle":"Manca il blocco: {$moniker}","totalMissed":"Totale perso","block":"Blocco","missedCount":"Mancato conteggio","iDontMiss":"Non mi manca","lastSyncTime":"Ultima sincronizzazione ora","delegator":"Delegante","amount":"Importo"},"blocks":{"block":"Blocco","proposer":"Proponente","latestBlocks":"Ultimi blocchi","noBlock":"Nessun blocco","numOfTxs":"N. Txs","numOfTransactions":"N. di transazioni","notFound":"Nessun blocco trovato."},"transactions":{"transaction":"Transazione","transactions":"Transazioni","notFound":"Nessuna transazione trovata","activities":"Attività","txHash":"Hash Tx","valid":"Valido","fee":"Fee","noFee":"Nessuna fee","gasUsedWanted":"Gas (usato / voluto)","noTxFound":"Nessuna transazione trovata.","noValidatorTxsFound":"Nessuna transazione relativa a questo validatore trovata","memo":"Memo","transfer":"Trasferimento","staking":"Staking","distribution":"Distribuzione","governance":"Governance","slashing":"Slashing"},"proposals":{"notFound":"Nessuna proposta trovata.","listOfProposals":"Questa è la lista delle proposte di governance","proposer":"Proponente","proposal":"Proposta","proposals":"Proposte","proposalID":"ID Proposta","title":"Titolo","status":"Stato","submitTime":"Ora invio","depositEndTime":"Ora di fine deposito","votingStartTime":"Ora di inizio votazione","votingEndTime":"Ora di fine votazione","totalDeposit":"Deposito totale","description":"Descrizione","proposalType":"Tipo di proposta","proposalStatus":"Stato della proposta","notStarted":"Non iniziato","final":"Finale","deposit":"Deposito","tallyResult":"Risultato conteggio","yes":"Sì","abstain":"Astenersi","no":"No","noWithVeto":"No con Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> di voti raccolti tra i votanti attivi.","validMessage":"Questa proposta è {$tentative}<strong>valida</strong>.","invalidMessage":"Sono stati raccolti meno del {$quorum} di voti. Questa proposta è <strong>invalida</strong>.","moreVoteMessage":"Sarà una proposta valida quando <span class=\"text-info\">{$moreVotes}</span> più voti di ora saranno raccolti.","key":"Key","value":"Value","amount":"Amount","recipient":"Recipient","changes":"Changes","subspace":"Subspace"},"votingPower":{"distribution":"Distribuzione del potere di voto","pareto":"Principio di Pareto (regola 20/80)","minValidators34":"Min n. di validatori che possiede il 34%+ di potere"},"accounts":{"accountDetails":"Dettagli account","available":"Disponibile","delegated":"Delegati","unbonding":"Unbonding","rewards":"Rewards","total":"Totale","notFound":"Questo account non esiste. Forse hai inserito l'indirizzo sbagliato?","validators":"Validatori","shares":"Share","mature":"Maturo","no":"No ","none":"Nessuno","delegation":"Delega","plural":"","signOut":"Esci","signInText":"Registrati come","toLoginAs":"Accedi come","signInWithLedger":"Registrati con un Ledger","signInWarning":"Per favore assicurati che il tuo Ledger sia connesso e <strong class=\"text-primary\">{$network} App {$version} or above</strong> che sia aperto.","pleaseAccept":"Per favore accetta nel tuo Ledger","noRewards":"Nessun reward"},"activities":{"single":"Un (male), una (female)","happened":"è accaduto.","senders":"I seguenti mittenti","sent":"Inviato","receivers":"I seguenti destinatati","received":"Ricevuto","failedTo":"Ha fallito a ","to":"A","from":"Da","operatingAt":"che operano presso","withMoniker":"con moniker","withTitle":"con titolo","withA":"con un (male) / una (female)"},"messageTypes":{"send":"Invia","multiSend":"Invio multipo","createValidator":"Crea un validatore","editValidator":"Modifica un validatore","delegate":"Delega","undelegate":"Rimuovi delega","redelegate":"Ridelega","submitProposal":"Invia proposta","deposit":"Deposita","vote":"Vota","withdrawComission":"Ritira una commissione","withdrawReward":"Ottieni un reward","modifyWithdrawAddress":"Modifica indirizzo di ritiro","unjail":"Unjail","IBCTransfer":"Trasferisci IBC","IBCReceive":"Ricevi IBC"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pl-PL.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/pl-PL.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('pl-PL','',{"common":{"height":"Wysokość","voter":"Głosujący","votingPower":"Siła Głosu","addresses":"Adres","amounts":"Kwota","delegators":"Delegatorzy","block":"blok","blocks":"bloki","precommit":"precommit","precommits":"precommits","last":"ostatni","backToList":"Powrtót do Listy","information":"Informacje","time":"Czas","hash":"Hash","more":"Więcej","fullStop":".","searchPlaceholder":"Wyszukaj adres / transakcję / wysokość bloku","cancel":"Anuluj","retry":"Spróbuj ponownie","rewards":"Nagrody"},"navbar":{"siteName":"Wielki Wóz","validators":"Walidatorzy","blocks":"Bloki","transactions":"Transakcje","proposals":"Propozycje","votingPower":"Siła Głosu","lang":"PL","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","portuguese":"Português","license":"LICENCJA","forkMe":"Fork me!"},"consensus":{"consensusState":"Status Konsensusu","round":"Runda","step":"Etap"},"chainStates":{"price":"Cena","marketCap":"Kapitalizacja rynkowa","inflation":"Inflacja","communityPool":"Zasoby Społeczności"},"chainStatus":{"startMessage":"Łańcuch bloków danych rozpocznie działanie za ","topWarning":"Wygląda na to że, łańcuch bloków danych zatrzymał się na <em>{$time}</em>! Odśwież stronę i nakarm mnie nowymi blokami 😭!","latestHeight":"Ostatnia wysokość bloku","averageBlockTime":"Średni Czas Bloku","all":"Całość","now":"Teraz","allTime":"Cały Czas","lastMinute":"Ostatnia Minuta","lastHour":"Ostatnia Godzina","lastDay":"Ostatni Dzień","seconds":"sekund","activeValidators":"Aktywni Walidatorzy","outOfValidators":"z grona {$totalValidators} walidatorów","onlineVotingPower":"Siła Głosu Online","fromTotalStakes":"{$percent} spośród {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Czas Bloków","averageBlockTime":"Średni Czas Bloku","blockInterval":"Interwał Bloku","noOfValidators":"Liczba Walidatorów"},"validators":{"randomValidators":"Losowo Wybrani Walidatorzy","moniker":"Moniker","uptime":"Dyspozycyjność","selfPercentage":"Self%","commission":"Prowizja","lastSeen":"Ostatnio widziany","status":"Status","jailed":"Jailed","navActive":"Aktywni","navInactive":"Nieaktywni","active":"Aktywni Walidatorzy","inactive":"Nieaktywni Walidatorzy","listOfActive":"Lista aktywnych Walidatorów","listOfInactive":"Lista nieaktywnych Walidatorów","validatorDetails":"Szczegóły Walidatora","lastNumBlocks":"Ostatnie {$numBlocks} bloków","validatorInfo":"Szczegóły Walidatora","operatorAddress":"Adres Operatora","selfDelegationAddress":"Adres Delegacji Self","commissionRate":"Wysokość prowizji","maxRate":"Maksymalna Stawka","maxChangeRate":"Maksymalna Stawka Zmiany Prowizji","selfDelegationRatio":"Proporcja Delegacji Self","proposerPriority":"Piorytet Propozycji","delegatorShares":"Akcje Delegującego","userDelegateShares":"Akcje Oddelegowane przez Ciebie","tokens":"Tokeny","unbondingHeight":"Wysokość Unbonding","unbondingTime":"Czas Unbonding","powerChange":"Zmiana Siły Głosu","delegations":"Delegacje","transactions":"Transakcje","validatorNotExists":"Walidator nie istnieje.","backToValidator":"Powrtót do Walidatora","missedBlocks":"Pominięte Bloki","missedPrecommits":"Pominięte Precommits","missedBlocksTitle":"‘Pominięte Bloki od {$moniker}'","totalMissed":"Łącznie pominięto","block":"Blok","missedCount":"Liczba pominiętych","iDontMiss":"Żadne bloki nie zostały pominięte","lastSyncTime":"Ostatni czas synch","delegator":"Delegujący","amount":"Kwota"},"blocks":{"block":"Blok","proposer":"Autor Propozycji","latestBlocks":"Ostatnie Bloki","noBlock":"Ilość Bloków","numOfTxs":"Liczba Txs","numOfTransactions":"Liczba Transakcji","notFound":"Nie znaleziono bloku."},"transactions":{"transaction":"Transakcja","transactions":"Transakcje","notFound":"Nie znaleziono transakcji.","activities":"Aktywność","txHash":"Tx Hash","valid":"Ważna","fee":"Opłata","noFee":"Bezpłatnie","gasUsedWanted":"Gaz (użyty/ wymagany)","noTxFound":"Nie znaleziono podanej transakcji.","noValidatorTxsFound":"Nie znaleziono żadnej transakcji dla podanego Walidatora","memo":"Memo","transfer":"Wysłane","staking":"Udziały","distribution":"Dystrybucja","governance":"Administracja","slashing":"Cięcia"},"proposals":{"notFound":"Nie znaleziono propozycji.'","listOfProposals":"Poniżej znajduje się lista propozycji administracyjnych.","proposer":"Autor Propozycji","proposal":"propozycja","proposals":"Propozycje","proposalID":"ID Propozycji","title":"Tytuł","status":"Status","submitTime":"Czas Wysłania","depositEndTime":"Czas Końcowy dla Skladania Depozytu","votingStartTime":"Czas Rozpoczęcia Głosowania","votingEndTime":"Czas Końcowy Głosowania","totalDeposit":"Kwota Depozytu","description":"Szczegóły","proposalType":"Typ Propozycji","proposalStatus":"Status Propozycji","notStarted":"nie rozpoczęto","final":"końcowy","deposit":"Depozyt","tallyResult":"Wyniki Tally","yes":"Tak","abstain":"Wstrzymaj się od Głosu","no":"Nie","noWithVeto":"Nie z Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> Głosów Online zostalo oddanych","validMessage":"Podana propozycja jest {$tentative}<strong>ważna</strong>.","invalidMessage":"Mniej niż {$quorum} głosów zostało oddanych. Podana propozycja jest <strong>nieważna</strong>.","moreVoteMessage":"Propozycja zostanie uznana za ważną jeśli <span class=\"text-info\">{$moreVotes}</span> lub więcej głosów zostanie oddanych.","key":"Key","value":"Value","amount":"Kwota","recipient":"Odbiorca","changes":"Zmiany","subspace":"Subspace"},"votingPower":{"distribution":"Podział Siły Głosu","pareto":"Zasada Pareta (zasada 20/80)","minValidators34":"Co najmniej 34% Walidatorów ma prawo do głosowania."},"accounts":{"accountDetails":"Szczegóły Konta","available":"Dostępe","delegated":"Oddelegowane","unbonding":"Unbonding","rewards":"Nagrody","total":"Łącznie","notFound":"Konto nie istnieje. Sprawdź, czy adres odbiorcy został prawidłowo wpisany.","validators":"Walidatorzy","shares":"Akcje","mature":"Dojrzały","no":"Nie ","none":"Brak ","delegation":"Delegacja","plural":"","signOut":"Wyloguj","signInText":"Zalogowany jako ","toLoginAs":"Aby zalogować się jako ","signInWithLedger":"Zaloguj się z Ledgerem","signInWarning":"Upewnij się, że Twój Ledger jest podłączony do komputera oraz aplikacja <strong class=\"text-primary\">{$network} App {$version} lub nowsza </strong> jest uruchomiona.","pleaseAccept":"zaakceptuj połączenie na Twoim Ledgerze.","noRewards":"Brak Nagród"},"activities":{"single":" ","happened":"został wykonany","senders":"Nadawca","sent":"wysłał","receivers":"do podanych odbiorców/cy","received":"otrzymał","failedTo":"Nie udało się","to":"do","from":"od","operatingAt":"operujący pod adresem","withMoniker":"z monikerem","withTitle":"pod tytułem","withA":"razem z"},"messageTypes":{"send":"Wysłał","multiSend":"Wysłał Multi","createValidator":"Utwórz Walidatora","editValidator":"Edytuj Walidatora","delegate":"Oddelegował","undelegate":"Wycofał Oddelegowane Tokeny","redelegate":"Oddelegował Ponownie","submitProposal":"Wyśłał Propozycję","deposit":"Wpłacił Depozyt","vote":"Zagłosował","withdrawComission":"Wypłacił Prowizję","withdrawReward":"Wypłacił Nagrody","modifyWithdrawAddress":"Zmienił adres do wypłaty","unjail":"Unjail","IBCTransfer":"Wyślij IBC","IBCReceive":"Odbierz IBC"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pt-BR.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/pt-BR.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('pt-BR','',{"common":{"height":"Altura","voter":"Eleitor","votingPower":"Poder de voto","addresses":"Endereços","amounts":"Quantidades","delegators":"delegadores","block":"bloco","blocks":"blocos","precommit":"precommit","precommits":"precommits","last":"último","backToList":"Voltar para lista","information":"Informação","time":"Data e hora","hash":"Hash","more":"Mais","fullStop":".","searchPlaceholder":"Pesquise por tx hash / altura do bloco / endereço","cancel":"Cancelar","retry":"Tentar novamente","rewards":"Recompensas"},"navbar":{"siteName":"BIG DIPPER","validators":"Validadores","blocks":"Blocos","transactions":"Transações","proposals":"Propostas","votingPower":"Poder de voto","lang":"pt-BR","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","chinese":"中文（繁）","simChinese":"中文（简）","portuguese":"Português","license":"LICENÇA","forkMe":"Fork me!"},"consensus":{"consensusState":"Estado de consenso","round":"Rodada","step":"Etapa"},"chainStates":{"price":"Preço","marketCap":"Valor de mercado","inflation":"Inflação","communityPool":"Pool da comunidade"},"chainStatus":{"startMessage":"A cadeia vai começar em","stopWarning":"A cadeia parece ter parado por <em>{$time}</em>! Alimente-me com novos blocos 😭!","latestHeight":"Última altura de bloco","averageBlockTime":"Tempo médio de bloco","all":"Tudo","now":"Agora","allTime":"Todo tempo","lastMinute":"Último minuto","lastHour":"Última hora","lastDay":"Último dia","seconds":"segundos","activeValidators":"Validadores ativos","outOfValidators":"de {$totalValidators} validadores","onlineVotingPower":"Poder de votação online","fromTotalStakes":"{$percent} de {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Histórico de tempo de bloco","averageBlockTime":"Tempo médio de bloco","blockInterval":"Intervalo de bloco","noOfValidators":"Nº de validadores"},"validators":{"randomValidators":"Validadores aleatórios","moniker":"Apelido","uptime":"Tempo de atividade","selfPercentage":"Self%","commission":"Comissão","lastSeen":"Visto pela última vez","status":"Status","jailed":"Engaiolado","navActive":"Ativo","navInactive":"Inativo","active":"Validadores Ativos","inactive":"Validadores Inativos","listOfActive":"Aqui está uma lista de validadores ativos.","listOfInactive":"Aqui está uma lista de validadores inativos.","validatorDetails":"Detalhes do validador","lastNumBlocks":"Últimos {$numBlocks} blocos","validatorInfo":"Informação do validador","operatorAddress":"Endereço do operador","selfDelegationAddress":"Endereço de auto-delegação","commissionRate":"Taxa de Comissão","maxRate":"Taxa máxima","maxChangeRate":"Taxa máxima de alteração","selfDelegationRatio":"Razão de auto-delegação","proposerPriority":"Prioridade do proponente","delegatorShares":"Ações do delegador","userDelegateShares":"Ações delegadas por você","tokens":"Tokens","unbondingHeight":"Altura de desvinculação","unbondingTime":"Tempo de desvinculação","powerChange":"Mudança de poder","delegations":"Delegações","transactions":"Transações","validatorNotExists":"O validador não existe.","backToValidator":"Voltar para validador","missedBlocks":"Blocos perdidos","missedPrecommits":"Precommits perdidos","missedBlocksTitle":"Blocos perdidos por {$moniker}","totalMissed":"Total perdido","block":"Bloco","missedCount":"Contagem de perdidos","iDontMiss":"Não há perdidos ","lastSyncTime":"Última sincronização","delegator":"Delegador","amount":"Quantidade"},"blocks":{"block":"Bloco","proposer":"Proponente","latestBlocks":"Últimos Blocos","noBlock":"Sem bloco.","numOfTxs":"No. de Txs","numOfTransactions":"Nº de transações","notFound":"Nenhum bloco encontrado."},"transactions":{"transaction":"Transação","transactions":"Transações","notFound":"Nenhuma transação encontrada.","activities":"Atividades","txHash":"Tx Hash","valid":"Validade","fee":"Taxa","noFee":"Sem taxa","gasUsedWanted":"Gas (usado / desejado)","noTxFound":"Nenhuma transação encontrada.","noValidatorTxsFound":"Nenhuma transação relacionada a este validador foi encontrada.","memo":"Memo","transfer":"Transferência","staking":"Participação","distribution":"Distribuição","governance":"Governança","slashing":"Cortando"},"proposals":{"notFound":"Nenhuma proposta encontrada.","listOfProposals":"Aqui está uma lista de propostas de governança.","proposer":"Proponente","proposal":"proposta","proposals":"Propostas","proposalID":"ID da proposta","title":"Título","status":"Status","submitTime":"Tempo de envio","depositEndTime":"Fim do tempo de depósito","votingStartTime":"Hora do início da votação","votingEndTime":"Fim do tempo de votação","totalDeposit":"Depósito Total","description":"Descrição","proposalType":"Tipo de proposta","proposalStatus":"Status da proposta","notStarted":"não iniciado","final":"final","deposit":"Depósito","tallyResult":"Resultado da contagem","yes":"Sim","abstain":"Abstenção","no":"Não","noWithVeto":"Não com Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> do poder de voto já votou.","validMessage":"Esta proposta é {$tentative}<strong>válida</strong>.","invalidMessage":"Menos de {$ quorum} do poder de voto foi votado. Esta proposta é <strong>inválida.</strong>.","moreVoteMessage":"Será uma proposta válida uma vez que <span class=\"text-info\">{$moreVotes}</span> mais votos sejam enviados.","key":"Chave","value":"Valor","amount":"Quantidade","recipient":"Recebedor","changes":"Alterações","subspace":"Subespaço"},"votingPower":{"distribution":"Distribuição do poder de voto","pareto":"Princípio de Pareto (regra 20/80)","minValidators34":"Número mínimo de validadores que detem 34%+ de poder"},"accounts":{"accountDetails":"Detalhes da conta","available":"disponível","delegated":"delegado","unbonding":"desvinculação","rewards":"Recompensas","total":"Total","notFound":"Essa conta não existe. Você está informando o endereço correto?","validators":"Validadores","shares":"Ações","mature":"Mature","no":"Não ","none":"Sem ","delegation":"delegação","plural":"s","signOut":"Sair","signInText":"Você está conectado como ","toLoginAs":"Para entrar como","signInWithLedger":"Entrar com Ledger","signInWarning":"Certifique-se de que seu dispositivo Ledger esteja conectado e o <strong class=\"text-primary\">{$network} App {$version} ou superior</strong> esteja aberto.","pleaseAccept":"por favor, aceite em seu dispositivo Ledger.","noRewards":"Sem recompensas"},"activities":{"single":"A","happened":"aconteceu.","senders":"O(s) seguinte(s) remetente(s)","sent":"enviado","receivers":"para o(s) seguinte(s) destinatário(s)","received":"recebido","failedTo":"falhou em","to":"para","from":"de","operatingAt":"operado por","withMoniker":"com o apelido","withTitle":"com o título","withA":"com"},"messageTypes":{"send":"Enviou","multiSend":"Envio múltiplo","createValidator":"Criar Validador","editValidator":"Editar Validador","delegate":"Delegar","undelegate":"Undelegar","redelegate":"Redelegar","submitProposal":"Enviar proposta","deposit":"Depósito","vote":"Vote","withdrawComission":"Retirar Comissão","withdrawReward":"Retirar Recompensa","modifyWithdrawAddress":"Modificar Endereço de Retirada","unjail":"Sair da jaula","IBCTransfer":"IBC transferido","IBCReceive":"IBC recebido"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ru-RU.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/ru-RU.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('ru-RU','',{"common":{"height":"высота блока","voter":"избиратель","votingPower":"право голоса","addresses":"Адреса","amounts":"Суммы","delegators":"делегаторы","block":"блок","blocks":"блоки","precommit":"прикоммит","precommits":"прикоммиты","last":"последний","backToList":"назад к списку","information":"информация","time":"время","hash":"хэш","more":"дальше","fullStop":".","searchPlaceholder":"Поиск с хэшем сделки / высотой блока / адресом","cancel":"отменять","retry":"Повторить попытку","rewards":"награды"},"navbar":{"siteName":"BIG DIPPER","validators":"валидаторы","blocks":"блоки","transactions":"транзакции","proposals":"Предложения","votingPower":"право голоса","lang":"RU","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","portuguese":"Português","license":"ЛИЦЕНЗИЯ","forkMe":"Форк!'"},"consensus":{"consensusState":"состояние консенсуса","round":"раунд","step":"этап"},"chainStates":{"price":"расценка","marketCap":"рыночная капитализация","inflation":"Инфляция","communityPool":"коммьюнити пул"},"chainStatus":{"startMessage":"Чейн собирается начать в","stopWarning":"Наверное, чейн остановлен из-за ! Накорми меня новыми блоками 😭!","latestHeight":"Последняя Высота Блока","averageBlockTime":"Среднее Время Блока","all":"Всё","now":"Сейчас","allTime":"всё время","lastMinute":"последняя минута","lastHour":"последний час","lastDay":"последний день","seconds":"секунды","activeValidators":"активные валидаторы","outOfValidators":"из {$totalValidators} валидаторах","onlineVotingPower":"онлайн право голоса","fromTotalStakes":"{$percent} от {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"История Времени Блока","averageBlockTime":"Среднее Время Блока","blockInterval":"Интервал Блока","noOfValidators":"количество валидаторов"},"validators":{"randomValidators":"Случайные Валидаторы","moniker":"Кличка","uptime":"Рабочее время","selfPercentage":"Сам%","commission":"Комиссия","lastSeen":"Последний увиденный","status":"Статус","jailed":"Тюрьма","navActive":"Активный","navInactive":"Неактивный","active":"Активные валидаторы","inactive":"Неактивные валидаторы","listOfActive":"Вот список активных валидаторов.","listOfInactive":"Вот список неактивных валидаторов.","validatorDetails":"Детали валидатора","lastNumBlocks":"Последние {$numBlocks} блоки","validatorInfo":"Информация о валидаторе","operatorAddress":"Адрес оператора","selfDelegationAddress":"Адрес самоделегирования","commissionRate":"Ставка Комиссии","maxRate":"Максимальная Ставка","maxChangeRate":"Максимальная Ставка Изменения","selfDelegationRatio":"Коэффициент самостоятельной делегации","proposerPriority":"Приоритет предложения","delegatorShares":"Доли делегатора","userDelegateShares":"Доли, делегированные вами","tokens":"Токены","unbondingHeight":"высота Un-Бондинг","unbondingTime":"Время Un-Бондинг","powerChange":"Изменение власти","delegations":"Делегации","transactions":"транзакции","validatorNotExists":"Валидатор не существует.","backToValidator":"Назад к валидатору","missedBlocks":"Пропущенные блоки","missedPrecommits":"опущенные прикоммиты","missedBlocksTitle":"опущенные блоки {$moniker}","totalMissed":"Всего пропущено","block":"Блок","missedCount":"опущенные отсчеты","iDontMiss":"Я не пропускаю","lastSyncTime":"Последнее время синхронизации","delegator":"Делегатор","amount":"Сумма"},"blocks":{"block":"Блок","proposer":"Предложение","latestBlocks":"Последние блоки","noBlock":"Нет блока.","numOfTxs":"количество сделок","numOfTransactions":"количество сделок","notFound":"Такого блока не найдено."},"transactions":{"transaction":"Сделка","transactions":"Сделки","notFound":"Не найдено.","activities":"Деятельность","txHash":"хэш сделки","valid":"Действительны","fee":"Плата","gasUsedWanted":"Газ (используется / хотел)","noTxFound":"Сделка не найдена","noValidatorTxsFound":"Сделка связанной с этом валидатором не найдена.","memo":"Записка","transfer":"Передача","staking":"Стейкать","distribution":"Распределение","governance":"Управление","slashing":"Сокращение"},"proposals":{"notFound":"Ни одно предложение не найдено.","listOfProposals":"список предложений по управлению","proposer":"Предлагающий","proposal":"Предложение","proposals":"Предложения","proposalID":"ID предложений","title":"Название","status":"Статус","submitTime":"Время Отправки","depositEndTime":"Время Окончания Депозита","votingStartTime":"Время Начала Голосования","votingEndTime":"Время Окончания Голосования","totalDeposit":"Общий депозит","description":"Описание","proposalType":"Тип Предложения","proposalStatus":"Статус Предложения","notStarted":"не начался","final":"окончательный","deposit":"Депозит","tallyResult":"Итог Подсчета","yes":"За","abstain":"Воздержался","no":"Против","noWithVeto":"Против с правом Вето","percentageVoted":"<span class=\"text-info\">{$percent}</span> количество голосов онлайн проголосовало.","validMessage":"Это предположение {$tentative}<strong>действительное</strong>.","invalidMessage":"Меньше чем {$quorum} количество голосов проголосовало. Это предположение <strong>недействительное</strong>.","moreVoteMessage":"Это будет действительным если<span class=\"text-info\">{$moreVotes}</span> большее количество голосов."},"votingPower":{"distribution":"Распределение количество голосов","pareto":"Принцип Парето (правило 20/80)","minValidators34":"Минимальное количество валидаторов c 34%+ количеством голосов"},"accounts":{"accountDetails":"Детали счета","available":"Доступный","delegated":"Делегирование","unbonding":"Un-Бондинг","rewards":"Награды","total":"Общее количество","notFound":"Такого счета не существует. Вы ищете неправильный адрес?","validators":"Валидаторы","shares":"Доли","mature":"Зрелые","no":"Нет","delegation":"Делегация","plural":"множественное число","signOut":"Выйти","signInText":"Войти","toLoginAs":"Войти","signInWithLedger":"Войти с Ledger","signInWarning":"Пожалуйста, убедитесь, что устройство Ledger подключен и <strong class=\"text-primary\">{$network} App {$version} или выше </strong> открыто.","pleaseAccept":"пожалуйста, примите в свой Ledger устройство."},"activities":{"single":" ","happened":"получилось.","senders":"Следующие отправителя (ей)","sent":"отправлено","receivers":"к следующему получателю(ам)","received":"полученный","failedTo":"не удалось","to":"к","from":"из'","operatingAt":"работающих на","withMoniker":"с кличкой","withTitle":"с названием","withA":"с"},"messageTypes":{"send":"Отправить","multiSend":"Отправить многократно","createValidator":"Создание валидатор","editValidator":"Редактировать валидатор","delegate":"делегировать","undelegate":"Un-делегировать","redelegate":"Ре-делегировать","submitProposal":"Отправлять Предложение","deposit":"Депозит","vote":"Голосовать","withdrawComission":"Выводить Комиссии","withdrawReward":"Выводить Награду","modifyWithdrawAddress":"Изменить Адрес Вывода","unjail":"Un-Джейл","IBCTransfer":"IBC Трансферт","IBCReceive":"IBC Получение"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hans.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hans.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hans','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票权","addresses":"地址","amounts":"数量","delegators":"委托人","block":"区块","blocks":"区块","precommit":"建块前保证","precommits":"建块前保证","last":"最后","backToList":"回到列表","information":"资讯","time":"时间","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜寻交易哈希 / 区块高度 / 地址","cancel":"取消","retry":"重试","bondedTokens":"受委托量"},"navbar":{"siteName":"北斗","validators":"验证人","blocks":"区块","transactions":"交易","proposals":"治理提案","votingPower":"投票权分布","lang":"中文（简）","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","portuguese":"Português","license":"LICENSE","forkMe":"Fork me!"},"consensus":{"consensusState":"共识状态","round":"轮数","step":"阶数"},"chainStates":{"price":"价格","marketCap":"市值","inflation":"通胀率","communityPool":"社区储备"},"chainStatus":{"startMessage":"这链将还有以下时间便会开始","stopWarning":"这链似乎已经停了 <em>{$time}</em>！ 请继续喂我吃新的区块 😭!","latestHeight":"最新区块高度","averageBlockTime":"平均区块时间","all":"全部","now":"现在","allTime":"全部","lastMinute":"前一分钟","lastHour":"前一小时","lastDay":"前一天","seconds":"秒","activeValidators":"有效验证人","outOfValidators":"来自总共 {$totalValidators} 个验证人","onlineVotingPower":"在线投票权","fromTotalStakes":"为 {$totalStakes} 颗 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在线投票权","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"随机验证人","moniker":"验证人代号","uptime":"上线时间比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最后投票时间","status":"状态","jailed":"被禁制","navActive":"有效","navInactive":"无效","active":"有效验证人","inactive":"无效验证人","listOfActive":"这名单显示所有有效验证人","listOfInactive":"这名单显示所有无效验证人","validatorDetails":"验证人详情","lastNumBlocks":"最后 {$numBlocks} 个区块","validatorInfo":"验证人资讯","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金变化限制","selfDelegationRatio":"自我委托比例","proposerPriority":"建块优先权","delegatorShares":"委托股数","userDelegateShares":"你委托的股数","tokens":"代币数量","unbondingHeight":"解绑高度","unbondingTime":"解绑时间","jailedUntil":"被禁制至","powerChange":"投票权变更","delegations":"委托","transactions":"交易","validatorNotExists":"验证人不存在。","backToValidator":"回到验证人页面","missedBlocks":"错过了的区块","missedPrecommits":"遗留了的建块前保证","missedBlocksTitle":"错过了 {$moniker} 的区块","totalMissed":"一共错过了","block":"区块","missedCount":"错过数量","iDontMiss":"我不会错过任何一个","lastSyncTime":"上一次同步时间","delegator":"委托人","amount":"数量"},"blocks":{"proposer":"建块人","block":"区块","latestBlocks":"最近区块","noBlock":"没有区块。","numOfTxs":"交易数量","numOfTransactions":"交易数量","notFound":"没有这个区块。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活动","txHash":"交易哈希","valid":"有效","fee":"费用","noFee":"No fee","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"没有这笔交易。","noValidatorTxsFound":"没有跟这个验证人有关的交易","memo":"备忘录","transfer":"代币转移","staking":"委托","distribution":"收益分配","governance":"链上治理","slashing":"削减"},"proposals":{"notFound":"没有治理提案","listOfProposals":"这名单显示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案编号","title":"主题","status":"状态","submitTime":"提案时间","depositEndTime":"存入押金","votingStartTime":"投票开始时间","votingEndTime":"投票结束时间","totalDeposit":"押金总额","description":"详细内容","proposalType":"提案类型","proposalStatus":"提案状态","notStarted":"未开始","final":"最后结果","deposit":"押金","tallyResult":"投票结果","yes":"赞成","abstain":"弃权","no":"反对","noWithVeto":"强烈反对","percentageVoted":"现时在线投票权的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"这个提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在线投票权少于 {$quorum}。这个提案 <strong>無效</strong>。","moreVoteMessage":"当再有多 <span class=\"text-info\">{$moreVotes}</span> 投票权投了票的话，这个提案将会有效。","key":"Key","value":"Value","amount":"Amount","recipient":"Recipient","changes":"Changes","subspace":"Subspace"},"votingPower":{"distribution":"投票权分布","pareto":"帕累托原则 (20/80 定率)","minValidators34":"最少合共有超过 34% 投票权的验证人"},"accounts":{"accountDetails":"帐户详情","available":"可用的","delegated":"委托中","unbonding":"解绑中","rewards":"未取回收益","total":"总共","notFound":"这个帐户不存在。你是否在查看一个错误的地址？","validators":"验证人","shares":"股数","mature":"成熟日期","no":"没有","none":"没有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登录以下帐户","toLoginAs":"登录以下帐户","signInWithLedger":"透过 Ledger 登录","signInWarning":"请确定你已经连接 Ledger 设备，并已开启 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"请从你的 Ledger 设备确认。","noRewards":"No Rewards"},"activities":{"single":"一个","happened":"发生了","senders":"以下的帐户","sent":"发了","receivers":"到以下的帐户","received":"收到","failedTo":"未能","to":"到","from":"从","operatingAt":"操作地址为","withMoniker":"而验证人代号为","withTitle":"治理提案主题为","withA":"投了"},"messageTypes":{"send":"发送","multiSend":"多重发送","createValidator":"建立验证人","editValidator":"编辑验证人资料","delegate":"委托","undelegate":"解委托","redelegate":"转委托","submitProposal":"提交议案","deposit":"存入","vote":"投票","withdrawComission":"提取手续费","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hant.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hant.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hant','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票權","addresses":"地址","amounts":"數量","delegators":"委托人","block":"區塊","blocks":"區塊","precommit":"建塊前保證","precommits":"建塊前保證","last":"最後","backToList":"回到列表","information":"資訊","time":"時間","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜尋交易哈希 / 區塊高度 / 地址","cancel":"取消","retry":"重試","bondedTokens":"受委托量"},"navbar":{"siteName":"北斗","validators":"驗證人","blocks":"區塊","transactions":"交易","proposals":"治理提案","votingPower":"投票權分佈","lang":"中文（繁）","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","portuguese":"Português","license":"LICENSE","forkMe":"Fork me!"},"consensus":{"consensusState":"共識狀態","round":"輪數","step":"階數"},"chainStates":{"price":"價格","marketCap":"市值","inflation":"通漲率","communityPool":"社區儲備"},"chainStatus":{"startMessage":"這鏈將還有以下時間便會開始","stopWarning":"這鏈似乎已經停了 <em>{$time}</em>！ 請繼續餵我吃新的區塊 😭!","latestHeight":"最新區塊高度","averageBlockTime":"平均區塊時間","all":"全部","now":"現在","allTime":"全部","lastMinute":"前一分鐘","lastHour":"前一小時","lastDay":"前一天","seconds":"秒","activeValidators":"有效驗證人","outOfValidators":"來自總共 {$totalValidators} 個驗證人","onlineVotingPower":"在線投票權","fromTotalStakes":"為 {$totalStakes} 顆 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在線投票權","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"隨機驗證人","moniker":"驗證人代號","uptime":"上線時間比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最後投票時間","status":"狀態","jailed":"被禁制","navActive":"有效","navInactive":"無效","active":"有效驗證人","inactive":"無效驗證人","listOfActive":"這名單顯示所有有效驗證人","listOfInactive":"這名單顯示所有無效驗證人","validatorDetails":"驗證人詳情","lastNumBlocks":"最後 {$numBlocks} 個區塊","validatorInfo":"驗證人資訊","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金變化限制","selfDelegationRatio":"自我委托比列","proposerPriority":"建塊優先權","delegatorShares":"委托股數","userDelegateShares":"你委托的股數","tokens":"代幣數量","unbondingHeight":"解綁高度","unbondingTime":"解綁時間","jailedUntil":"被禁制至","powerChange":"投票權變更","delegations":"委托","transactions":"交易","validatorNotExists":"驗證人不存在。","backToValidator":"回到驗證人頁面","missedBlocks":"錯過了的區塊","missedPrecommits":"遺留了的建塊前保證","missedBlocksTitle":"錯過了 {$moniker} 的區塊","totalMissed":"一共錯過了","block":"區塊","missedCount":"錯過數量","iDontMiss":"我不會錯過任何一個","lastSyncTime":"上一次同步時間","delegator":"委托人","amount":"數量"},"blocks":{"proposer":"建塊人","block":"區塊","latestBlocks":"最近區塊","noBlock":"沒有區塊。","numOfTxs":"交易數量","numOfTransactions":"交易數量","notFound":"沒有這個區塊。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活動","txHash":"交易哈希","valid":"有效","fee":"費用","noFee":"No fee","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"沒有這筆交易。","noValidatorTxsFound":"沒有跟這個驗證人有關的交易","memo":"備忘錄","transfer":"代幣轉移","staking":"委托","distribution":"收益分配","governance":"鏈上治理","slashing":"削減"},"proposals":{"notFound":"沒有治理提案","listOfProposals":"這名單顯示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案編號","title":"主題","status":"狀態","submitTime":"提案時間","depositEndTime":"存入押金","votingStartTime":"投票開始時間","votingEndTime":"投票結束時間","totalDeposit":"押金總額","description":"詳細內容","proposalType":"提案類型","proposalStatus":"提案狀態","notStarted":"未開始","final":"最後結果","deposit":"押金","tallyResult":"投票結果","yes":"贊成","abstain":"棄權","no":"反對","none":"反對","noWithVeto":"強烈反對","percentageVoted":"現時在線投票權的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"這個提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在線投票權少於 {$quorum}。這個 <strong>無效</strong>。","moreVoteMessage":"當再有多 <span class=\"text-info\">{$moreVotes}</span> 投票權投了票的話，這個提案將會有效。","key":"Key","value":"Value","amount":"Amount","recipient":"Recipient","changes":"Changes","subspace":"Subspace"},"votingPower":{"distribution":"投票權分佈","pareto":"帕累托原則 (20/80 定率)","minValidators34":"最少合共有超過 34% 投票權的驗證人"},"accounts":{"accountDetails":"帳戶詳情","available":"可用的","delegated":"委托中","unbonding":"解綁中","rewards":"未取回收益","total":"總共","notFound":"這個帳戶不存在。你是否在查看一個錯誤的地址？","validators":"驗證人","shares":"股數","mature":"成熟日期","no":"沒有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登入以下帳戶","toLoginAs":"登入以下帳戶","signInWithLedger":"透過 Ledger 登入","signInWarning":"請確定你已經連接 Ledger 設備，並已開啓 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"請從你的 Ledger 設備確認。","noRewards":"No Rewards"},"activities":{"single":"一個","happened":"發生了","senders":"以下的帳戶","sent":"發了","receivers":"到以下的帳戶","received":"收到","failedTo":"未能","to":"到","from":"從","operatingAt":"操作地止為","withMoniker":"而驗證人代號為","withTitle":"治理提案主題為","withA":"投了"},"messageTypes":{"send":"發送","multiSend":"多重發送","createValidator":"建立驗證人","editValidator":"編輯驗證人資料","delegate":"委托","undelegate":"解委托","redelegate":"轉委托","submitProposal":"提交議案","deposit":"存入","vote":"投票","withdrawComission":"提取手續費","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"utils":{"coins.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/utils/coins.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => Coin
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let numbro;
module.link("numbro", {
  default(v) {
    numbro = v;
  }

}, 1);

autoformat = value => {
  let formatter = '0,0.0000';
  value = Math.round(value * 1000) / 1000;
  if (Math.round(value) === value) formatter = '0,0';else if (Math.round(value * 10) === value * 10) formatter = '0,0.0';else if (Math.round(value * 100) === value * 100) formatter = '0,0.00';else if (Math.round(value * 1000) === value * 1000) formatter = '0,0.000';
  return numbro(value).format(formatter);
};

const coinList = Meteor.settings.public.coins;

class Coin {
  constructor(amount) {
    let denom = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Meteor.settings.public.bondDenom;
    const lowerDenom = denom.toLowerCase();
    this._coin = coinList.find(coin => coin.denom.toLowerCase() === lowerDenom || coin.displayName.toLowerCase() === lowerDenom);

    if (this._coin) {
      if (lowerDenom === this._coin.denom.toLowerCase()) {
        this._amount = Number(amount);
      } else if (lowerDenom === this._coin.displayName.toLowerCase()) {
        this._amount = Number(amount) * this._coin.fraction;
      }
    } else {
      this._coin = "";
      this._amount = Number(amount);
    }
  }

  get amount() {
    return this._amount;
  }

  get stakingAmount() {
    return this._coin ? this._amount / this._coin.fraction : this._amount;
  }

  toString(precision) {
    // default to display in mint denom if it has more than 4 decimal places
    let minStake = Coin.StakingCoin.fraction / (precision ? Math.pow(10, precision) : 10000);

    if (this.amount < minStake) {
      return "".concat(numbro(this.amount).format('0,0.0000'), " ").concat(this._coin.denom);
    } else {
      return "".concat(precision ? numbro(this.stakingAmount).format('0,0.' + '0'.repeat(precision)) : autoformat(this.stakingAmount), " ").concat(this._coin.displayName);
    }
  }

  mintString(formatter) {
    let amount = this.amount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    let denom = this._coin == "" ? Coin.StakingCoin.displayName : this._coin.denom;
    return "".concat(amount, " ").concat(denom);
  }

  stakeString(formatter) {
    let amount = this.stakingAmount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.StakingCoin.displayName);
  }

}

Coin.StakingCoin = coinList.find(coin => coin.denom === Meteor.settings.public.bondDenom);
Coin.MinStake = 1 / Number(Coin.StakingCoin.fraction);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"time.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/utils/time.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  goTimeToISOString: () => goTimeToISOString
});

const goTimeToISOString = time => {
  const millisecond = parseInt(time.seconds + time.nanos.toString().substring(0, 3));
  return new Date(millisecond).toISOString();
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("/imports/startup/server");
module.link("/imports/startup/both");
// import moment from 'moment';
// import '/imports/api/blocks/blocks.js';
SYNCING = false;
TXSYNCING = false;
COUNTMISSEDBLOCKS = false;
COUNTMISSEDBLOCKSSTATS = false;
RPC = Meteor.settings.remote.rpc;
API = Meteor.settings.remote.api;
timerBlocks = 0;
timerTransactions = 0;
timerChain = 0;
timerConsensus = 0;
timerProposal = 0;
timerProposalsResults = 0;
timerMissedBlock = 0;
timerDelegation = 0;
timerAggregate = 0;
const DEFAULTSETTINGS = '/default_settings.json';

updateChainStatus = () => {
  Meteor.call('chain.updateStatus', (error, result) => {
    if (error) {
      console.log("updateStatus: %o", error);
    } else {
      console.log("updateStatus: %o", result);
    }
  });
};

updateBlock = () => {
  Meteor.call('blocks.blocksUpdate', (error, result) => {
    if (error) {
      console.log("updateBlocks: %o", error);
    } else {
      console.log("updateBlocks: %o", result);
    }
  });
};

updateTransactions = () => {
  Meteor.call('Transactions.updateTransactions', (error, result) => {
    if (error) {
      console.log("updateTransactions: %o", error);
    } else {
      console.log("updateTransactions: %o", result);
    }
  });
};

getConsensusState = () => {
  Meteor.call('chain.getConsensusState', (error, result) => {
    if (error) {
      console.log("get consensus: %o", error);
    }
  });
};

getProposals = () => {
  Meteor.call('proposals.getProposals', (error, result) => {
    if (error) {
      console.log("get proposal: %o", error);
    }

    if (result) {
      console.log("get proposal: %o", result);
    }
  });
};

getProposalsResults = () => {
  Meteor.call('proposals.getProposalResults', (error, result) => {
    if (error) {
      console.log("get proposals result: %o", error);
    }

    if (result) {
      console.log("get proposals result: %o", result);
    }
  });
};

updateMissedBlocks = () => {
  Meteor.call('ValidatorRecords.calculateMissedBlocks', (error, result) => {
    if (error) {
      console.log("missed blocks error: %o", error);
    }

    if (result) {
      console.log("missed blocks ok: %o", result);
    }
  });
};

getDelegations = () => {
  Meteor.call('delegations.getDelegations', (error, result) => {
    if (error) {
      console.log("get delegations error: %o", error);
    } else {
      console.log("get delegations ok: %o", result);
    }
  });
};

aggregateMinutely = () => {
  // doing something every min
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "m", (error, result) => {
    if (error) {
      console.log("aggregate minutely block time error: %o", error);
    } else {
      console.log("aggregate minutely block time ok: %o", result);
    }
  });
  Meteor.call('coinStats.getCoinStats', (error, result) => {
    if (error) {
      console.log("get coin stats error: %o", error);
    } else {
      console.log("get coin stats ok: %o", result);
    }
  });
};

aggregateHourly = () => {
  // doing something every hour
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "h", (error, result) => {
    if (error) {
      console.log("aggregate hourly block time error: %o", error);
    } else {
      console.log("aggregate hourly block time ok: %o", result);
    }
  });
};

aggregateDaily = () => {
  // doing somthing every day
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "d", (error, result) => {
    if (error) {
      console.log("aggregate daily block time error: %o", error);
    } else {
      console.log("aggregate daily block time ok: %o", result);
    }
  });
  Meteor.call('Analytics.aggregateValidatorDailyBlockTime', (error, result) => {
    if (error) {
      console.log("aggregate validators block time error: %o", error);
    } else {
      console.log("aggregate validators block time ok: %o", result);
    }
  });
};

Meteor.startup(function () {
  return Promise.asyncApply(() => {
    if (Meteor.isDevelopment) {
      let DEFAULTSETTINGSJSON;
      module.link("../default_settings.json", {
        default(v) {
          DEFAULTSETTINGSJSON = v;
        }

      }, 0);
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
      Object.keys(DEFAULTSETTINGSJSON).forEach(key => {
        if (Meteor.settings[key] == undefined) {
          console.warn("CHECK SETTINGS JSON: ".concat(key, " is missing from settings"));
          Meteor.settings[key] = {};
        }

        Object.keys(DEFAULTSETTINGSJSON[key]).forEach(param => {
          if (Meteor.settings[key][param] == undefined) {
            console.warn("CHECK SETTINGS JSON: ".concat(key, ".").concat(param, " is missing from settings"));
            Meteor.settings[key][param] = DEFAULTSETTINGSJSON[key][param];
          }
        });
      });
    }

    if (Meteor.settings.debug.startTimer) {
      timerConsensus = Meteor.setInterval(function () {
        getConsensusState();
      }, Meteor.settings.params.consensusInterval);
      timerBlocks = Meteor.setInterval(function () {
        updateBlock();
      }, Meteor.settings.params.blockInterval);
      timerTransactions = Meteor.setInterval(function () {
        updateTransactions();
      }, Meteor.settings.params.transactionsInterval);
      timerChain = Meteor.setInterval(function () {
        updateChainStatus();
      }, Meteor.settings.params.statusInterval);

      if (Meteor.settings.public.modules.gov) {
        timerProposal = Meteor.setInterval(function () {
          getProposals();
        }, Meteor.settings.params.proposalInterval);
        timerProposalsResults = Meteor.setInterval(function () {
          getProposalsResults();
        }, Meteor.settings.params.proposalInterval);
      }

      timerMissedBlock = Meteor.setInterval(function () {
        updateMissedBlocks();
      }, Meteor.settings.params.missedBlocksInterval); // timerDelegation = Meteor.setInterval(function(){
      //     getDelegations();
      // }, Meteor.settings.params.delegationInterval);

      timerAggregate = Meteor.setInterval(function () {
        let now = new Date();

        if (now.getUTCSeconds() == 0) {
          aggregateMinutely();
        }

        if (now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
          aggregateHourly();
        }

        if (now.getUTCHours() == 0 && now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
          aggregateDaily();
        }
      }, 1000);
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"default_settings.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// default_settings.json                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "public": {
    "chainName": "zenchain",
    "chainId": "zenchain",
    "gtm": "{Add your Google Tag Manager ID here}",
    "slashingWindow": 10000,
    "uptimeWindow": 250,
    "initialPageSize": 30,
    "secp256k1": false,
    "bech32PrefixAccAddr": "zen",
    "bech32PrefixAccPub": "zenpub",
    "bech32PrefixValAddr": "zenvaloper",
    "bech32PrefixValPub": "zenvaloperpub",
    "bech32PrefixConsAddr": "zenvalcons",
    "bech32PrefixConsPub": "zenvalconspub",
    "bondDenom": "uzen",
    "powerReduction": 1000000,
    "coins": [
      {
        "denom": "uzen",
        "displayName": "ZEN",
        "fraction": 1000000
      }
    ],
    "ledger": {
      "coinType": 118,
      "appName": "Cosmos",
      "appVersion": "2.16.0",
      "gasPrice": 0.02
    },
    "modules": {
      "bank": true,
      "supply": true,
      "minting": false,
      "gov": true,
      "distribution": false
    },
    "coingeckoId": "cosmos"
  },
  "remote": {
    "rpc": "http://45.63.22.19:26657",
    "api": "http://45.63.22.19:1317"
  },
  "debug": {
    "startTimer": true
  },
  "params": {
    "startHeight": 0,
    "defaultBlockTime": 5000,
    "validatorUpdateWindow": 300,
    "blockInterval": 15000,
    "transactionsInterval": 18000,
    "keybaseFetchingInterval": 18000000,
    "consensusInterval": 1000,
    "statusInterval": 7500,
    "signingInfoInterval": 1800000,
    "proposalInterval": 5000,
    "missedBlocksInterval": 60000,
    "delegationInterval": 900000
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".mjs",
    ".jsx",
    ".i18n.yml"
  ]
});

require("/both/i18n/en-us.i18n.yml.js");
require("/both/i18n/es-es.i18n.yml.js");
require("/both/i18n/it-IT.i18n.yml.js");
require("/both/i18n/pl-PL.i18n.yml.js");
require("/both/i18n/pt-BR.i18n.yml.js");
require("/both/i18n/ru-RU.i18n.yml.js");
require("/both/i18n/zh-hans.i18n.yml.js");
require("/both/i18n/zh-hant.i18n.yml.js");
require("/both/utils/coins.js");
require("/both/utils/time.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWNjb3VudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYmxvY2tzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9ibG9ja3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2NoYWluL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9jaGFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZGVsZWdhdGlvbnMvZGVsZWdhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2xlZGdlci9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcHJvcG9zYWxzL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9wcm9wb3NhbHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcHJvcG9zYWxzL3Byb3Bvc2Fscy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVjb3Jkcy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVjb3Jkcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9yZWNvcmRzL3JlY29yZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3N0YXR1cy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zdGF0dXMvc3RhdHVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3RyYW5zYWN0aW9ucy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdm90aW5nLXBvd2VyL2hpc3RvcnkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2V2aWRlbmNlcy9ldmlkZW5jZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3ZhbGlkYXRvci1zZXRzL3ZhbGlkYXRvci1zZXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvYm90aC9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9jcmVhdGUtaW5kZXhlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9yZWdpc3Rlci1hcGkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvdXRpbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91aS9jb21wb25lbnRzL0ljb25zLmpzeCIsIm1ldGVvcjovL/CfkrthcHAvYm90aC91dGlscy9jb2lucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC91dGlscy90aW1lLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJNZXRlb3IiLCJtb2R1bGUiLCJsaW5rIiwidiIsIkhUVFAiLCJWYWxpZGF0b3JzIiwiZmV0Y2hGcm9tVXJsIiwidXJsIiwicmVzIiwiZ2V0IiwiQVBJIiwic3RhdHVzQ29kZSIsImUiLCJjb25zb2xlIiwibG9nIiwibWV0aG9kcyIsImFkZHJlc3MiLCJ1bmJsb2NrIiwiYXZhaWxhYmxlIiwicmVzcG9uc2UiLCJKU09OIiwicGFyc2UiLCJjb250ZW50IiwicmVzdWx0IiwiYWNjb3VudCIsInR5cGUiLCJ2YWx1ZSIsIkJhc2VWZXN0aW5nQWNjb3VudCIsIkJhc2VBY2NvdW50IiwiYmFsYW5jZXMiLCJjb2lucyIsImFjY291bnRfbnVtYmVyIiwiYmFsYW5jZSIsImRlbGVnYXRpb25zIiwiZGVsZWdhdGlvbl9yZXNwb25zZXMiLCJ1bmJvbmRpbmciLCJ1bmJvbmRpbmdfcmVzcG9uc2VzIiwicmV3YXJkcyIsInRvdGFsX3Jld2FyZHMiLCJ0b3RhbCIsInZhbGlkYXRvciIsImZpbmRPbmUiLCIkb3IiLCJvcGVyYXRvcl9hZGRyZXNzIiwiZGVsZWdhdG9yX2FkZHJlc3MiLCJvcGVyYXRvckFkZHJlc3MiLCJjb21taXNzaW9uIiwibGVuZ3RoIiwiZGF0YSIsImRlbGVnYXRpb25fcmVzcG9uc2UiLCJkZWxlZ2F0aW9uIiwic2hhcmVzIiwicGFyc2VGbG9hdCIsInJlbGVnYXRpb25zIiwicmVkZWxlZ2F0aW9uX3Jlc3BvbnNlcyIsImNvbXBsZXRpb25UaW1lIiwiZm9yRWFjaCIsInJlbGVnYXRpb24iLCJlbnRyaWVzIiwidGltZSIsIkRhdGUiLCJjb21wbGV0aW9uX3RpbWUiLCJyZWRlbGVnYXRpb25Db21wbGV0aW9uVGltZSIsInVuZGVsZWdhdGlvbnMiLCJ1bmJvbmRpbmdDb21wbGV0aW9uVGltZSIsImkiLCJ1bmJvbmRpbmdzIiwicmVkZWxlZ2F0aW9ucyIsInJlZGVsZWdhdGlvbiIsInZhbGlkYXRvcl9kc3RfYWRkcmVzcyIsImNvdW50IiwidXNlclJlZGVsZWdhdGlvbnMiLCJCbG9ja3Njb24iLCJDaGFpbiIsIlZhbGlkYXRvclNldHMiLCJWYWxpZGF0b3JSZWNvcmRzIiwiQW5hbHl0aWNzIiwiVlBEaXN0cmlidXRpb25zIiwiVm90aW5nUG93ZXJIaXN0b3J5IiwiVHJhbnNhY3Rpb25zIiwiRXZpZGVuY2VzIiwic2hhMjU2IiwiY2hlZXJpbyIsImdldFJlbW92ZWRWYWxpZGF0b3JzIiwicHJldlZhbGlkYXRvcnMiLCJ2YWxpZGF0b3JzIiwicCIsInNwbGljZSIsImdldFZhbGlkYXRvckZyb21Db25zZW5zdXNLZXkiLCJjb25zZW5zdXNLZXkiLCJwdWJrZXlUeXBlIiwic2V0dGluZ3MiLCJwdWJsaWMiLCJzZWNwMjU2azEiLCJwdWJrZXkiLCJjYWxsIiwicHViX2tleSIsImdldFZhbGlkYXRvclByb2ZpbGVVcmwiLCJpZGVudGl0eSIsInRoZW0iLCJwaWN0dXJlcyIsInByaW1hcnkiLCJzdHJpbmdpZnkiLCJpbmRleE9mIiwidGVhbVBhZ2UiLCJwYWdlIiwibG9hZCIsImF0dHIiLCJnZXRWYWxpZGF0b3JVcHRpbWUiLCJ2YWxpZGF0b3JTZXQiLCJzbGFzaGluZ1BhcmFtcyIsInVwc2VydCIsImNoYWluSWQiLCIkc2V0Iiwia2V5IiwiYmVjaDMyVmFsQ29uc0FkZHJlc3MiLCJzaWduaW5nSW5mbyIsInZhbF9zaWduaW5nX2luZm8iLCJ2YWxEYXRhIiwidG9tYnN0b25lZCIsImphaWxlZF91bnRpbCIsImluZGV4X29mZnNldCIsInBhcnNlSW50Iiwic3RhcnRfaGVpZ2h0IiwidXB0aW1lIiwicGFyYW1zIiwic2lnbmVkX2Jsb2Nrc193aW5kb3ciLCJtaXNzZWRfYmxvY2tzX2NvdW50ZXIiLCJjYWxjdWxhdGVWUERpc3QiLCJhbmFseXRpY3NEYXRhIiwiYmxvY2tEYXRhIiwiYWN0aXZlVmFsaWRhdG9ycyIsImZpbmQiLCJzdGF0dXMiLCJqYWlsZWQiLCJzb3J0Iiwidm90aW5nX3Bvd2VyIiwiZmV0Y2giLCJudW1Ub3BUd2VudHkiLCJNYXRoIiwiY2VpbCIsIm51bUJvdHRvbUVpZ2h0eSIsInRvcFR3ZW50eVBvd2VyIiwiYm90dG9tRWlnaHR5UG93ZXIiLCJudW1Ub3BUaGlydHlGb3VyIiwibnVtQm90dG9tU2l4dHlTaXgiLCJ0b3BUaGlydHlGb3VyUGVyY2VudCIsImJvdHRvbVNpeHR5U2l4UGVyY2VudCIsInZwRGlzdCIsImhlaWdodCIsIm51bVZhbGlkYXRvcnMiLCJ0b3RhbFZvdGluZ1Bvd2VyIiwiYmxvY2tUaW1lIiwiY3JlYXRlQXQiLCJpbnNlcnQiLCJibG9ja3MiLCJwcm9wb3NlckFkZHJlc3MiLCJoZWlnaHRzIiwibWFwIiwiYmxvY2siLCJibG9ja3NTdGF0cyIsIiRpbiIsInRvdGFsQmxvY2tEaWZmIiwiYiIsInRpbWVEaWZmIiwiUlBDIiwic3luY19pbmZvIiwibGF0ZXN0X2Jsb2NrX2hlaWdodCIsImN1cnJIZWlnaHQiLCJsaW1pdCIsInN0YXJ0SGVpZ2h0IiwiU1lOQ0lORyIsInVudGlsIiwiY3VyciIsImNvbnNlbnN1c19wdWJrZXkiLCJ0b3RhbFZhbGlkYXRvcnMiLCJPYmplY3QiLCJrZXlzIiwidXBkYXRlIiwic3RhcnRCbG9ja1RpbWUiLCJidWxrVmFsaWRhdG9ycyIsInJhd0NvbGxlY3Rpb24iLCJpbml0aWFsaXplVW5vcmRlcmVkQnVsa09wIiwiYnVsa1VwZGF0ZUxhc3RTZWVuIiwiYnVsa1ZhbGlkYXRvclJlY29yZHMiLCJidWxrVlBIaXN0b3J5IiwiYnVsa1RyYW5zYWN0aW9ucyIsInN0YXJ0R2V0SGVpZ2h0VGltZSIsImhhc2giLCJibG9ja19pZCIsInRyYW5zTnVtIiwidHhzIiwiaGVhZGVyIiwibGFzdEJsb2NrSGFzaCIsImxhc3RfYmxvY2tfaWQiLCJwcm9wb3Nlcl9hZGRyZXNzIiwidCIsInR4aGFzaCIsIkJ1ZmZlciIsImZyb20iLCJ0b1VwcGVyQ2FzZSIsInByb2Nlc3NlZCIsImV4ZWN1dGUiLCJlcnIiLCJldmlkZW5jZSIsImV2aWRlbmNlTGlzdCIsInByZWNvbW1pdHNDb3VudCIsImxhc3RfY29tbWl0Iiwic2lnbmF0dXJlcyIsImVuZEdldEhlaWdodFRpbWUiLCJzdGFydEdldFZhbGlkYXRvcnNUaW1lIiwiYmxvY2tfaGVpZ2h0IiwidmFsaWRhdG9yc0NvdW50IiwidGVtcFZhbGlkYXRvcnMiLCJ2YWxjb25zQWRkcmVzcyIsImJlY2gzMlByZWZpeENvbnNBZGRyIiwicHJlY29tbWl0cyIsInB1c2giLCJ2YWxpZGF0b3JfYWRkcmVzcyIsInJlY29yZCIsImV4aXN0cyIsImoiLCJwcmVjb21taXRBZGRyZXNzIiwidXBkYXRlT25lIiwibGFzdFNlZW4iLCJzdGFydEJsb2NrSW5zZXJ0VGltZSIsImVuZEJsb2NrSW5zZXJ0VGltZSIsImNoYWluU3RhdHVzIiwiY2hhaW5faWQiLCJsYXN0U3luY2VkVGltZSIsImRlZmF1bHRCbG9ja1RpbWUiLCJkYXRlTGF0ZXN0IiwiZGF0ZUxhc3QiLCJnZW5lc2lzVGltZSIsImFicyIsImdldFRpbWUiLCJlbmRHZXRWYWxpZGF0b3JzVGltZSIsImF2ZXJhZ2VCbG9ja1RpbWUiLCJzdGFydEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUiLCJ0b2tlbnMiLCJ1bmJvbmRpbmdfaGVpZ2h0IiwidmFsRXhpc3QiLCJiZWNoMzJDb25zZW5zdXNQdWJLZXkiLCJiZWNoMzJQcmVmaXhDb25zUHViIiwiZGVzY3JpcHRpb24iLCJwcm9maWxlX3VybCIsImFjY3B1YiIsImJlY2gzMlByZWZpeEFjY1B1YiIsIm9wZXJhdG9yX3B1YmtleSIsImJlY2gzMlByZWZpeFZhbFB1YiIsInByb3Bvc2VyX3ByaW9yaXR5IiwicHJldl92b3RpbmdfcG93ZXIiLCJibG9ja190aW1lIiwicHJldlZvdGluZ1Bvd2VyIiwiY2hhbmdlVHlwZSIsImNoYW5nZURhdGEiLCJ2YWxpZGF0b3JVcGRhdGVXaW5kb3ciLCJzZWxmRGVsZWdhdGlvbiIsInNlbGZfZGVsZWdhdGlvbiIsImRlbGVnYXRvcl9zaGFyZXMiLCJub3ciLCJsYXN0S2V5YmFzZUZldGNoVGltZSIsImtleWJhc2VGZXRjaGluZ0ludGVydmFsIiwicHJvZmlsZVVybCIsInRvVVRDU3RyaW5nIiwiZW5kRmluZFZhbGlkYXRvcnNOYW1lVGltZSIsInN0YXJ0QW5heXRpY3NJbnNlcnRUaW1lIiwiZW5kQW5hbHl0aWNzSW5zZXJ0VGltZSIsInN0YXJ0VlVwVGltZSIsImVuZFZVcFRpbWUiLCJzdGFydFZSVGltZSIsImVuZFZSVGltZSIsImVuZEJsb2NrVGltZSIsImxhc3RCbG9ja3NTeW5jZWRUaW1lIiwicHVibGlzaENvbXBvc2l0ZSIsImNoaWxkcmVuIiwiZXhwb3J0IiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiaGVscGVycyIsInByb3Bvc2VyIiwiQ2hhaW5TdGF0ZXMiLCJDb2luIiwiZGVmYXVsdCIsImZpbmRWb3RpbmdQb3dlciIsImdlblZhbGlkYXRvcnMiLCJwb3dlciIsImNvbnNlbnN1cyIsInJvdW5kX3N0YXRlIiwicm91bmQiLCJzdGVwIiwidm90ZWRQb3dlciIsInZvdGVzIiwicHJldm90ZXNfYml0X2FycmF5Iiwic3BsaXQiLCJ2b3RpbmdIZWlnaHQiLCJ2b3RpbmdSb3VuZCIsInZvdGluZ1N0ZXAiLCJwcmV2b3RlcyIsImxhdGVzdEJsb2NrIiwiY2hhaW4iLCJsYXRlc3RCbG9ja0hlaWdodCIsImxhdGVzdEJsb2NrVGltZSIsImxhdGVzdFN0YXRlIiwiYWN0aXZlVlAiLCJhY3RpdmVWb3RpbmdQb3dlciIsInN0YWtpbmciLCJjaGFpblN0YXRlcyIsImJvbmRpbmciLCJwb29sIiwiYm9uZGVkVG9rZW5zIiwiYm9uZGVkX3Rva2VucyIsIm5vdEJvbmRlZFRva2VucyIsIm5vdF9ib25kZWRfdG9rZW5zIiwiU3Rha2luZ0NvaW4iLCJkZW5vbSIsIm1vZHVsZXMiLCJiYW5rIiwic3VwcGx5IiwidG90YWxTdXBwbHkiLCJhbW91bnQiLCJkaXN0cmlidXRpb24iLCJjb21tdW5pdHlQb29sIiwibWludGluZyIsImluZmxhdGlvbiIsInByb3Zpc2lvbnMiLCJhbm51YWxfcHJvdmlzaW9ucyIsImFubnVhbFByb3Zpc2lvbnMiLCJtaW50IiwiZ292IiwiY3JlYXRlZCIsIkNvaW5TdGF0cyIsInB1Ymxpc2giLCJsYXN0X3VwZGF0ZWRfYXQiLCJmaWVsZHMiLCJjb2luSWQiLCJjb2luZ2Vja29JZCIsInNldE1pbnV0ZXMiLCJEZWxlZ2F0aW9ucyIsImNvbmNhdCIsImNyZWF0ZWRBdCIsIl9vYmplY3RTcHJlYWQiLCJ0eEluZm8iLCJ0aW1lc3RhbXAiLCJwb3N0IiwiY29kZSIsIkVycm9yIiwicmF3X2xvZyIsIm1lc3NhZ2UiLCJib2R5IiwicGF0aCIsInR4TXNnIiwiYWNjb3VudE51bWJlciIsInNlcXVlbmNlIiwiYWRqdXN0bWVudCIsImdhc19lc3RpbWF0ZSIsIlByb3Bvc2FscyIsInRhbGx5X3BhcmFtcyIsInByb3Bvc2FscyIsImZpbmlzaGVkUHJvcG9zYWxJZHMiLCJTZXQiLCJwcm9wb3NhbElkIiwicHJvcG9zYWxJZHMiLCJidWxrUHJvcG9zYWxzIiwicHJvcG9zYWwiLCJwcm9wb3NhbF9pZCIsImhhcyIsIiRuaW4iLCJkZXBvc2l0cyIsImdldFZvdGVEZXRhaWwiLCJ0YWxseSIsInVwZGF0ZWRBdCIsInZvdGVycyIsInZvdGUiLCJ2b3RlciIsInZvdGluZ1Bvd2VyTWFwIiwidmFsaWRhdG9yQWRkcmVzc01hcCIsIm1vbmlrZXIiLCJkZWxlZ2F0b3JTaGFyZXMiLCJkZWR1Y3RlZFNoYXJlcyIsInZvdGluZ1Bvd2VyIiwiZGVsZWdhdGlvbnNfcmVzcG9uc2UiLCJ1bmRlZmluZWQiLCJjaGVjayIsImlkIiwiTnVtYmVyIiwiQXZlcmFnZURhdGEiLCJBdmVyYWdlVmFsaWRhdG9yRGF0YSIsIlN0YXR1cyIsIk1pc3NlZEJsb2Nrc1N0YXRzIiwiTWlzc2VkQmxvY2tzIiwiXyIsIkJVTEtVUERBVEVNQVhTSVpFIiwiZ2V0QmxvY2tTdGF0cyIsImxhdGVzdEhlaWdodCIsImJsb2NrU3RhdHMiLCJjb25kIiwiJGFuZCIsIiRndCIsIiRsdGUiLCJvcHRpb25zIiwiYXNzaWduIiwiZ2V0UHJldmlvdXNSZWNvcmQiLCJ2b3RlckFkZHJlc3MiLCJwcmV2aW91c1JlY29yZCIsImJsb2NrSGVpZ2h0IiwibGFzdFVwZGF0ZWRIZWlnaHQiLCJwcmV2U3RhdHMiLCJwaWNrIiwibWlzc0NvdW50IiwidG90YWxDb3VudCIsIkNPVU5UTUlTU0VEQkxPQ0tTIiwic3RhcnRUaW1lIiwiZXhwbG9yZXJTdGF0dXMiLCJsYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tIZWlnaHQiLCJtaW4iLCJidWxrTWlzc2VkU3RhdHMiLCJpbml0aWFsaXplT3JkZXJlZEJ1bGtPcCIsInZhbGlkYXRvcnNNYXAiLCJwcm9wb3NlclZvdGVyU3RhdHMiLCJ2b3RlZFZhbGlkYXRvcnMiLCJ2YWxpZGF0b3JTZXRzIiwidm90ZWRWb3RpbmdQb3dlciIsImFjdGl2ZVZhbGlkYXRvciIsImN1cnJlbnRWYWxpZGF0b3IiLCJzZXQiLCJuIiwic3RhdHMiLCJjbGllbnQiLCJfZHJpdmVyIiwibW9uZ28iLCJidWxrUHJvbWlzZSIsInRoZW4iLCJiaW5kRW52aXJvbm1lbnQiLCJuSW5zZXJ0ZWQiLCJuVXBzZXJ0ZWQiLCJuTW9kaWZpZWQiLCJQcm9taXNlIiwiYXdhaXQiLCJsYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tUaW1lIiwiQ09VTlRNSVNTRURCTE9DS1NTVEFUUyIsImxhc3RNaXNzZWRCbG9ja0hlaWdodCIsIm1pc3NlZFJlY29yZHMiLCJjb3VudHMiLCJleGlzdGluZ1JlY29yZCIsImxhc3RNaXNzZWRCbG9ja1RpbWUiLCJhdmVyYWdlVm90aW5nUG93ZXIiLCJhbmFseXRpY3MiLCJsYXN0TWludXRlVm90aW5nUG93ZXIiLCJsYXN0TWludXRlQmxvY2tUaW1lIiwibGFzdEhvdXJWb3RpbmdQb3dlciIsImxhc3RIb3VyQmxvY2tUaW1lIiwibGFzdERheVZvdGluZ1Bvd2VyIiwibGFzdERheUJsb2NrVGltZSIsImJsb2NrSGVpZ2h0cyIsImEiLCJudW0iLCJjb25kaXRpb25zIiwicHJvcG9zZXJNb25pa2VyIiwidm90ZXJNb25pa2VyIiwiQWRkcmVzc0xlbmd0aCIsIlRYU1lOQ0lORyIsInRyYW5zYWN0aW9ucyIsInR4IiwidHhfcmVzcG9uc2UiLCJtaXNzaW5nIiwiJGx0IiwiaW5jbHVkZXMiLCJiZWNoMzJQcmVmaXhWYWxBZGRyIiwiYmVjaDMyUHJlZml4QWNjQWRkciIsIiRleGlzdHMiLCIkbmUiLCJ2YWxpZGF0b3JBZGRyZXNzIiwiZGVsZWdhdG9yQWRkcmVzcyIsInF1ZXJ5IiwiVHhJY29uIiwiZGlyZWN0aW9uIiwidmFsIiwidXB0aW1lV2luZG93IiwiZmlyc3RTZWVuIiwiaGlzdG9yeSIsImNyZWF0ZUluZGV4IiwidW5pcXVlIiwicGFydGlhbEZpbHRlckV4cHJlc3Npb24iLCJvblBhZ2VMb2FkIiwiSGVsbWV0Iiwic2luayIsImhlbG1ldCIsInJlbmRlclN0YXRpYyIsImFwcGVuZFRvSGVhZCIsIm1ldGEiLCJ0b1N0cmluZyIsInRpdGxlIiwiYmVjaDMyIiwidG1oYXNoIiwiaGV4VG9CZWNoMzIiLCJwcmVmaXgiLCJhZGRyZXNzQnVmZmVyIiwiZW5jb2RlIiwidG9Xb3JkcyIsInB1YmtleVRvQmVjaDMyT2xkIiwiYnVmZmVyIiwicHVia2V5QW1pbm9QcmVmaXgiLCJhbGxvYyIsImNvcHkiLCJwdWJrZXlUb0JlY2gzMiIsImJlY2gzMlRvUHVia2V5IiwiZnJvbVdvcmRzIiwiZGVjb2RlIiwid29yZHMiLCJzbGljZSIsImdldEFkZHJlc3NGcm9tUHVia2V5IiwiYnl0ZXMiLCJnZXREZWxlZ2F0b3IiLCJvcGVyYXRvckFkZHIiLCJnZXRLZXliYXNlVGVhbVBpYyIsImtleWJhc2VVcmwiLCJnZXRWZXJzaW9uIiwidmVyc2lvbiIsIkFzc2V0cyIsImdldFRleHQiLCJEZW5vbVN5bWJvbCIsIlByb3Bvc2FsU3RhdHVzSWNvbiIsIlZvdGVJY29uIiwiSW5mb0ljb24iLCJSZWFjdCIsIlVuY29udHJvbGxlZFRvb2x0aXAiLCJwcm9wcyIsInZhbGlkIiwiQ29tcG9uZW50IiwiY29uc3RydWN0b3IiLCJyZWYiLCJjcmVhdGVSZWYiLCJyZW5kZXIiLCJ0b29sdGlwVGV4dCIsIm51bWJybyIsImF1dG9mb3JtYXQiLCJmb3JtYXR0ZXIiLCJmb3JtYXQiLCJjb2luTGlzdCIsImJvbmREZW5vbSIsImxvd2VyRGVub20iLCJ0b0xvd2VyQ2FzZSIsIl9jb2luIiwiY29pbiIsImRpc3BsYXlOYW1lIiwiX2Ftb3VudCIsImZyYWN0aW9uIiwic3Rha2luZ0Ftb3VudCIsInByZWNpc2lvbiIsIm1pblN0YWtlIiwicmVwZWF0IiwibWludFN0cmluZyIsInN0YWtlU3RyaW5nIiwiTWluU3Rha2UiLCJnb1RpbWVUb0lTT1N0cmluZyIsIm1pbGxpc2Vjb25kIiwic2Vjb25kcyIsIm5hbm9zIiwic3Vic3RyaW5nIiwidG9JU09TdHJpbmciLCJyZW1vdGUiLCJycGMiLCJhcGkiLCJ0aW1lckJsb2NrcyIsInRpbWVyVHJhbnNhY3Rpb25zIiwidGltZXJDaGFpbiIsInRpbWVyQ29uc2Vuc3VzIiwidGltZXJQcm9wb3NhbCIsInRpbWVyUHJvcG9zYWxzUmVzdWx0cyIsInRpbWVyTWlzc2VkQmxvY2siLCJ0aW1lckRlbGVnYXRpb24iLCJ0aW1lckFnZ3JlZ2F0ZSIsIkRFRkFVTFRTRVRUSU5HUyIsInVwZGF0ZUNoYWluU3RhdHVzIiwiZXJyb3IiLCJ1cGRhdGVCbG9jayIsInVwZGF0ZVRyYW5zYWN0aW9ucyIsImdldENvbnNlbnN1c1N0YXRlIiwiZ2V0UHJvcG9zYWxzIiwiZ2V0UHJvcG9zYWxzUmVzdWx0cyIsInVwZGF0ZU1pc3NlZEJsb2NrcyIsImdldERlbGVnYXRpb25zIiwiYWdncmVnYXRlTWludXRlbHkiLCJhZ2dyZWdhdGVIb3VybHkiLCJhZ2dyZWdhdGVEYWlseSIsInN0YXJ0dXAiLCJpc0RldmVsb3BtZW50IiwiREVGQVVMVFNFVFRJTkdTSlNPTiIsInByb2Nlc3MiLCJlbnYiLCJOT0RFX1RMU19SRUpFQ1RfVU5BVVRIT1JJWkVEIiwid2FybiIsInBhcmFtIiwiZGVidWciLCJzdGFydFRpbWVyIiwic2V0SW50ZXJ2YWwiLCJjb25zZW5zdXNJbnRlcnZhbCIsImJsb2NrSW50ZXJ2YWwiLCJ0cmFuc2FjdGlvbnNJbnRlcnZhbCIsInN0YXR1c0ludGVydmFsIiwicHJvcG9zYWxJbnRlcnZhbCIsIm1pc3NlZEJsb2Nrc0ludGVydmFsIiwiZ2V0VVRDU2Vjb25kcyIsImdldFVUQ01pbnV0ZXMiLCJnZXRVVENIb3VycyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSx1Q0FBWixFQUFvRDtBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBcEQsRUFBa0YsQ0FBbEY7O0FBR3ZJLE1BQU1HLFlBQVksR0FBSUMsR0FBRCxJQUFTO0FBQzFCLE1BQUc7QUFDQyxRQUFJQyxHQUFHLEdBQUdKLElBQUksQ0FBQ0ssR0FBTCxDQUFTQyxHQUFHLEdBQUdILEdBQWYsQ0FBVjs7QUFDQSxRQUFJQyxHQUFHLENBQUNHLFVBQUosSUFBa0IsR0FBdEIsRUFBMEI7QUFDdEIsYUFBT0gsR0FBUDtBQUNIOztBQUFBO0FBQ0osR0FMRCxDQU1BLE9BQU9JLENBQVAsRUFBUztBQUNMQyxXQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBTSxXQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osQ0FYRDs7QUFhQVosTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCwrQkFBNkIsVUFBU0MsT0FBVCxFQUFpQjtBQUMxQyxTQUFLQyxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQU4sR0FBeUJNLE9BQW5DOztBQUNBLFFBQUc7QUFDQyxVQUFJRSxTQUFTLEdBQUdkLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWhCOztBQUNBLFVBQUlXLFNBQVMsQ0FBQ1AsVUFBVixJQUF3QixHQUE1QixFQUFnQztBQUM1QjtBQUNBLFlBQUlRLFFBQVEsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdILFNBQVMsQ0FBQ0ksT0FBckIsRUFBOEJDLE1BQTdDO0FBQ0EsWUFBSUMsT0FBSjtBQUNBLFlBQUtMLFFBQVEsQ0FBQ00sSUFBVCxLQUFrQixvQkFBbkIsSUFBNkNOLFFBQVEsQ0FBQ00sSUFBVCxLQUFrQix3QkFBbkUsRUFDSUQsT0FBTyxHQUFHTCxRQUFRLENBQUNPLEtBQW5CLENBREosS0FFSyxJQUFJUCxRQUFRLENBQUNNLElBQVQsS0FBa0Isa0NBQWxCLElBQXdETixRQUFRLENBQUNNLElBQVQsS0FBa0IscUNBQTlFLEVBQ0RELE9BQU8sR0FBR0wsUUFBUSxDQUFDTyxLQUFULENBQWVDLGtCQUFmLENBQWtDQyxXQUE1Qzs7QUFFSixZQUFHO0FBQ0NyQixhQUFHLEdBQUdHLEdBQUcsR0FBRyxpQkFBTixHQUEwQk0sT0FBaEM7QUFDQUcsa0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGNBQUlzQixRQUFRLEdBQUdULElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE1QztBQUNBQyxpQkFBTyxDQUFDTSxLQUFSLEdBQWdCRCxRQUFoQjtBQUVBLGNBQUlMLE9BQU8sSUFBSUEsT0FBTyxDQUFDTyxjQUFSLElBQTBCLElBQXpDLEVBQ0ksT0FBT1AsT0FBUDtBQUNKLGlCQUFPLElBQVA7QUFDSCxTQVRELENBVUEsT0FBT1osQ0FBUCxFQUFTO0FBQ0wsaUJBQU8sSUFBUDtBQUNIO0FBQ0o7QUFDSixLQXpCRCxDQTBCQSxPQUFPQSxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7QUFDQU0sYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEdBbENVO0FBbUNYLHlCQUF1QixVQUFTSSxPQUFULEVBQWlCO0FBQ3BDLFNBQUtDLE9BQUw7QUFDQSxRQUFJZSxPQUFPLEdBQUcsRUFBZCxDQUZvQyxDQUlwQzs7QUFDQSxRQUFJekIsR0FBRyxHQUFHRyxHQUFHLEdBQUcsZ0NBQU4sR0FBd0NNLE9BQWxEOztBQUNBLFFBQUc7QUFDQyxVQUFJRSxTQUFTLEdBQUdkLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWhCOztBQUNBLFVBQUlXLFNBQVMsQ0FBQ1AsVUFBVixJQUF3QixHQUE1QixFQUFnQztBQUM1QnFCLGVBQU8sQ0FBQ2QsU0FBUixHQUFvQkUsSUFBSSxDQUFDQyxLQUFMLENBQVdILFNBQVMsQ0FBQ0ksT0FBckIsRUFBOEJPLFFBQWxEO0FBRUg7QUFDSixLQU5ELENBT0EsT0FBT2pCLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBTSxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNILEtBaEJtQyxDQWtCcEM7OztBQUNBTCxPQUFHLEdBQUdHLEdBQUcsR0FBRyxzQ0FBTixHQUE2Q00sT0FBbkQ7O0FBQ0EsUUFBRztBQUNDLFVBQUlpQixXQUFXLEdBQUc3QixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFsQjs7QUFDQSxVQUFJMEIsV0FBVyxDQUFDdEIsVUFBWixJQUEwQixHQUE5QixFQUFrQztBQUM5QnFCLGVBQU8sQ0FBQ0MsV0FBUixHQUFzQmIsSUFBSSxDQUFDQyxLQUFMLENBQVdZLFdBQVcsQ0FBQ1gsT0FBdkIsRUFBZ0NZLG9CQUF0RDtBQUNIO0FBQ0osS0FMRCxDQU1BLE9BQU90QixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7QUFDQU0sYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQTdCbUMsQ0E4QnBDOzs7QUFDQUwsT0FBRyxHQUFHRyxHQUFHLEdBQUcscUNBQU4sR0FBNENNLE9BQTVDLEdBQW9ELHdCQUExRDs7QUFDQSxRQUFHO0FBQ0MsVUFBSW1CLFNBQVMsR0FBRy9CLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWhCOztBQUNBLFVBQUk0QixTQUFTLENBQUN4QixVQUFWLElBQXdCLEdBQTVCLEVBQWdDO0FBQzVCcUIsZUFBTyxDQUFDRyxTQUFSLEdBQW9CZixJQUFJLENBQUNDLEtBQUwsQ0FBV2MsU0FBUyxDQUFDYixPQUFyQixFQUE4QmMsbUJBQWxEO0FBQ0g7QUFDSixLQUxELENBTUEsT0FBT3hCLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBTSxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNILEtBekNtQyxDQTJDcEM7OztBQUNBTCxPQUFHLEdBQUdHLEdBQUcsR0FBRywwQ0FBTixHQUFpRE0sT0FBakQsR0FBeUQsVUFBL0Q7O0FBQ0EsUUFBRztBQUNDLFVBQUlxQixPQUFPLEdBQUdqQyxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFkOztBQUNBLFVBQUk4QixPQUFPLENBQUMxQixVQUFSLElBQXNCLEdBQTFCLEVBQThCO0FBQzFCO0FBQ0FxQixlQUFPLENBQUNLLE9BQVIsR0FBa0JqQixJQUFJLENBQUNDLEtBQUwsQ0FBV2dCLE9BQU8sQ0FBQ2YsT0FBbkIsRUFBNEJlLE9BQTlDLENBRjBCLENBRzFCOztBQUNBTCxlQUFPLENBQUNNLGFBQVIsR0FBdUJsQixJQUFJLENBQUNDLEtBQUwsQ0FBV2dCLE9BQU8sQ0FBQ2YsT0FBbkIsRUFBNEJpQixLQUFuRDtBQUVIO0FBQ0osS0FURCxDQVVBLE9BQU8zQixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7QUFDQU0sYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQTFEbUMsQ0E0RHBDOzs7QUFDQSxRQUFJNEIsU0FBUyxHQUFHbkMsVUFBVSxDQUFDb0MsT0FBWCxDQUNaO0FBQUNDLFNBQUcsRUFBRSxDQUFDO0FBQUNDLHdCQUFnQixFQUFDM0I7QUFBbEIsT0FBRCxFQUE2QjtBQUFDNEIseUJBQWlCLEVBQUM1QjtBQUFuQixPQUE3QixFQUEwRDtBQUFDQSxlQUFPLEVBQUNBO0FBQVQsT0FBMUQ7QUFBTixLQURZLENBQWhCOztBQUVBLFFBQUl3QixTQUFKLEVBQWU7QUFDWCxVQUFJakMsR0FBRyxHQUFHRyxHQUFHLEdBQUcsMENBQU4sR0FBaUQ4QixTQUFTLENBQUNHLGdCQUEzRCxHQUE0RSxhQUF0RjtBQUNBWCxhQUFPLENBQUNhLGVBQVIsR0FBMEJMLFNBQVMsQ0FBQ0csZ0JBQXBDOztBQUNBLFVBQUk7QUFDQSxZQUFJTixPQUFPLEdBQUdqQyxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFkOztBQUNBLFlBQUk4QixPQUFPLENBQUMxQixVQUFSLElBQXNCLEdBQTFCLEVBQThCO0FBQzFCLGNBQUlXLE9BQU8sR0FBR0YsSUFBSSxDQUFDQyxLQUFMLENBQVdnQixPQUFPLENBQUNmLE9BQW5CLEVBQTRCd0IsVUFBMUM7QUFDQSxjQUFJeEIsT0FBTyxDQUFDd0IsVUFBUixJQUFzQnhCLE9BQU8sQ0FBQ3dCLFVBQVIsQ0FBbUJDLE1BQW5CLEdBQTRCLENBQXRELEVBQ0lmLE9BQU8sQ0FBQ2MsVUFBUixHQUFxQnhCLE9BQU8sQ0FBQ3dCLFVBQTdCO0FBRVA7QUFFSixPQVRELENBVUEsT0FBT2xDLENBQVAsRUFBUztBQUNMQyxlQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBTSxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0o7O0FBRUQsV0FBT29CLE9BQVA7QUFDSCxHQXRIVTs7QUF1SFgsMkJBQXlCaEIsT0FBekIsRUFBa0N3QixTQUFsQyxFQUE0QztBQUN4QyxTQUFLdkIsT0FBTDtBQUNBLFFBQUlWLEdBQUcsZ0RBQXlDaUMsU0FBekMsMEJBQWtFeEIsT0FBbEUsQ0FBUDtBQUNBLFFBQUlpQixXQUFXLEdBQUczQixZQUFZLENBQUNDLEdBQUQsQ0FBOUI7QUFDQU0sV0FBTyxDQUFDQyxHQUFSLENBQVltQixXQUFaO0FBQ0FBLGVBQVcsR0FBR0EsV0FBVyxJQUFJQSxXQUFXLENBQUNlLElBQVosQ0FBaUJDLG1CQUE5QztBQUNBLFFBQUloQixXQUFXLElBQUlBLFdBQVcsQ0FBQ2lCLFVBQVosQ0FBdUJDLE1BQTFDLEVBQ0lsQixXQUFXLENBQUNpQixVQUFaLENBQXVCQyxNQUF2QixHQUFnQ0MsVUFBVSxDQUFDbkIsV0FBVyxDQUFDaUIsVUFBWixDQUF1QkMsTUFBeEIsQ0FBMUM7QUFFSjVDLE9BQUcsZ0RBQXlDUyxPQUF6QywrQ0FBcUZ3QixTQUFyRixDQUFIO0FBQ0EsUUFBSWEsV0FBVyxHQUFHL0MsWUFBWSxDQUFDQyxHQUFELENBQTlCO0FBQ0E4QyxlQUFXLEdBQUdBLFdBQVcsSUFBSUEsV0FBVyxDQUFDTCxJQUFaLENBQWlCTSxzQkFBOUM7QUFDQSxRQUFJQyxjQUFKOztBQUNBLFFBQUlGLFdBQUosRUFBaUI7QUFDYkEsaUJBQVcsQ0FBQ0csT0FBWixDQUFxQkMsVUFBRCxJQUFnQjtBQUNoQyxZQUFJQyxPQUFPLEdBQUdELFVBQVUsQ0FBQ0MsT0FBekI7QUFDQSxZQUFJQyxJQUFJLEdBQUcsSUFBSUMsSUFBSixDQUFTRixPQUFPLENBQUNBLE9BQU8sQ0FBQ1gsTUFBUixHQUFlLENBQWhCLENBQVAsQ0FBMEJjLGVBQW5DLENBQVg7QUFDQSxZQUFJLENBQUNOLGNBQUQsSUFBbUJJLElBQUksR0FBR0osY0FBOUIsRUFDSUEsY0FBYyxHQUFHSSxJQUFqQjtBQUNQLE9BTEQ7QUFNQTFCLGlCQUFXLENBQUM2QiwwQkFBWixHQUF5Q1AsY0FBekM7QUFDSDs7QUFFRGhELE9BQUcsZ0RBQXlDaUMsU0FBekMsMEJBQWtFeEIsT0FBbEUsMEJBQUg7QUFDQSxRQUFJK0MsYUFBYSxHQUFHekQsWUFBWSxDQUFDQyxHQUFELENBQWhDO0FBQ0F3RCxpQkFBYSxHQUFHQSxhQUFhLElBQUlBLGFBQWEsQ0FBQ2YsSUFBZCxDQUFtQnpCLE1BQXBEOztBQUNBLFFBQUl3QyxhQUFKLEVBQW1CO0FBQ2Y5QixpQkFBVyxDQUFDRSxTQUFaLEdBQXdCNEIsYUFBYSxDQUFDTCxPQUFkLENBQXNCWCxNQUE5QztBQUNBZCxpQkFBVyxDQUFDK0IsdUJBQVosR0FBc0NELGFBQWEsQ0FBQ0wsT0FBZCxDQUFzQixDQUF0QixFQUF5QkcsZUFBL0Q7QUFDSDs7QUFDRCxXQUFPNUIsV0FBUDtBQUNILEdBdEpVOztBQXVKWCwrQkFBNkJqQixPQUE3QixFQUFxQztBQUNqQyxTQUFLQyxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHRyxHQUFHLEdBQUcscUNBQU4sR0FBNENNLE9BQTVDLEdBQW9ELGNBQTlEOztBQUVBLFFBQUc7QUFDQyxVQUFJaUIsV0FBVyxHQUFHN0IsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBbEI7O0FBQ0EsVUFBSTBCLFdBQVcsQ0FBQ3RCLFVBQVosSUFBMEIsR0FBOUIsRUFBa0M7QUFDOUJzQixtQkFBVyxHQUFHYixJQUFJLENBQUNDLEtBQUwsQ0FBV1ksV0FBVyxDQUFDWCxPQUF2QixFQUFnQ0MsTUFBOUM7O0FBQ0EsWUFBSVUsV0FBVyxJQUFJQSxXQUFXLENBQUNjLE1BQVosR0FBcUIsQ0FBeEMsRUFBMEM7QUFDdENkLHFCQUFXLENBQUN1QixPQUFaLENBQW9CLENBQUNOLFVBQUQsRUFBYWUsQ0FBYixLQUFtQjtBQUNuQyxnQkFBSWhDLFdBQVcsQ0FBQ2dDLENBQUQsQ0FBWCxJQUFrQmhDLFdBQVcsQ0FBQ2dDLENBQUQsQ0FBWCxDQUFlZCxNQUFyQyxFQUNJbEIsV0FBVyxDQUFDZ0MsQ0FBRCxDQUFYLENBQWVkLE1BQWYsR0FBd0JDLFVBQVUsQ0FBQ25CLFdBQVcsQ0FBQ2dDLENBQUQsQ0FBWCxDQUFlZCxNQUFoQixDQUFsQztBQUNQLFdBSEQ7QUFJSDs7QUFFRCxlQUFPbEIsV0FBUDtBQUNIOztBQUFBO0FBQ0osS0FiRCxDQWNBLE9BQU9yQixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7QUFDQU0sYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEdBN0tVOztBQThLWCw4QkFBNEJJLE9BQTVCLEVBQW9DO0FBQ2hDLFNBQUtDLE9BQUw7QUFDQSxRQUFJVixHQUFHLEdBQUdHLEdBQUcsR0FBRyxxQ0FBTixHQUE0Q00sT0FBNUMsR0FBb0Qsd0JBQTlEOztBQUVBLFFBQUc7QUFDQyxVQUFJa0QsVUFBVSxHQUFHOUQsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBakI7O0FBQ0EsVUFBSTJELFVBQVUsQ0FBQ3ZELFVBQVgsSUFBeUIsR0FBN0IsRUFBaUM7QUFDN0J1RCxrQkFBVSxHQUFHOUMsSUFBSSxDQUFDQyxLQUFMLENBQVc2QyxVQUFVLENBQUM1QyxPQUF0QixFQUErQkMsTUFBNUM7QUFDQSxlQUFPMkMsVUFBUDtBQUNIOztBQUFBO0FBQ0osS0FORCxDQU9BLE9BQU90RCxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7QUFDQU0sYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEdBN0xVOztBQThMWCxpQ0FBK0JJLE9BQS9CLEVBQXdDd0IsU0FBeEMsRUFBa0Q7QUFDOUMsU0FBS3ZCLE9BQUw7QUFDQSxRQUFJVixHQUFHLHdEQUFpRFMsT0FBakQsK0NBQTZGd0IsU0FBN0YsQ0FBUDs7QUFDQSxRQUFHO0FBQ0MsVUFBSWpCLE1BQU0sR0FBR2pCLFlBQVksQ0FBQ0MsR0FBRCxDQUF6Qjs7QUFDQSxVQUFJZ0IsTUFBTSxJQUFJQSxNQUFNLENBQUN5QixJQUFyQixFQUEyQjtBQUN2QixZQUFJbUIsYUFBYSxHQUFHLEVBQXBCO0FBQ0E1QyxjQUFNLENBQUN5QixJQUFQLENBQVlRLE9BQVosQ0FBcUJZLFlBQUQsSUFBa0I7QUFDbEMsY0FBSVYsT0FBTyxHQUFHVSxZQUFZLENBQUNWLE9BQTNCO0FBQ0FTLHVCQUFhLENBQUNDLFlBQVksQ0FBQ0MscUJBQWQsQ0FBYixHQUFvRDtBQUNoREMsaUJBQUssRUFBRVosT0FBTyxDQUFDWCxNQURpQztBQUVoRFEsMEJBQWMsRUFBRUcsT0FBTyxDQUFDLENBQUQsQ0FBUCxDQUFXRztBQUZxQixXQUFwRDtBQUlILFNBTkQ7QUFPQSxlQUFPTSxhQUFQO0FBQ0g7QUFDSixLQWJELENBY0EsT0FBTXZELENBQU4sRUFBUTtBQUNKQyxhQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBTSxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osR0FuTlU7O0FBb05YLDhCQUE0QkksT0FBNUIsRUFBcUM7QUFDakMsU0FBS0MsT0FBTDtBQUNBLFFBQUlWLEdBQUcsR0FBR0csR0FBRyxHQUFHLDZDQUFOLEdBQXNETSxPQUF0RCxHQUErRCxnQkFBekU7O0FBRUEsUUFBSTtBQUNBLFVBQUl1RCxpQkFBaUIsR0FBR25FLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQXhCOztBQUNBLFVBQUlnRSxpQkFBaUIsQ0FBQzVELFVBQWxCLElBQWdDLEdBQXBDLEVBQXlDO0FBQ3JDNEQseUJBQWlCLEdBQUduRCxJQUFJLENBQUNDLEtBQUwsQ0FBV2tELGlCQUFpQixDQUFDakQsT0FBN0IsRUFBc0NDLE1BQTFEO0FBRUEsZUFBT2dELGlCQUFQO0FBQ0g7O0FBQUE7QUFDSixLQVBELENBT0UsT0FBTzNELENBQVAsRUFBVTtBQUNSQyxhQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBTSxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBQyxDQUFDTyxRQUFGLENBQVdHLE9BQXZCO0FBQ0g7QUFDSjs7QUFuT1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ2hCQSxJQUFJdEIsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlxRSxTQUFKO0FBQWN2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDc0UsV0FBUyxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxhQUFTLEdBQUNyRSxDQUFWO0FBQVk7O0FBQTFCLENBQTVDLEVBQXdFLENBQXhFO0FBQTJFLElBQUlzRSxLQUFKO0FBQVV4RSxNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDdUUsT0FBSyxDQUFDdEUsQ0FBRCxFQUFHO0FBQUNzRSxTQUFLLEdBQUN0RSxDQUFOO0FBQVE7O0FBQWxCLENBQTFDLEVBQThELENBQTlEO0FBQWlFLElBQUl1RSxhQUFKO0FBQWtCekUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVosRUFBNEQ7QUFBQ3dFLGVBQWEsQ0FBQ3ZFLENBQUQsRUFBRztBQUFDdUUsaUJBQWEsR0FBQ3ZFLENBQWQ7QUFBZ0I7O0FBQWxDLENBQTVELEVBQWdHLENBQWhHO0FBQW1HLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksdUNBQVosRUFBb0Q7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQXBELEVBQWtGLENBQWxGO0FBQXFGLElBQUl3RSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0JDLGVBQS9CO0FBQStDNUUsTUFBTSxDQUFDQyxJQUFQLENBQVksaUNBQVosRUFBOEM7QUFBQ3lFLGtCQUFnQixDQUFDeEUsQ0FBRCxFQUFHO0FBQUN3RSxvQkFBZ0IsR0FBQ3hFLENBQWpCO0FBQW1CLEdBQXhDOztBQUF5Q3lFLFdBQVMsQ0FBQ3pFLENBQUQsRUFBRztBQUFDeUUsYUFBUyxHQUFDekUsQ0FBVjtBQUFZLEdBQWxFOztBQUFtRTBFLGlCQUFlLENBQUMxRSxDQUFELEVBQUc7QUFBQzBFLG1CQUFlLEdBQUMxRSxDQUFoQjtBQUFrQjs7QUFBeEcsQ0FBOUMsRUFBd0osQ0FBeEo7QUFBMkosSUFBSTJFLGtCQUFKO0FBQXVCN0UsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVosRUFBbUQ7QUFBQzRFLG9CQUFrQixDQUFDM0UsQ0FBRCxFQUFHO0FBQUMyRSxzQkFBa0IsR0FBQzNFLENBQW5CO0FBQXFCOztBQUE1QyxDQUFuRCxFQUFpRyxDQUFqRztBQUFvRyxJQUFJNEUsWUFBSjtBQUFpQjlFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUM2RSxjQUFZLENBQUM1RSxDQUFELEVBQUc7QUFBQzRFLGdCQUFZLEdBQUM1RSxDQUFiO0FBQWU7O0FBQWhDLENBQWpELEVBQW1GLENBQW5GO0FBQXNGLElBQUk2RSxTQUFKO0FBQWMvRSxNQUFNLENBQUNDLElBQVAsQ0FBWSw4QkFBWixFQUEyQztBQUFDOEUsV0FBUyxDQUFDN0UsQ0FBRCxFQUFHO0FBQUM2RSxhQUFTLEdBQUM3RSxDQUFWO0FBQVk7O0FBQTFCLENBQTNDLEVBQXVFLENBQXZFO0FBQTBFLElBQUk4RSxNQUFKO0FBQVdoRixNQUFNLENBQUNDLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUMrRSxRQUFNLENBQUM5RSxDQUFELEVBQUc7QUFBQzhFLFVBQU0sR0FBQzlFLENBQVA7QUFBUzs7QUFBcEIsQ0FBeEIsRUFBOEMsRUFBOUM7QUFBa0QsSUFBSStFLE9BQUo7QUFBWWpGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQyxNQUFJQyxDQUFKLEVBQU07QUFBQytFLFdBQU8sR0FBQy9FLENBQVI7QUFBVTs7QUFBbEIsQ0FBdEIsRUFBMEMsRUFBMUM7O0FBZWxrQ2dGLG9CQUFvQixHQUFHLENBQUNDLGNBQUQsRUFBaUJDLFVBQWpCLEtBQWdDO0FBQ25EO0FBQ0EsT0FBS0MsQ0FBTCxJQUFVRixjQUFWLEVBQXlCO0FBQ3JCLFNBQUtqRixDQUFMLElBQVVrRixVQUFWLEVBQXFCO0FBQ2pCLFVBQUlELGNBQWMsQ0FBQ0UsQ0FBRCxDQUFkLENBQWtCdEUsT0FBbEIsSUFBNkJxRSxVQUFVLENBQUNsRixDQUFELENBQVYsQ0FBY2EsT0FBL0MsRUFBdUQ7QUFDbkRvRSxzQkFBYyxDQUFDRyxNQUFmLENBQXNCRCxDQUF0QixFQUF3QixDQUF4QjtBQUNIO0FBQ0o7QUFDSjs7QUFFRCxTQUFPRixjQUFQO0FBQ0gsQ0FYRDs7QUFhQUksNEJBQTRCLEdBQUcsQ0FBQ0gsVUFBRCxFQUFhSSxZQUFiLEtBQThCO0FBQ3pELE9BQUt0RixDQUFMLElBQVVrRixVQUFWLEVBQXFCO0FBQ2pCLFFBQUk7QUFDQSxVQUFJSyxVQUFVLEdBQUcxRixNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1QkMsU0FBdkIsR0FBaUMsNEJBQWpDLEdBQThELDBCQUEvRTtBQUNBLFVBQUlDLE1BQU0sR0FBRzlGLE1BQU0sQ0FBQytGLElBQVAsQ0FBWSxnQkFBWixFQUE4Qk4sWUFBOUIsRUFBNENDLFVBQTVDLENBQWI7O0FBQ0EsVUFBSUwsVUFBVSxDQUFDbEYsQ0FBRCxDQUFWLENBQWM2RixPQUFkLENBQXNCdEUsS0FBdEIsSUFBK0JvRSxNQUFuQyxFQUEwQztBQUN0QyxlQUFPVCxVQUFVLENBQUNsRixDQUFELENBQWpCO0FBQ0g7QUFDSixLQU5ELENBT0EsT0FBT1MsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGlDQUFaLEVBQStDMkUsWUFBL0MsRUFBNkQ3RSxDQUE3RDtBQUNIO0FBQ0o7O0FBQ0QsU0FBTyxJQUFQO0FBQ0gsQ0FkRDs7QUFnQkFxRixzQkFBc0IsR0FBSUMsUUFBRCxJQUFjO0FBQ25DckYsU0FBTyxDQUFDQyxHQUFSLENBQVksdUJBQVo7O0FBQ0EsTUFBSW9GLFFBQVEsQ0FBQ25ELE1BQVQsSUFBbUIsRUFBdkIsRUFBMEI7QUFDdEIsUUFBSTVCLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLG9FQUFxRXlGLFFBQXJFLHNCQUFmOztBQUNBLFFBQUkvRSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsVUFBSXdGLElBQUksR0FBR2hGLFFBQVEsQ0FBQzZCLElBQVQsQ0FBY21ELElBQXpCO0FBQ0EsYUFBT0EsSUFBSSxJQUFJQSxJQUFJLENBQUNwRCxNQUFiLElBQXVCb0QsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUEvQixJQUEyQ0QsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUFSLENBQWlCQyxPQUE1RCxJQUF1RUYsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUFSLENBQWlCQyxPQUFqQixDQUF5QjlGLEdBQXZHO0FBQ0gsS0FIRCxNQUdPO0FBQ0hNLGFBQU8sQ0FBQ0MsR0FBUixDQUFZTSxJQUFJLENBQUNrRixTQUFMLENBQWVuRixRQUFmLENBQVo7QUFDSDtBQUNKLEdBUkQsTUFRTyxJQUFJK0UsUUFBUSxDQUFDSyxPQUFULENBQWlCLGtCQUFqQixJQUFxQyxDQUF6QyxFQUEyQztBQUM5QyxRQUFJQyxRQUFRLEdBQUdwRyxJQUFJLENBQUNLLEdBQUwsQ0FBU3lGLFFBQVQsQ0FBZjs7QUFDQSxRQUFJTSxRQUFRLENBQUM3RixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLFVBQUk4RixJQUFJLEdBQUd2QixPQUFPLENBQUN3QixJQUFSLENBQWFGLFFBQVEsQ0FBQ2xGLE9BQXRCLENBQVg7QUFDQSxhQUFPbUYsSUFBSSxDQUFDLG1CQUFELENBQUosQ0FBMEJFLElBQTFCLENBQStCLEtBQS9CLENBQVA7QUFDSCxLQUhELE1BR087QUFDSDlGLGFBQU8sQ0FBQ0MsR0FBUixDQUFZTSxJQUFJLENBQUNrRixTQUFMLENBQWVFLFFBQWYsQ0FBWjtBQUNIO0FBQ0o7QUFDSixDQW5CRDs7QUFxQkFJLGtCQUFrQixHQUFVQyxZQUFQLDZCQUF3QjtBQUV6QztBQUVBLE1BQUl0RyxHQUFHLGFBQU1HLEdBQU4sb0NBQVA7QUFDQSxNQUFJUyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxNQUFJdUcsY0FBYyxHQUFHMUYsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBckI7QUFFQW1ELE9BQUssQ0FBQ3NDLE1BQU4sQ0FBYTtBQUFDQyxXQUFPLEVBQUNoSCxNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm9CO0FBQWhDLEdBQWIsRUFBdUQ7QUFBQ0MsUUFBSSxFQUFDO0FBQUMsa0JBQVdIO0FBQVo7QUFBTixHQUF2RDs7QUFFQSxPQUFJLElBQUlJLEdBQVIsSUFBZUwsWUFBZixFQUE0QjtBQUN4QjtBQUNBLFFBQUk7QUFDQTtBQUVBdEcsU0FBRyxhQUFNRyxHQUFOLG9EQUFtRG1HLFlBQVksQ0FBQ0ssR0FBRCxDQUFaLENBQWtCQyxvQkFBckUsQ0FBSDtBQUNBLFVBQUloRyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxVQUFJNkcsV0FBVyxHQUFHaEcsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkIrRixnQkFBL0M7O0FBQ0EsVUFBSUQsV0FBSixFQUFnQjtBQUNaLFlBQUlFLE9BQU8sR0FBR1QsWUFBWSxDQUFDSyxHQUFELENBQTFCO0FBQ0FJLGVBQU8sQ0FBQ0MsVUFBUixHQUFxQkgsV0FBVyxDQUFDRyxVQUFqQztBQUNBRCxlQUFPLENBQUNFLFlBQVIsR0FBdUJKLFdBQVcsQ0FBQ0ksWUFBbkM7QUFDQUYsZUFBTyxDQUFDRyxZQUFSLEdBQXVCQyxRQUFRLENBQUNOLFdBQVcsQ0FBQ0ssWUFBYixDQUEvQjtBQUNBSCxlQUFPLENBQUNLLFlBQVIsR0FBdUJELFFBQVEsQ0FBQ04sV0FBVyxDQUFDTyxZQUFiLENBQS9CO0FBQ0FMLGVBQU8sQ0FBQ00sTUFBUixHQUFpQixDQUFDZCxjQUFjLENBQUNlLE1BQWYsQ0FBc0JDLG9CQUF0QixHQUE2Q0osUUFBUSxDQUFDTixXQUFXLENBQUNXLHFCQUFiLENBQXRELElBQTJGakIsY0FBYyxDQUFDZSxNQUFmLENBQXNCQyxvQkFBakgsR0FBd0ksR0FBeko7QUFDQXpILGtCQUFVLENBQUMwRyxNQUFYLENBQWtCO0FBQUNJLDhCQUFvQixFQUFDTixZQUFZLENBQUNLLEdBQUQsQ0FBWixDQUFrQkM7QUFBeEMsU0FBbEIsRUFBaUY7QUFBQ0YsY0FBSSxFQUFDSztBQUFOLFNBQWpGO0FBQ0g7QUFDSixLQWZELENBZ0JBLE9BQU0xRyxDQUFOLEVBQVE7QUFDSkMsYUFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7QUFDQU0sYUFBTyxDQUFDQyxHQUFSLENBQVksZ0NBQVosRUFBOEMrRixZQUFZLENBQUNLLEdBQUQsQ0FBWixDQUFrQkMsb0JBQWhFLEVBQXNGdkcsQ0FBdEY7QUFDSDtBQUNKO0FBQ0osQ0FqQ29CLENBQXJCOztBQW1DQW9ILGVBQWUsR0FBRyxDQUFPQyxhQUFQLEVBQXNCQyxTQUF0Qiw4QkFBb0M7QUFDbERySCxTQUFPLENBQUNDLEdBQVIsQ0FBWSxpREFBWjtBQUNBLE1BQUlxSCxnQkFBZ0IsR0FBRzlILFVBQVUsQ0FBQytILElBQVgsQ0FBZ0I7QUFBQ0MsVUFBTSxFQUFDLG9CQUFSO0FBQTZCQyxVQUFNLEVBQUM7QUFBcEMsR0FBaEIsRUFBMkQ7QUFBQ0MsUUFBSSxFQUFDO0FBQUNDLGtCQUFZLEVBQUMsQ0FBQztBQUFmO0FBQU4sR0FBM0QsRUFBcUZDLEtBQXJGLEVBQXZCO0FBQ0EsTUFBSUMsWUFBWSxHQUFHQyxJQUFJLENBQUNDLElBQUwsQ0FBVVQsZ0JBQWdCLENBQUNwRixNQUFqQixHQUF3QixHQUFsQyxDQUFuQjtBQUNBLE1BQUk4RixlQUFlLEdBQUdWLGdCQUFnQixDQUFDcEYsTUFBakIsR0FBMEIyRixZQUFoRDtBQUVBLE1BQUlJLGNBQWMsR0FBRyxDQUFyQjtBQUNBLE1BQUlDLGlCQUFpQixHQUFHLENBQXhCO0FBRUEsTUFBSUMsZ0JBQWdCLEdBQUcsQ0FBdkI7QUFDQSxNQUFJQyxpQkFBaUIsR0FBRyxDQUF4QjtBQUNBLE1BQUlDLG9CQUFvQixHQUFHLENBQTNCO0FBQ0EsTUFBSUMscUJBQXFCLEdBQUcsQ0FBNUI7O0FBSUEsT0FBS2hKLENBQUwsSUFBVWdJLGdCQUFWLEVBQTJCO0FBQ3ZCLFFBQUloSSxDQUFDLEdBQUd1SSxZQUFSLEVBQXFCO0FBQ2pCSSxvQkFBYyxJQUFJWCxnQkFBZ0IsQ0FBQ2hJLENBQUQsQ0FBaEIsQ0FBb0JxSSxZQUF0QztBQUNILEtBRkQsTUFHSTtBQUNBTyx1QkFBaUIsSUFBSVosZ0JBQWdCLENBQUNoSSxDQUFELENBQWhCLENBQW9CcUksWUFBekM7QUFDSDs7QUFHRCxRQUFJVSxvQkFBb0IsR0FBRyxJQUEzQixFQUFnQztBQUM1QkEsMEJBQW9CLElBQUlmLGdCQUFnQixDQUFDaEksQ0FBRCxDQUFoQixDQUFvQnFJLFlBQXBCLEdBQW1DUCxhQUFhLENBQUNPLFlBQXpFO0FBQ0FRLHNCQUFnQjtBQUNuQjtBQUNKOztBQUVERyx1QkFBcUIsR0FBRyxJQUFJRCxvQkFBNUI7QUFDQUQsbUJBQWlCLEdBQUdkLGdCQUFnQixDQUFDcEYsTUFBakIsR0FBMEJpRyxnQkFBOUM7QUFFQSxNQUFJSSxNQUFNLEdBQUc7QUFDVEMsVUFBTSxFQUFFbkIsU0FBUyxDQUFDbUIsTUFEVDtBQUVUWCxnQkFBWSxFQUFFQSxZQUZMO0FBR1RJLGtCQUFjLEVBQUVBLGNBSFA7QUFJVEQsbUJBQWUsRUFBRUEsZUFKUjtBQUtURSxxQkFBaUIsRUFBRUEsaUJBTFY7QUFNVEMsb0JBQWdCLEVBQUVBLGdCQU5UO0FBT1RFLHdCQUFvQixFQUFFQSxvQkFQYjtBQVFURCxxQkFBaUIsRUFBRUEsaUJBUlY7QUFTVEUseUJBQXFCLEVBQUVBLHFCQVRkO0FBVVRHLGlCQUFhLEVBQUVuQixnQkFBZ0IsQ0FBQ3BGLE1BVnZCO0FBV1R3RyxvQkFBZ0IsRUFBRXRCLGFBQWEsQ0FBQ08sWUFYdkI7QUFZVGdCLGFBQVMsRUFBRXRCLFNBQVMsQ0FBQ3ZFLElBWlo7QUFhVDhGLFlBQVEsRUFBRSxJQUFJN0YsSUFBSjtBQWJELEdBQWI7QUFnQkEvQyxTQUFPLENBQUNDLEdBQVIsQ0FBWXNJLE1BQVo7QUFFQXZFLGlCQUFlLENBQUM2RSxNQUFoQixDQUF1Qk4sTUFBdkI7QUFDSCxDQXJEaUIsQ0FBbEIsQyxDQXVEQTtBQUNBOzs7QUFFQXBKLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNEJBQTBCQyxPQUExQixFQUFrQztBQUM5QixTQUFLQyxPQUFMO0FBQ0EsUUFBSTBJLE1BQU0sR0FBR25GLFNBQVMsQ0FBQzRELElBQVYsQ0FBZTtBQUFDd0IscUJBQWUsRUFBQzVJO0FBQWpCLEtBQWYsRUFBMEN5SCxLQUExQyxFQUFiO0FBQ0EsUUFBSW9CLE9BQU8sR0FBR0YsTUFBTSxDQUFDRyxHQUFQLENBQVlDLEtBQUQsSUFBVztBQUNoQyxhQUFPQSxLQUFLLENBQUNWLE1BQWI7QUFDSCxLQUZhLENBQWQ7QUFHQSxRQUFJVyxXQUFXLEdBQUdwRixTQUFTLENBQUN3RCxJQUFWLENBQWU7QUFBQ2lCLFlBQU0sRUFBQztBQUFDWSxXQUFHLEVBQUNKO0FBQUw7QUFBUixLQUFmLEVBQXVDcEIsS0FBdkMsRUFBbEIsQ0FOOEIsQ0FPOUI7O0FBRUEsUUFBSXlCLGNBQWMsR0FBRyxDQUFyQjs7QUFDQSxTQUFLQyxDQUFMLElBQVVILFdBQVYsRUFBc0I7QUFDbEJFLG9CQUFjLElBQUlGLFdBQVcsQ0FBQ0csQ0FBRCxDQUFYLENBQWVDLFFBQWpDO0FBQ0g7O0FBQ0QsV0FBT0YsY0FBYyxHQUFDTCxPQUFPLENBQUM5RyxNQUE5QjtBQUNILEdBZlU7O0FBZ0JYLDRCQUEwQixZQUFXO0FBQ2pDLFNBQUs5QixPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHOEosR0FBRyxHQUFDLFNBQWQ7O0FBQ0EsUUFBRztBQUNDLFVBQUlsSixRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxVQUFJOEgsTUFBTSxHQUFHakgsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBYjtBQUNBLGFBQVErRyxNQUFNLENBQUM5RyxNQUFQLENBQWMrSSxTQUFkLENBQXdCQyxtQkFBaEM7QUFDSCxLQUpELENBS0EsT0FBTzNKLENBQVAsRUFBUztBQUNMLGFBQU8sQ0FBUDtBQUNIO0FBQ0osR0EzQlU7QUE0QlgsNkJBQTJCLFlBQVc7QUFDbEMsU0FBS0ssT0FBTDtBQUNBLFFBQUl1SixVQUFVLEdBQUdoRyxTQUFTLENBQUM0RCxJQUFWLENBQWUsRUFBZixFQUFrQjtBQUFDRyxVQUFJLEVBQUM7QUFBQ2MsY0FBTSxFQUFDLENBQUM7QUFBVCxPQUFOO0FBQWtCb0IsV0FBSyxFQUFDO0FBQXhCLEtBQWxCLEVBQThDaEMsS0FBOUMsRUFBakIsQ0FGa0MsQ0FHbEM7O0FBQ0EsUUFBSWlDLFdBQVcsR0FBRzFLLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JrQyxNQUFoQixDQUF1QjZDLFdBQXpDOztBQUNBLFFBQUlGLFVBQVUsSUFBSUEsVUFBVSxDQUFDekgsTUFBWCxJQUFxQixDQUF2QyxFQUEwQztBQUN0QyxVQUFJc0csTUFBTSxHQUFHbUIsVUFBVSxDQUFDLENBQUQsQ0FBVixDQUFjbkIsTUFBM0I7QUFDQSxVQUFJQSxNQUFNLEdBQUdxQixXQUFiLEVBQ0ksT0FBT3JCLE1BQVA7QUFDUDs7QUFDRCxXQUFPcUIsV0FBUDtBQUNILEdBdkNVO0FBd0NYLHlCQUF1QjtBQUFBLG9DQUFpQjtBQUNwQyxXQUFLekosT0FBTDtBQUNBLFVBQUkwSixPQUFKLEVBQ0ksT0FBTyxZQUFQLENBREosS0FFSzlKLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosRUFKK0IsQ0FLcEM7QUFDQTs7QUFDQSxVQUFJOEosS0FBSyxHQUFHNUssTUFBTSxDQUFDK0YsSUFBUCxDQUFZLHdCQUFaLENBQVosQ0FQb0MsQ0FRcEM7QUFDQTs7QUFDQSxVQUFJOEUsSUFBSSxHQUFHN0ssTUFBTSxDQUFDK0YsSUFBUCxDQUFZLHlCQUFaLENBQVg7QUFDQWxGLGFBQU8sQ0FBQ0MsR0FBUixDQUFZK0osSUFBWixFQVhvQyxDQVlwQzs7QUFDQSxVQUFJRCxLQUFLLEdBQUdDLElBQVosRUFBa0I7QUFDZEYsZUFBTyxHQUFHLElBQVY7QUFFQSxZQUFJOUQsWUFBWSxHQUFHLEVBQW5CLENBSGMsQ0FJZDs7QUFFQSxZQUFJdEcsR0FBRyxHQUFHRyxHQUFHLEdBQUcsK0dBQWhCOztBQUVBLFlBQUc7QUFDQyxjQUFJUyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxjQUFJZ0IsTUFBTSxHQUFHSCxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QitELFVBQTFDO0FBQ0E5RCxnQkFBTSxDQUFDaUMsT0FBUCxDQUFnQmhCLFNBQUQsSUFBZXFFLFlBQVksQ0FBQ3JFLFNBQVMsQ0FBQ3NJLGdCQUFWLENBQTJCNUQsR0FBNUIsQ0FBWixHQUErQzFFLFNBQTdFO0FBQ0gsU0FKRCxDQUtBLE9BQU01QixDQUFOLEVBQVE7QUFDSkMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZUCxHQUFaO0FBQ0FNLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVELFlBQUc7QUFDQ0wsYUFBRyxHQUFHRyxHQUFHLEdBQUcsa0hBQVo7QUFDQSxjQUFJUyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxjQUFJZ0IsTUFBTSxHQUFHSCxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QitELFVBQTFDO0FBQ0E5RCxnQkFBTSxDQUFDaUMsT0FBUCxDQUFnQmhCLFNBQUQsSUFBZXFFLFlBQVksQ0FBQ3JFLFNBQVMsQ0FBQ3NJLGdCQUFWLENBQTJCNUQsR0FBNUIsQ0FBWixHQUErQzFFLFNBQTdFO0FBQ0gsU0FMRCxDQU1BLE9BQU01QixDQUFOLEVBQVE7QUFDSkMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZUCxHQUFaO0FBQ0FNLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVELFlBQUc7QUFDQ0wsYUFBRyxHQUFHRyxHQUFHLEdBQUcsaUhBQVo7QUFDQSxjQUFJUyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxjQUFJZ0IsTUFBTSxHQUFHSCxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QitELFVBQTFDO0FBQ0E5RCxnQkFBTSxDQUFDaUMsT0FBUCxDQUFnQmhCLFNBQUQsSUFBZXFFLFlBQVksQ0FBQ3JFLFNBQVMsQ0FBQ3NJLGdCQUFWLENBQTJCNUQsR0FBNUIsQ0FBWixHQUErQzFFLFNBQTdFO0FBQ0gsU0FMRCxDQU1BLE9BQU01QixDQUFOLEVBQVE7QUFDSkMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZUCxHQUFaO0FBQ0FNLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNILFNBdENhLENBd0NkOzs7QUFDQSxZQUFJbUssZUFBZSxHQUFHQyxNQUFNLENBQUNDLElBQVAsQ0FBWXBFLFlBQVosRUFBMEI5RCxNQUFoRDtBQUNBbEMsZUFBTyxDQUFDQyxHQUFSLENBQVkscUJBQW9CaUssZUFBaEM7QUFDQXRHLGFBQUssQ0FBQ3lHLE1BQU4sQ0FBYTtBQUFDbEUsaUJBQU8sRUFBQ2hILE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCb0I7QUFBaEMsU0FBYixFQUF1RDtBQUFDQyxjQUFJLEVBQUM7QUFBQzhELDJCQUFlLEVBQUNBO0FBQWpCO0FBQU4sU0FBdkQ7O0FBRUEsYUFBSyxJQUFJMUIsTUFBTSxHQUFHd0IsSUFBSSxHQUFDLENBQXZCLEVBQTJCeEIsTUFBTSxJQUFJdUIsS0FBckMsRUFBNkN2QixNQUFNLEVBQW5ELEVBQXVEO0FBQ3ZEO0FBQ0ksY0FBSThCLGNBQWMsR0FBRyxJQUFJdkgsSUFBSixFQUFyQixDQUZtRCxDQUduRDs7QUFDQSxlQUFLM0MsT0FBTCxHQUptRCxDQUtuRDs7QUFFQVYsYUFBRyxhQUFNRyxHQUFOLHFCQUFvQjJJLE1BQXBCLENBQUg7QUFDQSxjQUFJcEIsYUFBYSxHQUFHLEVBQXBCO0FBRUEsZ0JBQU1tRCxjQUFjLEdBQUcvSyxVQUFVLENBQUNnTCxhQUFYLEdBQTJCQyx5QkFBM0IsRUFBdkI7QUFDQSxnQkFBTUMsa0JBQWtCLEdBQUdsTCxVQUFVLENBQUNnTCxhQUFYLEdBQTJCQyx5QkFBM0IsRUFBM0I7QUFDQSxnQkFBTUUsb0JBQW9CLEdBQUc3RyxnQkFBZ0IsQ0FBQzBHLGFBQWpCLEdBQWlDQyx5QkFBakMsRUFBN0I7QUFDQSxnQkFBTUcsYUFBYSxHQUFHM0csa0JBQWtCLENBQUN1RyxhQUFuQixHQUFtQ0MseUJBQW5DLEVBQXRCO0FBQ0EsZ0JBQU1JLGdCQUFnQixHQUFHM0csWUFBWSxDQUFDc0csYUFBYixHQUE2QkMseUJBQTdCLEVBQXpCO0FBRUF6SyxpQkFBTyxDQUFDQyxHQUFSLENBQVksNkJBQVosRUFBMkN1SSxNQUEzQzs7QUFDQSxjQUFHO0FBQ0MsZ0JBQUlzQyxrQkFBa0IsR0FBRyxJQUFJL0gsSUFBSixFQUF6QjtBQUVBLGdCQUFJekMsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmLENBSEQsQ0FLQzs7QUFDQSxnQkFBSTJILFNBQVMsR0FBRyxFQUFoQjtBQUNBLGdCQUFJNkIsS0FBSyxHQUFHM0ksSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBWjtBQUNBNEcscUJBQVMsQ0FBQ21CLE1BQVYsR0FBbUJBLE1BQW5CO0FBQ0FuQixxQkFBUyxDQUFDMEQsSUFBVixHQUFpQjdCLEtBQUssQ0FBQzhCLFFBQU4sQ0FBZUQsSUFBaEM7QUFDQTFELHFCQUFTLENBQUM0RCxRQUFWLEdBQXFCL0IsS0FBSyxDQUFDQSxLQUFOLENBQVkvRyxJQUFaLENBQWlCK0ksR0FBakIsR0FBcUJoQyxLQUFLLENBQUNBLEtBQU4sQ0FBWS9HLElBQVosQ0FBaUIrSSxHQUFqQixDQUFxQmhKLE1BQTFDLEdBQWlELENBQXRFO0FBQ0FtRixxQkFBUyxDQUFDdkUsSUFBVixHQUFpQm9HLEtBQUssQ0FBQ0EsS0FBTixDQUFZaUMsTUFBWixDQUFtQnJJLElBQXBDO0FBQ0F1RSxxQkFBUyxDQUFDK0QsYUFBVixHQUEwQmxDLEtBQUssQ0FBQ0EsS0FBTixDQUFZaUMsTUFBWixDQUFtQkUsYUFBbkIsQ0FBaUNOLElBQTNEO0FBQ0ExRCxxQkFBUyxDQUFDMEIsZUFBVixHQUE0QkcsS0FBSyxDQUFDQSxLQUFOLENBQVlpQyxNQUFaLENBQW1CRyxnQkFBL0M7QUFDQWpFLHFCQUFTLENBQUM3QyxVQUFWLEdBQXVCLEVBQXZCLENBZEQsQ0FpQkM7O0FBQ0EsZ0JBQUkwRSxLQUFLLENBQUNBLEtBQU4sQ0FBWS9HLElBQVosQ0FBaUIrSSxHQUFqQixJQUF3QmhDLEtBQUssQ0FBQ0EsS0FBTixDQUFZL0csSUFBWixDQUFpQitJLEdBQWpCLENBQXFCaEosTUFBckIsR0FBOEIsQ0FBMUQsRUFBNEQ7QUFDeEQsbUJBQUtxSixDQUFMLElBQVVyQyxLQUFLLENBQUNBLEtBQU4sQ0FBWS9HLElBQVosQ0FBaUIrSSxHQUEzQixFQUErQjtBQUMzQkwsZ0NBQWdCLENBQUNoQyxNQUFqQixDQUF3QjtBQUNwQjtBQUNBMkMsd0JBQU0sRUFBRXBILE1BQU0sQ0FBQ3FILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZeEMsS0FBSyxDQUFDQSxLQUFOLENBQVkvRyxJQUFaLENBQWlCK0ksR0FBakIsQ0FBcUJLLENBQXJCLENBQVosRUFBcUMsUUFBckMsQ0FBRCxDQUFOLENBQXVESSxXQUF2RCxFQUZZO0FBR3BCbkQsd0JBQU0sRUFBRTNCLFFBQVEsQ0FBQzJCLE1BQUQsQ0FISTtBQUlwQm9ELDJCQUFTLEVBQUU7QUFKUyxpQkFBeEI7QUFNSDs7QUFFRCxrQkFBSWYsZ0JBQWdCLENBQUMzSSxNQUFqQixHQUEwQixDQUE5QixFQUFnQztBQUM1QjJJLGdDQUFnQixDQUFDZ0IsT0FBakIsQ0FBeUIsQ0FBQ0MsR0FBRCxFQUFNcEwsTUFBTixLQUFpQjtBQUN0QyxzQkFBSW9MLEdBQUosRUFBUTtBQUNKOUwsMkJBQU8sQ0FBQ0MsR0FBUixDQUFZNkwsR0FBWjtBQUNIOztBQUNELHNCQUFJcEwsTUFBSixFQUFXLENBQ1A7QUFDSDtBQUNKLGlCQVBEO0FBUUg7QUFDSixhQXRDRixDQXdDQzs7O0FBQ0EsZ0JBQUl3SSxLQUFLLENBQUNBLEtBQU4sQ0FBWTZDLFFBQVosQ0FBcUJDLFlBQXpCLEVBQXNDO0FBQ2xDN0gsdUJBQVMsQ0FBQzBFLE1BQVYsQ0FBaUI7QUFDYkwsc0JBQU0sRUFBRUEsTUFESztBQUVidUQsd0JBQVEsRUFBRTdDLEtBQUssQ0FBQ0EsS0FBTixDQUFZNkMsUUFBWixDQUFxQkM7QUFGbEIsZUFBakI7QUFJSCxhQTlDRixDQWdEQzs7O0FBRUEzRSxxQkFBUyxDQUFDNEUsZUFBVixHQUE0Qi9DLEtBQUssQ0FBQ0EsS0FBTixDQUFZZ0QsV0FBWixDQUF3QkMsVUFBeEIsQ0FBbUNqSyxNQUEvRDtBQUVBa0YseUJBQWEsQ0FBQ29CLE1BQWQsR0FBdUJBLE1BQXZCO0FBRUEsZ0JBQUk0RCxnQkFBZ0IsR0FBRyxJQUFJckosSUFBSixFQUF2QjtBQUNBL0MsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFxQixDQUFDbU0sZ0JBQWdCLEdBQUN0QixrQkFBbEIsSUFBc0MsSUFBM0QsR0FBaUUsVUFBN0U7QUFHQSxnQkFBSXVCLHNCQUFzQixHQUFHLElBQUl0SixJQUFKLEVBQTdCLENBMURELENBMkRDOztBQUVBLGdCQUFJeUIsVUFBVSxHQUFHLEVBQWpCO0FBQ0EsZ0JBQUlvQixJQUFJLEdBQUcsQ0FBWCxDQTlERCxDQStEQzs7QUFDQSxnQkFBSTtBQUNBLGtCQUFJbEYsTUFBSjs7QUFFQSxpQkFBRztBQUNDLG9CQUFJaEIsR0FBRyxHQUFHOEosR0FBRyxnQ0FBdUJoQixNQUF2QixtQkFBc0MsRUFBRTVDLElBQXhDLGtCQUFiO0FBQ0Esb0JBQUl0RixRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQWdCLHNCQUFNLEdBQUdILElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUF0QyxDQUhELENBSUM7O0FBQ0E4RCwwQkFBVSxHQUFHLENBQUMsR0FBR0EsVUFBSixFQUFnQixHQUFHOUQsTUFBTSxDQUFDOEQsVUFBMUIsQ0FBYixDQUxELENBT0M7QUFDQTtBQUNILGVBVEQsUUFVT0EsVUFBVSxDQUFDdEMsTUFBWCxHQUFvQjJFLFFBQVEsQ0FBQ25HLE1BQU0sQ0FBQ2dCLEtBQVIsQ0FWbkM7QUFZSCxhQWZELENBZ0JBLE9BQU0zQixDQUFOLEVBQVE7QUFDSkMscUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHdDQUFaLEVBQXNEdUksTUFBdEQsRUFBOER6SSxDQUE5RDtBQUNILGFBbEZGLENBb0ZDOzs7QUFFQThELHlCQUFhLENBQUNnRixNQUFkLENBQXFCO0FBQ2pCeUQsMEJBQVksRUFBRTlELE1BREc7QUFFakJoRSx3QkFBVSxFQUFFQTtBQUZLLGFBQXJCO0FBS0E2QyxxQkFBUyxDQUFDa0YsZUFBVixHQUE0Qi9ILFVBQVUsQ0FBQ3RDLE1BQXZDLENBM0ZELENBNkZDOztBQUNBLGdCQUFJc0ssY0FBYyxHQUFHLEVBQXJCOztBQUNBLGlCQUFLLElBQUlsTixDQUFULElBQWNrRixVQUFkLEVBQXlCO0FBQ3JCO0FBQ0E7QUFDQUEsd0JBQVUsQ0FBQ2xGLENBQUQsQ0FBVixDQUFjbU4sY0FBZCxHQUErQnROLE1BQU0sQ0FBQytGLElBQVAsQ0FBWSxhQUFaLEVBQTJCVixVQUFVLENBQUNsRixDQUFELENBQVYsQ0FBY2EsT0FBekMsRUFBa0RoQixNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1QjJILG9CQUF6RSxDQUEvQixDQUhxQixDQUlyQjtBQUNBOztBQUNBRiw0QkFBYyxDQUFDaEksVUFBVSxDQUFDbEYsQ0FBRCxDQUFWLENBQWNhLE9BQWYsQ0FBZCxHQUF3Q3FFLFVBQVUsQ0FBQ2xGLENBQUQsQ0FBbEQ7QUFDSDs7QUFDRGtGLHNCQUFVLEdBQUdnSSxjQUFiLENBdkdELENBeUdDO0FBRUE7O0FBQ0EsZ0JBQUlHLFVBQVUsR0FBR3pELEtBQUssQ0FBQ0EsS0FBTixDQUFZZ0QsV0FBWixDQUF3QkMsVUFBekM7O0FBQ0EsZ0JBQUlRLFVBQVUsSUFBSSxJQUFsQixFQUF1QjtBQUNuQjtBQUNBLG1CQUFLLElBQUl2SixDQUFDLEdBQUMsQ0FBWCxFQUFjQSxDQUFDLEdBQUN1SixVQUFVLENBQUN6SyxNQUEzQixFQUFtQ2tCLENBQUMsRUFBcEMsRUFBdUM7QUFDbkMsb0JBQUl1SixVQUFVLENBQUN2SixDQUFELENBQVYsSUFBaUIsSUFBckIsRUFBMEI7QUFDdEJpRSwyQkFBUyxDQUFDN0MsVUFBVixDQUFxQm9JLElBQXJCLENBQTBCRCxVQUFVLENBQUN2SixDQUFELENBQVYsQ0FBY3lKLGlCQUF4QztBQUNIO0FBQ0o7O0FBRUR6RiwyQkFBYSxDQUFDdUYsVUFBZCxHQUEyQkEsVUFBVSxDQUFDekssTUFBdEMsQ0FSbUIsQ0FTbkI7QUFDQTtBQUNIOztBQUVELGdCQUFJc0csTUFBTSxHQUFHLENBQWIsRUFBZTtBQUNYO0FBQ0E7QUFDQXhJLHFCQUFPLENBQUNDLEdBQVIsQ0FBWSxzQkFBWjs7QUFDQSxtQkFBS21ELENBQUwsSUFBVW9CLFVBQVYsRUFBcUI7QUFDakIsb0JBQUlyRSxPQUFPLEdBQUdxRSxVQUFVLENBQUNwQixDQUFELENBQVYsQ0FBY2pELE9BQTVCO0FBQ0Esb0JBQUkyTSxNQUFNLEdBQUc7QUFDVHRFLHdCQUFNLEVBQUVBLE1BREM7QUFFVHJJLHlCQUFPLEVBQUVBLE9BRkE7QUFHVDRNLHdCQUFNLEVBQUUsS0FIQztBQUlUcEYsOEJBQVksRUFBRWQsUUFBUSxDQUFDckMsVUFBVSxDQUFDcEIsQ0FBRCxDQUFWLENBQWN1RSxZQUFmO0FBSmIsaUJBQWI7O0FBT0EscUJBQUtxRixDQUFMLElBQVVMLFVBQVYsRUFBcUI7QUFDakIsc0JBQUlBLFVBQVUsQ0FBQ0ssQ0FBRCxDQUFWLElBQWlCLElBQXJCLEVBQTBCO0FBQ3RCLHdCQUFJQyxnQkFBZ0IsR0FBR04sVUFBVSxDQUFDSyxDQUFELENBQVYsQ0FBY0gsaUJBQXJDOztBQUNBLHdCQUFJMU0sT0FBTyxJQUFJOE0sZ0JBQWYsRUFBZ0M7QUFDNUJILDRCQUFNLENBQUNDLE1BQVAsR0FBZ0IsSUFBaEI7QUFDQXJDLHdDQUFrQixDQUFDbkQsSUFBbkIsQ0FBd0I7QUFBQ3BILCtCQUFPLEVBQUM4TTtBQUFULHVCQUF4QixFQUFvRC9HLE1BQXBELEdBQTZEZ0gsU0FBN0QsQ0FBdUU7QUFBQzlHLDRCQUFJLEVBQUM7QUFBQytHLGtDQUFRLEVBQUM5RixTQUFTLENBQUN2RTtBQUFwQjtBQUFOLHVCQUF2RTtBQUNBNkosZ0NBQVUsQ0FBQ2pJLE1BQVgsQ0FBa0JzSSxDQUFsQixFQUFvQixDQUFwQjtBQUNBO0FBQ0g7QUFDSjtBQUNKOztBQUVEckMsb0NBQW9CLENBQUM5QixNQUFyQixDQUE0QmlFLE1BQTVCLEVBckJpQixDQXNCakI7QUFDSDtBQUNKOztBQUVELGdCQUFJTSxvQkFBb0IsR0FBRyxJQUFJckssSUFBSixFQUEzQjtBQUNBWSxxQkFBUyxDQUFDa0YsTUFBVixDQUFpQnhCLFNBQWpCO0FBQ0EsZ0JBQUlnRyxrQkFBa0IsR0FBRyxJQUFJdEssSUFBSixFQUF6QjtBQUNBL0MsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUF1QixDQUFDb04sa0JBQWtCLEdBQUNELG9CQUFwQixJQUEwQyxJQUFqRSxHQUF1RSxVQUFuRjtBQUVBLGdCQUFJRSxXQUFXLEdBQUcxSixLQUFLLENBQUNoQyxPQUFOLENBQWM7QUFBQ3VFLHFCQUFPLEVBQUMrQyxLQUFLLENBQUNBLEtBQU4sQ0FBWWlDLE1BQVosQ0FBbUJvQztBQUE1QixhQUFkLENBQWxCO0FBQ0EsZ0JBQUlDLGNBQWMsR0FBR0YsV0FBVyxHQUFDQSxXQUFXLENBQUNFLGNBQWIsR0FBNEIsQ0FBNUQ7QUFDQSxnQkFBSWpFLFFBQUo7QUFDQSxnQkFBSVosU0FBUyxHQUFHeEosTUFBTSxDQUFDMkYsUUFBUCxDQUFnQmtDLE1BQWhCLENBQXVCeUcsZ0JBQXZDOztBQUNBLGdCQUFJRCxjQUFKLEVBQW1CO0FBQ2Ysa0JBQUlFLFVBQVUsR0FBRyxJQUFJM0ssSUFBSixDQUFTc0UsU0FBUyxDQUFDdkUsSUFBbkIsQ0FBakI7QUFDQSxrQkFBSTZLLFFBQVEsR0FBRyxJQUFJNUssSUFBSixDQUFTeUssY0FBVCxDQUFmO0FBQ0Esa0JBQUlJLFdBQVcsR0FBRyxJQUFJN0ssSUFBSixDQUFTNUQsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI2SSxXQUFoQyxDQUFsQjtBQUNBckUsc0JBQVEsR0FBR3pCLElBQUksQ0FBQytGLEdBQUwsQ0FBU0gsVUFBVSxDQUFDSSxPQUFYLEtBQXVCSCxRQUFRLENBQUNHLE9BQVQsRUFBaEMsQ0FBWCxDQUplLENBS2Y7O0FBQ0FuRix1QkFBUyxHQUFHLENBQUMrRSxVQUFVLENBQUNJLE9BQVgsS0FBdUJGLFdBQVcsQ0FBQ0UsT0FBWixFQUF4QixJQUFpRHpHLFNBQVMsQ0FBQ21CLE1BQXZFO0FBQ0g7O0FBRUQsZ0JBQUl1RixvQkFBb0IsR0FBRyxJQUFJaEwsSUFBSixFQUEzQjtBQUNBL0MsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLGlDQUFnQyxDQUFDOE4sb0JBQW9CLEdBQUMxQixzQkFBdEIsSUFBOEMsSUFBOUUsR0FBb0YsVUFBaEc7QUFFQXpJLGlCQUFLLENBQUN5RyxNQUFOLENBQWE7QUFBQ2xFLHFCQUFPLEVBQUMrQyxLQUFLLENBQUNBLEtBQU4sQ0FBWWlDLE1BQVosQ0FBbUJoRjtBQUE1QixhQUFiLEVBQW1EO0FBQUNDLGtCQUFJLEVBQUM7QUFBQ29ILDhCQUFjLEVBQUNuRyxTQUFTLENBQUN2RSxJQUExQjtBQUFnQzZGLHlCQUFTLEVBQUNBO0FBQTFDO0FBQU4sYUFBbkQ7QUFFQXZCLHlCQUFhLENBQUM0RyxnQkFBZCxHQUFpQ3JGLFNBQWpDO0FBQ0F2Qix5QkFBYSxDQUFDbUMsUUFBZCxHQUF5QkEsUUFBekI7QUFFQW5DLHlCQUFhLENBQUN0RSxJQUFkLEdBQXFCdUUsU0FBUyxDQUFDdkUsSUFBL0IsQ0FsTEQsQ0FvTEM7QUFDQTtBQUNBO0FBQ0E7O0FBRUFzRSx5QkFBYSxDQUFDTyxZQUFkLEdBQTZCLENBQTdCO0FBRUEsZ0JBQUlzRywyQkFBMkIsR0FBRyxJQUFJbEwsSUFBSixFQUFsQzs7QUFDQSxpQkFBS3pELENBQUwsSUFBVTBHLFlBQVYsRUFBdUI7QUFDbkIsa0JBQUlTLE9BQU8sR0FBR1QsWUFBWSxDQUFDMUcsQ0FBRCxDQUExQjtBQUVBbUgscUJBQU8sQ0FBQ3lILE1BQVIsR0FBaUJySCxRQUFRLENBQUNKLE9BQU8sQ0FBQ3lILE1BQVQsQ0FBekI7QUFDQXpILHFCQUFPLENBQUMwSCxnQkFBUixHQUEyQnRILFFBQVEsQ0FBQ0osT0FBTyxDQUFDMEgsZ0JBQVQsQ0FBbkM7QUFFQSxrQkFBSUMsUUFBUSxHQUFHNU8sVUFBVSxDQUFDb0MsT0FBWCxDQUFtQjtBQUFDLHdDQUF1QnRDO0FBQXhCLGVBQW5CLENBQWYsQ0FObUIsQ0FRbkI7QUFFQTs7QUFDQThILDJCQUFhLENBQUNPLFlBQWQsSUFBOEJsQixPQUFPLENBQUNrQixZQUF0QyxDQVhtQixDQWFuQjs7QUFDQSxrQkFBSSxDQUFDeUcsUUFBRCxJQUFhM0gsT0FBTyxDQUFDd0QsZ0JBQXpCLEVBQTBDO0FBRXRDO0FBQ0E7QUFFQXhELHVCQUFPLENBQUMxRSxpQkFBUixHQUE0QjVDLE1BQU0sQ0FBQytGLElBQVAsQ0FBWSxjQUFaLEVBQTRCdUIsT0FBTyxDQUFDM0UsZ0JBQXBDLENBQTVCLENBTHNDLENBT3RDO0FBQ0E7O0FBQ0E5Qix1QkFBTyxDQUFDQyxHQUFSLENBQVksNkJBQVo7QUFDQXdHLHVCQUFPLENBQUM0SCxxQkFBUixHQUFnQ2xQLE1BQU0sQ0FBQytGLElBQVAsQ0FBWSxnQkFBWixFQUE4QnVCLE9BQU8sQ0FBQ3dELGdCQUF0QyxFQUF3RDlLLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCdUosbUJBQS9FLENBQWhDO0FBR0E3SCx1QkFBTyxDQUFDdEcsT0FBUixHQUFrQmhCLE1BQU0sQ0FBQytGLElBQVAsQ0FBWSxzQkFBWixFQUFvQ3VCLE9BQU8sQ0FBQ3dELGdCQUE1QyxDQUFsQjtBQUNBeEQsdUJBQU8sQ0FBQ0gsb0JBQVIsR0FBK0JuSCxNQUFNLENBQUMrRixJQUFQLENBQVksYUFBWixFQUEyQnVCLE9BQU8sQ0FBQ3RHLE9BQW5DLEVBQTRDaEIsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIySCxvQkFBbkUsQ0FBL0IsQ0Fkc0MsQ0FnQnRDOztBQUVBLG9CQUFJMUcsWUFBWSxDQUFDMUcsQ0FBRCxDQUFoQixFQUNJMEcsWUFBWSxDQUFDMUcsQ0FBRCxDQUFaLENBQWdCZ0gsb0JBQWhCLEdBQXVDRyxPQUFPLENBQUNILG9CQUEvQyxDQW5Ca0MsQ0FzQnRDO0FBQ0E7O0FBRUEsb0JBQUlHLE9BQU8sQ0FBQzhILFdBQVIsSUFBdUI5SCxPQUFPLENBQUM4SCxXQUFSLENBQW9CbEosUUFBL0MsRUFBd0Q7QUFDcEQsc0JBQUc7QUFDQ29CLDJCQUFPLENBQUMrSCxXQUFSLEdBQXVCcEosc0JBQXNCLENBQUNxQixPQUFPLENBQUM4SCxXQUFSLENBQW9CbEosUUFBckIsQ0FBN0M7QUFDSCxtQkFGRCxDQUdBLE9BQU90RixDQUFQLEVBQVM7QUFDTEMsMkJBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUFaLEVBQTBDRixDQUExQztBQUNIO0FBQ0o7O0FBR0QwRyx1QkFBTyxDQUFDZ0ksTUFBUixHQUFpQnRQLE1BQU0sQ0FBQytGLElBQVAsQ0FBWSxnQkFBWixFQUE4QnVCLE9BQU8sQ0FBQ3dELGdCQUF0QyxFQUF3RDlLLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCMkosa0JBQS9FLENBQWpCO0FBQ0FqSSx1QkFBTyxDQUFDa0ksZUFBUixHQUEwQnhQLE1BQU0sQ0FBQytGLElBQVAsQ0FBWSxnQkFBWixFQUE4QnVCLE9BQU8sQ0FBQ3dELGdCQUF0QyxFQUF3RDlLLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkosa0JBQS9FLENBQTFCLENBcENzQyxDQXNDdEM7QUFFQTs7QUFDQW5JLHVCQUFPLENBQUNrQixZQUFSLEdBQXVCbkQsVUFBVSxDQUFDaUMsT0FBTyxDQUFDdEcsT0FBVCxDQUFWLEdBQTRCMEcsUUFBUSxDQUFDckMsVUFBVSxDQUFDaUMsT0FBTyxDQUFDdEcsT0FBVCxDQUFWLENBQTRCd0gsWUFBN0IsQ0FBcEMsR0FBK0UsQ0FBdEc7QUFDQWxCLHVCQUFPLENBQUNvSSxpQkFBUixHQUE0QnJLLFVBQVUsQ0FBQ2lDLE9BQU8sQ0FBQ3RHLE9BQVQsQ0FBVixHQUE0QjBHLFFBQVEsQ0FBQ3JDLFVBQVUsQ0FBQ2lDLE9BQU8sQ0FBQ3RHLE9BQVQsQ0FBVixDQUE0QjBPLGlCQUE3QixDQUFwQyxHQUFvRixDQUFoSDtBQUVBN08sdUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHFEQUFaLEVBNUNzQyxDQThDdEM7O0FBQ0EySyw2QkFBYSxDQUFDL0IsTUFBZCxDQUFxQjtBQUNqQjFJLHlCQUFPLEVBQUVzRyxPQUFPLENBQUN0RyxPQURBO0FBRWpCMk8sbUNBQWlCLEVBQUUsQ0FGRjtBQUdqQm5ILDhCQUFZLEVBQUVsQixPQUFPLENBQUNrQixZQUhMO0FBSWpCL0csc0JBQUksRUFBRSxLQUpXO0FBS2pCNEgsd0JBQU0sRUFBRW5CLFNBQVMsQ0FBQ21CLE1BTEQ7QUFNakJ1Ryw0QkFBVSxFQUFFMUgsU0FBUyxDQUFDdkU7QUFOTCxpQkFBckIsRUEvQ3NDLENBdUR0QztBQUNILGVBeERELE1BeURJO0FBQ0E7QUFDQTJELHVCQUFPLENBQUN0RyxPQUFSLEdBQWtCaU8sUUFBUSxDQUFDak8sT0FBM0IsQ0FGQSxDQUlBOztBQUNBc0csdUJBQU8sQ0FBQzFFLGlCQUFSLEdBQTRCcU0sUUFBUSxDQUFDck0saUJBQXJDO0FBQ0EwRSx1QkFBTyxDQUFDSCxvQkFBUixHQUErQjhILFFBQVEsQ0FBQzlILG9CQUF4Qzs7QUFFQSxvQkFBSU4sWUFBWSxDQUFDMUcsQ0FBRCxDQUFoQixFQUFvQjtBQUNoQjBHLDhCQUFZLENBQUMxRyxDQUFELENBQVosQ0FBZ0JnSCxvQkFBaEIsR0FBdUM4SCxRQUFRLENBQUM5SCxvQkFBaEQ7QUFDSCxpQkFWRCxDQVdBO0FBQ0E7QUFDQTs7O0FBQ0Esb0JBQUk5QixVQUFVLENBQUM0SixRQUFRLENBQUNqTyxPQUFWLENBQWQsRUFBaUM7QUFDN0I7QUFDQTtBQUNBc0cseUJBQU8sQ0FBQ2tCLFlBQVIsR0FBdUJkLFFBQVEsQ0FBQ3JDLFVBQVUsQ0FBQzRKLFFBQVEsQ0FBQ2pPLE9BQVYsQ0FBVixDQUE2QndILFlBQTlCLENBQS9CO0FBQ0FsQix5QkFBTyxDQUFDb0ksaUJBQVIsR0FBNEJoSSxRQUFRLENBQUNyQyxVQUFVLENBQUM0SixRQUFRLENBQUNqTyxPQUFWLENBQVYsQ0FBNkIwTyxpQkFBOUIsQ0FBcEM7QUFDQSxzQkFBSUcsZUFBZSxHQUFHL0ssa0JBQWtCLENBQUNyQyxPQUFuQixDQUEyQjtBQUFDekIsMkJBQU8sRUFBQ2lPLFFBQVEsQ0FBQ2pPO0FBQWxCLG1CQUEzQixFQUF1RDtBQUFDcUksMEJBQU0sRUFBQyxDQUFDLENBQVQ7QUFBWW9CLHlCQUFLLEVBQUM7QUFBbEIsbUJBQXZELENBQXRCO0FBRUE1Six5QkFBTyxDQUFDQyxHQUFSLENBQVksK0NBQVo7O0FBQ0Esc0JBQUkrTyxlQUFKLEVBQW9CO0FBQ2hCLHdCQUFJQSxlQUFlLENBQUNySCxZQUFoQixJQUFnQ2xCLE9BQU8sQ0FBQ2tCLFlBQTVDLEVBQXlEO0FBQ3JELDBCQUFJc0gsVUFBVSxHQUFJRCxlQUFlLENBQUNySCxZQUFoQixHQUErQmxCLE9BQU8sQ0FBQ2tCLFlBQXhDLEdBQXNELE1BQXRELEdBQTZELElBQTlFO0FBQ0EsMEJBQUl1SCxVQUFVLEdBQUc7QUFDYi9PLCtCQUFPLEVBQUVpTyxRQUFRLENBQUNqTyxPQURMO0FBRWIyTyx5Q0FBaUIsRUFBRUUsZUFBZSxDQUFDckgsWUFGdEI7QUFHYkEsb0NBQVksRUFBRWxCLE9BQU8sQ0FBQ2tCLFlBSFQ7QUFJYi9HLDRCQUFJLEVBQUVxTyxVQUpPO0FBS2J6Ryw4QkFBTSxFQUFFbkIsU0FBUyxDQUFDbUIsTUFMTDtBQU1idUcsa0NBQVUsRUFBRTFILFNBQVMsQ0FBQ3ZFO0FBTlQsdUJBQWpCO0FBUUE4SCxtQ0FBYSxDQUFDL0IsTUFBZCxDQUFxQnFHLFVBQXJCO0FBQ0g7QUFDSjtBQUNKLGlCQXRCRCxNQXVCSTtBQUNBO0FBQ0E7QUFFQXpJLHlCQUFPLENBQUN0RyxPQUFSLEdBQWtCaU8sUUFBUSxDQUFDak8sT0FBM0I7QUFDQXNHLHlCQUFPLENBQUNrQixZQUFSLEdBQXVCLENBQXZCO0FBQ0FsQix5QkFBTyxDQUFDb0ksaUJBQVIsR0FBNEIsQ0FBNUI7QUFFQSxzQkFBSUcsZUFBZSxHQUFHL0ssa0JBQWtCLENBQUNyQyxPQUFuQixDQUEyQjtBQUFDekIsMkJBQU8sRUFBQ2lPLFFBQVEsQ0FBQ2pPO0FBQWxCLG1CQUEzQixFQUF1RDtBQUFDcUksMEJBQU0sRUFBQyxDQUFDLENBQVQ7QUFBWW9CLHlCQUFLLEVBQUM7QUFBbEIsbUJBQXZELENBQXRCOztBQUVBLHNCQUFJb0YsZUFBZSxJQUFLQSxlQUFlLENBQUNySCxZQUFoQixHQUErQixDQUF2RCxFQUEwRDtBQUN0RDNILDJCQUFPLENBQUNDLEdBQVIsQ0FBWSx3RUFBWjtBQUNBMkssaUNBQWEsQ0FBQy9CLE1BQWQsQ0FBcUI7QUFDakIxSSw2QkFBTyxFQUFFaU8sUUFBUSxDQUFDak8sT0FERDtBQUVqQjJPLHVDQUFpQixFQUFFRSxlQUZGO0FBR2pCckgsa0NBQVksRUFBRSxDQUhHO0FBSWpCL0csMEJBQUksRUFBRSxRQUpXO0FBS2pCNEgsNEJBQU0sRUFBRW5CLFNBQVMsQ0FBQ21CLE1BTEQ7QUFNakJ1RyxnQ0FBVSxFQUFFMUgsU0FBUyxDQUFDdkU7QUFOTCxxQkFBckI7QUFRSDtBQUNKO0FBQ0osZUFsSWtCLENBb0luQjs7O0FBQ0Esa0JBQUswRixNQUFNLElBQUl3QixJQUFJLEdBQUMsQ0FBaEIsSUFBdUJ4QixNQUFNLElBQUlySixNQUFNLENBQUMyRixRQUFQLENBQWdCa0MsTUFBaEIsQ0FBdUI2QyxXQUF2QixHQUFtQyxDQUFwRSxJQUEyRXJCLE1BQU0sSUFBSXVCLEtBQXJGLElBQWdHdkIsTUFBTSxHQUFHckosTUFBTSxDQUFDMkYsUUFBUCxDQUFnQmtDLE1BQWhCLENBQXVCbUkscUJBQWhDLElBQXlELENBQTdKLEVBQWdLO0FBQzVKLG9CQUFLM0csTUFBTSxJQUFJckosTUFBTSxDQUFDMkYsUUFBUCxDQUFnQmtDLE1BQWhCLENBQXVCNkMsV0FBdkIsR0FBbUMsQ0FBOUMsSUFBcURyQixNQUFNLEdBQUdySixNQUFNLENBQUMyRixRQUFQLENBQWdCa0MsTUFBaEIsQ0FBdUJtSSxxQkFBaEMsSUFBeUQsQ0FBbEgsRUFBcUg7QUFDakgsc0JBQUkxSSxPQUFPLENBQUNlLE1BQVIsSUFBa0Isb0JBQXRCLEVBQTJDO0FBQ3ZDOUgsdUJBQUcsYUFBTUcsR0FBTixnREFBK0M0RyxPQUFPLENBQUMzRSxnQkFBdkQsMEJBQXVGMkUsT0FBTyxDQUFDMUUsaUJBQS9GLENBQUg7O0FBQ0Esd0JBQUc7QUFDQy9CLDZCQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWjtBQUVBLDBCQUFJSyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSwwQkFBSTBQLGNBQWMsR0FBRzdPLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCMkIsbUJBQWxEO0FBRUFxRSw2QkFBTyxDQUFDNEksZUFBUixHQUEyQkQsY0FBYyxDQUFDL00sVUFBZixJQUE2QitNLGNBQWMsQ0FBQy9NLFVBQWYsQ0FBMEJDLE1BQXhELEdBQWdFQyxVQUFVLENBQUM2TSxjQUFjLENBQUMvTSxVQUFmLENBQTBCQyxNQUEzQixDQUFWLEdBQTZDQyxVQUFVLENBQUNrRSxPQUFPLENBQUM2SSxnQkFBVCxDQUF2SCxHQUFrSixDQUE1SztBQUVILHFCQVJELENBU0EsT0FBTXZQLENBQU4sRUFBUTtBQUNKQyw2QkFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7QUFDQU0sNkJBQU8sQ0FBQ0MsR0FBUixDQUFZLDZCQUFaLEVBQTJDRixDQUEzQztBQUNBMEcsNkJBQU8sQ0FBQzRJLGVBQVIsR0FBMEIsQ0FBMUI7QUFFSDtBQUNKO0FBQ0o7O0FBRURyUCx1QkFBTyxDQUFDQyxHQUFSLENBQVksMENBQVo7QUFDQXNLLDhCQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMsNkJBQVdkLE9BQU8sQ0FBQ3RHO0FBQXBCLGlCQUFwQixFQUFrRCtGLE1BQWxELEdBQTJEZ0gsU0FBM0QsQ0FBcUU7QUFBQzlHLHNCQUFJLEVBQUNLO0FBQU4saUJBQXJFO0FBQ0g7QUFDSixhQTFWRixDQTRWQztBQUNBO0FBRUE7OztBQUNBLGdCQUFLK0IsTUFBTSxHQUFHckosTUFBTSxDQUFDMkYsUUFBUCxDQUFnQmtDLE1BQWhCLENBQXVCbUkscUJBQWhDLElBQXlELENBQTFELElBQWlFM0csTUFBTSxJQUFJdUIsS0FBL0UsRUFBc0Y7QUFDbEYvSixxQkFBTyxDQUFDQyxHQUFSLENBQVksMEJBQVo7QUFDQThGLGdDQUFrQixDQUFDQyxZQUFELENBQWxCO0FBQ0gsYUFuV0YsQ0FxV0M7QUFDQTs7O0FBRUEsZ0JBQUl3QyxNQUFNLElBQUl3QixJQUFJLEdBQUMsQ0FBbkIsRUFBcUI7QUFFakI7QUFFQSxrQkFBSXVGLEdBQUcsR0FBR3hNLElBQUksQ0FBQ3dNLEdBQUwsRUFBVjtBQUNBLGtCQUFJQyxvQkFBb0IsR0FBR3pNLElBQUksQ0FBQ3ZDLEtBQUwsQ0FBVzhNLFdBQVcsQ0FBQ2tDLG9CQUF2QixLQUFnRCxDQUEzRTtBQUNBeFAscUJBQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVosRUFBdUJzUCxHQUF2QjtBQUNBdlAscUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHFCQUFaLEVBQW1DdVAsb0JBQW5DOztBQUVBLGtCQUFJLENBQUNBLG9CQUFELElBQTBCRCxHQUFHLEdBQUdDLG9CQUFQLEdBQStCclEsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQmtDLE1BQWhCLENBQXVCeUksdUJBQW5GLEVBQTRHO0FBQ3hHelAsdUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHFCQUFaLEVBRHdHLENBRXhHOztBQUNBVCwwQkFBVSxDQUFDK0gsSUFBWCxDQUFnQixFQUFoQixFQUFvQjVFLE9BQXBCLENBQW1DaEIsU0FBUCw2QkFBcUI7QUFDN0Msc0JBQUk7QUFDQSx3QkFBSUEsU0FBUyxDQUFDNE0sV0FBVixJQUF5QjVNLFNBQVMsQ0FBQzRNLFdBQVYsQ0FBc0JsSixRQUFuRCxFQUE0RDtBQUN4RCwwQkFBSXFLLFVBQVUsR0FBR3RLLHNCQUFzQixDQUFDekQsU0FBUyxDQUFDNE0sV0FBVixDQUFzQmxKLFFBQXZCLENBQXZDOztBQUNBLDBCQUFJcUssVUFBSixFQUFnQjtBQUNabkYsc0NBQWMsQ0FBQ2hELElBQWYsQ0FBb0I7QUFBQ3BILGlDQUFPLEVBQUV3QixTQUFTLENBQUN4QjtBQUFwQix5QkFBcEIsRUFBa0QrRixNQUFsRCxHQUEyRGdILFNBQTNELENBQXFFO0FBQUM5Ryw4QkFBSSxFQUFDO0FBQUMsMkNBQWNzSjtBQUFmO0FBQU4seUJBQXJFO0FBQ0g7QUFDSjtBQUNKLG1CQVBELENBT0UsT0FBTzNQLENBQVAsRUFBVTtBQUNSQywyQkFBTyxDQUFDQyxHQUFSLENBQVksbUNBQVosRUFBaUQwQixTQUFTLENBQUN4QixPQUEzRCxFQUFvRUosQ0FBcEU7QUFDSDtBQUNKLGlCQVgyQixDQUE1QjtBQWFBNkQscUJBQUssQ0FBQ3lHLE1BQU4sQ0FBYTtBQUFDbEUseUJBQU8sRUFBQytDLEtBQUssQ0FBQ0EsS0FBTixDQUFZaUMsTUFBWixDQUFtQmhGO0FBQTVCLGlCQUFiLEVBQW1EO0FBQUNDLHNCQUFJLEVBQUM7QUFBQ29KLHdDQUFvQixFQUFDLElBQUl6TSxJQUFKLEdBQVc0TSxXQUFYO0FBQXRCO0FBQU4saUJBQW5EO0FBQ0g7QUFFSjs7QUFFRCxnQkFBSUMseUJBQXlCLEdBQUcsSUFBSTdNLElBQUosRUFBaEM7QUFDQS9DLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSwrQkFBOEIsQ0FBQzJQLHlCQUF5QixHQUFDM0IsMkJBQTNCLElBQXdELElBQXRGLEdBQTRGLFVBQXhHLEVBdllELENBeVlDOztBQUNBLGdCQUFJNEIsdUJBQXVCLEdBQUcsSUFBSTlNLElBQUosRUFBOUI7QUFDQWdCLHFCQUFTLENBQUM4RSxNQUFWLENBQWlCekIsYUFBakI7QUFDQSxnQkFBSTBJLHNCQUFzQixHQUFHLElBQUkvTSxJQUFKLEVBQTdCO0FBQ0EvQyxtQkFBTyxDQUFDQyxHQUFSLENBQVksNEJBQTJCLENBQUM2UCxzQkFBc0IsR0FBQ0QsdUJBQXhCLElBQWlELElBQTVFLEdBQWtGLFVBQTlGLEVBN1lELENBK1lDOztBQUVBLGdCQUFJckgsTUFBTSxHQUFHLEVBQVQsSUFBZSxDQUFuQixFQUFxQjtBQUNqQnJCLDZCQUFlLENBQUNDLGFBQUQsRUFBZ0JDLFNBQWhCLENBQWY7QUFDSDs7QUFFRCxnQkFBSTBJLFlBQVksR0FBRyxJQUFJaE4sSUFBSixFQUFuQjs7QUFDQSxnQkFBSXdILGNBQWMsQ0FBQ3JJLE1BQWYsR0FBd0IsQ0FBNUIsRUFBOEI7QUFDMUJsQyxxQkFBTyxDQUFDQyxHQUFSLENBQVksNkNBQVo7QUFDQXNLLDRCQUFjLENBQUNzQixPQUFmLENBQXVCLENBQUNDLEdBQUQsRUFBTXBMLE1BQU4sS0FBaUI7QUFDcEMsb0JBQUlvTCxHQUFKLEVBQVE7QUFDSjlMLHlCQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBWixFQUFxRDZMLEdBQXJEO0FBQ0g7O0FBQ0Qsb0JBQUlwTCxNQUFKLEVBQVc7QUFDUGdLLG9DQUFrQixDQUFDbUIsT0FBbkIsQ0FBMkIsQ0FBQ0MsR0FBRCxFQUFNcEwsTUFBTixLQUFpQjtBQUN4Qyx3QkFBSW9MLEdBQUosRUFBUTtBQUNKOUwsNkJBQU8sQ0FBQ0MsR0FBUixDQUFZLGlEQUFaLEVBQThENkwsR0FBOUQ7QUFDSDs7QUFDRCx3QkFBSXBMLE1BQUosRUFBVyxDQUNWO0FBQ0osbUJBTkQ7QUFPSDtBQUNKLGVBYkQ7QUFjSDs7QUFFRCxnQkFBSXNQLFVBQVUsR0FBRyxJQUFJak4sSUFBSixFQUFqQjtBQUNBL0MsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUEyQixDQUFDK1AsVUFBVSxHQUFDRCxZQUFaLElBQTBCLElBQXJELEdBQTJELFVBQXZFO0FBRUEsZ0JBQUlFLFdBQVcsR0FBRyxJQUFJbE4sSUFBSixFQUFsQjs7QUFDQSxnQkFBSTRILG9CQUFvQixDQUFDekksTUFBckIsR0FBOEIsQ0FBbEMsRUFBb0M7QUFDaEN5SSxrQ0FBb0IsQ0FBQ2tCLE9BQXJCLENBQThCQyxHQUFELElBQVM7QUFDbEMsb0JBQUlBLEdBQUosRUFBUTtBQUNKOUwseUJBQU8sQ0FBQ0MsR0FBUixDQUFZNkwsR0FBWjtBQUNIO0FBQ0osZUFKRDtBQUtIOztBQUVELGdCQUFJb0UsU0FBUyxHQUFHLElBQUluTixJQUFKLEVBQWhCO0FBQ0EvQyxtQkFBTyxDQUFDQyxHQUFSLENBQVksb0NBQW1DLENBQUNpUSxTQUFTLEdBQUNELFdBQVgsSUFBd0IsSUFBM0QsR0FBaUUsVUFBN0U7O0FBRUEsZ0JBQUlyRixhQUFhLENBQUMxSSxNQUFkLEdBQXVCLENBQTNCLEVBQTZCO0FBQ3pCMEksMkJBQWEsQ0FBQ2lCLE9BQWQsQ0FBdUJDLEdBQUQsSUFBUztBQUMzQixvQkFBSUEsR0FBSixFQUFRO0FBQ0o5TCx5QkFBTyxDQUFDQyxHQUFSLENBQVk2TCxHQUFaO0FBQ0g7QUFDSixlQUpEO0FBS0gsYUE3YkYsQ0FnY0M7O0FBQ0gsV0FqY0QsQ0FrY0EsT0FBTy9MLENBQVAsRUFBUztBQUNMQyxtQkFBTyxDQUFDQyxHQUFSLENBQVksMkJBQVosRUFBeUNGLENBQXpDO0FBQ0ErSixtQkFBTyxHQUFHLEtBQVY7QUFDQSxtQkFBTyxTQUFQO0FBQ0g7O0FBQ0QsY0FBSXFHLFlBQVksR0FBRyxJQUFJcE4sSUFBSixFQUFuQjtBQUNBL0MsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFxQixDQUFDa1EsWUFBWSxHQUFDN0YsY0FBZCxJQUE4QixJQUFuRCxHQUF5RCxVQUFyRTtBQUNIOztBQUNEUixlQUFPLEdBQUcsS0FBVjtBQUNBbEcsYUFBSyxDQUFDeUcsTUFBTixDQUFhO0FBQUNsRSxpQkFBTyxFQUFDaEgsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJvQjtBQUFoQyxTQUFiLEVBQXVEO0FBQUNDLGNBQUksRUFBQztBQUFDZ0ssZ0NBQW9CLEVBQUMsSUFBSXJOLElBQUo7QUFBdEI7QUFBTixTQUF2RDtBQUNIOztBQUVELGFBQU9nSCxLQUFQO0FBQ0gsS0ExaEJzQjtBQUFBLEdBeENaO0FBbWtCWCxjQUFZLFVBQVNILEtBQVQsRUFBZ0I7QUFDeEI7QUFDQSxXQUFRQSxLQUFLLEdBQUMsRUFBZDtBQUNILEdBdGtCVTtBQXVrQlgsYUFBVyxVQUFTQSxLQUFULEVBQWdCO0FBQ3ZCLFFBQUlBLEtBQUssR0FBR3pLLE1BQU0sQ0FBQytGLElBQVAsQ0FBWSxrQkFBWixDQUFaLEVBQTZDO0FBQ3pDLGFBQVEsS0FBUjtBQUNILEtBRkQsTUFFTztBQUNILGFBQVEsSUFBUjtBQUNIO0FBQ0o7QUE3a0JVLENBQWYsRTs7Ozs7Ozs7Ozs7QUM5SkEsSUFBSS9GLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXFFLFNBQUo7QUFBY3ZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3NFLFdBQVMsQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsYUFBUyxHQUFDckUsQ0FBVjtBQUFZOztBQUExQixDQUEzQixFQUF1RCxDQUF2RDtBQUEwRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJNEUsWUFBSjtBQUFpQjlFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUM2RSxjQUFZLENBQUM1RSxDQUFELEVBQUc7QUFBQzRFLGdCQUFZLEdBQUM1RSxDQUFiO0FBQWU7O0FBQWhDLENBQWpELEVBQW1GLENBQW5GO0FBS3RQK1EsZ0JBQWdCLENBQUMsZUFBRCxFQUFrQixVQUFTekcsS0FBVCxFQUFlO0FBQzdDLFNBQU87QUFDSHJDLFFBQUksR0FBRTtBQUNGLGFBQU81RCxTQUFTLENBQUM0RCxJQUFWLENBQWUsRUFBZixFQUFtQjtBQUFDcUMsYUFBSyxFQUFFQSxLQUFSO0FBQWVsQyxZQUFJLEVBQUU7QUFBQ2MsZ0JBQU0sRUFBRSxDQUFDO0FBQVY7QUFBckIsT0FBbkIsQ0FBUDtBQUNILEtBSEU7O0FBSUg4SCxZQUFRLEVBQUUsQ0FDTjtBQUNJL0ksVUFBSSxDQUFDMkIsS0FBRCxFQUFPO0FBQ1AsZUFBTzFKLFVBQVUsQ0FBQytILElBQVgsQ0FDSDtBQUFDcEgsaUJBQU8sRUFBQytJLEtBQUssQ0FBQ0g7QUFBZixTQURHLEVBRUg7QUFBQ2EsZUFBSyxFQUFDO0FBQVAsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQWhCZSxDQUFoQjtBQWtCQXlHLGdCQUFnQixDQUFDLGdCQUFELEVBQW1CLFVBQVM3SCxNQUFULEVBQWdCO0FBQy9DLFNBQU87QUFDSGpCLFFBQUksR0FBRTtBQUNGLGFBQU81RCxTQUFTLENBQUM0RCxJQUFWLENBQWU7QUFBQ2lCLGNBQU0sRUFBQ0E7QUFBUixPQUFmLENBQVA7QUFDSCxLQUhFOztBQUlIOEgsWUFBUSxFQUFFLENBQ047QUFDSS9JLFVBQUksQ0FBQzJCLEtBQUQsRUFBTztBQUNQLGVBQU9oRixZQUFZLENBQUNxRCxJQUFiLENBQ0g7QUFBQ2lCLGdCQUFNLEVBQUNVLEtBQUssQ0FBQ1Y7QUFBZCxTQURHLENBQVA7QUFHSDs7QUFMTCxLQURNLEVBUU47QUFDSWpCLFVBQUksQ0FBQzJCLEtBQUQsRUFBTztBQUNQLGVBQU8xSixVQUFVLENBQUMrSCxJQUFYLENBQ0g7QUFBQ3BILGlCQUFPLEVBQUMrSSxLQUFLLENBQUNIO0FBQWYsU0FERyxFQUVIO0FBQUNhLGVBQUssRUFBQztBQUFQLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBUk07QUFKUCxHQUFQO0FBc0JILENBdkJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDdkJBeEssTUFBTSxDQUFDbVIsTUFBUCxDQUFjO0FBQUM1TSxXQUFTLEVBQUMsTUFBSUE7QUFBZixDQUFkO0FBQXlDLElBQUk2TSxLQUFKO0FBQVVwUixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNtUixPQUFLLENBQUNsUixDQUFELEVBQUc7QUFBQ2tSLFNBQUssR0FBQ2xSLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBMUMsRUFBd0UsQ0FBeEU7QUFHN0csTUFBTXFFLFNBQVMsR0FBRyxJQUFJNk0sS0FBSyxDQUFDQyxVQUFWLENBQXFCLFFBQXJCLENBQWxCO0FBRVA5TSxTQUFTLENBQUMrTSxPQUFWLENBQWtCO0FBQ2RDLFVBQVEsR0FBRTtBQUNOLFdBQU9uUixVQUFVLENBQUNvQyxPQUFYLENBQW1CO0FBQUN6QixhQUFPLEVBQUMsS0FBSzRJO0FBQWQsS0FBbkIsQ0FBUDtBQUNIOztBQUhhLENBQWxCLEUsQ0FNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQjs7Ozs7Ozs7Ozs7QUN0QkEsSUFBSTVKLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJc0UsS0FBSixFQUFVZ04sV0FBVjtBQUFzQnhSLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ3VFLE9BQUssQ0FBQ3RFLENBQUQsRUFBRztBQUFDc0UsU0FBSyxHQUFDdEUsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQnNSLGFBQVcsQ0FBQ3RSLENBQUQsRUFBRztBQUFDc1IsZUFBVyxHQUFDdFIsQ0FBWjtBQUFjOztBQUFoRCxDQUExQixFQUE0RSxDQUE1RTtBQUErRSxJQUFJdVIsSUFBSjtBQUFTelIsTUFBTSxDQUFDQyxJQUFQLENBQVksaUNBQVosRUFBOEM7QUFBQ3lSLFNBQU8sQ0FBQ3hSLENBQUQsRUFBRztBQUFDdVIsUUFBSSxHQUFDdlIsQ0FBTDtBQUFPOztBQUFuQixDQUE5QyxFQUFtRSxDQUFuRTs7QUFLdE95UixlQUFlLEdBQUcsQ0FBQ3BQLFNBQUQsRUFBWXFQLGFBQVosS0FBOEI7QUFDNUMsT0FBSyxJQUFJMVIsQ0FBVCxJQUFjMFIsYUFBZCxFQUE0QjtBQUN4QixRQUFJclAsU0FBUyxDQUFDd0QsT0FBVixDQUFrQnRFLEtBQWxCLElBQTJCbVEsYUFBYSxDQUFDMVIsQ0FBRCxDQUFiLENBQWlCNkYsT0FBakIsQ0FBeUJ0RSxLQUF4RCxFQUE4RDtBQUMxRCxhQUFPZ0csUUFBUSxDQUFDbUssYUFBYSxDQUFDMVIsQ0FBRCxDQUFiLENBQWlCMlIsS0FBbEIsQ0FBZjtBQUNIO0FBQ0o7QUFDSixDQU5EOztBQVFBOVIsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw2QkFBMkIsWUFBVTtBQUNqQyxTQUFLRSxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHOEosR0FBRyxHQUFDLHVCQUFkOztBQUNBLFFBQUc7QUFDQyxVQUFJbEosUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsVUFBSXdSLFNBQVMsR0FBRzNRLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWhCO0FBQ0F5USxlQUFTLEdBQUdBLFNBQVMsQ0FBQ3hRLE1BQXRCO0FBQ0EsVUFBSThILE1BQU0sR0FBRzBJLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQjNJLE1BQW5DO0FBQ0EsVUFBSTRJLEtBQUssR0FBR0YsU0FBUyxDQUFDQyxXQUFWLENBQXNCQyxLQUFsQztBQUNBLFVBQUlDLElBQUksR0FBR0gsU0FBUyxDQUFDQyxXQUFWLENBQXNCRSxJQUFqQztBQUNBLFVBQUlDLFVBQVUsR0FBR3hKLElBQUksQ0FBQ3NKLEtBQUwsQ0FBVzdPLFVBQVUsQ0FBQzJPLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkksS0FBdEIsQ0FBNEJILEtBQTVCLEVBQW1DSSxrQkFBbkMsQ0FBc0RDLEtBQXRELENBQTRELEdBQTVELEVBQWlFLENBQWpFLENBQUQsQ0FBVixHQUFnRixHQUEzRixDQUFqQjtBQUVBN04sV0FBSyxDQUFDeUcsTUFBTixDQUFhO0FBQUNsRSxlQUFPLEVBQUNoSCxNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm9CO0FBQWhDLE9BQWIsRUFBdUQ7QUFBQ0MsWUFBSSxFQUFDO0FBQ3pEc0wsc0JBQVksRUFBRWxKLE1BRDJDO0FBRXpEbUoscUJBQVcsRUFBRVAsS0FGNEM7QUFHekRRLG9CQUFVLEVBQUVQLElBSDZDO0FBSXpEQyxvQkFBVSxFQUFFQSxVQUo2QztBQUt6RHZJLHlCQUFlLEVBQUVtSSxTQUFTLENBQUNDLFdBQVYsQ0FBc0IzTSxVQUF0QixDQUFpQ21NLFFBQWpDLENBQTBDeFEsT0FMRjtBQU16RDBSLGtCQUFRLEVBQUVYLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkksS0FBdEIsQ0FBNEJILEtBQTVCLEVBQW1DUyxRQU5ZO0FBT3pEbEYsb0JBQVUsRUFBRXVFLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkksS0FBdEIsQ0FBNEJILEtBQTVCLEVBQW1DekU7QUFQVTtBQUFOLE9BQXZEO0FBU0gsS0FsQkQsQ0FtQkEsT0FBTTVNLENBQU4sRUFBUTtBQUNKQyxhQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBTSxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osR0EzQlU7QUE0Qlgsd0JBQXNCO0FBQUEsb0NBQWdCO0FBQ2xDLFdBQUtLLE9BQUw7QUFDQSxVQUFJVixHQUFHLEdBQUcsRUFBVjs7QUFDQSxVQUFHO0FBQ0NBLFdBQUcsR0FBR0csR0FBRyxHQUFHLGdCQUFaO0FBQ0EsWUFBSVMsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsWUFBSW9TLFdBQVcsR0FBR3ZSLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWxCO0FBRUEsWUFBSXNSLEtBQUssR0FBRyxFQUFaO0FBQ0FBLGFBQUssQ0FBQzVMLE9BQU4sR0FBZ0IyTCxXQUFXLENBQUM1SSxLQUFaLENBQWtCaUMsTUFBbEIsQ0FBeUJvQyxRQUF6QztBQUNBd0UsYUFBSyxDQUFDQyxpQkFBTixHQUEwQm5MLFFBQVEsQ0FBQ2lMLFdBQVcsQ0FBQzVJLEtBQVosQ0FBa0JpQyxNQUFsQixDQUF5QjNDLE1BQTFCLENBQWxDO0FBQ0F1SixhQUFLLENBQUNFLGVBQU4sR0FBd0JILFdBQVcsQ0FBQzVJLEtBQVosQ0FBa0JpQyxNQUFsQixDQUF5QnJJLElBQWpEO0FBQ0EsWUFBSW9QLFdBQVcsR0FBR3RCLFdBQVcsQ0FBQ2hQLE9BQVosQ0FBb0IsRUFBcEIsRUFBd0I7QUFBQzhGLGNBQUksRUFBRTtBQUFDYyxrQkFBTSxFQUFFLENBQUM7QUFBVjtBQUFQLFNBQXhCLENBQWxCOztBQUNBLFlBQUkwSixXQUFXLElBQUlBLFdBQVcsQ0FBQzFKLE1BQVosSUFBc0J1SixLQUFLLENBQUNDLGlCQUEvQyxFQUFrRTtBQUM5RCxxREFBb0NELEtBQUssQ0FBQ0MsaUJBQTFDLHVCQUF3RUUsV0FBVyxDQUFDMUosTUFBcEY7QUFDSCxTQVpGLENBY0M7QUFDQTtBQUVBO0FBQ0E7OztBQUVBLFlBQUloRSxVQUFVLEdBQUcsRUFBakI7QUFDQSxZQUFJb0IsSUFBSSxHQUFHLENBQVg7O0FBRUEsV0FBRztBQUNDbEcsYUFBRyxHQUFHOEosR0FBRyw4QkFBcUIsRUFBRTVELElBQXZCLGtCQUFUO0FBQ0EsY0FBSXRGLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBZ0IsZ0JBQU0sR0FBR0gsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQXRDO0FBQ0E4RCxvQkFBVSxHQUFHLENBQUMsR0FBR0EsVUFBSixFQUFnQixHQUFHOUQsTUFBTSxDQUFDOEQsVUFBMUIsQ0FBYjtBQUVILFNBTkQsUUFPT0EsVUFBVSxDQUFDdEMsTUFBWCxHQUFvQjJFLFFBQVEsQ0FBQ25HLE1BQU0sQ0FBQ2dCLEtBQVIsQ0FQbkM7O0FBU0FxUSxhQUFLLENBQUN2TixVQUFOLEdBQW1CQSxVQUFVLENBQUN0QyxNQUE5QjtBQUNBLFlBQUlpUSxRQUFRLEdBQUcsQ0FBZjs7QUFDQSxhQUFLN1MsQ0FBTCxJQUFVa0YsVUFBVixFQUFxQjtBQUNqQjJOLGtCQUFRLElBQUl0TCxRQUFRLENBQUNyQyxVQUFVLENBQUNsRixDQUFELENBQVYsQ0FBY3FJLFlBQWYsQ0FBcEI7QUFDSDs7QUFDRG9LLGFBQUssQ0FBQ0ssaUJBQU4sR0FBMEJELFFBQTFCLENBckNELENBdUNDOztBQUNBLFlBQUk7QUFDQXpTLGFBQUcsR0FBR0csR0FBRyxHQUFHLGdDQUFaO0FBQ0FTLGtCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQXFTLGVBQUssQ0FBQ00sT0FBTixHQUFnQjlSLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWhCO0FBQ0gsU0FKRCxDQUtBLE9BQU1WLENBQU4sRUFBUTtBQUNKQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxTQS9DRixDQWlEQzs7O0FBQ0EsWUFBSThHLFFBQVEsQ0FBQ2tMLEtBQUssQ0FBQ0MsaUJBQVAsQ0FBUixHQUFvQyxDQUF4QyxFQUEwQztBQUN0QyxjQUFJTSxXQUFXLEdBQUcsRUFBbEI7QUFDQUEscUJBQVcsQ0FBQzlKLE1BQVosR0FBcUIzQixRQUFRLENBQUNrTCxLQUFLLENBQUNDLGlCQUFQLENBQTdCO0FBQ0FNLHFCQUFXLENBQUN4UCxJQUFaLEdBQW1CLElBQUlDLElBQUosQ0FBU2dQLEtBQUssQ0FBQ0UsZUFBZixDQUFuQjs7QUFFQSxjQUFHO0FBQ0N2UyxlQUFHLEdBQUdHLEdBQUcsR0FBRyw4QkFBWjtBQUNBLGdCQUFJUyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxnQkFBSTZTLE9BQU8sR0FBR2hTLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCK1IsSUFBM0M7QUFDQUYsdUJBQVcsQ0FBQ0csWUFBWixHQUEyQjVMLFFBQVEsQ0FBQzBMLE9BQU8sQ0FBQ0csYUFBVCxDQUFuQztBQUNBSix1QkFBVyxDQUFDSyxlQUFaLEdBQThCOUwsUUFBUSxDQUFDMEwsT0FBTyxDQUFDSyxpQkFBVCxDQUF0QztBQUNILFdBTkQsQ0FPQSxPQUFNN1MsQ0FBTixFQUFRO0FBQ0pDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVELGNBQUs4USxJQUFJLENBQUNnQyxXQUFMLENBQWlCQyxLQUF0QixFQUE4QjtBQUMxQixnQkFBSTNULE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCZ08sT0FBdkIsQ0FBK0JDLElBQW5DLEVBQXdDO0FBQ3BDLGtCQUFHO0FBQ0N0VCxtQkFBRyxHQUFHRyxHQUFHLEdBQUcsOEJBQU4sR0FBdUNnUixJQUFJLENBQUNnQyxXQUFMLENBQWlCQyxLQUE5RDtBQUNBLG9CQUFJeFMsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0Esb0JBQUl1VCxNQUFNLEdBQUcxUyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFiO0FBQ0E2UiwyQkFBVyxDQUFDWSxXQUFaLEdBQTBCck0sUUFBUSxDQUFDb00sTUFBTSxDQUFDRSxNQUFQLENBQWNBLE1BQWYsQ0FBbEM7QUFDSCxlQUxELENBTUEsT0FBTXBULENBQU4sRUFBUTtBQUNKQyx1QkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxlQVRtQyxDQVdwQzs7O0FBQ0Esa0JBQUk7QUFDQUwsbUJBQUcsR0FBR0csR0FBRyxHQUFHLDZCQUFaO0FBQ0FTLHdCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQXFTLHFCQUFLLENBQUNpQixJQUFOLEdBQWF6UyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFiO0FBQ0gsZUFKRCxDQUtBLE9BQU1WLENBQU4sRUFBUTtBQUNKQyx1QkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUVKOztBQUVELGdCQUFJWixNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1QmdPLE9BQXZCLENBQStCSyxZQUFuQyxFQUFnRDtBQUM1QyxrQkFBSTtBQUNBMVQsbUJBQUcsR0FBR0csR0FBRyxHQUFHLDZDQUFaO0FBQ0Esb0JBQUlTLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLG9CQUFJOFMsSUFBSSxHQUFHalMsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkIrUixJQUF4Qzs7QUFDQSxvQkFBSUEsSUFBSSxJQUFJQSxJQUFJLENBQUN0USxNQUFMLEdBQWMsQ0FBMUIsRUFBNEI7QUFDeEJvUSw2QkFBVyxDQUFDZSxhQUFaLEdBQTRCLEVBQTVCO0FBQ0FiLHNCQUFJLENBQUM3UCxPQUFMLENBQWN3USxNQUFELElBQVk7QUFDckJiLCtCQUFXLENBQUNlLGFBQVosQ0FBMEJ6RyxJQUExQixDQUErQjtBQUMzQmtHLDJCQUFLLEVBQUVLLE1BQU0sQ0FBQ0wsS0FEYTtBQUUzQkssNEJBQU0sRUFBRTVRLFVBQVUsQ0FBQzRRLE1BQU0sQ0FBQ0EsTUFBUjtBQUZTLHFCQUEvQjtBQUlILG1CQUxEO0FBTUg7QUFDSixlQWJELENBY0EsT0FBT3BULENBQVAsRUFBUztBQUNMQyx1QkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxlQWpCMkMsQ0FtQjVDOzs7QUFDQSxrQkFBSTtBQUNBTCxtQkFBRyxHQUFHRyxHQUFHLEdBQUcscUNBQVo7QUFDQVMsd0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBcVMscUJBQUssQ0FBQ3FCLFlBQU4sR0FBcUI3UyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFyQjtBQUNILGVBSkQsQ0FLQSxPQUFNVixDQUFOLEVBQVE7QUFDSkMsdUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSjs7QUFFRCxnQkFBSVosTUFBTSxDQUFDMkYsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJnTyxPQUF2QixDQUErQk8sT0FBbkMsRUFBMkM7QUFDdkMsa0JBQUc7QUFDQzVULG1CQUFHLEdBQUdHLEdBQUcsR0FBRyxnQ0FBWjtBQUNBLG9CQUFJUyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxvQkFBSTZULFNBQVMsR0FBR2hULElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCOFMsU0FBN0MsQ0FIRCxDQUlDO0FBQ0E7O0FBQ0Esb0JBQUlBLFNBQUosRUFBYztBQUNWakIsNkJBQVcsQ0FBQ2lCLFNBQVosR0FBd0JoUixVQUFVLENBQUNnUixTQUFELENBQWxDO0FBQ0g7QUFDSixlQVRELENBVUEsT0FBTXhULENBQU4sRUFBUTtBQUNKQyx1QkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFRCxrQkFBRztBQUNDTCxtQkFBRyxHQUFHRyxHQUFHLEdBQUcsd0NBQVo7QUFDQSxvQkFBSVMsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0Esb0JBQUk4VCxVQUFVLEdBQUdqVCxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QmdULGlCQUE5QztBQUNBelQsdUJBQU8sQ0FBQ0MsR0FBUixDQUFZdVQsVUFBWjs7QUFDQSxvQkFBSUEsVUFBSixFQUFlO0FBQ1hsQiw2QkFBVyxDQUFDb0IsZ0JBQVosR0FBK0JuUixVQUFVLENBQUNpUixVQUFELENBQXpDO0FBQ0g7QUFDSixlQVJELENBU0EsT0FBTXpULENBQU4sRUFBUTtBQUNKQyx1QkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxlQTFCc0MsQ0E0QnZDOzs7QUFDQSxrQkFBSTtBQUNBTCxtQkFBRyxHQUFHRyxHQUFHLEdBQUcsNkJBQVo7QUFDQVMsd0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBcVMscUJBQUssQ0FBQzRCLElBQU4sR0FBYXBULElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWI7QUFDSCxlQUpELENBS0EsT0FBTVYsQ0FBTixFQUFRO0FBQ0pDLHVCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0o7O0FBRUQsZ0JBQUlaLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCZ08sT0FBdkIsQ0FBK0JhLEdBQW5DLEVBQXVDO0FBQ25DO0FBQ0Esa0JBQUk7QUFDQWxVLG1CQUFHLEdBQUdHLEdBQUcsR0FBRyw0QkFBWjtBQUNBUyx3QkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0FxUyxxQkFBSyxDQUFDNkIsR0FBTixHQUFZclQsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBWjtBQUNILGVBSkQsQ0FLQSxPQUFNVixDQUFOLEVBQVE7QUFDSkMsdUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSjtBQUNKOztBQUVENlEscUJBQVcsQ0FBQy9ILE1BQVosQ0FBbUJ5SixXQUFuQjtBQUNIOztBQUVEMU8sYUFBSyxDQUFDeUcsTUFBTixDQUFhO0FBQUNsRSxpQkFBTyxFQUFDNEwsS0FBSyxDQUFDNUw7QUFBZixTQUFiLEVBQXNDO0FBQUNDLGNBQUksRUFBQzJMO0FBQU4sU0FBdEMsRUFBb0Q7QUFBQzdMLGdCQUFNLEVBQUU7QUFBVCxTQUFwRCxFQS9LRCxDQWlMQztBQUVBO0FBQ0E7O0FBQ0EsZUFBTzZMLEtBQUssQ0FBQ0MsaUJBQWI7QUFDSCxPQXRMRCxDQXVMQSxPQUFPalMsQ0FBUCxFQUFTO0FBQ0xDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZUCxHQUFaO0FBQ0FNLGVBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0EsZUFBTyw2QkFBUDtBQUNIO0FBQ0osS0EvTHFCO0FBQUEsR0E1Qlg7QUE0TlgsMkJBQXlCLFlBQVU7QUFDL0IsU0FBS0ssT0FBTDtBQUNBd0QsU0FBSyxDQUFDMkQsSUFBTixHQUFhRyxJQUFiLENBQWtCO0FBQUNtTSxhQUFPLEVBQUMsQ0FBQztBQUFWLEtBQWxCLEVBQWdDakssS0FBaEMsQ0FBc0MsQ0FBdEM7QUFDSDtBQS9OVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDYkEsSUFBSXpLLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXNFLEtBQUosRUFBVWdOLFdBQVY7QUFBc0J4UixNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUN1RSxPQUFLLENBQUN0RSxDQUFELEVBQUc7QUFBQ3NFLFNBQUssR0FBQ3RFLENBQU47QUFBUSxHQUFsQjs7QUFBbUJzUixhQUFXLENBQUN0UixDQUFELEVBQUc7QUFBQ3NSLGVBQVcsR0FBQ3RSLENBQVo7QUFBYzs7QUFBaEQsQ0FBMUIsRUFBNEUsQ0FBNUU7QUFBK0UsSUFBSXdVLFNBQUo7QUFBYzFVLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUN5VSxXQUFTLENBQUN4VSxDQUFELEVBQUc7QUFBQ3dVLGFBQVMsR0FBQ3hVLENBQVY7QUFBWTs7QUFBMUIsQ0FBN0MsRUFBeUUsQ0FBekU7QUFBNEUsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFLOVFILE1BQU0sQ0FBQzRVLE9BQVAsQ0FBZSxvQkFBZixFQUFxQyxZQUFZO0FBQzdDLFNBQU8sQ0FDSG5ELFdBQVcsQ0FBQ3JKLElBQVosQ0FBaUIsRUFBakIsRUFBb0I7QUFBQ0csUUFBSSxFQUFDO0FBQUNjLFlBQU0sRUFBQyxDQUFDO0FBQVQsS0FBTjtBQUFrQm9CLFNBQUssRUFBQztBQUF4QixHQUFwQixDQURHLEVBRUhrSyxTQUFTLENBQUN2TSxJQUFWLENBQWUsRUFBZixFQUFrQjtBQUFDRyxRQUFJLEVBQUM7QUFBQ3NNLHFCQUFlLEVBQUMsQ0FBQztBQUFsQixLQUFOO0FBQTJCcEssU0FBSyxFQUFDO0FBQWpDLEdBQWxCLENBRkcsQ0FBUDtBQUlILENBTEQ7QUFPQXlHLGdCQUFnQixDQUFDLGNBQUQsRUFBaUIsWUFBVTtBQUN2QyxTQUFPO0FBQ0g5SSxRQUFJLEdBQUU7QUFDRixhQUFPM0QsS0FBSyxDQUFDMkQsSUFBTixDQUFXO0FBQUNwQixlQUFPLEVBQUNoSCxNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm9CO0FBQWhDLE9BQVgsQ0FBUDtBQUNILEtBSEU7O0FBSUhtSyxZQUFRLEVBQUUsQ0FDTjtBQUNJL0ksVUFBSSxDQUFDd0ssS0FBRCxFQUFPO0FBQ1AsZUFBT3ZTLFVBQVUsQ0FBQytILElBQVgsQ0FDSCxFQURHLEVBRUg7QUFBQzBNLGdCQUFNLEVBQUM7QUFDSjlULG1CQUFPLEVBQUMsQ0FESjtBQUVKb08sdUJBQVcsRUFBQyxDQUZSO0FBR0p2TSwyQkFBZSxFQUFDLENBSFo7QUFJSndGLGtCQUFNLEVBQUMsQ0FBQyxDQUpKO0FBS0pDLGtCQUFNLEVBQUMsQ0FMSDtBQU1KK0csdUJBQVcsRUFBQztBQU5SO0FBQVIsU0FGRyxDQUFQO0FBV0g7O0FBYkwsS0FETTtBQUpQLEdBQVA7QUFzQkgsQ0F2QmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNaQXBQLE1BQU0sQ0FBQ21SLE1BQVAsQ0FBYztBQUFDM00sT0FBSyxFQUFDLE1BQUlBLEtBQVg7QUFBaUJnTixhQUFXLEVBQUMsTUFBSUE7QUFBakMsQ0FBZDtBQUE2RCxJQUFJSixLQUFKO0FBQVVwUixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNtUixPQUFLLENBQUNsUixDQUFELEVBQUc7QUFBQ2tSLFNBQUssR0FBQ2xSLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBMUMsRUFBd0UsQ0FBeEU7QUFHakksTUFBTXNFLEtBQUssR0FBRyxJQUFJNE0sS0FBSyxDQUFDQyxVQUFWLENBQXFCLE9BQXJCLENBQWQ7QUFDQSxNQUFNRyxXQUFXLEdBQUcsSUFBSUosS0FBSyxDQUFDQyxVQUFWLENBQXFCLGNBQXJCLENBQXBCO0FBRVA3TSxLQUFLLENBQUM4TSxPQUFOLENBQWM7QUFDVkMsVUFBUSxHQUFFO0FBQ04sV0FBT25SLFVBQVUsQ0FBQ29DLE9BQVgsQ0FBbUI7QUFBQ3pCLGFBQU8sRUFBQyxLQUFLNEk7QUFBZCxLQUFuQixDQUFQO0FBQ0g7O0FBSFMsQ0FBZCxFOzs7Ozs7Ozs7OztBQ05BLElBQUk1SixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl3VSxTQUFKO0FBQWMxVSxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDeVUsV0FBUyxDQUFDeFUsQ0FBRCxFQUFHO0FBQUN3VSxhQUFTLEdBQUN4VSxDQUFWO0FBQVk7O0FBQTFCLENBQS9CLEVBQTJELENBQTNEO0FBQThELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFJckpILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNEJBQTBCLFlBQVU7QUFDaEMsU0FBS0UsT0FBTDtBQUNBLFFBQUk4VCxNQUFNLEdBQUcvVSxNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm9QLFdBQXBDOztBQUNBLFFBQUlELE1BQUosRUFBVztBQUNQLFVBQUc7QUFDQyxZQUFJM0UsR0FBRyxHQUFHLElBQUl4TSxJQUFKLEVBQVY7QUFDQXdNLFdBQUcsQ0FBQzZFLFVBQUosQ0FBZSxDQUFmO0FBQ0EsWUFBSTFVLEdBQUcsR0FBRyx1REFBcUR3VSxNQUFyRCxHQUE0RCx3SEFBdEU7QUFDQSxZQUFJNVQsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmOztBQUNBLFlBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQjtBQUNBLGNBQUlxQyxJQUFJLEdBQUc1QixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFYO0FBQ0EwQixjQUFJLEdBQUdBLElBQUksQ0FBQytSLE1BQUQsQ0FBWCxDQUgyQixDQUkzQjs7QUFDQSxpQkFBT0osU0FBUyxDQUFDNU4sTUFBVixDQUFpQjtBQUFDOE4sMkJBQWUsRUFBQzdSLElBQUksQ0FBQzZSO0FBQXRCLFdBQWpCLEVBQXlEO0FBQUM1TixnQkFBSSxFQUFDakU7QUFBTixXQUF6RCxDQUFQO0FBQ0g7QUFDSixPQVpELENBYUEsT0FBTXBDLENBQU4sRUFBUTtBQUNKQyxlQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBTSxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osS0FsQkQsTUFtQkk7QUFDQSxhQUFPLDJCQUFQO0FBQ0g7QUFDSixHQTFCVTtBQTJCWCx3QkFBc0IsWUFBVTtBQUM1QixTQUFLSyxPQUFMO0FBQ0EsUUFBSThULE1BQU0sR0FBRy9VLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCb1AsV0FBcEM7O0FBQ0EsUUFBSUQsTUFBSixFQUFXO0FBQ1AsYUFBUUosU0FBUyxDQUFDbFMsT0FBVixDQUFrQixFQUFsQixFQUFxQjtBQUFDOEYsWUFBSSxFQUFDO0FBQUNzTSx5QkFBZSxFQUFDLENBQUM7QUFBbEI7QUFBTixPQUFyQixDQUFSO0FBQ0gsS0FGRCxNQUdJO0FBQ0EsYUFBTywyQkFBUDtBQUNIO0FBRUo7QUFyQ1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBNVUsTUFBTSxDQUFDbVIsTUFBUCxDQUFjO0FBQUN1RCxXQUFTLEVBQUMsTUFBSUE7QUFBZixDQUFkO0FBQXlDLElBQUl0RCxLQUFKO0FBQVVwUixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNtUixPQUFLLENBQUNsUixDQUFELEVBQUc7QUFBQ2tSLFNBQUssR0FBQ2xSLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFNUMsTUFBTXdVLFNBQVMsR0FBRyxJQUFJdEQsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFlBQXJCLENBQWxCLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSXRSLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSStVLFdBQUo7QUFBZ0JqVixNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDZ1YsYUFBVyxDQUFDL1UsQ0FBRCxFQUFHO0FBQUMrVSxlQUFXLEdBQUMvVSxDQUFaO0FBQWM7O0FBQTlCLENBQWhDLEVBQWdFLENBQWhFO0FBQW1FLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBSWxLSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLGdDQUE4QjtBQUFBLG9DQUFnQjtBQUMxQyxXQUFLRSxPQUFMO0FBQ0EsVUFBSW9FLFVBQVUsR0FBR2hGLFVBQVUsQ0FBQytILElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0JLLEtBQXBCLEVBQWpCO0FBQ0EsVUFBSXhHLFdBQVcsR0FBRyxFQUFsQjtBQUNBcEIsYUFBTyxDQUFDQyxHQUFSLENBQVksNkJBQVo7O0FBQ0EsV0FBS1gsQ0FBTCxJQUFVa0YsVUFBVixFQUFxQjtBQUNqQixZQUFJQSxVQUFVLENBQUNsRixDQUFELENBQVYsQ0FBY3dDLGdCQUFsQixFQUFtQztBQUMvQixjQUFJcEMsR0FBRyxHQUFHRyxHQUFHLEdBQUcscUNBQU4sR0FBNEMyRSxVQUFVLENBQUNsRixDQUFELENBQVYsQ0FBYzBDLGVBQTFELEdBQTBFLGNBQXBGOztBQUNBLGNBQUc7QUFDQyxnQkFBSTFCLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjs7QUFDQSxnQkFBSVksUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLGtCQUFJdUMsVUFBVSxHQUFHOUIsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTlDLENBRDJCLENBRTNCOztBQUNBVSx5QkFBVyxHQUFHQSxXQUFXLENBQUNrVCxNQUFaLENBQW1CalMsVUFBbkIsQ0FBZDtBQUNILGFBSkQsTUFLSTtBQUNBckMscUJBQU8sQ0FBQ0MsR0FBUixDQUFZSyxRQUFRLENBQUNSLFVBQXJCO0FBQ0g7QUFDSixXQVZELENBV0EsT0FBT0MsQ0FBUCxFQUFTO0FBQ0w7QUFDQUMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSjtBQUNKOztBQUVELFVBQUlvQyxJQUFJLEdBQUc7QUFDUGYsbUJBQVcsRUFBRUEsV0FETjtBQUVQbVQsaUJBQVMsRUFBRSxJQUFJeFIsSUFBSjtBQUZKLE9BQVg7QUFLQSxhQUFPc1IsV0FBVyxDQUFDeEwsTUFBWixDQUFtQjFHLElBQW5CLENBQVA7QUFDSCxLQWhDNkI7QUFBQTtBQURuQixDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0pBL0MsTUFBTSxDQUFDbVIsTUFBUCxDQUFjO0FBQUM4RCxhQUFXLEVBQUMsTUFBSUE7QUFBakIsQ0FBZDtBQUE2QyxJQUFJN0QsS0FBSjtBQUFVcFIsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDbVIsT0FBSyxDQUFDbFIsQ0FBRCxFQUFHO0FBQUNrUixTQUFLLEdBQUNsUixDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRWhELE1BQU0rVSxXQUFXLEdBQUcsSUFBSTdELEtBQUssQ0FBQ0MsVUFBVixDQUFxQixhQUFyQixDQUFwQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUkrRCxhQUFKOztBQUFrQnBWLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNDQUFaLEVBQW1EO0FBQUN5UixTQUFPLENBQUN4UixDQUFELEVBQUc7QUFBQ2tWLGlCQUFhLEdBQUNsVixDQUFkO0FBQWdCOztBQUE1QixDQUFuRCxFQUFpRixDQUFqRjtBQUFsQixJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksNkJBQVosRUFBMEM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTFDLEVBQXdFLENBQXhFO0FBR3ZFSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLHdCQUFzQixVQUFTdVUsTUFBVCxFQUFpQjtBQUNuQyxTQUFLclUsT0FBTDtBQUNBLFVBQU1WLEdBQUcsYUFBTUcsR0FBTixTQUFUO0FBQ0FzQyxRQUFJLEdBQUc7QUFDSCxZQUFNc1MsTUFBTSxDQUFDNVQsS0FEVjtBQUVILGNBQVE7QUFGTCxLQUFQO0FBSUEsVUFBTTZULFNBQVMsR0FBRyxJQUFJM1IsSUFBSixHQUFXK0ssT0FBWCxFQUFsQjtBQUNBOU4sV0FBTyxDQUFDQyxHQUFSLGlDQUFxQ3lVLFNBQXJDLGNBQWtEaFYsR0FBbEQsd0JBQW1FYSxJQUFJLENBQUNrRixTQUFMLENBQWV0RCxJQUFmLENBQW5FO0FBRUEsUUFBSTdCLFFBQVEsR0FBR2YsSUFBSSxDQUFDb1YsSUFBTCxDQUFValYsR0FBVixFQUFlO0FBQUN5QztBQUFELEtBQWYsQ0FBZjtBQUNBbkMsV0FBTyxDQUFDQyxHQUFSLG1DQUF1Q3lVLFNBQXZDLGNBQW9EaFYsR0FBcEQsZUFBNERhLElBQUksQ0FBQ2tGLFNBQUwsQ0FBZW5GLFFBQWYsQ0FBNUQ7O0FBQ0EsUUFBSUEsUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQWdDO0FBQzVCLFVBQUlxQyxJQUFJLEdBQUc3QixRQUFRLENBQUM2QixJQUFwQjtBQUNBLFVBQUlBLElBQUksQ0FBQ3lTLElBQVQsRUFDSSxNQUFNLElBQUl6VixNQUFNLENBQUMwVixLQUFYLENBQWlCMVMsSUFBSSxDQUFDeVMsSUFBdEIsRUFBNEJyVSxJQUFJLENBQUNDLEtBQUwsQ0FBVzJCLElBQUksQ0FBQzJTLE9BQWhCLEVBQXlCQyxPQUFyRCxDQUFOO0FBQ0osYUFBT3pVLFFBQVEsQ0FBQzZCLElBQVQsQ0FBY3FKLE1BQXJCO0FBQ0g7QUFDSixHQW5CVTtBQW9CWCx5QkFBdUIsVUFBU3dKLElBQVQsRUFBZUMsSUFBZixFQUFxQjtBQUN4QyxTQUFLN1UsT0FBTDtBQUNBLFVBQU1WLEdBQUcsYUFBTUcsR0FBTixjQUFhb1YsSUFBYixDQUFUO0FBQ0E5UyxRQUFJLEdBQUc7QUFDSCxrREFDTzZTLElBRFA7QUFFSSxvQkFBWTdWLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCb0IsT0FGdkM7QUFHSSxvQkFBWTtBQUhoQjtBQURHLEtBQVA7QUFPQSxRQUFJN0YsUUFBUSxHQUFHZixJQUFJLENBQUNvVixJQUFMLENBQVVqVixHQUFWLEVBQWU7QUFBQ3lDO0FBQUQsS0FBZixDQUFmOztBQUNBLFFBQUk3QixRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsYUFBT1MsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBUDtBQUNIO0FBQ0osR0FsQ1U7QUFtQ1gsMEJBQXdCLFVBQVN5VSxLQUFULEVBQWdCeEosSUFBaEIsRUFBc0J5SixhQUF0QixFQUFxQ0MsUUFBckMsRUFBK0NILElBQS9DLEVBQXVFO0FBQUEsUUFBbEJJLFVBQWtCLHVFQUFQLEtBQU87QUFDM0YsU0FBS2pWLE9BQUw7QUFDQSxVQUFNVixHQUFHLGFBQU1HLEdBQU4sY0FBYW9WLElBQWIsQ0FBVDtBQUNBalYsV0FBTyxDQUFDQyxHQUFSLENBQVlpVixLQUFaO0FBQ0EvUyxRQUFJLG1DQUFPK1MsS0FBUDtBQUNBLGtCQUFZO0FBQ1IsZ0JBQVF4SixJQURBO0FBRVIsb0JBQVl2TSxNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm9CLE9BRjNCO0FBR1IsMEJBQWtCa1AsVUFIVjtBQUlSLDBCQUFrQkYsYUFKVjtBQUtSLG9CQUFZQyxRQUxKO0FBTVIsb0JBQVk7QUFOSjtBQURaLE1BQUo7QUFVQXBWLFdBQU8sQ0FBQ0MsR0FBUixDQUFZUCxHQUFaO0FBQ0FNLFdBQU8sQ0FBQ0MsR0FBUixDQUFZa0MsSUFBWjtBQUNBLFFBQUk3QixRQUFRLEdBQUdmLElBQUksQ0FBQ29WLElBQUwsQ0FBVWpWLEdBQVYsRUFBZTtBQUFDeUM7QUFBRCxLQUFmLENBQWY7O0FBQ0EsUUFBSTdCLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUFnQztBQUM1QixhQUFPUyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QjZVLFlBQXBDO0FBQ0g7QUFDSixHQXZEVTtBQXdEWCxpQkFBZSxVQUFTblYsT0FBVCxFQUFpQjtBQUM1QixTQUFLQyxPQUFMO0FBQ0EsUUFBSXVCLFNBQVMsR0FBR25DLFVBQVUsQ0FBQ29DLE9BQVgsQ0FBbUI7QUFBQ0csdUJBQWlCLEVBQUM1QjtBQUFuQixLQUFuQixDQUFoQjtBQUNBLFdBQU93QixTQUFQO0FBQ0g7QUE1RFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ0hBLElBQUk2UyxhQUFKOztBQUFrQnBWLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNDQUFaLEVBQW1EO0FBQUN5UixTQUFPLENBQUN4UixDQUFELEVBQUc7QUFBQ2tWLGlCQUFhLEdBQUNsVixDQUFkO0FBQWdCOztBQUE1QixDQUFuRCxFQUFpRixDQUFqRjtBQUFsQixJQUFJSCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSWlXLFNBQUo7QUFBY25XLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGlCQUFaLEVBQThCO0FBQUNrVyxXQUFTLENBQUNqVyxDQUFELEVBQUc7QUFBQ2lXLGFBQVMsR0FBQ2pXLENBQVY7QUFBWTs7QUFBMUIsQ0FBOUIsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSXNFLEtBQUo7QUFBVXhFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUN1RSxPQUFLLENBQUN0RSxDQUFELEVBQUc7QUFBQ3NFLFNBQUssR0FBQ3RFLENBQU47QUFBUTs7QUFBbEIsQ0FBbkMsRUFBdUQsQ0FBdkQ7QUFBMEQsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFNdFJILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNEJBQTBCLFlBQVU7QUFDaEMsU0FBS0UsT0FBTCxHQURnQyxDQUdoQzs7QUFDQSxRQUFJVixHQUFHLEdBQUdHLEdBQUcsR0FBRyxxQ0FBaEI7O0FBQ0EsUUFBRztBQUNDLFVBQUlTLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLFVBQUlzSCxNQUFNLEdBQUd6RyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFiO0FBRUFtRCxXQUFLLENBQUN5RyxNQUFOLENBQWE7QUFBQ2xFLGVBQU8sRUFBRWhILE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCb0I7QUFBakMsT0FBYixFQUF3RDtBQUFDQyxZQUFJLEVBQUM7QUFBQyw2QkFBa0JZLE1BQU0sQ0FBQ3dPO0FBQTFCO0FBQU4sT0FBeEQ7QUFFQTlWLFNBQUcsR0FBR0csR0FBRyxHQUFHLCtCQUFaO0FBQ0FTLGNBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLFVBQUkrVixTQUFTLEdBQUdsVixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QmdWLFNBQTdDLENBUkQsQ0FTQzs7QUFFQSxVQUFJQyxtQkFBbUIsR0FBRyxJQUFJQyxHQUFKLENBQVFKLFNBQVMsQ0FBQ2hPLElBQVYsQ0FDOUI7QUFBQywyQkFBa0I7QUFBQzZCLGFBQUcsRUFBQyxDQUFDLHdCQUFELEVBQTJCLDBCQUEzQixFQUF1RCx5QkFBdkQ7QUFBTDtBQUFuQixPQUQ4QixFQUVoQ3hCLEtBRmdDLEdBRXhCcUIsR0FGd0IsQ0FFbkJ4RSxDQUFELElBQU1BLENBQUMsQ0FBQ21SLFVBRlksQ0FBUixDQUExQjtBQUlBLFVBQUlDLFdBQVcsR0FBRyxFQUFsQjs7QUFDQSxVQUFJSixTQUFTLENBQUN2VCxNQUFWLEdBQW1CLENBQXZCLEVBQXlCO0FBQ3JCO0FBQ0EsY0FBTTRULGFBQWEsR0FBR1AsU0FBUyxDQUFDL0ssYUFBVixHQUEwQkMseUJBQTFCLEVBQXRCOztBQUNBLGFBQUssSUFBSXJILENBQVQsSUFBY3FTLFNBQWQsRUFBd0I7QUFDcEIsY0FBSU0sUUFBUSxHQUFHTixTQUFTLENBQUNyUyxDQUFELENBQXhCO0FBQ0EyUyxrQkFBUSxDQUFDSCxVQUFULEdBQXNCL08sUUFBUSxDQUFDa1AsUUFBUSxDQUFDQyxXQUFWLENBQTlCO0FBQ0FILHFCQUFXLENBQUNqSixJQUFaLENBQWlCbUosUUFBUSxDQUFDSCxVQUExQjs7QUFDQSxjQUFJRyxRQUFRLENBQUNILFVBQVQsR0FBc0IsQ0FBdEIsSUFBMkIsQ0FBQ0YsbUJBQW1CLENBQUNPLEdBQXBCLENBQXdCRixRQUFRLENBQUNILFVBQWpDLENBQWhDLEVBQThFO0FBQzFFLGdCQUFHO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBRSwyQkFBYSxDQUFDdk8sSUFBZCxDQUFtQjtBQUFDcU8sMEJBQVUsRUFBRUcsUUFBUSxDQUFDSDtBQUF0QixlQUFuQixFQUFzRDFQLE1BQXRELEdBQStEZ0gsU0FBL0QsQ0FBeUU7QUFBQzlHLG9CQUFJLEVBQUMyUDtBQUFOLGVBQXpFO0FBQ0gsYUFWRCxDQVdBLE9BQU1oVyxDQUFOLEVBQVE7QUFDSitWLDJCQUFhLENBQUN2TyxJQUFkLENBQW1CO0FBQUNxTywwQkFBVSxFQUFFRyxRQUFRLENBQUNIO0FBQXRCLGVBQW5CLEVBQXNEMVAsTUFBdEQsR0FBK0RnSCxTQUEvRCxDQUF5RTtBQUFDOUcsb0JBQUksRUFBQzJQO0FBQU4sZUFBekUsRUFESSxDQUVKOztBQUNBL1YscUJBQU8sQ0FBQ0MsR0FBUixDQUFZUCxHQUFaO0FBQ0FNLHFCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBQyxDQUFDTyxRQUFGLENBQVdHLE9BQXZCO0FBQ0g7QUFDSjtBQUNKOztBQUNEcVYscUJBQWEsQ0FBQ3ZPLElBQWQsQ0FBbUI7QUFBQ3FPLG9CQUFVLEVBQUM7QUFBQ00sZ0JBQUksRUFBQ0w7QUFBTixXQUFaO0FBQWdDck8sZ0JBQU0sRUFBQztBQUFDME8sZ0JBQUksRUFBQyxDQUFDLCtCQUFELEVBQWtDLHdCQUFsQyxFQUE0RCwwQkFBNUQsRUFBd0YseUJBQXhGO0FBQU47QUFBdkMsU0FBbkIsRUFDSzdMLE1BREwsQ0FDWTtBQUFDakUsY0FBSSxFQUFFO0FBQUMsc0JBQVU7QUFBWDtBQUFQLFNBRFo7QUFFQTBQLHFCQUFhLENBQUNqSyxPQUFkO0FBQ0g7O0FBQ0QsYUFBTyxJQUFQO0FBQ0gsS0FoREQsQ0FpREEsT0FBTzlMLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBTSxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osR0EzRFU7QUE0RFgsa0NBQWdDLFlBQVU7QUFDdEMsU0FBS0ssT0FBTDtBQUNBLFFBQUlxVixTQUFTLEdBQUdGLFNBQVMsQ0FBQ2hPLElBQVYsQ0FBZTtBQUFDLGdCQUFTO0FBQUMyTyxZQUFJLEVBQUMsQ0FBQyx3QkFBRCxFQUEyQiwwQkFBM0IsRUFBdUQseUJBQXZEO0FBQU47QUFBVixLQUFmLEVBQW9IdE8sS0FBcEgsRUFBaEI7O0FBRUEsUUFBSTZOLFNBQVMsSUFBS0EsU0FBUyxDQUFDdlQsTUFBVixHQUFtQixDQUFyQyxFQUF3QztBQUNwQyxXQUFLLElBQUlrQixDQUFULElBQWNxUyxTQUFkLEVBQXdCO0FBQ3BCLFlBQUk1TyxRQUFRLENBQUM0TyxTQUFTLENBQUNyUyxDQUFELENBQVQsQ0FBYXdTLFVBQWQsQ0FBUixHQUFvQyxDQUF4QyxFQUEwQztBQUN0QyxjQUFJbFcsR0FBRyxHQUFHLEVBQVY7O0FBQ0EsY0FBRztBQUNDO0FBQ0FBLGVBQUcsR0FBR0csR0FBRyxHQUFHLGdDQUFOLEdBQXVDNFYsU0FBUyxDQUFDclMsQ0FBRCxDQUFULENBQWF3UyxVQUFwRCxHQUErRCw2REFBckU7QUFDQSxnQkFBSXRWLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLGdCQUFJcVcsUUFBUSxHQUFHO0FBQUNILHdCQUFVLEVBQUVILFNBQVMsQ0FBQ3JTLENBQUQsQ0FBVCxDQUFhd1M7QUFBMUIsYUFBZjs7QUFDQSxnQkFBSXRWLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixrQkFBSXFXLFFBQVEsR0FBRzVWLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCMFYsUUFBNUM7QUFDQUosc0JBQVEsQ0FBQ0ksUUFBVCxHQUFvQkEsUUFBcEI7QUFDSDs7QUFFRHpXLGVBQUcsR0FBR0csR0FBRyxHQUFHLGdDQUFOLEdBQXVDNFYsU0FBUyxDQUFDclMsQ0FBRCxDQUFULENBQWF3UyxVQUFwRCxHQUErRCwwREFBckU7QUFDQXRWLG9CQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7O0FBQ0EsZ0JBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixrQkFBSXlSLEtBQUssR0FBR2hSLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCOFEsS0FBekM7QUFDQXdFLHNCQUFRLENBQUN4RSxLQUFULEdBQWlCNkUsYUFBYSxDQUFDN0UsS0FBRCxDQUE5QjtBQUNIOztBQUVEN1IsZUFBRyxHQUFHRyxHQUFHLEdBQUcsZ0NBQU4sR0FBdUM0VixTQUFTLENBQUNyUyxDQUFELENBQVQsQ0FBYXdTLFVBQXBELEdBQStELFFBQXJFO0FBQ0F0VixvQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYOztBQUNBLGdCQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0Isa0JBQUl1VyxLQUFLLEdBQUc5VixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QjRWLEtBQXpDO0FBQ0FOLHNCQUFRLENBQUNNLEtBQVQsR0FBaUJBLEtBQWpCO0FBQ0g7O0FBRUROLG9CQUFRLENBQUNPLFNBQVQsR0FBcUIsSUFBSXZULElBQUosRUFBckI7QUFDQXdTLHFCQUFTLENBQUNsTCxNQUFWLENBQWlCO0FBQUN1TCx3QkFBVSxFQUFFSCxTQUFTLENBQUNyUyxDQUFELENBQVQsQ0FBYXdTO0FBQTFCLGFBQWpCLEVBQXdEO0FBQUN4UCxrQkFBSSxFQUFDMlA7QUFBTixhQUF4RDtBQUNILFdBMUJELENBMkJBLE9BQU1oVyxDQUFOLEVBQVE7QUFDSkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZUCxHQUFaO0FBQ0FNLG1CQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0o7QUFDSjtBQUNKOztBQUNELFdBQU8sSUFBUDtBQUNIO0FBdkdVLENBQWY7O0FBMEdBLE1BQU1xVyxhQUFhLEdBQUk3RSxLQUFELElBQVc7QUFDN0IsTUFBSSxDQUFDQSxLQUFMLEVBQVk7QUFDUixXQUFPLEVBQVA7QUFDSDs7QUFFRCxNQUFJZ0YsTUFBTSxHQUFHaEYsS0FBSyxDQUFDdEksR0FBTixDQUFXdU4sSUFBRCxJQUFVQSxJQUFJLENBQUNDLEtBQXpCLENBQWI7QUFDQSxNQUFJQyxjQUFjLEdBQUcsRUFBckI7QUFDQSxNQUFJQyxtQkFBbUIsR0FBRyxFQUExQjtBQUNBblgsWUFBVSxDQUFDK0gsSUFBWCxDQUFnQjtBQUFDeEYscUJBQWlCLEVBQUU7QUFBQ3FILFNBQUcsRUFBRW1OO0FBQU47QUFBcEIsR0FBaEIsRUFBb0Q1VCxPQUFwRCxDQUE2RGhCLFNBQUQsSUFBZTtBQUN2RStVLGtCQUFjLENBQUMvVSxTQUFTLENBQUNJLGlCQUFYLENBQWQsR0FBOEM7QUFDMUM2VSxhQUFPLEVBQUVqVixTQUFTLENBQUM0TSxXQUFWLENBQXNCcUksT0FEVztBQUUxQ3pXLGFBQU8sRUFBRXdCLFNBQVMsQ0FBQ3hCLE9BRnVCO0FBRzFDK04sWUFBTSxFQUFFM0wsVUFBVSxDQUFDWixTQUFTLENBQUN1TSxNQUFYLENBSHdCO0FBSTFDMkkscUJBQWUsRUFBRXRVLFVBQVUsQ0FBQ1osU0FBUyxDQUFDMk4sZ0JBQVgsQ0FKZTtBQUsxQ3dILG9CQUFjLEVBQUV2VSxVQUFVLENBQUNaLFNBQVMsQ0FBQzJOLGdCQUFYO0FBTGdCLEtBQTlDO0FBT0FxSCx1QkFBbUIsQ0FBQ2hWLFNBQVMsQ0FBQ0csZ0JBQVgsQ0FBbkIsR0FBa0RILFNBQVMsQ0FBQ0ksaUJBQTVEO0FBQ0gsR0FURDtBQVVBd1UsUUFBTSxDQUFDNVQsT0FBUCxDQUFnQjhULEtBQUQsSUFBVztBQUN0QixRQUFJLENBQUNDLGNBQWMsQ0FBQ0QsS0FBRCxDQUFuQixFQUE0QjtBQUN4QjtBQUNBLFVBQUkvVyxHQUFHLGFBQU1HLEdBQU4saURBQWdENFcsS0FBaEQsQ0FBUDtBQUNBLFVBQUlyVixXQUFKO0FBQ0EsVUFBSTJWLFdBQVcsR0FBRyxDQUFsQjs7QUFDQSxVQUFHO0FBQ0MsWUFBSXpXLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjs7QUFDQSxZQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0JzQixxQkFBVyxHQUFHYixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QnVXLG9CQUEzQzs7QUFDQSxjQUFJNVYsV0FBVyxJQUFJQSxXQUFXLENBQUNjLE1BQVosR0FBcUIsQ0FBeEMsRUFBMkM7QUFDdkNkLHVCQUFXLENBQUN1QixPQUFaLENBQXFCTixVQUFELElBQWdCO0FBQ2hDLGtCQUFJQyxNQUFNLEdBQUdDLFVBQVUsQ0FBQ0YsVUFBVSxDQUFDQSxVQUFYLENBQXNCQyxNQUF2QixDQUF2Qjs7QUFDQSxrQkFBSXFVLG1CQUFtQixDQUFDdFUsVUFBVSxDQUFDQSxVQUFYLENBQXNCd0ssaUJBQXZCLENBQXZCLEVBQWtFO0FBQzlEO0FBQ0Esb0JBQUlsTCxTQUFTLEdBQUcrVSxjQUFjLENBQUNDLG1CQUFtQixDQUFDdFUsVUFBVSxDQUFDd0ssaUJBQVosQ0FBcEIsQ0FBOUI7QUFDQWxMLHlCQUFTLENBQUNtVixjQUFWLElBQTRCeFUsTUFBNUI7O0FBQ0Esb0JBQUlYLFNBQVMsQ0FBQ2tWLGVBQVYsSUFBNkIsQ0FBakMsRUFBbUM7QUFBRTtBQUNqQ0UsNkJBQVcsSUFBS3pVLE1BQU0sR0FBQ1gsU0FBUyxDQUFDa1YsZUFBbEIsR0FBcUNsVixTQUFTLENBQUN1TSxNQUE5RDtBQUNIO0FBRUosZUFSRCxNQVFPO0FBQ0gsb0JBQUl2TSxTQUFTLEdBQUduQyxVQUFVLENBQUNvQyxPQUFYLENBQW1CO0FBQUNJLGlDQUFlLEVBQUVLLFVBQVUsQ0FBQ3dLO0FBQTdCLGlCQUFuQixDQUFoQjs7QUFDQSxvQkFBSWxMLFNBQVMsSUFBSUEsU0FBUyxDQUFDa1YsZUFBVixJQUE2QixDQUE5QyxFQUFnRDtBQUFFO0FBQzlDRSw2QkFBVyxJQUFLelUsTUFBTSxHQUFDQyxVQUFVLENBQUNaLFNBQVMsQ0FBQ2tWLGVBQVgsQ0FBbEIsR0FBaUR0VSxVQUFVLENBQUNaLFNBQVMsQ0FBQ3VNLE1BQVgsQ0FBMUU7QUFDSDtBQUNKO0FBQ0osYUFoQkQ7QUFpQkg7QUFDSjtBQUNKLE9BeEJELENBeUJBLE9BQU9uTyxDQUFQLEVBQVM7QUFDTEMsZUFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7QUFDQU0sZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQUMsQ0FBQ08sUUFBRixDQUFXRyxPQUF2QjtBQUNIOztBQUNEaVcsb0JBQWMsQ0FBQ0QsS0FBRCxDQUFkLEdBQXdCO0FBQUNNLG1CQUFXLEVBQUVBO0FBQWQsT0FBeEI7QUFDSDtBQUNKLEdBckNEO0FBc0NBLFNBQU94RixLQUFLLENBQUN0SSxHQUFOLENBQVd1TixJQUFELElBQVU7QUFDdkIsUUFBSUMsS0FBSyxHQUFHQyxjQUFjLENBQUNGLElBQUksQ0FBQ0MsS0FBTixDQUExQjtBQUNBLFFBQUlNLFdBQVcsR0FBR04sS0FBSyxDQUFDTSxXQUF4Qjs7QUFDQSxRQUFJQSxXQUFXLElBQUlFLFNBQW5CLEVBQThCO0FBQzFCO0FBQ0FGLGlCQUFXLEdBQUdOLEtBQUssQ0FBQ0ksZUFBTixHQUF3QkosS0FBSyxDQUFDSyxjQUFOLEdBQXFCTCxLQUFLLENBQUNJLGVBQTVCLEdBQStDSixLQUFLLENBQUN2SSxNQUE1RSxHQUFvRixDQUFsRztBQUNIOztBQUNELDJDQUFXc0ksSUFBWDtBQUFpQk87QUFBakI7QUFDSCxHQVJNLENBQVA7QUFTSCxDQWpFRCxDOzs7Ozs7Ozs7OztBQ2hIQSxJQUFJNVgsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJaVcsU0FBSjtBQUFjblcsTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVosRUFBOEI7QUFBQ2tXLFdBQVMsQ0FBQ2pXLENBQUQsRUFBRztBQUFDaVcsYUFBUyxHQUFDalcsQ0FBVjtBQUFZOztBQUExQixDQUE5QixFQUEwRCxDQUExRDtBQUE2RCxJQUFJNFgsS0FBSjtBQUFVOVgsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDNlgsT0FBSyxDQUFDNVgsQ0FBRCxFQUFHO0FBQUM0WCxTQUFLLEdBQUM1WCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBSXJKSCxNQUFNLENBQUM0VSxPQUFQLENBQWUsZ0JBQWYsRUFBaUMsWUFBWTtBQUN6QyxTQUFPd0IsU0FBUyxDQUFDaE8sSUFBVixDQUFlLEVBQWYsRUFBbUI7QUFBQ0csUUFBSSxFQUFDO0FBQUNrTyxnQkFBVSxFQUFDLENBQUM7QUFBYjtBQUFOLEdBQW5CLENBQVA7QUFDSCxDQUZEO0FBSUF6VyxNQUFNLENBQUM0VSxPQUFQLENBQWUsZUFBZixFQUFnQyxVQUFVb0QsRUFBVixFQUFhO0FBQ3pDRCxPQUFLLENBQUNDLEVBQUQsRUFBS0MsTUFBTCxDQUFMO0FBQ0EsU0FBTzdCLFNBQVMsQ0FBQ2hPLElBQVYsQ0FBZTtBQUFDcU8sY0FBVSxFQUFDdUI7QUFBWixHQUFmLENBQVA7QUFDSCxDQUhELEU7Ozs7Ozs7Ozs7O0FDUkEvWCxNQUFNLENBQUNtUixNQUFQLENBQWM7QUFBQ2dGLFdBQVMsRUFBQyxNQUFJQTtBQUFmLENBQWQ7QUFBeUMsSUFBSS9FLEtBQUo7QUFBVXBSLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ21SLE9BQUssQ0FBQ2xSLENBQUQsRUFBRztBQUFDa1IsU0FBSyxHQUFDbFIsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUU1QyxNQUFNaVcsU0FBUyxHQUFHLElBQUkvRSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsV0FBckIsQ0FBbEIsQzs7Ozs7Ozs7Ozs7QUNGUCxJQUFJdFIsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJa1IsS0FBSjtBQUFVcFIsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDbVIsT0FBSyxDQUFDbFIsQ0FBRCxFQUFHO0FBQUNrUixTQUFLLEdBQUNsUixDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUl3RSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0JzVCxXQUEvQixFQUEyQ0Msb0JBQTNDO0FBQWdFbFksTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDeUUsa0JBQWdCLENBQUN4RSxDQUFELEVBQUc7QUFBQ3dFLG9CQUFnQixHQUFDeEUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDeUUsV0FBUyxDQUFDekUsQ0FBRCxFQUFHO0FBQUN5RSxhQUFTLEdBQUN6RSxDQUFWO0FBQVksR0FBbEU7O0FBQW1FK1gsYUFBVyxDQUFDL1gsQ0FBRCxFQUFHO0FBQUMrWCxlQUFXLEdBQUMvWCxDQUFaO0FBQWMsR0FBaEc7O0FBQWlHZ1ksc0JBQW9CLENBQUNoWSxDQUFELEVBQUc7QUFBQ2dZLHdCQUFvQixHQUFDaFksQ0FBckI7QUFBdUI7O0FBQWhKLENBQTVCLEVBQThLLENBQTlLO0FBQWlMLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBQThFLElBQUl1RSxhQUFKO0FBQWtCekUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVosRUFBNEQ7QUFBQ3dFLGVBQWEsQ0FBQ3ZFLENBQUQsRUFBRztBQUFDdUUsaUJBQWEsR0FBQ3ZFLENBQWQ7QUFBZ0I7O0FBQWxDLENBQTVELEVBQWdHLENBQWhHO0FBQW1HLElBQUlpWSxNQUFKO0FBQVduWSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDa1ksUUFBTSxDQUFDalksQ0FBRCxFQUFHO0FBQUNpWSxVQUFNLEdBQUNqWSxDQUFQO0FBQVM7O0FBQXBCLENBQXJDLEVBQTJELENBQTNEO0FBQThELElBQUlrWSxpQkFBSjtBQUFzQnBZLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ21ZLG1CQUFpQixDQUFDbFksQ0FBRCxFQUFHO0FBQUNrWSxxQkFBaUIsR0FBQ2xZLENBQWxCO0FBQW9COztBQUExQyxDQUE1QixFQUF3RSxDQUF4RTtBQUEyRSxJQUFJbVksWUFBSjtBQUFpQnJZLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ29ZLGNBQVksQ0FBQ25ZLENBQUQsRUFBRztBQUFDbVksZ0JBQVksR0FBQ25ZLENBQWI7QUFBZTs7QUFBaEMsQ0FBNUIsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSXFFLFNBQUo7QUFBY3ZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUNzRSxXQUFTLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLGFBQVMsR0FBQ3JFLENBQVY7QUFBWTs7QUFBMUIsQ0FBckMsRUFBaUUsQ0FBakU7QUFBb0UsSUFBSXNFLEtBQUo7QUFBVXhFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUN1RSxPQUFLLENBQUN0RSxDQUFELEVBQUc7QUFBQ3NFLFNBQUssR0FBQ3RFLENBQU47QUFBUTs7QUFBbEIsQ0FBbkMsRUFBdUQsQ0FBdkQ7O0FBQTBELElBQUlvWSxDQUFKOztBQUFNdFksTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDeVIsU0FBTyxDQUFDeFIsQ0FBRCxFQUFHO0FBQUNvWSxLQUFDLEdBQUNwWSxDQUFGO0FBQUk7O0FBQWhCLENBQXJCLEVBQXVDLEVBQXZDO0FBV3Y5QixNQUFNcVksaUJBQWlCLEdBQUcsSUFBMUI7O0FBRUEsTUFBTUMsYUFBYSxHQUFHLENBQUMvTixXQUFELEVBQWNnTyxZQUFkLEtBQStCO0FBQ2pELE1BQUlDLFVBQVUsR0FBRyxFQUFqQjtBQUNBLFFBQU1DLElBQUksR0FBRztBQUFDQyxRQUFJLEVBQUUsQ0FDaEI7QUFBRXhQLFlBQU0sRUFBRTtBQUFFeVAsV0FBRyxFQUFFcE87QUFBUDtBQUFWLEtBRGdCLEVBRWhCO0FBQUVyQixZQUFNLEVBQUU7QUFBRTBQLFlBQUksRUFBRUw7QUFBUjtBQUFWLEtBRmdCO0FBQVAsR0FBYjtBQUdBLFFBQU1NLE9BQU8sR0FBRztBQUFDelEsUUFBSSxFQUFDO0FBQUNjLFlBQU0sRUFBRTtBQUFUO0FBQU4sR0FBaEI7QUFDQTdFLFdBQVMsQ0FBQzRELElBQVYsQ0FBZXdRLElBQWYsRUFBcUJJLE9BQXJCLEVBQThCeFYsT0FBOUIsQ0FBdUN1RyxLQUFELElBQVc7QUFDN0M0TyxjQUFVLENBQUM1TyxLQUFLLENBQUNWLE1BQVAsQ0FBVixHQUEyQjtBQUN2QkEsWUFBTSxFQUFFVSxLQUFLLENBQUNWLE1BRFM7QUFFdkJPLHFCQUFlLEVBQUVHLEtBQUssQ0FBQ0gsZUFGQTtBQUd2QmtELHFCQUFlLEVBQUUvQyxLQUFLLENBQUMrQyxlQUhBO0FBSXZCTSxxQkFBZSxFQUFFckQsS0FBSyxDQUFDcUQsZUFKQTtBQUt2Qi9ILGdCQUFVLEVBQUUwRSxLQUFLLENBQUMxRSxVQUxLO0FBTXZCMUIsVUFBSSxFQUFFb0csS0FBSyxDQUFDcEc7QUFOVyxLQUEzQjtBQVFILEdBVEQ7QUFXQWlCLFdBQVMsQ0FBQ3dELElBQVYsQ0FBZXdRLElBQWYsRUFBcUJJLE9BQXJCLEVBQThCeFYsT0FBOUIsQ0FBdUN1RyxLQUFELElBQVc7QUFDN0MsUUFBSSxDQUFDNE8sVUFBVSxDQUFDNU8sS0FBSyxDQUFDVixNQUFQLENBQWYsRUFBK0I7QUFDM0JzUCxnQkFBVSxDQUFDNU8sS0FBSyxDQUFDVixNQUFQLENBQVYsR0FBMkI7QUFBRUEsY0FBTSxFQUFFVSxLQUFLLENBQUNWO0FBQWhCLE9BQTNCO0FBQ0F4SSxhQUFPLENBQUNDLEdBQVIsaUJBQXFCaUosS0FBSyxDQUFDVixNQUEzQjtBQUNIOztBQUNEa1AsS0FBQyxDQUFDVSxNQUFGLENBQVNOLFVBQVUsQ0FBQzVPLEtBQUssQ0FBQ1YsTUFBUCxDQUFuQixFQUFtQztBQUMvQm1FLGdCQUFVLEVBQUV6RCxLQUFLLENBQUN5RCxVQURhO0FBRS9CcUIsc0JBQWdCLEVBQUU5RSxLQUFLLENBQUM4RSxnQkFGTztBQUcvQnpFLGNBQVEsRUFBRUwsS0FBSyxDQUFDSyxRQUhlO0FBSS9CNUIsa0JBQVksRUFBRXVCLEtBQUssQ0FBQ3ZCO0FBSlcsS0FBbkM7QUFNSCxHQVhEO0FBWUEsU0FBT21RLFVBQVA7QUFDSCxDQTlCRDs7QUFnQ0EsTUFBTU8saUJBQWlCLEdBQUcsQ0FBQ0MsWUFBRCxFQUFldlAsZUFBZixLQUFtQztBQUN6RCxNQUFJd1AsY0FBYyxHQUFHZCxZQUFZLENBQUM3VixPQUFiLENBQ2pCO0FBQUM2VSxTQUFLLEVBQUM2QixZQUFQO0FBQXFCM0gsWUFBUSxFQUFDNUgsZUFBOUI7QUFBK0N5UCxlQUFXLEVBQUUsQ0FBQztBQUE3RCxHQURpQixDQUFyQjtBQUVBLE1BQUlDLGlCQUFpQixHQUFHdFosTUFBTSxDQUFDMkYsUUFBUCxDQUFnQmtDLE1BQWhCLENBQXVCNkMsV0FBL0M7QUFDQSxNQUFJNk8sU0FBUyxHQUFHLEVBQWhCOztBQUNBLE1BQUlILGNBQUosRUFBb0I7QUFDaEJHLGFBQVMsR0FBR2hCLENBQUMsQ0FBQ2lCLElBQUYsQ0FBT0osY0FBUCxFQUF1QixDQUFDLFdBQUQsRUFBYyxZQUFkLENBQXZCLENBQVo7QUFDSCxHQUZELE1BRU87QUFDSEcsYUFBUyxHQUFHO0FBQ1JFLGVBQVMsRUFBRSxDQURIO0FBRVJDLGdCQUFVLEVBQUU7QUFGSixLQUFaO0FBSUg7O0FBQ0QsU0FBT0gsU0FBUDtBQUNILENBZEQ7O0FBZ0JBdlosTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw0Q0FBMEMsWUFBVTtBQUNoRCxTQUFLRSxPQUFMOztBQUNBLFFBQUksQ0FBQzBZLGlCQUFMLEVBQXVCO0FBQ25CLFVBQUk7QUFDQSxZQUFJQyxTQUFTLEdBQUdoVyxJQUFJLENBQUN3TSxHQUFMLEVBQWhCO0FBQ0F1Six5QkFBaUIsR0FBRyxJQUFwQjtBQUNBOVksZUFBTyxDQUFDQyxHQUFSLENBQVksOEJBQVo7QUFDQSxhQUFLRyxPQUFMO0FBQ0EsWUFBSW9FLFVBQVUsR0FBR2hGLFVBQVUsQ0FBQytILElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0JLLEtBQXBCLEVBQWpCO0FBQ0EsWUFBSWlRLFlBQVksR0FBRzFZLE1BQU0sQ0FBQytGLElBQVAsQ0FBWSx5QkFBWixDQUFuQjtBQUNBLFlBQUk4VCxjQUFjLEdBQUd6QixNQUFNLENBQUMzVixPQUFQLENBQWU7QUFBQ3VFLGlCQUFPLEVBQUVoSCxNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm9CO0FBQWpDLFNBQWYsQ0FBckI7QUFDQSxZQUFJMEQsV0FBVyxHQUFJbVAsY0FBYyxJQUFFQSxjQUFjLENBQUNDLDhCQUFoQyxHQUFnRUQsY0FBYyxDQUFDQyw4QkFBL0UsR0FBOEc5WixNQUFNLENBQUMyRixRQUFQLENBQWdCa0MsTUFBaEIsQ0FBdUI2QyxXQUF2SjtBQUNBZ08sb0JBQVksR0FBRy9QLElBQUksQ0FBQ29SLEdBQUwsQ0FBU3JQLFdBQVcsR0FBRzhOLGlCQUF2QixFQUEwQ0UsWUFBMUMsQ0FBZjtBQUNBLGNBQU1zQixlQUFlLEdBQUcxQixZQUFZLENBQUNqTixhQUFiLEdBQTZCNE8sdUJBQTdCLEVBQXhCO0FBRUEsWUFBSUMsYUFBYSxHQUFHLEVBQXBCO0FBQ0E3VSxrQkFBVSxDQUFDN0IsT0FBWCxDQUFvQmhCLFNBQUQsSUFBZTBYLGFBQWEsQ0FBQzFYLFNBQVMsQ0FBQ3hCLE9BQVgsQ0FBYixHQUFtQ3dCLFNBQXJFLEVBYkEsQ0FlQTs7QUFDQSxZQUFJbVcsVUFBVSxHQUFHRixhQUFhLENBQUMvTixXQUFELEVBQWNnTyxZQUFkLENBQTlCLENBaEJBLENBa0JBOztBQUNBLFlBQUl5QixrQkFBa0IsR0FBRyxFQUF6Qjs7QUFFQTVCLFNBQUMsQ0FBQy9VLE9BQUYsQ0FBVW1WLFVBQVYsRUFBc0IsQ0FBQzVPLEtBQUQsRUFBUXNQLFdBQVIsS0FBd0I7QUFDMUMsY0FBSXpQLGVBQWUsR0FBR0csS0FBSyxDQUFDSCxlQUE1QjtBQUNBLGNBQUl3USxlQUFlLEdBQUcsSUFBSTVELEdBQUosQ0FBUXpNLEtBQUssQ0FBQzFFLFVBQWQsQ0FBdEI7QUFDQSxjQUFJZ1YsYUFBYSxHQUFHM1YsYUFBYSxDQUFDakMsT0FBZCxDQUFzQjtBQUFDMEssd0JBQVksRUFBQ3BELEtBQUssQ0FBQ1Y7QUFBcEIsV0FBdEIsQ0FBcEI7QUFDQSxjQUFJaVIsZ0JBQWdCLEdBQUcsQ0FBdkI7QUFFQUQsdUJBQWEsQ0FBQ2hWLFVBQWQsQ0FBeUI3QixPQUF6QixDQUFrQytXLGVBQUQsSUFBcUI7QUFDbEQsZ0JBQUlILGVBQWUsQ0FBQ3RELEdBQWhCLENBQW9CeUQsZUFBZSxDQUFDdlosT0FBcEMsQ0FBSixFQUNJc1osZ0JBQWdCLElBQUlsWCxVQUFVLENBQUNtWCxlQUFlLENBQUMvUixZQUFqQixDQUE5QjtBQUNQLFdBSEQ7QUFLQTZSLHVCQUFhLENBQUNoVixVQUFkLENBQXlCN0IsT0FBekIsQ0FBa0MrVyxlQUFELElBQXFCO0FBQ2xELGdCQUFJQyxnQkFBZ0IsR0FBR0QsZUFBZSxDQUFDdlosT0FBdkM7O0FBQ0EsZ0JBQUksQ0FBQ3VYLENBQUMsQ0FBQ3pCLEdBQUYsQ0FBTXFELGtCQUFOLEVBQTBCLENBQUN2USxlQUFELEVBQWtCNFEsZ0JBQWxCLENBQTFCLENBQUwsRUFBcUU7QUFDakUsa0JBQUlqQixTQUFTLEdBQUdMLGlCQUFpQixDQUFDc0IsZ0JBQUQsRUFBbUI1USxlQUFuQixDQUFqQzs7QUFDQTJPLGVBQUMsQ0FBQ2tDLEdBQUYsQ0FBTU4sa0JBQU4sRUFBMEIsQ0FBQ3ZRLGVBQUQsRUFBa0I0USxnQkFBbEIsQ0FBMUIsRUFBK0RqQixTQUEvRDtBQUNIOztBQUVEaEIsYUFBQyxDQUFDck4sTUFBRixDQUFTaVAsa0JBQVQsRUFBNkIsQ0FBQ3ZRLGVBQUQsRUFBa0I0USxnQkFBbEIsRUFBb0MsWUFBcEMsQ0FBN0IsRUFBaUZFLENBQUQsSUFBT0EsQ0FBQyxHQUFDLENBQXpGOztBQUNBLGdCQUFJLENBQUNOLGVBQWUsQ0FBQ3RELEdBQWhCLENBQW9CMEQsZ0JBQXBCLENBQUwsRUFBNEM7QUFDeENqQyxlQUFDLENBQUNyTixNQUFGLENBQVNpUCxrQkFBVCxFQUE2QixDQUFDdlEsZUFBRCxFQUFrQjRRLGdCQUFsQixFQUFvQyxXQUFwQyxDQUE3QixFQUFnRkUsQ0FBRCxJQUFPQSxDQUFDLEdBQUMsQ0FBeEY7O0FBQ0FWLDZCQUFlLENBQUN0USxNQUFoQixDQUF1QjtBQUNuQjROLHFCQUFLLEVBQUVrRCxnQkFEWTtBQUVuQm5CLDJCQUFXLEVBQUV0UCxLQUFLLENBQUNWLE1BRkE7QUFHbkJtSSx3QkFBUSxFQUFFNUgsZUFIUztBQUluQmtELCtCQUFlLEVBQUUvQyxLQUFLLENBQUMrQyxlQUpKO0FBS25CTSwrQkFBZSxFQUFFckQsS0FBSyxDQUFDcUQsZUFMSjtBQU1uQnpKLG9CQUFJLEVBQUVvRyxLQUFLLENBQUNwRyxJQU5PO0FBT25CNkosMEJBQVUsRUFBRXpELEtBQUssQ0FBQ3lELFVBUEM7QUFRbkJxQixnQ0FBZ0IsRUFBRTlFLEtBQUssQ0FBQzhFLGdCQVJMO0FBU25CekUsd0JBQVEsRUFBRUwsS0FBSyxDQUFDSyxRQVRHO0FBVW5Cd04sMkJBQVcsRUFBRTdOLEtBQUssQ0FBQ3ZCLFlBVkE7QUFXbkI4UixnQ0FYbUI7QUFZbkJuRCx5QkFBUyxFQUFFdUIsWUFaUTtBQWFuQmUseUJBQVMsRUFBRWxCLENBQUMsQ0FBQzlYLEdBQUYsQ0FBTTBaLGtCQUFOLEVBQTBCLENBQUN2USxlQUFELEVBQWtCNFEsZ0JBQWxCLEVBQW9DLFdBQXBDLENBQTFCLENBYlE7QUFjbkJkLDBCQUFVLEVBQUVuQixDQUFDLENBQUM5WCxHQUFGLENBQU0wWixrQkFBTixFQUEwQixDQUFDdlEsZUFBRCxFQUFrQjRRLGdCQUFsQixFQUFvQyxZQUFwQyxDQUExQjtBQWRPLGVBQXZCO0FBZ0JIO0FBQ0osV0EzQkQ7QUE0QkgsU0F2Q0Q7O0FBeUNBakMsU0FBQyxDQUFDL1UsT0FBRixDQUFVMlcsa0JBQVYsRUFBOEIsQ0FBQy9DLE1BQUQsRUFBU3hOLGVBQVQsS0FBNkI7QUFDdkQyTyxXQUFDLENBQUMvVSxPQUFGLENBQVU0VCxNQUFWLEVBQWtCLENBQUN1RCxLQUFELEVBQVF4QixZQUFSLEtBQXlCO0FBQ3ZDYSwyQkFBZSxDQUFDNVIsSUFBaEIsQ0FBcUI7QUFDakJrUCxtQkFBSyxFQUFFNkIsWUFEVTtBQUVqQjNILHNCQUFRLEVBQUU1SCxlQUZPO0FBR2pCeVAseUJBQVcsRUFBRSxDQUFDO0FBSEcsYUFBckIsRUFJR3RTLE1BSkgsR0FJWWdILFNBSlosQ0FJc0I7QUFBQzlHLGtCQUFJLEVBQUU7QUFDekJxUSxxQkFBSyxFQUFFNkIsWUFEa0I7QUFFekIzSCx3QkFBUSxFQUFFNUgsZUFGZTtBQUd6QnlQLDJCQUFXLEVBQUUsQ0FBQyxDQUhXO0FBSXpCbEMseUJBQVMsRUFBRXVCLFlBSmM7QUFLekJlLHlCQUFTLEVBQUVsQixDQUFDLENBQUM5WCxHQUFGLENBQU1rYSxLQUFOLEVBQWEsV0FBYixDQUxjO0FBTXpCakIsMEJBQVUsRUFBRW5CLENBQUMsQ0FBQzlYLEdBQUYsQ0FBTWthLEtBQU4sRUFBYSxZQUFiO0FBTmE7QUFBUCxhQUp0QjtBQVlILFdBYkQ7QUFjSCxTQWZEOztBQWlCQSxZQUFJL0UsT0FBTyxHQUFHLEVBQWQ7O0FBQ0EsWUFBSW9FLGVBQWUsQ0FBQ2pYLE1BQWhCLEdBQXlCLENBQTdCLEVBQStCO0FBQzNCLGdCQUFNNlgsTUFBTSxHQUFHdEMsWUFBWSxDQUFDdUMsT0FBYixDQUFxQkMsS0FBckIsQ0FBMkJGLE1BQTFDLENBRDJCLENBRTNCO0FBQ0E7QUFDQTs7QUFDQSxjQUFJRyxXQUFXLEdBQUdmLGVBQWUsQ0FBQ3ROLE9BQWhCLENBQXdCO0FBQUk7QUFBNUIsWUFBNkNzTyxJQUE3QyxDQUNkaGIsTUFBTSxDQUFDaWIsZUFBUCxDQUF1QixDQUFDMVosTUFBRCxFQUFTb0wsR0FBVCxLQUFpQjtBQUNwQyxnQkFBSUEsR0FBSixFQUFRO0FBQ0pnTiwrQkFBaUIsR0FBRyxLQUFwQixDQURJLENBRUo7O0FBQ0Esb0JBQU1oTixHQUFOO0FBQ0g7O0FBQ0QsZ0JBQUlwTCxNQUFKLEVBQVc7QUFDUDtBQUNBcVUscUJBQU8sR0FBRyxXQUFJclUsTUFBTSxDQUFDQSxNQUFQLENBQWMyWixTQUFsQiw2QkFDSTNaLE1BQU0sQ0FBQ0EsTUFBUCxDQUFjNFosU0FEbEIsNkJBRUk1WixNQUFNLENBQUNBLE1BQVAsQ0FBYzZaLFNBRmxCLGVBQVY7QUFHSDtBQUNKLFdBWkQsQ0FEYyxDQUFsQjtBQWVBQyxpQkFBTyxDQUFDQyxLQUFSLENBQWNQLFdBQWQ7QUFDSDs7QUFFRHBCLHlCQUFpQixHQUFHLEtBQXBCO0FBQ0F2QixjQUFNLENBQUNyUixNQUFQLENBQWM7QUFBQ0MsaUJBQU8sRUFBRWhILE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCb0I7QUFBakMsU0FBZCxFQUF5RDtBQUFDQyxjQUFJLEVBQUM7QUFBQzZTLDBDQUE4QixFQUFDcEIsWUFBaEM7QUFBOEM2Qyx3Q0FBNEIsRUFBRSxJQUFJM1gsSUFBSjtBQUE1RTtBQUFOLFNBQXpEO0FBQ0EsaUNBQWtCQSxJQUFJLENBQUN3TSxHQUFMLEtBQWF3SixTQUEvQixnQkFBOENoRSxPQUE5QztBQUNILE9BMUdELENBMEdFLE9BQU9oVixDQUFQLEVBQVU7QUFDUitZLHlCQUFpQixHQUFHLEtBQXBCO0FBQ0EsY0FBTS9ZLENBQU47QUFDSDtBQUNKLEtBL0dELE1BZ0hJO0FBQ0EsYUFBTyxhQUFQO0FBQ0g7QUFDSixHQXRIVTtBQXVIWCxpREFBK0MsWUFBVTtBQUNyRCxTQUFLSyxPQUFMLEdBRHFELENBRXJEO0FBQ0E7O0FBQ0EsUUFBSSxDQUFDdWEsc0JBQUwsRUFBNEI7QUFDeEJBLDRCQUFzQixHQUFHLElBQXpCO0FBQ0EzYSxhQUFPLENBQUNDLEdBQVIsQ0FBWSw4QkFBWjtBQUNBLFdBQUtHLE9BQUw7QUFDQSxVQUFJb0UsVUFBVSxHQUFHaEYsVUFBVSxDQUFDK0gsSUFBWCxDQUFnQixFQUFoQixFQUFvQkssS0FBcEIsRUFBakI7QUFDQSxVQUFJaVEsWUFBWSxHQUFHMVksTUFBTSxDQUFDK0YsSUFBUCxDQUFZLHlCQUFaLENBQW5CO0FBQ0EsVUFBSThULGNBQWMsR0FBR3pCLE1BQU0sQ0FBQzNWLE9BQVAsQ0FBZTtBQUFDdUUsZUFBTyxFQUFFaEgsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJvQjtBQUFqQyxPQUFmLENBQXJCO0FBQ0EsVUFBSTBELFdBQVcsR0FBSW1QLGNBQWMsSUFBRUEsY0FBYyxDQUFDNEIscUJBQWhDLEdBQXVENUIsY0FBYyxDQUFDNEIscUJBQXRFLEdBQTRGemIsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQmtDLE1BQWhCLENBQXVCNkMsV0FBckksQ0FQd0IsQ0FReEI7QUFDQTs7QUFDQSxZQUFNc1AsZUFBZSxHQUFHM0IsaUJBQWlCLENBQUNoTixhQUFsQixHQUFrQ0MseUJBQWxDLEVBQXhCOztBQUNBLFdBQUtySCxDQUFMLElBQVVvQixVQUFWLEVBQXFCO0FBQ2pCO0FBQ0EsWUFBSThULFlBQVksR0FBRzlULFVBQVUsQ0FBQ3BCLENBQUQsQ0FBVixDQUFjakQsT0FBakM7QUFDQSxZQUFJMGEsYUFBYSxHQUFHL1csZ0JBQWdCLENBQUN5RCxJQUFqQixDQUFzQjtBQUN0Q3BILGlCQUFPLEVBQUNtWSxZQUQ4QjtBQUV0Q3ZMLGdCQUFNLEVBQUMsS0FGK0I7QUFHdENpTCxjQUFJLEVBQUUsQ0FBRTtBQUFFeFAsa0JBQU0sRUFBRTtBQUFFeVAsaUJBQUcsRUFBRXBPO0FBQVA7QUFBVixXQUFGLEVBQW9DO0FBQUVyQixrQkFBTSxFQUFFO0FBQUUwUCxrQkFBSSxFQUFFTDtBQUFSO0FBQVYsV0FBcEM7QUFIZ0MsU0FBdEIsRUFJakJqUSxLQUppQixFQUFwQjtBQU1BLFlBQUlrVCxNQUFNLEdBQUcsRUFBYixDQVRpQixDQVdqQjs7QUFDQSxhQUFLeFIsQ0FBTCxJQUFVdVIsYUFBVixFQUF3QjtBQUNwQixjQUFJM1IsS0FBSyxHQUFHdkYsU0FBUyxDQUFDL0IsT0FBVixDQUFrQjtBQUFDNEcsa0JBQU0sRUFBQ3FTLGFBQWEsQ0FBQ3ZSLENBQUQsQ0FBYixDQUFpQmQ7QUFBekIsV0FBbEIsQ0FBWjtBQUNBLGNBQUl1UyxjQUFjLEdBQUd2RCxpQkFBaUIsQ0FBQzVWLE9BQWxCLENBQTBCO0FBQUM2VSxpQkFBSyxFQUFDNkIsWUFBUDtBQUFxQjNILG9CQUFRLEVBQUN6SCxLQUFLLENBQUNIO0FBQXBDLFdBQTFCLENBQXJCOztBQUVBLGNBQUksT0FBTytSLE1BQU0sQ0FBQzVSLEtBQUssQ0FBQ0gsZUFBUCxDQUFiLEtBQXlDLFdBQTdDLEVBQXlEO0FBQ3JELGdCQUFJZ1MsY0FBSixFQUFtQjtBQUNmRCxvQkFBTSxDQUFDNVIsS0FBSyxDQUFDSCxlQUFQLENBQU4sR0FBZ0NnUyxjQUFjLENBQUN0WCxLQUFmLEdBQXFCLENBQXJEO0FBQ0gsYUFGRCxNQUdJO0FBQ0FxWCxvQkFBTSxDQUFDNVIsS0FBSyxDQUFDSCxlQUFQLENBQU4sR0FBZ0MsQ0FBaEM7QUFDSDtBQUNKLFdBUEQsTUFRSTtBQUNBK1Isa0JBQU0sQ0FBQzVSLEtBQUssQ0FBQ0gsZUFBUCxDQUFOO0FBQ0g7QUFDSjs7QUFFRCxhQUFLNUksT0FBTCxJQUFnQjJhLE1BQWhCLEVBQXVCO0FBQ25CLGNBQUkzWSxJQUFJLEdBQUc7QUFDUHNVLGlCQUFLLEVBQUU2QixZQURBO0FBRVAzSCxvQkFBUSxFQUFDeFEsT0FGRjtBQUdQc0QsaUJBQUssRUFBRXFYLE1BQU0sQ0FBQzNhLE9BQUQ7QUFITixXQUFYO0FBTUFnWix5QkFBZSxDQUFDNVIsSUFBaEIsQ0FBcUI7QUFBQ2tQLGlCQUFLLEVBQUM2QixZQUFQO0FBQXFCM0gsb0JBQVEsRUFBQ3hRO0FBQTlCLFdBQXJCLEVBQTZEK0YsTUFBN0QsR0FBc0VnSCxTQUF0RSxDQUFnRjtBQUFDOUcsZ0JBQUksRUFBQ2pFO0FBQU4sV0FBaEY7QUFDSCxTQXJDZ0IsQ0FzQ2pCOztBQUVIOztBQUVELFVBQUlnWCxlQUFlLENBQUNqWCxNQUFoQixHQUF5QixDQUE3QixFQUErQjtBQUMzQmlYLHVCQUFlLENBQUN0TixPQUFoQixDQUF3QjFNLE1BQU0sQ0FBQ2liLGVBQVAsQ0FBdUIsQ0FBQ3RPLEdBQUQsRUFBTXBMLE1BQU4sS0FBaUI7QUFDNUQsY0FBSW9MLEdBQUosRUFBUTtBQUNKNk8sa0NBQXNCLEdBQUcsS0FBekI7QUFDQTNhLG1CQUFPLENBQUNDLEdBQVIsQ0FBWTZMLEdBQVo7QUFDSDs7QUFDRCxjQUFJcEwsTUFBSixFQUFXO0FBQ1A2VyxrQkFBTSxDQUFDclIsTUFBUCxDQUFjO0FBQUNDLHFCQUFPLEVBQUVoSCxNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm9CO0FBQWpDLGFBQWQsRUFBeUQ7QUFBQ0Msa0JBQUksRUFBQztBQUFDd1UscUNBQXFCLEVBQUMvQyxZQUF2QjtBQUFxQ21ELG1DQUFtQixFQUFFLElBQUlqWSxJQUFKO0FBQTFEO0FBQU4sYUFBekQ7QUFDQTRYLGtDQUFzQixHQUFHLEtBQXpCO0FBQ0EzYSxtQkFBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNIO0FBQ0osU0FWdUIsQ0FBeEI7QUFXSCxPQVpELE1BYUk7QUFDQTBhLDhCQUFzQixHQUFHLEtBQXpCO0FBQ0g7O0FBRUQsYUFBTyxJQUFQO0FBQ0gsS0F2RUQsTUF3RUk7QUFDQSxhQUFPLGFBQVA7QUFDSDtBQUNKLEdBdE1VO0FBdU1YLGdEQUE4QyxVQUFTN1gsSUFBVCxFQUFjO0FBQ3hELFNBQUsxQyxPQUFMO0FBQ0EsUUFBSW1QLEdBQUcsR0FBRyxJQUFJeE0sSUFBSixFQUFWOztBQUVBLFFBQUlELElBQUksSUFBSSxHQUFaLEVBQWdCO0FBQ1osVUFBSWtMLGdCQUFnQixHQUFHLENBQXZCO0FBQ0EsVUFBSWlOLGtCQUFrQixHQUFHLENBQXpCO0FBRUEsVUFBSUMsU0FBUyxHQUFHblgsU0FBUyxDQUFDd0QsSUFBVixDQUFlO0FBQUUsZ0JBQVE7QUFBRTBRLGFBQUcsRUFBRSxJQUFJbFYsSUFBSixDQUFTQSxJQUFJLENBQUN3TSxHQUFMLEtBQWEsS0FBSyxJQUEzQjtBQUFQO0FBQVYsT0FBZixFQUFzRTNILEtBQXRFLEVBQWhCOztBQUNBLFVBQUlzVCxTQUFTLENBQUNoWixNQUFWLEdBQW1CLENBQXZCLEVBQXlCO0FBQ3JCLGFBQUtrQixDQUFMLElBQVU4WCxTQUFWLEVBQW9CO0FBQ2hCbE4sMEJBQWdCLElBQUlrTixTQUFTLENBQUM5WCxDQUFELENBQVQsQ0FBYW1HLFFBQWpDO0FBQ0EwUiw0QkFBa0IsSUFBSUMsU0FBUyxDQUFDOVgsQ0FBRCxDQUFULENBQWF1RSxZQUFuQztBQUNIOztBQUNEcUcsd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHa04sU0FBUyxDQUFDaFosTUFBaEQ7QUFDQStZLDBCQUFrQixHQUFHQSxrQkFBa0IsR0FBR0MsU0FBUyxDQUFDaFosTUFBcEQ7QUFFQTBCLGFBQUssQ0FBQ3lHLE1BQU4sQ0FBYTtBQUFDbEUsaUJBQU8sRUFBQ2hILE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCb0I7QUFBaEMsU0FBYixFQUFzRDtBQUFDQyxjQUFJLEVBQUM7QUFBQytVLGlDQUFxQixFQUFDRixrQkFBdkI7QUFBMkNHLCtCQUFtQixFQUFDcE47QUFBL0Q7QUFBTixTQUF0RDtBQUNBcUosbUJBQVcsQ0FBQ3hPLE1BQVosQ0FBbUI7QUFDZm1GLDBCQUFnQixFQUFFQSxnQkFESDtBQUVmaU4sNEJBQWtCLEVBQUVBLGtCQUZMO0FBR2ZyYSxjQUFJLEVBQUVrQyxJQUhTO0FBSWZ5UixtQkFBUyxFQUFFaEY7QUFKSSxTQUFuQjtBQU1IO0FBQ0o7O0FBQ0QsUUFBSXpNLElBQUksSUFBSSxHQUFaLEVBQWdCO0FBQ1osVUFBSWtMLGdCQUFnQixHQUFHLENBQXZCO0FBQ0EsVUFBSWlOLGtCQUFrQixHQUFHLENBQXpCO0FBQ0EsVUFBSUMsU0FBUyxHQUFHblgsU0FBUyxDQUFDd0QsSUFBVixDQUFlO0FBQUUsZ0JBQVE7QUFBRTBRLGFBQUcsRUFBRSxJQUFJbFYsSUFBSixDQUFTQSxJQUFJLENBQUN3TSxHQUFMLEtBQWEsS0FBRyxFQUFILEdBQVEsSUFBOUI7QUFBUDtBQUFWLE9BQWYsRUFBeUUzSCxLQUF6RSxFQUFoQjs7QUFDQSxVQUFJc1QsU0FBUyxDQUFDaFosTUFBVixHQUFtQixDQUF2QixFQUF5QjtBQUNyQixhQUFLa0IsQ0FBTCxJQUFVOFgsU0FBVixFQUFvQjtBQUNoQmxOLDBCQUFnQixJQUFJa04sU0FBUyxDQUFDOVgsQ0FBRCxDQUFULENBQWFtRyxRQUFqQztBQUNBMFIsNEJBQWtCLElBQUlDLFNBQVMsQ0FBQzlYLENBQUQsQ0FBVCxDQUFhdUUsWUFBbkM7QUFDSDs7QUFDRHFHLHdCQUFnQixHQUFHQSxnQkFBZ0IsR0FBR2tOLFNBQVMsQ0FBQ2haLE1BQWhEO0FBQ0ErWSwwQkFBa0IsR0FBR0Esa0JBQWtCLEdBQUdDLFNBQVMsQ0FBQ2haLE1BQXBEO0FBRUEwQixhQUFLLENBQUN5RyxNQUFOLENBQWE7QUFBQ2xFLGlCQUFPLEVBQUNoSCxNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm9CO0FBQWhDLFNBQWIsRUFBc0Q7QUFBQ0MsY0FBSSxFQUFDO0FBQUNpViwrQkFBbUIsRUFBQ0osa0JBQXJCO0FBQXlDSyw2QkFBaUIsRUFBQ3ROO0FBQTNEO0FBQU4sU0FBdEQ7QUFDQXFKLG1CQUFXLENBQUN4TyxNQUFaLENBQW1CO0FBQ2ZtRiwwQkFBZ0IsRUFBRUEsZ0JBREg7QUFFZmlOLDRCQUFrQixFQUFFQSxrQkFGTDtBQUdmcmEsY0FBSSxFQUFFa0MsSUFIUztBQUlmeVIsbUJBQVMsRUFBRWhGO0FBSkksU0FBbkI7QUFNSDtBQUNKOztBQUVELFFBQUl6TSxJQUFJLElBQUksR0FBWixFQUFnQjtBQUNaLFVBQUlrTCxnQkFBZ0IsR0FBRyxDQUF2QjtBQUNBLFVBQUlpTixrQkFBa0IsR0FBRyxDQUF6QjtBQUNBLFVBQUlDLFNBQVMsR0FBR25YLFNBQVMsQ0FBQ3dELElBQVYsQ0FBZTtBQUFFLGdCQUFRO0FBQUUwUSxhQUFHLEVBQUUsSUFBSWxWLElBQUosQ0FBU0EsSUFBSSxDQUFDd00sR0FBTCxLQUFhLEtBQUcsRUFBSCxHQUFNLEVBQU4sR0FBVyxJQUFqQztBQUFQO0FBQVYsT0FBZixFQUE0RTNILEtBQTVFLEVBQWhCOztBQUNBLFVBQUlzVCxTQUFTLENBQUNoWixNQUFWLEdBQW1CLENBQXZCLEVBQXlCO0FBQ3JCLGFBQUtrQixDQUFMLElBQVU4WCxTQUFWLEVBQW9CO0FBQ2hCbE4sMEJBQWdCLElBQUlrTixTQUFTLENBQUM5WCxDQUFELENBQVQsQ0FBYW1HLFFBQWpDO0FBQ0EwUiw0QkFBa0IsSUFBSUMsU0FBUyxDQUFDOVgsQ0FBRCxDQUFULENBQWF1RSxZQUFuQztBQUNIOztBQUNEcUcsd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHa04sU0FBUyxDQUFDaFosTUFBaEQ7QUFDQStZLDBCQUFrQixHQUFHQSxrQkFBa0IsR0FBR0MsU0FBUyxDQUFDaFosTUFBcEQ7QUFFQTBCLGFBQUssQ0FBQ3lHLE1BQU4sQ0FBYTtBQUFDbEUsaUJBQU8sRUFBQ2hILE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCb0I7QUFBaEMsU0FBYixFQUFzRDtBQUFDQyxjQUFJLEVBQUM7QUFBQ21WLDhCQUFrQixFQUFDTixrQkFBcEI7QUFBd0NPLDRCQUFnQixFQUFDeE47QUFBekQ7QUFBTixTQUF0RDtBQUNBcUosbUJBQVcsQ0FBQ3hPLE1BQVosQ0FBbUI7QUFDZm1GLDBCQUFnQixFQUFFQSxnQkFESDtBQUVmaU4sNEJBQWtCLEVBQUVBLGtCQUZMO0FBR2ZyYSxjQUFJLEVBQUVrQyxJQUhTO0FBSWZ5UixtQkFBUyxFQUFFaEY7QUFKSSxTQUFuQjtBQU1IO0FBQ0osS0FwRXVELENBc0V4RDs7QUFDSCxHQTlRVTtBQStRWCxnREFBOEMsWUFBVTtBQUNwRCxTQUFLblAsT0FBTDtBQUNBLFFBQUlvRSxVQUFVLEdBQUdoRixVQUFVLENBQUMrSCxJQUFYLENBQWdCLEVBQWhCLEVBQW9CSyxLQUFwQixFQUFqQjtBQUNBLFFBQUkySCxHQUFHLEdBQUcsSUFBSXhNLElBQUosRUFBVjs7QUFDQSxTQUFLSyxDQUFMLElBQVVvQixVQUFWLEVBQXFCO0FBQ2pCLFVBQUl3SixnQkFBZ0IsR0FBRyxDQUF2QjtBQUVBLFVBQUlsRixNQUFNLEdBQUduRixTQUFTLENBQUM0RCxJQUFWLENBQWU7QUFBQ3dCLHVCQUFlLEVBQUN2RSxVQUFVLENBQUNwQixDQUFELENBQVYsQ0FBY2pELE9BQS9CO0FBQXdDLGdCQUFRO0FBQUU4WCxhQUFHLEVBQUUsSUFBSWxWLElBQUosQ0FBU0EsSUFBSSxDQUFDd00sR0FBTCxLQUFhLEtBQUcsRUFBSCxHQUFNLEVBQU4sR0FBVyxJQUFqQztBQUFQO0FBQWhELE9BQWYsRUFBaUg7QUFBQzBFLGNBQU0sRUFBQztBQUFDekwsZ0JBQU0sRUFBQztBQUFSO0FBQVIsT0FBakgsRUFBc0laLEtBQXRJLEVBQWI7O0FBRUEsVUFBSWtCLE1BQU0sQ0FBQzVHLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBc0I7QUFDbEIsWUFBSXVaLFlBQVksR0FBRyxFQUFuQjs7QUFDQSxhQUFLblMsQ0FBTCxJQUFVUixNQUFWLEVBQWlCO0FBQ2IyUyxzQkFBWSxDQUFDN08sSUFBYixDQUFrQjlELE1BQU0sQ0FBQ1EsQ0FBRCxDQUFOLENBQVVkLE1BQTVCO0FBQ0g7O0FBRUQsWUFBSTBTLFNBQVMsR0FBR25YLFNBQVMsQ0FBQ3dELElBQVYsQ0FBZTtBQUFDaUIsZ0JBQU0sRUFBRTtBQUFDWSxlQUFHLEVBQUNxUztBQUFMO0FBQVQsU0FBZixFQUE2QztBQUFDeEgsZ0JBQU0sRUFBQztBQUFDekwsa0JBQU0sRUFBQyxDQUFSO0FBQVVlLG9CQUFRLEVBQUM7QUFBbkI7QUFBUixTQUE3QyxFQUE2RTNCLEtBQTdFLEVBQWhCOztBQUdBLGFBQUs4VCxDQUFMLElBQVVSLFNBQVYsRUFBb0I7QUFDaEJsTiwwQkFBZ0IsSUFBSWtOLFNBQVMsQ0FBQ1EsQ0FBRCxDQUFULENBQWFuUyxRQUFqQztBQUNIOztBQUVEeUUsd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHa04sU0FBUyxDQUFDaFosTUFBaEQ7QUFDSDs7QUFFRG9WLDBCQUFvQixDQUFDek8sTUFBckIsQ0FBNEI7QUFDeEJFLHVCQUFlLEVBQUV2RSxVQUFVLENBQUNwQixDQUFELENBQVYsQ0FBY2pELE9BRFA7QUFFeEI2Tix3QkFBZ0IsRUFBRUEsZ0JBRk07QUFHeEJwTixZQUFJLEVBQUUsZ0NBSGtCO0FBSXhCMlQsaUJBQVMsRUFBRWhGO0FBSmEsT0FBNUI7QUFNSDs7QUFFRCxXQUFPLElBQVA7QUFDSDtBQWpUVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDN0RBLElBQUlwUSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl3RSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0IwVCxZQUEvQixFQUE0Q0QsaUJBQTVDLEVBQThEeFQsZUFBOUQ7QUFBOEU1RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUN5RSxrQkFBZ0IsQ0FBQ3hFLENBQUQsRUFBRztBQUFDd0Usb0JBQWdCLEdBQUN4RSxDQUFqQjtBQUFtQixHQUF4Qzs7QUFBeUN5RSxXQUFTLENBQUN6RSxDQUFELEVBQUc7QUFBQ3lFLGFBQVMsR0FBQ3pFLENBQVY7QUFBWSxHQUFsRTs7QUFBbUVtWSxjQUFZLENBQUNuWSxDQUFELEVBQUc7QUFBQ21ZLGdCQUFZLEdBQUNuWSxDQUFiO0FBQWUsR0FBbEc7O0FBQW1Ha1ksbUJBQWlCLENBQUNsWSxDQUFELEVBQUc7QUFBQ2tZLHFCQUFpQixHQUFDbFksQ0FBbEI7QUFBb0IsR0FBNUk7O0FBQTZJMEUsaUJBQWUsQ0FBQzFFLENBQUQsRUFBRztBQUFDMEUsbUJBQWUsR0FBQzFFLENBQWhCO0FBQWtCOztBQUFsTCxDQUE1QixFQUFnTixDQUFoTjtBQUFtTixJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUloWEgsTUFBTSxDQUFDNFUsT0FBUCxDQUFlLHVCQUFmLEVBQXdDLFlBQVk7QUFDaEQsU0FBT2pRLGdCQUFnQixDQUFDeUQsSUFBakIsRUFBUDtBQUNILENBRkQ7QUFJQXBJLE1BQU0sQ0FBQzRVLE9BQVAsQ0FBZSwwQkFBZixFQUEyQyxVQUFTNVQsT0FBVCxFQUFrQndiLEdBQWxCLEVBQXNCO0FBQzdELFNBQU83WCxnQkFBZ0IsQ0FBQ3lELElBQWpCLENBQXNCO0FBQUNwSCxXQUFPLEVBQUNBO0FBQVQsR0FBdEIsRUFBd0M7QUFBQ3lKLFNBQUssRUFBQytSLEdBQVA7QUFBWWpVLFFBQUksRUFBQztBQUFDYyxZQUFNLEVBQUMsQ0FBQztBQUFUO0FBQWpCLEdBQXhDLENBQVA7QUFDSCxDQUZEO0FBSUFySixNQUFNLENBQUM0VSxPQUFQLENBQWUsbUJBQWYsRUFBb0MsWUFBVTtBQUMxQyxTQUFPaFEsU0FBUyxDQUFDd0QsSUFBVixDQUFlLEVBQWYsRUFBa0I7QUFBQ0csUUFBSSxFQUFDO0FBQUNjLFlBQU0sRUFBQyxDQUFDO0FBQVQsS0FBTjtBQUFrQm9CLFNBQUssRUFBQztBQUF4QixHQUFsQixDQUFQO0FBQ0gsQ0FGRDtBQUlBekssTUFBTSxDQUFDNFUsT0FBUCxDQUFlLHVCQUFmLEVBQXdDLFlBQVU7QUFDOUMsU0FBTy9QLGVBQWUsQ0FBQ3VELElBQWhCLENBQXFCLEVBQXJCLEVBQXdCO0FBQUNHLFFBQUksRUFBQztBQUFDYyxZQUFNLEVBQUMsQ0FBQztBQUFULEtBQU47QUFBbUJvQixTQUFLLEVBQUM7QUFBekIsR0FBeEIsQ0FBUDtBQUNILENBRkQ7QUFJQXlHLGdCQUFnQixDQUFDLHdCQUFELEVBQTJCLFVBQVNsUSxPQUFULEVBQWtCUyxJQUFsQixFQUF1QjtBQUM5RCxNQUFJZ2IsVUFBVSxHQUFHLEVBQWpCOztBQUNBLE1BQUloYixJQUFJLElBQUksT0FBWixFQUFvQjtBQUNoQmdiLGNBQVUsR0FBRztBQUNUbkYsV0FBSyxFQUFFdFc7QUFERSxLQUFiO0FBR0gsR0FKRCxNQUtJO0FBQ0F5YixjQUFVLEdBQUc7QUFDVGpMLGNBQVEsRUFBRXhRO0FBREQsS0FBYjtBQUdIOztBQUNELFNBQU87QUFDSG9ILFFBQUksR0FBRTtBQUNGLGFBQU9pUSxpQkFBaUIsQ0FBQ2pRLElBQWxCLENBQXVCcVUsVUFBdkIsQ0FBUDtBQUNILEtBSEU7O0FBSUh0TCxZQUFRLEVBQUUsQ0FDTjtBQUNJL0ksVUFBSSxDQUFDdVMsS0FBRCxFQUFPO0FBQ1AsZUFBT3RhLFVBQVUsQ0FBQytILElBQVgsQ0FDSCxFQURHLEVBRUg7QUFBQzBNLGdCQUFNLEVBQUM7QUFBQzlULG1CQUFPLEVBQUMsQ0FBVDtBQUFZb08sdUJBQVcsRUFBQyxDQUF4QjtBQUEyQkMsdUJBQVcsRUFBQztBQUF2QztBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFKUCxHQUFQO0FBZUgsQ0EzQmUsQ0FBaEI7QUE2QkE2QixnQkFBZ0IsQ0FBQyx5QkFBRCxFQUE0QixVQUFTbFEsT0FBVCxFQUFrQlMsSUFBbEIsRUFBdUI7QUFDL0QsU0FBTztBQUNIMkcsUUFBSSxHQUFFO0FBQ0YsYUFBT2tRLFlBQVksQ0FBQ2xRLElBQWIsQ0FDSDtBQUFDLFNBQUMzRyxJQUFELEdBQVFUO0FBQVQsT0FERyxFQUVIO0FBQUN1SCxZQUFJLEVBQUU7QUFBQzRPLG1CQUFTLEVBQUUsQ0FBQztBQUFiO0FBQVAsT0FGRyxDQUFQO0FBSUgsS0FORTs7QUFPSGhHLFlBQVEsRUFBRSxDQUNOO0FBQ0kvSSxVQUFJLEdBQUU7QUFDRixlQUFPL0gsVUFBVSxDQUFDK0gsSUFBWCxDQUNILEVBREcsRUFFSDtBQUFDME0sZ0JBQU0sRUFBQztBQUFDOVQsbUJBQU8sRUFBQyxDQUFUO0FBQVlvTyx1QkFBVyxFQUFDLENBQXhCO0FBQTJCdk0sMkJBQWUsRUFBQztBQUEzQztBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFQUCxHQUFQO0FBa0JILENBbkJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDakRBNUMsTUFBTSxDQUFDbVIsTUFBUCxDQUFjO0FBQUN6TSxrQkFBZ0IsRUFBQyxNQUFJQSxnQkFBdEI7QUFBdUNDLFdBQVMsRUFBQyxNQUFJQSxTQUFyRDtBQUErRHlULG1CQUFpQixFQUFDLE1BQUlBLGlCQUFyRjtBQUF1R0MsY0FBWSxFQUFDLE1BQUlBLFlBQXhIO0FBQXFJelQsaUJBQWUsRUFBQyxNQUFJQSxlQUF6SjtBQUF5S3FULGFBQVcsRUFBQyxNQUFJQSxXQUF6TDtBQUFxTUMsc0JBQW9CLEVBQUMsTUFBSUE7QUFBOU4sQ0FBZDtBQUFtUSxJQUFJOUcsS0FBSjtBQUFVcFIsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDbVIsT0FBSyxDQUFDbFIsQ0FBRCxFQUFHO0FBQUNrUixTQUFLLEdBQUNsUixDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQXZDLEVBQXFFLENBQXJFO0FBR3ZVLE1BQU13RSxnQkFBZ0IsR0FBRyxJQUFJME0sS0FBSyxDQUFDQyxVQUFWLENBQXFCLG1CQUFyQixDQUF6QjtBQUNBLE1BQU0xTSxTQUFTLEdBQUcsSUFBSXlNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixXQUFyQixDQUFsQjtBQUNBLE1BQU0rRyxpQkFBaUIsR0FBRyxJQUFJaEgsS0FBSyxDQUFDQyxVQUFWLENBQXFCLHFCQUFyQixDQUExQjtBQUNBLE1BQU1nSCxZQUFZLEdBQUcsSUFBS2pILEtBQUssQ0FBQ0MsVUFBWCxDQUFzQixlQUF0QixDQUFyQjtBQUNBLE1BQU16TSxlQUFlLEdBQUcsSUFBSXdNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQiw0QkFBckIsQ0FBeEI7QUFDQSxNQUFNNEcsV0FBVyxHQUFHLElBQUk3RyxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsY0FBckIsQ0FBcEI7QUFDQSxNQUFNNkcsb0JBQW9CLEdBQUcsSUFBSTlHLEtBQUssQ0FBQ0MsVUFBVixDQUFxQix3QkFBckIsQ0FBN0I7QUFFUCtHLGlCQUFpQixDQUFDOUcsT0FBbEIsQ0FBMEI7QUFDdEJtTCxpQkFBZSxHQUFFO0FBQ2IsUUFBSWxhLFNBQVMsR0FBR25DLFVBQVUsQ0FBQ29DLE9BQVgsQ0FBbUI7QUFBQ3pCLGFBQU8sRUFBQyxLQUFLd1E7QUFBZCxLQUFuQixDQUFoQjtBQUNBLFdBQVFoUCxTQUFTLENBQUM0TSxXQUFYLEdBQXdCNU0sU0FBUyxDQUFDNE0sV0FBVixDQUFzQnFJLE9BQTlDLEdBQXNELEtBQUtqRyxRQUFsRTtBQUNILEdBSnFCOztBQUt0Qm1MLGNBQVksR0FBRTtBQUNWLFFBQUluYSxTQUFTLEdBQUduQyxVQUFVLENBQUNvQyxPQUFYLENBQW1CO0FBQUN6QixhQUFPLEVBQUMsS0FBS3NXO0FBQWQsS0FBbkIsQ0FBaEI7QUFDQSxXQUFROVUsU0FBUyxDQUFDNE0sV0FBWCxHQUF3QjVNLFNBQVMsQ0FBQzRNLFdBQVYsQ0FBc0JxSSxPQUE5QyxHQUFzRCxLQUFLSCxLQUFsRTtBQUNIOztBQVJxQixDQUExQixFOzs7Ozs7Ozs7OztBQ1hBLElBQUl0WCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlpWSxNQUFKO0FBQVduWSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNrWSxRQUFNLENBQUNqWSxDQUFELEVBQUc7QUFBQ2lZLFVBQU0sR0FBQ2pZLENBQVA7QUFBUzs7QUFBcEIsQ0FBM0IsRUFBaUQsQ0FBakQ7QUFBb0QsSUFBSTRYLEtBQUo7QUFBVTlYLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzZYLE9BQUssQ0FBQzVYLENBQUQsRUFBRztBQUFDNFgsU0FBSyxHQUFDNVgsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUl6SUgsTUFBTSxDQUFDNFUsT0FBUCxDQUFlLGVBQWYsRUFBZ0MsWUFBWTtBQUN4QyxTQUFPd0QsTUFBTSxDQUFDaFEsSUFBUCxDQUFZO0FBQUNwQixXQUFPLEVBQUNoSCxNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm9CO0FBQWhDLEdBQVosQ0FBUDtBQUNILENBRkQsRTs7Ozs7Ozs7Ozs7QUNKQS9HLE1BQU0sQ0FBQ21SLE1BQVAsQ0FBYztBQUFDZ0gsUUFBTSxFQUFDLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJL0csS0FBSjtBQUFVcFIsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDbVIsT0FBSyxDQUFDbFIsQ0FBRCxFQUFHO0FBQUNrUixTQUFLLEdBQUNsUixDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRXRDLE1BQU1pWSxNQUFNLEdBQUcsSUFBSS9HLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixRQUFyQixDQUFmLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSXRSLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJNEUsWUFBSjtBQUFpQjlFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUM2RSxjQUFZLENBQUM1RSxDQUFELEVBQUc7QUFBQzRFLGdCQUFZLEdBQUM1RSxDQUFiO0FBQWU7O0FBQWhDLENBQWpELEVBQW1GLENBQW5GO0FBQXNGLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBSzlPLE1BQU15YyxhQUFhLEdBQUcsRUFBdEI7QUFFQTVjLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gscUNBQW1DO0FBQUEsb0NBQWdCO0FBQy9DLFdBQUtFLE9BQUw7QUFDQSxVQUFJNGIsU0FBSixFQUNJLE9BQU8seUJBQVA7QUFFSixZQUFNQyxZQUFZLEdBQUcvWCxZQUFZLENBQUNxRCxJQUFiLENBQWtCO0FBQUNxRSxpQkFBUyxFQUFDO0FBQVgsT0FBbEIsRUFBb0M7QUFBQ2hDLGFBQUssRUFBRTtBQUFSLE9BQXBDLEVBQWtEaEMsS0FBbEQsRUFBckI7O0FBQ0EsVUFBRztBQUNDb1UsaUJBQVMsR0FBRyxJQUFaO0FBQ0EsY0FBTW5SLGdCQUFnQixHQUFHM0csWUFBWSxDQUFDc0csYUFBYixHQUE2QkMseUJBQTdCLEVBQXpCOztBQUNBLGFBQUssSUFBSXJILENBQVQsSUFBYzZZLFlBQWQsRUFBMkI7QUFDdkIsY0FBSXZjLEdBQUcsR0FBRyxFQUFWOztBQUNBLGNBQUk7QUFDQUEsZUFBRyxHQUFHRyxHQUFHLEdBQUUseUJBQUwsR0FBK0JvYyxZQUFZLENBQUM3WSxDQUFELENBQVosQ0FBZ0JvSSxNQUFyRDtBQUNBLGdCQUFJbEwsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsZ0JBQUl3YyxFQUFFLEdBQUczYixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFUO0FBRUF5YixjQUFFLENBQUMxVCxNQUFILEdBQVkzQixRQUFRLENBQUNxVixFQUFFLENBQUNDLFdBQUgsQ0FBZTNULE1BQWhCLENBQXBCO0FBQ0EwVCxjQUFFLENBQUN0USxTQUFILEdBQWUsSUFBZjtBQUVBZiw0QkFBZ0IsQ0FBQ3RELElBQWpCLENBQXNCO0FBQUNpRSxvQkFBTSxFQUFDeVEsWUFBWSxDQUFDN1ksQ0FBRCxDQUFaLENBQWdCb0k7QUFBeEIsYUFBdEIsRUFBdUQwQixTQUF2RCxDQUFpRTtBQUFDOUcsa0JBQUksRUFBQzhWO0FBQU4sYUFBakU7QUFFSCxXQVZELENBV0EsT0FBTW5jLENBQU4sRUFBUztBQUNMO0FBQ0E7QUFDQUMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUFaLEVBQTBDZ2MsWUFBWSxDQUFDN1ksQ0FBRCxDQUFaLENBQWdCb0ksTUFBMUQsRUFBa0V6TCxDQUFsRTtBQUNBOEssNEJBQWdCLENBQUN0RCxJQUFqQixDQUFzQjtBQUFDaUUsb0JBQU0sRUFBQ3lRLFlBQVksQ0FBQzdZLENBQUQsQ0FBWixDQUFnQm9JO0FBQXhCLGFBQXRCLEVBQXVEMEIsU0FBdkQsQ0FBaUU7QUFBQzlHLGtCQUFJLEVBQUM7QUFBQ3dGLHlCQUFTLEVBQUMsSUFBWDtBQUFpQndRLHVCQUFPLEVBQUM7QUFBekI7QUFBTixhQUFqRTtBQUNIO0FBQ0o7O0FBQ0QsWUFBSXZSLGdCQUFnQixDQUFDM0ksTUFBakIsR0FBMEIsQ0FBOUIsRUFBZ0M7QUFDNUJsQyxpQkFBTyxDQUFDQyxHQUFSLENBQVksU0FBWixFQUFzQjRLLGdCQUFnQixDQUFDM0ksTUFBdkM7QUFDQTJJLDBCQUFnQixDQUFDZ0IsT0FBakIsQ0FBeUIsQ0FBQ0MsR0FBRCxFQUFNcEwsTUFBTixLQUFpQjtBQUN0QyxnQkFBSW9MLEdBQUosRUFBUTtBQUNKOUwscUJBQU8sQ0FBQ0MsR0FBUixDQUFZNkwsR0FBWjtBQUNIOztBQUNELGdCQUFJcEwsTUFBSixFQUFXO0FBQ1BWLHFCQUFPLENBQUNDLEdBQVIsQ0FBWVMsTUFBWjtBQUNIO0FBQ0osV0FQRDtBQVFIO0FBQ0osT0FsQ0QsQ0FtQ0EsT0FBT1gsQ0FBUCxFQUFVO0FBQ05pYyxpQkFBUyxHQUFHLEtBQVo7QUFDQSxlQUFPamMsQ0FBUDtBQUNIOztBQUNEaWMsZUFBUyxHQUFHLEtBQVo7QUFDQSxhQUFPQyxZQUFZLENBQUMvWixNQUFwQjtBQUNILEtBL0NrQztBQUFBLEdBRHhCO0FBaURYLGlDQUErQixVQUFTL0IsT0FBVCxFQUFrQnFJLE1BQWxCLEVBQXlCO0FBQ3BELFNBQUtwSSxPQUFMLEdBRG9ELENBRXBEOztBQUNBLFdBQU84RCxZQUFZLENBQUNxRCxJQUFiLENBQWtCO0FBQ3JCMUYsU0FBRyxFQUFFLENBQUM7QUFBQ21XLFlBQUksRUFBRSxDQUNUO0FBQUMsMENBQWdDO0FBQWpDLFNBRFMsRUFFVDtBQUFDLG9EQUEwQztBQUEzQyxTQUZTLEVBR1Q7QUFBQyxzREFBNEM3WDtBQUE3QyxTQUhTO0FBQVAsT0FBRCxFQUlEO0FBQUM2WCxZQUFJLEVBQUMsQ0FDTjtBQUFDLG9EQUEwQztBQUEzQyxTQURNLEVBRU47QUFBQyxzREFBNEM7QUFBN0MsU0FGTSxFQUdOO0FBQUMsb0RBQTBDO0FBQTNDLFNBSE0sRUFJTjtBQUFDLHNEQUE0QzdYO0FBQTdDLFNBSk07QUFBTixPQUpDLEVBU0Q7QUFBQzZYLFlBQUksRUFBQyxDQUNOO0FBQUMsMENBQWdDO0FBQWpDLFNBRE0sRUFFTjtBQUFDLG9EQUEwQztBQUEzQyxTQUZNLEVBR047QUFBQyxzREFBNEM3WDtBQUE3QyxTQUhNO0FBQU4sT0FUQyxFQWFEO0FBQUM2WCxZQUFJLEVBQUMsQ0FDTjtBQUFDLDBDQUFnQztBQUFqQyxTQURNLEVBRU47QUFBQyxvREFBMEM7QUFBM0MsU0FGTSxFQUdOO0FBQUMsc0RBQTRDN1g7QUFBN0MsU0FITTtBQUFOLE9BYkMsRUFpQkQ7QUFBQzZYLFlBQUksRUFBQyxDQUNOO0FBQUMsMENBQWdDO0FBQWpDLFNBRE0sRUFFTjtBQUFDLG9EQUEwQztBQUEzQyxTQUZNLEVBR047QUFBQyxzREFBNEM3WDtBQUE3QyxTQUhNO0FBQU4sT0FqQkMsQ0FEZ0I7QUF1QnJCLDBCQUFvQixDQXZCQztBQXdCckJxSSxZQUFNLEVBQUM7QUFBQzZULFdBQUcsRUFBQzdUO0FBQUw7QUF4QmMsS0FBbEIsRUF5QlA7QUFBQ2QsVUFBSSxFQUFDO0FBQUNjLGNBQU0sRUFBQyxDQUFDO0FBQVQsT0FBTjtBQUNJb0IsV0FBSyxFQUFFO0FBRFgsS0F6Qk8sRUEyQkxoQyxLQTNCSyxFQUFQO0FBNEJILEdBaEZVO0FBaUZYLDJCQUF5QixVQUFTekgsT0FBVCxFQUE4QjtBQUFBLFFBQVo4VCxNQUFZLHVFQUFMLElBQUs7QUFDbkQsU0FBSzdULE9BQUwsR0FEbUQsQ0FFbkQ7O0FBQ0EsUUFBSXVCLFNBQUo7QUFDQSxRQUFJLENBQUNzUyxNQUFMLEVBQ0lBLE1BQU0sR0FBRztBQUFDOVQsYUFBTyxFQUFDLENBQVQ7QUFBWW9PLGlCQUFXLEVBQUMsQ0FBeEI7QUFBMkJ6TSxzQkFBZ0IsRUFBQyxDQUE1QztBQUErQ0MsdUJBQWlCLEVBQUM7QUFBakUsS0FBVDs7QUFDSixRQUFJNUIsT0FBTyxDQUFDbWMsUUFBUixDQUFpQm5kLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCd1gsbUJBQXhDLENBQUosRUFBaUU7QUFDN0Q7QUFDQTVhLGVBQVMsR0FBR25DLFVBQVUsQ0FBQ29DLE9BQVgsQ0FBbUI7QUFBQ0Usd0JBQWdCLEVBQUMzQjtBQUFsQixPQUFuQixFQUErQztBQUFDOFQ7QUFBRCxPQUEvQyxDQUFaO0FBQ0gsS0FIRCxNQUlLLElBQUk5VCxPQUFPLENBQUNtYyxRQUFSLENBQWlCbmQsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJ5WCxtQkFBeEMsQ0FBSixFQUFpRTtBQUNsRTtBQUNBN2EsZUFBUyxHQUFHbkMsVUFBVSxDQUFDb0MsT0FBWCxDQUFtQjtBQUFDRyx5QkFBaUIsRUFBQzVCO0FBQW5CLE9BQW5CLEVBQWdEO0FBQUM4VDtBQUFELE9BQWhELENBQVo7QUFDSCxLQUhJLE1BSUEsSUFBSTlULE9BQU8sQ0FBQytCLE1BQVIsS0FBbUI2WixhQUF2QixFQUFzQztBQUN2Q3BhLGVBQVMsR0FBR25DLFVBQVUsQ0FBQ29DLE9BQVgsQ0FBbUI7QUFBQ3pCLGVBQU8sRUFBQ0E7QUFBVCxPQUFuQixFQUFzQztBQUFDOFQ7QUFBRCxPQUF0QyxDQUFaO0FBQ0g7O0FBQ0QsUUFBSXRTLFNBQUosRUFBYztBQUNWLGFBQU9BLFNBQVA7QUFDSDs7QUFDRCxXQUFPLEtBQVA7QUFFSDtBQXZHVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUEEsSUFBSXhDLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTRFLFlBQUo7QUFBaUI5RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQkFBWixFQUFpQztBQUFDNkUsY0FBWSxDQUFDNUUsQ0FBRCxFQUFHO0FBQUM0RSxnQkFBWSxHQUFDNUUsQ0FBYjtBQUFlOztBQUFoQyxDQUFqQyxFQUFtRSxDQUFuRTtBQUFzRSxJQUFJcUUsU0FBSjtBQUFjdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQ3NFLFdBQVMsQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsYUFBUyxHQUFDckUsQ0FBVjtBQUFZOztBQUExQixDQUFyQyxFQUFpRSxDQUFqRTtBQUtySytRLGdCQUFnQixDQUFDLG1CQUFELEVBQXNCLFlBQW9CO0FBQUEsTUFBWHpHLEtBQVcsdUVBQUgsRUFBRztBQUN0RCxTQUFPO0FBQ0hyQyxRQUFJLEdBQUU7QUFDRixhQUFPckQsWUFBWSxDQUFDcUQsSUFBYixDQUFrQjtBQUFDaUIsY0FBTSxFQUFFO0FBQUVpVSxpQkFBTyxFQUFFO0FBQVgsU0FBVDtBQUEyQjdRLGlCQUFTLEVBQUU7QUFBQzhRLGFBQUcsRUFBRTtBQUFOO0FBQXRDLE9BQWxCLEVBQXNFO0FBQUNoVixZQUFJLEVBQUM7QUFBQ2MsZ0JBQU0sRUFBQyxDQUFDO0FBQVQsU0FBTjtBQUFtQm9CLGFBQUssRUFBQ0E7QUFBekIsT0FBdEUsQ0FBUDtBQUNILEtBSEU7O0FBSUgwRyxZQUFRLEVBQUUsQ0FDTjtBQUNJL0ksVUFBSSxDQUFDMlUsRUFBRCxFQUFJO0FBQ0osWUFBSUEsRUFBRSxDQUFDMVQsTUFBUCxFQUNJLE9BQU83RSxTQUFTLENBQUM0RCxJQUFWLENBQ0g7QUFBQ2lCLGdCQUFNLEVBQUMwVCxFQUFFLENBQUMxVDtBQUFYLFNBREcsRUFFSDtBQUFDeUwsZ0JBQU0sRUFBQztBQUFDblIsZ0JBQUksRUFBQyxDQUFOO0FBQVMwRixrQkFBTSxFQUFDO0FBQWhCO0FBQVIsU0FGRyxDQUFQO0FBSVA7O0FBUEwsS0FETTtBQUpQLEdBQVA7QUFnQkgsQ0FqQmUsQ0FBaEI7QUFtQkE2SCxnQkFBZ0IsQ0FBQyx3QkFBRCxFQUEyQixVQUFTc00sZ0JBQVQsRUFBMkJDLGdCQUEzQixFQUF1RDtBQUFBLE1BQVZoVCxLQUFVLHVFQUFKLEdBQUk7QUFDOUYsTUFBSWlULEtBQUssR0FBRyxFQUFaOztBQUNBLE1BQUlGLGdCQUFnQixJQUFJQyxnQkFBeEIsRUFBeUM7QUFDckNDLFNBQUssR0FBRztBQUFDaGIsU0FBRyxFQUFDLENBQUM7QUFBQyxvREFBMkM4YTtBQUE1QyxPQUFELEVBQWdFO0FBQUMsb0RBQTJDQztBQUE1QyxPQUFoRTtBQUFMLEtBQVI7QUFDSDs7QUFFRCxNQUFJLENBQUNELGdCQUFELElBQXFCQyxnQkFBekIsRUFBMEM7QUFDdENDLFNBQUssR0FBRztBQUFDLGtEQUEyQ0Q7QUFBNUMsS0FBUjtBQUNIOztBQUVELFNBQU87QUFDSHJWLFFBQUksR0FBRTtBQUNGLGFBQU9yRCxZQUFZLENBQUNxRCxJQUFiLENBQWtCc1YsS0FBbEIsRUFBeUI7QUFBQ25WLFlBQUksRUFBQztBQUFDYyxnQkFBTSxFQUFDLENBQUM7QUFBVCxTQUFOO0FBQW1Cb0IsYUFBSyxFQUFDQTtBQUF6QixPQUF6QixDQUFQO0FBQ0gsS0FIRTs7QUFJSDBHLFlBQVEsRUFBQyxDQUNMO0FBQ0kvSSxVQUFJLENBQUMyVSxFQUFELEVBQUk7QUFDSixlQUFPdlksU0FBUyxDQUFDNEQsSUFBVixDQUNIO0FBQUNpQixnQkFBTSxFQUFDMFQsRUFBRSxDQUFDMVQ7QUFBWCxTQURHLEVBRUg7QUFBQ3lMLGdCQUFNLEVBQUM7QUFBQ25SLGdCQUFJLEVBQUMsQ0FBTjtBQUFTMEYsa0JBQU0sRUFBQztBQUFoQjtBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBREs7QUFKTixHQUFQO0FBZUgsQ0F6QmUsQ0FBaEI7QUEyQkE2SCxnQkFBZ0IsQ0FBQyxzQkFBRCxFQUF5QixVQUFTdEYsSUFBVCxFQUFjO0FBQ25ELFNBQU87QUFDSHhELFFBQUksR0FBRTtBQUNGLGFBQU9yRCxZQUFZLENBQUNxRCxJQUFiLENBQWtCO0FBQUNpRSxjQUFNLEVBQUNUO0FBQVIsT0FBbEIsQ0FBUDtBQUNILEtBSEU7O0FBSUh1RixZQUFRLEVBQUUsQ0FDTjtBQUNJL0ksVUFBSSxDQUFDMlUsRUFBRCxFQUFJO0FBQ0osZUFBT3ZZLFNBQVMsQ0FBQzRELElBQVYsQ0FDSDtBQUFDaUIsZ0JBQU0sRUFBQzBULEVBQUUsQ0FBQzFUO0FBQVgsU0FERyxFQUVIO0FBQUN5TCxnQkFBTSxFQUFDO0FBQUNuUixnQkFBSSxFQUFDLENBQU47QUFBUzBGLGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCO0FBa0JBNkgsZ0JBQWdCLENBQUMscUJBQUQsRUFBd0IsVUFBUzdILE1BQVQsRUFBZ0I7QUFDcEQsU0FBTztBQUNIakIsUUFBSSxHQUFFO0FBQ0YsYUFBT3JELFlBQVksQ0FBQ3FELElBQWIsQ0FBa0I7QUFBQ2lCLGNBQU0sRUFBQ0E7QUFBUixPQUFsQixDQUFQO0FBQ0gsS0FIRTs7QUFJSDhILFlBQVEsRUFBRSxDQUNOO0FBQ0kvSSxVQUFJLENBQUMyVSxFQUFELEVBQUk7QUFDSixlQUFPdlksU0FBUyxDQUFDNEQsSUFBVixDQUNIO0FBQUNpQixnQkFBTSxFQUFDMFQsRUFBRSxDQUFDMVQ7QUFBWCxTQURHLEVBRUg7QUFBQ3lMLGdCQUFNLEVBQUM7QUFBQ25SLGdCQUFJLEVBQUMsQ0FBTjtBQUFTMEYsa0JBQU0sRUFBQztBQUFoQjtBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFKUCxHQUFQO0FBZUgsQ0FoQmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNyRUFwSixNQUFNLENBQUNtUixNQUFQLENBQWM7QUFBQ3JNLGNBQVksRUFBQyxNQUFJQTtBQUFsQixDQUFkO0FBQStDLElBQUlzTSxLQUFKO0FBQVVwUixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNtUixPQUFLLENBQUNsUixDQUFELEVBQUc7QUFBQ2tSLFNBQUssR0FBQ2xSLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSXFFLFNBQUo7QUFBY3ZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNzRSxXQUFTLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLGFBQVMsR0FBQ3JFLENBQVY7QUFBWTs7QUFBMUIsQ0FBbEMsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSXdkLE1BQUo7QUFBVzFkLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUN5ZCxRQUFNLENBQUN4ZCxDQUFELEVBQUc7QUFBQ3dkLFVBQU0sR0FBQ3hkLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUMsRUFBa0UsQ0FBbEU7QUFJOUwsTUFBTTRFLFlBQVksR0FBRyxJQUFJc00sS0FBSyxDQUFDQyxVQUFWLENBQXFCLGNBQXJCLENBQXJCO0FBRVB2TSxZQUFZLENBQUN3TSxPQUFiLENBQXFCO0FBQ2pCeEgsT0FBSyxHQUFFO0FBQ0gsV0FBT3ZGLFNBQVMsQ0FBQy9CLE9BQVYsQ0FBa0I7QUFBQzRHLFlBQU0sRUFBQyxLQUFLQTtBQUFiLEtBQWxCLENBQVA7QUFDSDs7QUFIZ0IsQ0FBckIsRTs7Ozs7Ozs7Ozs7QUNOQSxJQUFJckosTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJNEUsWUFBSjtBQUFpQjlFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUM2RSxjQUFZLENBQUM1RSxDQUFELEVBQUc7QUFBQzRFLGdCQUFZLEdBQUM1RSxDQUFiO0FBQWU7O0FBQWhDLENBQWpELEVBQW1GLENBQW5GO0FBQXNGLElBQUlxRSxTQUFKO0FBQWN2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDc0UsV0FBUyxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxhQUFTLEdBQUNyRSxDQUFWO0FBQVk7O0FBQTFCLENBQXJDLEVBQWlFLENBQWpFO0FBSXJMSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLHdDQUFzQyxVQUFTQyxPQUFULEVBQWlCO0FBQ25ELFNBQUtDLE9BQUwsR0FEbUQsQ0FFbkQ7O0FBQ0EsUUFBSThiLEVBQUUsR0FBR2hZLFlBQVksQ0FBQ3RDLE9BQWIsQ0FBcUI7QUFBQ29XLFVBQUksRUFBQyxDQUNoQztBQUFDLDhDQUFxQzdYO0FBQXRDLE9BRGdDLEVBRWhDO0FBQUMsa0NBQXlCO0FBQTFCLE9BRmdDLEVBR2hDO0FBQUMsNEJBQW1CO0FBQXBCLE9BSGdDO0FBQU4sS0FBckIsQ0FBVDs7QUFNQSxRQUFJK2IsRUFBSixFQUFPO0FBQ0gsVUFBSWhULEtBQUssR0FBR3ZGLFNBQVMsQ0FBQy9CLE9BQVYsQ0FBa0I7QUFBQzRHLGNBQU0sRUFBQzBULEVBQUUsQ0FBQzFUO0FBQVgsT0FBbEIsQ0FBWjs7QUFDQSxVQUFJVSxLQUFKLEVBQVU7QUFDTixlQUFPQSxLQUFLLENBQUNwRyxJQUFiO0FBQ0g7QUFDSixLQUxELE1BTUk7QUFDQTtBQUNBLGFBQU8sS0FBUDtBQUNIO0FBQ0osR0FwQlU7O0FBcUJYO0FBQ0EsaUNBQStCM0MsT0FBL0IsRUFBdUM7QUFDbkMsU0FBS0MsT0FBTDtBQUNBLFFBQUlWLEdBQUcsR0FBR0csR0FBRyxHQUFHLHFDQUFOLEdBQTRDTSxPQUE1QyxHQUFvRCxjQUE5RDs7QUFFQSxRQUFHO0FBQ0MsVUFBSWlCLFdBQVcsR0FBRzdCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWxCOztBQUNBLFVBQUkwQixXQUFXLENBQUN0QixVQUFaLElBQTBCLEdBQTlCLEVBQWtDO0FBQzlCc0IsbUJBQVcsR0FBR2IsSUFBSSxDQUFDQyxLQUFMLENBQVdZLFdBQVcsQ0FBQ1gsT0FBdkIsRUFBZ0NZLG9CQUE5QztBQUNBRCxtQkFBVyxDQUFDdUIsT0FBWixDQUFvQixDQUFDTixVQUFELEVBQWFlLENBQWIsS0FBbUI7QUFDbkMsY0FBSWhDLFdBQVcsQ0FBQ2dDLENBQUQsQ0FBWCxJQUFrQmhDLFdBQVcsQ0FBQ2dDLENBQUQsQ0FBWCxDQUFlZCxNQUFyQyxFQUNJbEIsV0FBVyxDQUFDZ0MsQ0FBRCxDQUFYLENBQWVkLE1BQWYsR0FBd0JDLFVBQVUsQ0FBQ25CLFdBQVcsQ0FBQ2dDLENBQUQsQ0FBWCxDQUFlZCxNQUFoQixDQUFsQztBQUNQLFNBSEQ7QUFLQSxlQUFPbEIsV0FBUDtBQUNIOztBQUFBO0FBQ0osS0FYRCxDQVlBLE9BQU9yQixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7QUFDQU0sYUFBTyxDQUFDQyxHQUFSLENBQVkseUNBQVosRUFBdURGLENBQXZELEVBQTBETCxHQUExRDtBQUNIO0FBQ0o7O0FBMUNVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNKQSxJQUFJUCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQS9CLEVBQTZELENBQTdEO0FBQWdFLElBQUl3RSxnQkFBSjtBQUFxQjFFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUN5RSxrQkFBZ0IsQ0FBQ3hFLENBQUQsRUFBRztBQUFDd0Usb0JBQWdCLEdBQUN4RSxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBdkMsRUFBaUYsQ0FBakY7QUFBb0YsSUFBSTJFLGtCQUFKO0FBQXVCN0UsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQzRFLG9CQUFrQixDQUFDM0UsQ0FBRCxFQUFHO0FBQUMyRSxzQkFBa0IsR0FBQzNFLENBQW5CO0FBQXFCOztBQUE1QyxDQUE1QyxFQUEwRixDQUExRjtBQUsvUUgsTUFBTSxDQUFDNFUsT0FBUCxDQUFlLGdCQUFmLEVBQWlDLFlBQW1FO0FBQUEsTUFBekRyTSxJQUF5RCx1RUFBbEQscUJBQWtEO0FBQUEsTUFBM0JxVixTQUEyQix1RUFBZixDQUFDLENBQWM7QUFBQSxNQUFYOUksTUFBVyx1RUFBSixFQUFJO0FBQ2hHLFNBQU96VSxVQUFVLENBQUMrSCxJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQUNHLFFBQUksRUFBRTtBQUFDLE9BQUNBLElBQUQsR0FBUXFWO0FBQVQsS0FBUDtBQUE0QjlJLFVBQU0sRUFBRUE7QUFBcEMsR0FBcEIsQ0FBUDtBQUNILENBRkQ7QUFJQTVELGdCQUFnQixDQUFDLHNCQUFELEVBQXdCO0FBQ3BDOUksTUFBSSxHQUFHO0FBQ0gsV0FBTy9ILFVBQVUsQ0FBQytILElBQVgsQ0FBZ0IsRUFBaEIsQ0FBUDtBQUNILEdBSG1DOztBQUlwQytJLFVBQVEsRUFBRSxDQUNOO0FBQ0kvSSxRQUFJLENBQUN5VixHQUFELEVBQU07QUFDTixhQUFPbFosZ0JBQWdCLENBQUN5RCxJQUFqQixDQUNIO0FBQUVwSCxlQUFPLEVBQUU2YyxHQUFHLENBQUM3YztBQUFmLE9BREcsRUFFSDtBQUFFdUgsWUFBSSxFQUFFO0FBQUNjLGdCQUFNLEVBQUU7QUFBVCxTQUFSO0FBQXFCb0IsYUFBSyxFQUFFO0FBQTVCLE9BRkcsQ0FBUDtBQUlIOztBQU5MLEdBRE07QUFKMEIsQ0FBeEIsQ0FBaEI7QUFnQkF6SyxNQUFNLENBQUM0VSxPQUFQLENBQWUseUJBQWYsRUFBMEMsWUFBVTtBQUNoRCxTQUFPdlUsVUFBVSxDQUFDK0gsSUFBWCxDQUFnQjtBQUNuQkMsVUFBTSxFQUFFLG9CQURXO0FBRW5CQyxVQUFNLEVBQUM7QUFGWSxHQUFoQixFQUdMO0FBQ0VDLFFBQUksRUFBQztBQUNEQyxrQkFBWSxFQUFDLENBQUM7QUFEYixLQURQO0FBSUVzTSxVQUFNLEVBQUM7QUFDSDlULGFBQU8sRUFBRSxDQUROO0FBRUhvTyxpQkFBVyxFQUFDLENBRlQ7QUFHSDVHLGtCQUFZLEVBQUMsQ0FIVjtBQUlINkcsaUJBQVcsRUFBQztBQUpUO0FBSlQsR0FISyxDQUFQO0FBZUgsQ0FoQkQ7QUFrQkE2QixnQkFBZ0IsQ0FBQyxtQkFBRCxFQUFzQixVQUFTbFEsT0FBVCxFQUFpQjtBQUNuRCxNQUFJZ1ksT0FBTyxHQUFHO0FBQUNoWSxXQUFPLEVBQUNBO0FBQVQsR0FBZDs7QUFDQSxNQUFJQSxPQUFPLENBQUN1RixPQUFSLENBQWdCdkcsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJ3WCxtQkFBdkMsS0FBK0QsQ0FBQyxDQUFwRSxFQUFzRTtBQUNsRXBFLFdBQU8sR0FBRztBQUFDclcsc0JBQWdCLEVBQUMzQjtBQUFsQixLQUFWO0FBQ0g7O0FBQ0QsU0FBTztBQUNIb0gsUUFBSSxHQUFFO0FBQ0YsYUFBTy9ILFVBQVUsQ0FBQytILElBQVgsQ0FBZ0I0USxPQUFoQixDQUFQO0FBQ0gsS0FIRTs7QUFJSDdILFlBQVEsRUFBRSxDQUNOO0FBQ0kvSSxVQUFJLENBQUN5VixHQUFELEVBQUs7QUFDTCxlQUFPL1ksa0JBQWtCLENBQUNzRCxJQUFuQixDQUNIO0FBQUNwSCxpQkFBTyxFQUFDNmMsR0FBRyxDQUFDN2M7QUFBYixTQURHLEVBRUg7QUFBQ3VILGNBQUksRUFBQztBQUFDYyxrQkFBTSxFQUFDLENBQUM7QUFBVCxXQUFOO0FBQW1Cb0IsZUFBSyxFQUFDO0FBQXpCLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE0sRUFTTjtBQUNJckMsVUFBSSxDQUFDeVYsR0FBRCxFQUFNO0FBQ04sZUFBT2xaLGdCQUFnQixDQUFDeUQsSUFBakIsQ0FDSDtBQUFFcEgsaUJBQU8sRUFBRTZjLEdBQUcsQ0FBQzdjO0FBQWYsU0FERyxFQUVIO0FBQUV1SCxjQUFJLEVBQUU7QUFBQ2Msa0JBQU0sRUFBRSxDQUFDO0FBQVYsV0FBUjtBQUFzQm9CLGVBQUssRUFBRXpLLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCa1k7QUFBcEQsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FUTTtBQUpQLEdBQVA7QUF1QkgsQ0E1QmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUMzQ0E3ZCxNQUFNLENBQUNtUixNQUFQLENBQWM7QUFBQy9RLFlBQVUsRUFBQyxNQUFJQTtBQUFoQixDQUFkO0FBQTJDLElBQUlnUixLQUFKO0FBQVVwUixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNtUixPQUFLLENBQUNsUixDQUFELEVBQUc7QUFBQ2tSLFNBQUssR0FBQ2xSLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSXdFLGdCQUFKO0FBQXFCMUUsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ3lFLGtCQUFnQixDQUFDeEUsQ0FBRCxFQUFHO0FBQUN3RSxvQkFBZ0IsR0FBQ3hFLENBQWpCO0FBQW1COztBQUF4QyxDQUFwQyxFQUE4RSxDQUE5RTtBQUFpRixJQUFJMkUsa0JBQUo7QUFBdUI3RSxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWixFQUF5QztBQUFDNEUsb0JBQWtCLENBQUMzRSxDQUFELEVBQUc7QUFBQzJFLHNCQUFrQixHQUFDM0UsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQXpDLEVBQXVGLENBQXZGO0FBSTdOLE1BQU1FLFVBQVUsR0FBRyxJQUFJZ1IsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFlBQXJCLENBQW5CO0FBRVBqUixVQUFVLENBQUNrUixPQUFYLENBQW1CO0FBQ2Z3TSxXQUFTLEdBQUU7QUFDUCxXQUFPcFosZ0JBQWdCLENBQUNsQyxPQUFqQixDQUF5QjtBQUFDekIsYUFBTyxFQUFDLEtBQUtBO0FBQWQsS0FBekIsQ0FBUDtBQUNILEdBSGM7O0FBSWZnZCxTQUFPLEdBQUU7QUFDTCxXQUFPbFosa0JBQWtCLENBQUNzRCxJQUFuQixDQUF3QjtBQUFDcEgsYUFBTyxFQUFDLEtBQUtBO0FBQWQsS0FBeEIsRUFBZ0Q7QUFBQ3VILFVBQUksRUFBQztBQUFDYyxjQUFNLEVBQUMsQ0FBQztBQUFULE9BQU47QUFBbUJvQixXQUFLLEVBQUM7QUFBekIsS0FBaEQsRUFBOEVoQyxLQUE5RSxFQUFQO0FBQ0g7O0FBTmMsQ0FBbkIsRSxDQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0JBeEksTUFBTSxDQUFDbVIsTUFBUCxDQUFjO0FBQUN0TSxvQkFBa0IsRUFBQyxNQUFJQTtBQUF4QixDQUFkO0FBQTJELElBQUl1TSxLQUFKO0FBQVVwUixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNtUixPQUFLLENBQUNsUixDQUFELEVBQUc7QUFBQ2tSLFNBQUssR0FBQ2xSLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFOUQsTUFBTTJFLGtCQUFrQixHQUFHLElBQUl1TSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsc0JBQXJCLENBQTNCLEM7Ozs7Ozs7Ozs7O0FDRlByUixNQUFNLENBQUNtUixNQUFQLENBQWM7QUFBQ3BNLFdBQVMsRUFBQyxNQUFJQTtBQUFmLENBQWQ7QUFBeUMsSUFBSXFNLEtBQUo7QUFBVXBSLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ21SLE9BQUssQ0FBQ2xSLENBQUQsRUFBRztBQUFDa1IsU0FBSyxHQUFDbFIsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUU1QyxNQUFNNkUsU0FBUyxHQUFHLElBQUlxTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsV0FBckIsQ0FBbEIsQzs7Ozs7Ozs7Ozs7QUNGUHJSLE1BQU0sQ0FBQ21SLE1BQVAsQ0FBYztBQUFDMU0sZUFBYSxFQUFDLE1BQUlBO0FBQW5CLENBQWQ7QUFBaUQsSUFBSTJNLEtBQUo7QUFBVXBSLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ21SLE9BQUssQ0FBQ2xSLENBQUQsRUFBRztBQUFDa1IsU0FBSyxHQUFDbFIsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUVwRCxNQUFNdUUsYUFBYSxHQUFHLElBQUkyTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsZ0JBQXJCLENBQXRCLEM7Ozs7Ozs7Ozs7O0FDRlA7QUFDQSx3Qzs7Ozs7Ozs7Ozs7QUNEQSxJQUFJOU0sU0FBSjtBQUFjdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksNEJBQVosRUFBeUM7QUFBQ3NFLFdBQVMsQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsYUFBUyxHQUFDckUsQ0FBVjtBQUFZOztBQUExQixDQUF6QyxFQUFxRSxDQUFyRTtBQUF3RSxJQUFJaVcsU0FBSjtBQUFjblcsTUFBTSxDQUFDQyxJQUFQLENBQVksa0NBQVosRUFBK0M7QUFBQ2tXLFdBQVMsQ0FBQ2pXLENBQUQsRUFBRztBQUFDaVcsYUFBUyxHQUFDalcsQ0FBVjtBQUFZOztBQUExQixDQUEvQyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJd0UsZ0JBQUosRUFBcUJDLFNBQXJCLEVBQStCeVQsaUJBQS9CLEVBQWlEQyxZQUFqRCxFQUE4REosV0FBOUQsRUFBMEVDLG9CQUExRTtBQUErRmxZLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDhCQUFaLEVBQTJDO0FBQUN5RSxrQkFBZ0IsQ0FBQ3hFLENBQUQsRUFBRztBQUFDd0Usb0JBQWdCLEdBQUN4RSxDQUFqQjtBQUFtQixHQUF4Qzs7QUFBeUN5RSxXQUFTLENBQUN6RSxDQUFELEVBQUc7QUFBQ3lFLGFBQVMsR0FBQ3pFLENBQVY7QUFBWSxHQUFsRTs7QUFBbUVrWSxtQkFBaUIsQ0FBQ2xZLENBQUQsRUFBRztBQUFDa1kscUJBQWlCLEdBQUNsWSxDQUFsQjtBQUFvQixHQUE1Rzs7QUFBNkdtWSxjQUFZLENBQUNuWSxDQUFELEVBQUc7QUFBQ21ZLGdCQUFZLEdBQUNuWSxDQUFiO0FBQWUsR0FBNUk7O0FBQTZJK1gsYUFBVyxDQUFDL1gsQ0FBRCxFQUFHO0FBQUMrWCxlQUFXLEdBQUMvWCxDQUFaO0FBQWMsR0FBMUs7O0FBQTJLZ1ksc0JBQW9CLENBQUNoWSxDQUFELEVBQUc7QUFBQ2dZLHdCQUFvQixHQUFDaFksQ0FBckI7QUFBdUI7O0FBQTFOLENBQTNDLEVBQXVRLENBQXZRO0FBQTBRLElBQUk0RSxZQUFKO0FBQWlCOUUsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVosRUFBcUQ7QUFBQzZFLGNBQVksQ0FBQzVFLENBQUQsRUFBRztBQUFDNEUsZ0JBQVksR0FBQzVFLENBQWI7QUFBZTs7QUFBaEMsQ0FBckQsRUFBdUYsQ0FBdkY7QUFBMEYsSUFBSXVFLGFBQUo7QUFBa0J6RSxNQUFNLENBQUNDLElBQVAsQ0FBWSw0Q0FBWixFQUF5RDtBQUFDd0UsZUFBYSxDQUFDdkUsQ0FBRCxFQUFHO0FBQUN1RSxpQkFBYSxHQUFDdkUsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBekQsRUFBNkYsQ0FBN0Y7QUFBZ0csSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBakQsRUFBK0UsQ0FBL0U7QUFBa0YsSUFBSTJFLGtCQUFKO0FBQXVCN0UsTUFBTSxDQUFDQyxJQUFQLENBQVksbUNBQVosRUFBZ0Q7QUFBQzRFLG9CQUFrQixDQUFDM0UsQ0FBRCxFQUFHO0FBQUMyRSxzQkFBa0IsR0FBQzNFLENBQW5CO0FBQXFCOztBQUE1QyxDQUFoRCxFQUE4RixDQUE5RjtBQUFpRyxJQUFJNkUsU0FBSjtBQUFjL0UsTUFBTSxDQUFDQyxJQUFQLENBQVksa0NBQVosRUFBK0M7QUFBQzhFLFdBQVMsQ0FBQzdFLENBQUQsRUFBRztBQUFDNkUsYUFBUyxHQUFDN0UsQ0FBVjtBQUFZOztBQUExQixDQUEvQyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJd1UsU0FBSjtBQUFjMVUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3lVLFdBQVMsQ0FBQ3hVLENBQUQsRUFBRztBQUFDd1UsYUFBUyxHQUFDeFUsQ0FBVjtBQUFZOztBQUExQixDQUFqRCxFQUE2RSxDQUE3RTtBQUFnRixJQUFJc1IsV0FBSjtBQUFnQnhSLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUN1UixhQUFXLENBQUN0UixDQUFELEVBQUc7QUFBQ3NSLGVBQVcsR0FBQ3RSLENBQVo7QUFBYzs7QUFBOUIsQ0FBdkMsRUFBdUUsQ0FBdkU7QUFZM3BDc1IsV0FBVyxDQUFDcEcsYUFBWixHQUE0QjRTLFdBQTVCLENBQXdDO0FBQUM1VSxRQUFNLEVBQUUsQ0FBQztBQUFWLENBQXhDLEVBQXFEO0FBQUM2VSxRQUFNLEVBQUM7QUFBUixDQUFyRDtBQUVBMVosU0FBUyxDQUFDNkcsYUFBVixHQUEwQjRTLFdBQTFCLENBQXNDO0FBQUM1VSxRQUFNLEVBQUUsQ0FBQztBQUFWLENBQXRDLEVBQW1EO0FBQUM2VSxRQUFNLEVBQUM7QUFBUixDQUFuRDtBQUNBMVosU0FBUyxDQUFDNkcsYUFBVixHQUEwQjRTLFdBQTFCLENBQXNDO0FBQUNyVSxpQkFBZSxFQUFDO0FBQWpCLENBQXRDO0FBRUE1RSxTQUFTLENBQUNxRyxhQUFWLEdBQTBCNFMsV0FBMUIsQ0FBc0M7QUFBQzVVLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBdEM7QUFFQStNLFNBQVMsQ0FBQy9LLGFBQVYsR0FBMEI0UyxXQUExQixDQUFzQztBQUFDeEgsWUFBVSxFQUFFO0FBQWIsQ0FBdEMsRUFBdUQ7QUFBQ3lILFFBQU0sRUFBQztBQUFSLENBQXZEO0FBRUF2WixnQkFBZ0IsQ0FBQzBHLGFBQWpCLEdBQWlDNFMsV0FBakMsQ0FBNkM7QUFBQ2pkLFNBQU8sRUFBQyxDQUFUO0FBQVdxSSxRQUFNLEVBQUUsQ0FBQztBQUFwQixDQUE3QyxFQUFxRTtBQUFDNlUsUUFBTSxFQUFDO0FBQVIsQ0FBckU7QUFDQXZaLGdCQUFnQixDQUFDMEcsYUFBakIsR0FBaUM0UyxXQUFqQyxDQUE2QztBQUFDamQsU0FBTyxFQUFDLENBQVQ7QUFBVzRNLFFBQU0sRUFBQyxDQUFsQjtBQUFxQnZFLFFBQU0sRUFBRSxDQUFDO0FBQTlCLENBQTdDO0FBRUF6RSxTQUFTLENBQUN5RyxhQUFWLEdBQTBCNFMsV0FBMUIsQ0FBc0M7QUFBQzVVLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBdEMsRUFBb0Q7QUFBQzZVLFFBQU0sRUFBQztBQUFSLENBQXBEO0FBRUE1RixZQUFZLENBQUNqTixhQUFiLEdBQTZCNFMsV0FBN0IsQ0FBeUM7QUFBQ3pNLFVBQVEsRUFBQyxDQUFWO0FBQWE4RixPQUFLLEVBQUMsQ0FBbkI7QUFBc0JILFdBQVMsRUFBRSxDQUFDO0FBQWxDLENBQXpDO0FBQ0FtQixZQUFZLENBQUNqTixhQUFiLEdBQTZCNFMsV0FBN0IsQ0FBeUM7QUFBQ3pNLFVBQVEsRUFBQyxDQUFWO0FBQWE2SCxhQUFXLEVBQUMsQ0FBQztBQUExQixDQUF6QztBQUNBZixZQUFZLENBQUNqTixhQUFiLEdBQTZCNFMsV0FBN0IsQ0FBeUM7QUFBQzNHLE9BQUssRUFBQyxDQUFQO0FBQVUrQixhQUFXLEVBQUMsQ0FBQztBQUF2QixDQUF6QztBQUNBZixZQUFZLENBQUNqTixhQUFiLEdBQTZCNFMsV0FBN0IsQ0FBeUM7QUFBQzNHLE9BQUssRUFBQyxDQUFQO0FBQVU5RixVQUFRLEVBQUMsQ0FBbkI7QUFBc0I2SCxhQUFXLEVBQUMsQ0FBQztBQUFuQyxDQUF6QyxFQUFnRjtBQUFDNkUsUUFBTSxFQUFDO0FBQVIsQ0FBaEY7QUFFQTdGLGlCQUFpQixDQUFDaE4sYUFBbEIsR0FBa0M0UyxXQUFsQyxDQUE4QztBQUFDek0sVUFBUSxFQUFDO0FBQVYsQ0FBOUM7QUFDQTZHLGlCQUFpQixDQUFDaE4sYUFBbEIsR0FBa0M0UyxXQUFsQyxDQUE4QztBQUFDM0csT0FBSyxFQUFDO0FBQVAsQ0FBOUM7QUFDQWUsaUJBQWlCLENBQUNoTixhQUFsQixHQUFrQzRTLFdBQWxDLENBQThDO0FBQUN6TSxVQUFRLEVBQUMsQ0FBVjtBQUFhOEYsT0FBSyxFQUFDO0FBQW5CLENBQTlDLEVBQW9FO0FBQUM0RyxRQUFNLEVBQUM7QUFBUixDQUFwRTtBQUVBaEcsV0FBVyxDQUFDN00sYUFBWixHQUE0QjRTLFdBQTVCLENBQXdDO0FBQUN4YyxNQUFJLEVBQUMsQ0FBTjtBQUFTMlQsV0FBUyxFQUFDLENBQUM7QUFBcEIsQ0FBeEMsRUFBK0Q7QUFBQzhJLFFBQU0sRUFBQztBQUFSLENBQS9EO0FBQ0EvRixvQkFBb0IsQ0FBQzlNLGFBQXJCLEdBQXFDNFMsV0FBckMsQ0FBaUQ7QUFBQ3JVLGlCQUFlLEVBQUMsQ0FBakI7QUFBbUJ3TCxXQUFTLEVBQUMsQ0FBQztBQUE5QixDQUFqRCxFQUFrRjtBQUFDOEksUUFBTSxFQUFDO0FBQVIsQ0FBbEYsRSxDQUNBOztBQUVBblosWUFBWSxDQUFDc0csYUFBYixHQUE2QjRTLFdBQTdCLENBQXlDO0FBQUM1UixRQUFNLEVBQUM7QUFBUixDQUF6QyxFQUFvRDtBQUFDNlIsUUFBTSxFQUFDO0FBQVIsQ0FBcEQ7QUFDQW5aLFlBQVksQ0FBQ3NHLGFBQWIsR0FBNkI0UyxXQUE3QixDQUF5QztBQUFDNVUsUUFBTSxFQUFDLENBQUM7QUFBVCxDQUF6QztBQUNBdEUsWUFBWSxDQUFDc0csYUFBYixHQUE2QjRTLFdBQTdCLENBQXlDO0FBQUN4UixXQUFTLEVBQUM7QUFBWCxDQUF6QyxFLENBQ0E7O0FBQ0ExSCxZQUFZLENBQUNzRyxhQUFiLEdBQTZCNFMsV0FBN0IsQ0FBeUM7QUFBQyw0Q0FBeUM7QUFBMUMsQ0FBekM7QUFDQWxaLFlBQVksQ0FBQ3NHLGFBQWIsR0FBNkI0UyxXQUE3QixDQUF5QztBQUFDLDhDQUEyQztBQUE1QyxDQUF6QztBQUNBbFosWUFBWSxDQUFDc0csYUFBYixHQUE2QjRTLFdBQTdCLENBQXlDO0FBQ3JDLHdDQUFxQyxDQURBO0FBRXJDLDRCQUF5QixDQUZZO0FBR3JDLHNCQUFvQjtBQUhpQixDQUF6QyxFQUlFO0FBQUNFLHlCQUF1QixFQUFFO0FBQUMsd0JBQW1CO0FBQUNiLGFBQU8sRUFBRTtBQUFWO0FBQXBCO0FBQTFCLENBSkY7QUFNQTVZLGFBQWEsQ0FBQzJHLGFBQWQsR0FBOEI0UyxXQUE5QixDQUEwQztBQUFDOVEsY0FBWSxFQUFDLENBQUM7QUFBZixDQUExQztBQUVBOU0sVUFBVSxDQUFDZ0wsYUFBWCxHQUEyQjRTLFdBQTNCLENBQXVDO0FBQUNqZCxTQUFPLEVBQUM7QUFBVCxDQUF2QyxFQUFtRDtBQUFDa2QsUUFBTSxFQUFDLElBQVI7QUFBY0MseUJBQXVCLEVBQUU7QUFBRW5kLFdBQU8sRUFBRTtBQUFFc2MsYUFBTyxFQUFFO0FBQVg7QUFBWDtBQUF2QyxDQUFuRCxFLENBQ0E7O0FBQ0FqZCxVQUFVLENBQUNnTCxhQUFYLEdBQTJCNFMsV0FBM0IsQ0FBdUM7QUFBQywyQkFBd0I7QUFBekIsQ0FBdkMsRUFBbUU7QUFBQ0MsUUFBTSxFQUFDLElBQVI7QUFBY0MseUJBQXVCLEVBQUU7QUFBRSw2QkFBeUI7QUFBRWIsYUFBTyxFQUFFO0FBQVg7QUFBM0I7QUFBdkMsQ0FBbkU7QUFFQXhZLGtCQUFrQixDQUFDdUcsYUFBbkIsR0FBbUM0UyxXQUFuQyxDQUErQztBQUFDamQsU0FBTyxFQUFDLENBQVQ7QUFBV3FJLFFBQU0sRUFBQyxDQUFDO0FBQW5CLENBQS9DO0FBQ0F2RSxrQkFBa0IsQ0FBQ3VHLGFBQW5CLEdBQW1DNFMsV0FBbkMsQ0FBK0M7QUFBQ3hjLE1BQUksRUFBQztBQUFOLENBQS9DO0FBRUFrVCxTQUFTLENBQUN0SixhQUFWLEdBQTBCNFMsV0FBMUIsQ0FBc0M7QUFBQ3BKLGlCQUFlLEVBQUMsQ0FBQztBQUFsQixDQUF0QyxFQUEyRDtBQUFDcUosUUFBTSxFQUFDO0FBQVIsQ0FBM0QsRTs7Ozs7Ozs7Ozs7QUM1REFqZSxNQUFNLENBQUNDLElBQVAsQ0FBWSxXQUFaO0FBQXlCRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWjtBQUFpQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVo7QUFBbUMsSUFBSWtlLFVBQUo7QUFBZW5lLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNrZSxZQUFVLENBQUNqZSxDQUFELEVBQUc7QUFBQ2llLGNBQVUsR0FBQ2plLENBQVg7QUFBYTs7QUFBNUIsQ0FBbkMsRUFBaUUsQ0FBakU7QUFBb0UsSUFBSWtlLE1BQUo7QUFBV3BlLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ21lLFFBQU0sQ0FBQ2xlLENBQUQsRUFBRztBQUFDa2UsVUFBTSxHQUFDbGUsQ0FBUDtBQUFTOztBQUFwQixDQUEzQixFQUFpRCxDQUFqRDtBQWMzTDtBQUVBaWUsVUFBVSxDQUFDRSxJQUFJLElBQUk7QUFDZjtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUEsUUFBTUMsTUFBTSxHQUFHRixNQUFNLENBQUNHLFlBQVAsRUFBZjtBQUNBRixNQUFJLENBQUNHLFlBQUwsQ0FBa0JGLE1BQU0sQ0FBQ0csSUFBUCxDQUFZQyxRQUFaLEVBQWxCO0FBQ0FMLE1BQUksQ0FBQ0csWUFBTCxDQUFrQkYsTUFBTSxDQUFDSyxLQUFQLENBQWFELFFBQWIsRUFBbEIsRUFkZSxDQWdCZjtBQUNILENBakJTLENBQVYsQzs7Ozs7Ozs7Ozs7QUNoQkExZSxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWjtBQUFrREQsTUFBTSxDQUFDQyxJQUFQLENBQVksbUNBQVo7QUFBaURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaO0FBQXNERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWjtBQUFrREQsTUFBTSxDQUFDQyxJQUFQLENBQVkseUNBQVo7QUFBdURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaO0FBQXNERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw2Q0FBWjtBQUEyREQsTUFBTSxDQUFDQyxJQUFQLENBQVkscUNBQVo7QUFBbURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBDQUFaO0FBQXdERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx1Q0FBWjtBQUFxREQsTUFBTSxDQUFDQyxJQUFQLENBQVksNENBQVo7QUFBMERELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtDQUFaO0FBQTZERCxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQ0FBWjtBQUF3REQsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVo7QUFBNkRELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlDQUFaO0FBQXVERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw4Q0FBWjtBQUE0REQsTUFBTSxDQUFDQyxJQUFQLENBQVkseUNBQVo7QUFBdURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNDQUFaO0FBQW9ERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWixFOzs7Ozs7Ozs7OztBQ0E3OUIsSUFBSTJlLE1BQUo7QUFBVzVlLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ3lSLFNBQU8sQ0FBQ3hSLENBQUQsRUFBRztBQUFDMGUsVUFBTSxHQUFDMWUsQ0FBUDtBQUFTOztBQUFyQixDQUFyQixFQUE0QyxDQUE1QztBQUErQyxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUkrRSxPQUFKO0FBQVlqRixNQUFNLENBQUNDLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUMsTUFBSUMsQ0FBSixFQUFNO0FBQUMrRSxXQUFPLEdBQUMvRSxDQUFSO0FBQVU7O0FBQWxCLENBQXRCLEVBQTBDLENBQTFDO0FBQTZDLElBQUkyZSxNQUFKO0FBQVc3ZSxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDNGUsUUFBTSxDQUFDM2UsQ0FBRCxFQUFHO0FBQUMyZSxVQUFNLEdBQUMzZSxDQUFQO0FBQVM7O0FBQXBCLENBQWxDLEVBQXdELENBQXhEO0FBS3RMSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYZ2UsYUFBVyxFQUFFLFVBQVMvZCxPQUFULEVBQWtCZ2UsTUFBbEIsRUFBMEI7QUFDbkMsUUFBSUMsYUFBYSxHQUFHM1MsTUFBTSxDQUFDQyxJQUFQLENBQVl2TCxPQUFaLEVBQXFCLEtBQXJCLENBQXBCLENBRG1DLENBRW5DO0FBQ0E7O0FBQ0EsV0FBTzZkLE1BQU0sQ0FBQ0ssTUFBUCxDQUFjRixNQUFkLEVBQXNCSCxNQUFNLENBQUNNLE9BQVAsQ0FBZUYsYUFBZixDQUF0QixDQUFQO0FBQ0gsR0FOVTtBQU9YRyxtQkFBaUIsRUFBRSxVQUFTdFosTUFBVCxFQUFpQmtaLE1BQWpCLEVBQXlCO0FBQ3hDLFFBQUlLLE1BQUo7O0FBRUEsUUFBSTtBQUNBLFVBQUl2WixNQUFNLENBQUNyRSxJQUFQLENBQVk4RSxPQUFaLENBQW9CLFNBQXBCLElBQWlDLENBQXJDLEVBQXVDO0FBQ3ZDO0FBQ0ksWUFBSStZLGlCQUFpQixHQUFHaFQsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUEwQixLQUExQixDQUF4QjtBQUNBOFMsY0FBTSxHQUFHL1MsTUFBTSxDQUFDaVQsS0FBUCxDQUFhLEVBQWIsQ0FBVDtBQUVBRCx5QkFBaUIsQ0FBQ0UsSUFBbEIsQ0FBdUJILE1BQXZCLEVBQStCLENBQS9CO0FBQ0EvUyxjQUFNLENBQUNDLElBQVAsQ0FBWXpHLE1BQU0sQ0FBQ3BFLEtBQW5CLEVBQTBCLFFBQTFCLEVBQW9DOGQsSUFBcEMsQ0FBeUNILE1BQXpDLEVBQWlEQyxpQkFBaUIsQ0FBQ3ZjLE1BQW5FO0FBQ0gsT0FQRCxNQVFLLElBQUkrQyxNQUFNLENBQUNyRSxJQUFQLENBQVk4RSxPQUFaLENBQW9CLFdBQXBCLElBQW1DLENBQXZDLEVBQXlDO0FBQzlDO0FBQ0ksWUFBSStZLGlCQUFpQixHQUFHaFQsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUEwQixLQUExQixDQUF4QjtBQUNBOFMsY0FBTSxHQUFHL1MsTUFBTSxDQUFDaVQsS0FBUCxDQUFhLEVBQWIsQ0FBVDtBQUVBRCx5QkFBaUIsQ0FBQ0UsSUFBbEIsQ0FBdUJILE1BQXZCLEVBQStCLENBQS9CO0FBQ0EvUyxjQUFNLENBQUNDLElBQVAsQ0FBWXpHLE1BQU0sQ0FBQ3BFLEtBQW5CLEVBQTBCLFFBQTFCLEVBQW9DOGQsSUFBcEMsQ0FBeUNILE1BQXpDLEVBQWlEQyxpQkFBaUIsQ0FBQ3ZjLE1BQW5FO0FBQ0gsT0FQSSxNQVFBO0FBQ0RsQyxlQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBWjtBQUNBLGVBQU8sS0FBUDtBQUNIOztBQUVELGFBQU8rZCxNQUFNLENBQUNLLE1BQVAsQ0FBY0YsTUFBZCxFQUFzQkgsTUFBTSxDQUFDTSxPQUFQLENBQWVFLE1BQWYsQ0FBdEIsQ0FBUDtBQUNILEtBdkJELENBd0JBLE9BQU96ZSxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVksaURBQVosRUFBK0RnRixNQUEvRCxFQUF1RWxGLENBQXZFO0FBQ0EsYUFBTyxLQUFQO0FBQ0g7QUFDSixHQXRDVTtBQXVDWDZlLGdCQUFjLEVBQUUsVUFBUzNaLE1BQVQsRUFBaUJrWixNQUFqQixFQUF5QjtBQUNyQyxRQUFJSyxNQUFKOztBQUVBLFFBQUk7QUFDQSxVQUFJdlosTUFBTSxDQUFDLE9BQUQsQ0FBTixDQUFnQlMsT0FBaEIsQ0FBd0IsU0FBeEIsSUFBcUMsQ0FBekMsRUFBMkM7QUFDM0M7QUFDSSxZQUFJK1ksaUJBQWlCLEdBQUdoVCxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQTBCLEtBQTFCLENBQXhCO0FBQ0E4UyxjQUFNLEdBQUcvUyxNQUFNLENBQUNpVCxLQUFQLENBQWEsRUFBYixDQUFUO0FBRUFELHlCQUFpQixDQUFDRSxJQUFsQixDQUF1QkgsTUFBdkIsRUFBK0IsQ0FBL0I7QUFDQS9TLGNBQU0sQ0FBQ0MsSUFBUCxDQUFZekcsTUFBTSxDQUFDb0IsR0FBbkIsRUFBd0IsUUFBeEIsRUFBa0NzWSxJQUFsQyxDQUF1Q0gsTUFBdkMsRUFBK0NDLGlCQUFpQixDQUFDdmMsTUFBakU7QUFDSCxPQVBELE1BUUssSUFBSStDLE1BQU0sQ0FBQyxPQUFELENBQU4sQ0FBZ0JTLE9BQWhCLENBQXdCLFdBQXhCLElBQXVDLENBQTNDLEVBQTZDO0FBQ2xEO0FBQ0ksWUFBSStZLGlCQUFpQixHQUFHaFQsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUEwQixLQUExQixDQUF4QjtBQUNBOFMsY0FBTSxHQUFHL1MsTUFBTSxDQUFDaVQsS0FBUCxDQUFhLEVBQWIsQ0FBVDtBQUVBRCx5QkFBaUIsQ0FBQ0UsSUFBbEIsQ0FBdUJILE1BQXZCLEVBQStCLENBQS9CO0FBQ0EvUyxjQUFNLENBQUNDLElBQVAsQ0FBWXpHLE1BQU0sQ0FBQ29CLEdBQW5CLEVBQXdCLFFBQXhCLEVBQWtDc1ksSUFBbEMsQ0FBdUNILE1BQXZDLEVBQStDQyxpQkFBaUIsQ0FBQ3ZjLE1BQWpFO0FBQ0gsT0FQSSxNQVFBO0FBQ0RsQyxlQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBWjtBQUNBLGVBQU8sS0FBUDtBQUNIOztBQUVELGFBQU8rZCxNQUFNLENBQUNLLE1BQVAsQ0FBY0YsTUFBZCxFQUFzQkgsTUFBTSxDQUFDTSxPQUFQLENBQWVFLE1BQWYsQ0FBdEIsQ0FBUDtBQUNILEtBdkJELENBd0JBLE9BQU96ZSxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVksaURBQVosRUFBK0RnRixNQUEvRCxFQUF1RWxGLENBQXZFO0FBQ0EsYUFBTyxLQUFQO0FBQ0g7QUFDSixHQXRFVTtBQXVFWDhlLGdCQUFjLEVBQUUsVUFBUzVaLE1BQVQsRUFBaUJyRSxJQUFqQixFQUF1QjtBQUNuQztBQUNBLFFBQUk2ZCxpQkFBSixFQUF1QkQsTUFBdkI7O0FBRUEsUUFBSTtBQUNBLFVBQUk1ZCxJQUFJLENBQUM4RSxPQUFMLENBQWEsU0FBYixJQUEwQixDQUE5QixFQUFnQztBQUNoQztBQUNJK1kseUJBQWlCLEdBQUdoVCxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQTBCLEtBQTFCLENBQXBCO0FBQ0E4UyxjQUFNLEdBQUcvUyxNQUFNLENBQUNDLElBQVAsQ0FBWXNTLE1BQU0sQ0FBQ2MsU0FBUCxDQUFpQmQsTUFBTSxDQUFDZSxNQUFQLENBQWM5WixNQUFkLEVBQXNCK1osS0FBdkMsQ0FBWixDQUFUO0FBQ0gsT0FKRCxNQUtLLElBQUlwZSxJQUFJLENBQUM4RSxPQUFMLENBQWEsV0FBYixJQUE0QixDQUFoQyxFQUFrQztBQUN2QztBQUNJK1kseUJBQWlCLEdBQUdoVCxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQTBCLEtBQTFCLENBQXBCO0FBQ0E4UyxjQUFNLEdBQUcvUyxNQUFNLENBQUNDLElBQVAsQ0FBWXNTLE1BQU0sQ0FBQ2MsU0FBUCxDQUFpQmQsTUFBTSxDQUFDZSxNQUFQLENBQWM5WixNQUFkLEVBQXNCK1osS0FBdkMsQ0FBWixDQUFUO0FBQ0gsT0FKSSxNQUtBO0FBQ0RoZixlQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBWjtBQUNBLGVBQU8sS0FBUDtBQUNIOztBQUVELGFBQU91ZSxNQUFNLENBQUNTLEtBQVAsQ0FBYVIsaUJBQWlCLENBQUN2YyxNQUEvQixFQUF1QzRiLFFBQXZDLENBQWdELFFBQWhELENBQVA7QUFDSCxLQWpCRCxDQWtCQSxPQUFPL2QsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGlEQUFaLEVBQStEZ0YsTUFBL0QsRUFBdUVsRixDQUF2RTtBQUNBLGFBQU8sS0FBUDtBQUNIO0FBQ0osR0FqR1U7QUFrR1htZixzQkFBb0IsRUFBRSxVQUFTamEsTUFBVCxFQUFnQjtBQUNsQyxRQUFJa2EsS0FBSyxHQUFHMVQsTUFBTSxDQUFDQyxJQUFQLENBQVl6RyxNQUFNLENBQUNvQixHQUFuQixFQUF3QixRQUF4QixDQUFaO0FBQ0EsV0FBTzRYLE1BQU0sQ0FBQ2tCLEtBQUQsQ0FBTixDQUFjRixLQUFkLENBQW9CLENBQXBCLEVBQXVCLEVBQXZCLEVBQTJCbkIsUUFBM0IsQ0FBb0MsS0FBcEMsRUFBMkNuUyxXQUEzQyxFQUFQO0FBQ0gsR0FyR1U7QUFzR1h5VCxjQUFZLEVBQUUsVUFBU0MsWUFBVCxFQUFzQjtBQUNoQyxRQUFJbGYsT0FBTyxHQUFHNmQsTUFBTSxDQUFDZSxNQUFQLENBQWNNLFlBQWQsQ0FBZDtBQUNBLFdBQU9yQixNQUFNLENBQUNLLE1BQVAsQ0FBY2xmLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCeVgsbUJBQXJDLEVBQTBEcmMsT0FBTyxDQUFDNmUsS0FBbEUsQ0FBUDtBQUNILEdBekdVO0FBMEdYTSxtQkFBaUIsRUFBRSxVQUFTQyxVQUFULEVBQW9CO0FBQ25DLFFBQUk1WixRQUFRLEdBQUdwRyxJQUFJLENBQUNLLEdBQUwsQ0FBUzJmLFVBQVQsQ0FBZjs7QUFDQSxRQUFJNVosUUFBUSxDQUFDN0YsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixVQUFJOEYsSUFBSSxHQUFHdkIsT0FBTyxDQUFDd0IsSUFBUixDQUFhRixRQUFRLENBQUNsRixPQUF0QixDQUFYO0FBQ0EsYUFBT21GLElBQUksQ0FBQyxtQkFBRCxDQUFKLENBQTBCRSxJQUExQixDQUErQixLQUEvQixDQUFQO0FBQ0g7QUFDSixHQWhIVTtBQWlIWDBaLFlBQVUsRUFBRSxZQUFVO0FBQ2xCLFVBQU1DLE9BQU8sR0FBR0MsTUFBTSxDQUFDQyxPQUFQLENBQWUsU0FBZixDQUFoQjtBQUNBLFdBQU9GLE9BQU8sR0FBR0EsT0FBSCxHQUFhLE1BQTNCO0FBQ0g7QUFwSFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBcmdCLE1BQU0sQ0FBQ21SLE1BQVAsQ0FBYztBQUFDcVAsYUFBVyxFQUFDLE1BQUlBLFdBQWpCO0FBQTZCQyxvQkFBa0IsRUFBQyxNQUFJQSxrQkFBcEQ7QUFBdUVDLFVBQVEsRUFBQyxNQUFJQSxRQUFwRjtBQUE2RmhELFFBQU0sRUFBQyxNQUFJQSxNQUF4RztBQUErR2lELFVBQVEsRUFBQyxNQUFJQTtBQUE1SCxDQUFkO0FBQXFKLElBQUlDLEtBQUo7QUFBVTVnQixNQUFNLENBQUNDLElBQVAsQ0FBWSxPQUFaLEVBQW9CO0FBQUN5UixTQUFPLENBQUN4UixDQUFELEVBQUc7QUFBQzBnQixTQUFLLEdBQUMxZ0IsQ0FBTjtBQUFROztBQUFwQixDQUFwQixFQUEwQyxDQUExQztBQUE2QyxJQUFJMmdCLG1CQUFKO0FBQXdCN2dCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQzRnQixxQkFBbUIsQ0FBQzNnQixDQUFELEVBQUc7QUFBQzJnQix1QkFBbUIsR0FBQzNnQixDQUFwQjtBQUFzQjs7QUFBOUMsQ0FBekIsRUFBeUUsQ0FBekU7O0FBRzdOLE1BQU1zZ0IsV0FBVyxHQUFJTSxLQUFELElBQVc7QUFDbEMsVUFBUUEsS0FBSyxDQUFDcE4sS0FBZDtBQUNBLFNBQUssT0FBTDtBQUNJLGFBQU8sSUFBUDs7QUFDSjtBQUNJLGFBQU8sSUFBUDtBQUpKO0FBTUgsQ0FQTTs7QUFVQSxNQUFNK00sa0JBQWtCLEdBQUlLLEtBQUQsSUFBVztBQUN6QyxVQUFRQSxLQUFLLENBQUMxWSxNQUFkO0FBQ0EsU0FBSyx3QkFBTDtBQUNJLDBCQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSywwQkFBTDtBQUNJLDBCQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyx5QkFBTDtBQUNJLDBCQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxnQ0FBTDtBQUNJLDBCQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSywrQkFBTDtBQUNJLDBCQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0o7QUFDSSwwQkFBTyw4QkFBUDtBQVpKO0FBY0gsQ0FmTTs7QUFpQkEsTUFBTXNZLFFBQVEsR0FBSUksS0FBRCxJQUFXO0FBQy9CLFVBQVFBLEtBQUssQ0FBQzFKLElBQWQ7QUFDQSxTQUFLLEtBQUw7QUFDSSwwQkFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssSUFBTDtBQUNJLDBCQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxTQUFMO0FBQ0ksMEJBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLGNBQUw7QUFDSSwwQkFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKO0FBQ0ksMEJBQU8sOEJBQVA7QUFWSjtBQVlILENBYk07O0FBZUEsTUFBTXNHLE1BQU0sR0FBSW9ELEtBQUQsSUFBVztBQUM3QixNQUFJQSxLQUFLLENBQUNDLEtBQVYsRUFBZ0I7QUFDWix3QkFBTztBQUFNLGVBQVMsRUFBQztBQUFoQixvQkFBMkM7QUFBRyxlQUFTLEVBQUM7QUFBYixNQUEzQyxDQUFQO0FBQ0gsR0FGRCxNQUdJO0FBQ0Esd0JBQU87QUFBTSxlQUFTLEVBQUM7QUFBaEIsb0JBQTBDO0FBQUcsZUFBUyxFQUFDO0FBQWIsTUFBMUMsQ0FBUDtBQUNIO0FBQ0osQ0FQTTs7QUFTQSxNQUFNSixRQUFOLFNBQXVCQyxLQUFLLENBQUNJLFNBQTdCLENBQXVDO0FBQzFDQyxhQUFXLENBQUNILEtBQUQsRUFBUTtBQUNmLFVBQU1BLEtBQU47QUFDQSxTQUFLSSxHQUFMLGdCQUFXTixLQUFLLENBQUNPLFNBQU4sRUFBWDtBQUNIOztBQUVEQyxRQUFNLEdBQUc7QUFDTCxXQUFPLGNBQ0g7QUFBRyxTQUFHLEVBQUMsTUFBUDtBQUFjLGVBQVMsRUFBQywwQkFBeEI7QUFBbUQsU0FBRyxFQUFFLEtBQUtGO0FBQTdELGNBREcsZUFFSCxvQkFBQyxtQkFBRDtBQUFxQixTQUFHLEVBQUMsU0FBekI7QUFBbUMsZUFBUyxFQUFDLE9BQTdDO0FBQXFELFlBQU0sRUFBRSxLQUFLQTtBQUFsRSxPQUNLLEtBQUtKLEtBQUwsQ0FBVzVQLFFBQVgsR0FBb0IsS0FBSzRQLEtBQUwsQ0FBVzVQLFFBQS9CLEdBQXdDLEtBQUs0UCxLQUFMLENBQVdPLFdBRHhELENBRkcsQ0FBUDtBQU1IOztBQWJ5QyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0RDlDcmhCLE1BQU0sQ0FBQ21SLE1BQVAsQ0FBYztBQUFDTyxTQUFPLEVBQUMsTUFBSUQ7QUFBYixDQUFkO0FBQWtDLElBQUkxUixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlvaEIsTUFBSjtBQUFXdGhCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ3lSLFNBQU8sQ0FBQ3hSLENBQUQsRUFBRztBQUFDb2hCLFVBQU0sR0FBQ3BoQixDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDOztBQUk3R3FoQixVQUFVLEdBQUk5ZixLQUFELElBQVc7QUFDcEIsTUFBSStmLFNBQVMsR0FBRyxVQUFoQjtBQUNBL2YsT0FBSyxHQUFHaUgsSUFBSSxDQUFDc0osS0FBTCxDQUFXdlEsS0FBSyxHQUFHLElBQW5CLElBQTJCLElBQW5DO0FBQ0EsTUFBSWlILElBQUksQ0FBQ3NKLEtBQUwsQ0FBV3ZRLEtBQVgsTUFBc0JBLEtBQTFCLEVBQ0krZixTQUFTLEdBQUcsS0FBWixDQURKLEtBRUssSUFBSTlZLElBQUksQ0FBQ3NKLEtBQUwsQ0FBV3ZRLEtBQUssR0FBQyxFQUFqQixNQUF5QkEsS0FBSyxHQUFDLEVBQW5DLEVBQ0QrZixTQUFTLEdBQUcsT0FBWixDQURDLEtBRUEsSUFBSTlZLElBQUksQ0FBQ3NKLEtBQUwsQ0FBV3ZRLEtBQUssR0FBQyxHQUFqQixNQUEwQkEsS0FBSyxHQUFDLEdBQXBDLEVBQ0QrZixTQUFTLEdBQUcsUUFBWixDQURDLEtBRUEsSUFBSTlZLElBQUksQ0FBQ3NKLEtBQUwsQ0FBV3ZRLEtBQUssR0FBQyxJQUFqQixNQUEyQkEsS0FBSyxHQUFDLElBQXJDLEVBQ0QrZixTQUFTLEdBQUcsU0FBWjtBQUNKLFNBQU9GLE1BQU0sQ0FBQzdmLEtBQUQsQ0FBTixDQUFjZ2dCLE1BQWQsQ0FBcUJELFNBQXJCLENBQVA7QUFDSCxDQVpEOztBQWNBLE1BQU1FLFFBQVEsR0FBRzNoQixNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1QjlELEtBQXhDOztBQUVlLE1BQU00UCxJQUFOLENBQVc7QUFJMUJ3UCxhQUFXLENBQUNsTixNQUFELEVBQWlEO0FBQUEsUUFBeENMLEtBQXdDLHVFQUFsQzNULE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCZ2MsU0FBVztBQUN4RCxVQUFNQyxVQUFVLEdBQUdsTyxLQUFLLENBQUNtTyxXQUFOLEVBQW5CO0FBQ0EsU0FBS0MsS0FBTCxHQUFhSixRQUFRLENBQUN2WixJQUFULENBQWM0WixJQUFJLElBQzNCQSxJQUFJLENBQUNyTyxLQUFMLENBQVdtTyxXQUFYLE9BQTZCRCxVQUE3QixJQUEyQ0csSUFBSSxDQUFDQyxXQUFMLENBQWlCSCxXQUFqQixPQUFtQ0QsVUFEckUsQ0FBYjs7QUFJQSxRQUFJLEtBQUtFLEtBQVQsRUFBZTtBQUNYLFVBQUlGLFVBQVUsS0FBSyxLQUFLRSxLQUFMLENBQVdwTyxLQUFYLENBQWlCbU8sV0FBakIsRUFBbkIsRUFBbUQ7QUFDL0MsYUFBS0ksT0FBTCxHQUFlakssTUFBTSxDQUFDakUsTUFBRCxDQUFyQjtBQUNILE9BRkQsTUFFTyxJQUFJNk4sVUFBVSxLQUFLLEtBQUtFLEtBQUwsQ0FBV0UsV0FBWCxDQUF1QkgsV0FBdkIsRUFBbkIsRUFBeUQ7QUFDNUQsYUFBS0ksT0FBTCxHQUFlakssTUFBTSxDQUFDakUsTUFBRCxDQUFOLEdBQWlCLEtBQUsrTixLQUFMLENBQVdJLFFBQTNDO0FBQ0g7QUFDSixLQU5ELE1BT0s7QUFDRCxXQUFLSixLQUFMLEdBQWEsRUFBYjtBQUNBLFdBQUtHLE9BQUwsR0FBZWpLLE1BQU0sQ0FBQ2pFLE1BQUQsQ0FBckI7QUFDSDtBQUNKOztBQUVELE1BQUlBLE1BQUosR0FBYztBQUNWLFdBQU8sS0FBS2tPLE9BQVo7QUFDSDs7QUFFRCxNQUFJRSxhQUFKLEdBQXFCO0FBQ2pCLFdBQVEsS0FBS0wsS0FBTixHQUFhLEtBQUtHLE9BQUwsR0FBZSxLQUFLSCxLQUFMLENBQVdJLFFBQXZDLEdBQWdELEtBQUtELE9BQTVEO0FBQ0g7O0FBRUR2RCxVQUFRLENBQUUwRCxTQUFGLEVBQWE7QUFDakI7QUFDQSxRQUFJQyxRQUFRLEdBQUc1USxJQUFJLENBQUNnQyxXQUFMLENBQWlCeU8sUUFBakIsSUFBMkJFLFNBQVMsWUFBRSxFQUFGLEVBQVFBLFNBQVIsSUFBbUIsS0FBdkQsQ0FBZjs7QUFDQSxRQUFJLEtBQUtyTyxNQUFMLEdBQWNzTyxRQUFsQixFQUE0QjtBQUN4Qix1QkFBVWYsTUFBTSxDQUFDLEtBQUt2TixNQUFOLENBQU4sQ0FBb0IwTixNQUFwQixDQUEyQixVQUEzQixDQUFWLGNBQXFELEtBQUtLLEtBQUwsQ0FBV3BPLEtBQWhFO0FBQ0gsS0FGRCxNQUVPO0FBQ0gsdUJBQVUwTyxTQUFTLEdBQUNkLE1BQU0sQ0FBQyxLQUFLYSxhQUFOLENBQU4sQ0FBMkJWLE1BQTNCLENBQWtDLFNBQVMsSUFBSWEsTUFBSixDQUFXRixTQUFYLENBQTNDLENBQUQsR0FBbUViLFVBQVUsQ0FBQyxLQUFLWSxhQUFOLENBQWhHLGNBQXdILEtBQUtMLEtBQUwsQ0FBV0UsV0FBbkk7QUFDSDtBQUNKOztBQUVETyxZQUFVLENBQUVmLFNBQUYsRUFBYTtBQUNuQixRQUFJek4sTUFBTSxHQUFHLEtBQUtBLE1BQWxCOztBQUNBLFFBQUl5TixTQUFKLEVBQWU7QUFDWHpOLFlBQU0sR0FBR3VOLE1BQU0sQ0FBQ3ZOLE1BQUQsQ0FBTixDQUFlME4sTUFBZixDQUFzQkQsU0FBdEIsQ0FBVDtBQUNIOztBQUVELFFBQUk5TixLQUFLLEdBQUksS0FBS29PLEtBQUwsSUFBYyxFQUFmLEdBQW1CclEsSUFBSSxDQUFDZ0MsV0FBTCxDQUFpQnVPLFdBQXBDLEdBQWdELEtBQUtGLEtBQUwsQ0FBV3BPLEtBQXZFO0FBQ0EscUJBQVVLLE1BQVYsY0FBb0JMLEtBQXBCO0FBQ0g7O0FBRUQ4TyxhQUFXLENBQUVoQixTQUFGLEVBQWE7QUFDcEIsUUFBSXpOLE1BQU0sR0FBRyxLQUFLb08sYUFBbEI7O0FBQ0EsUUFBSVgsU0FBSixFQUFlO0FBQ1h6TixZQUFNLEdBQUd1TixNQUFNLENBQUN2TixNQUFELENBQU4sQ0FBZTBOLE1BQWYsQ0FBc0JELFNBQXRCLENBQVQ7QUFDSDs7QUFDRCxxQkFBVXpOLE1BQVYsY0FBb0J0QyxJQUFJLENBQUNnQyxXQUFMLENBQWlCdU8sV0FBckM7QUFDSDs7QUF6RHlCOztBQUFMdlEsSSxDQUNkZ0MsVyxHQUFjaU8sUUFBUSxDQUFDdlosSUFBVCxDQUFjNFosSUFBSSxJQUFJQSxJQUFJLENBQUNyTyxLQUFMLEtBQWUzVCxNQUFNLENBQUMyRixRQUFQLENBQWdCQyxNQUFoQixDQUF1QmdjLFNBQTVELEM7QUFEQWxRLEksQ0FFZGdSLFEsR0FBVyxJQUFJekssTUFBTSxDQUFDdkcsSUFBSSxDQUFDZ0MsV0FBTCxDQUFpQnlPLFFBQWxCLEM7Ozs7Ozs7Ozs7O0FDdEI1QmxpQixNQUFNLENBQUNtUixNQUFQLENBQWM7QUFBQ3VSLG1CQUFpQixFQUFDLE1BQUlBO0FBQXZCLENBQWQ7O0FBQU8sTUFBTUEsaUJBQWlCLEdBQUloZixJQUFELElBQVU7QUFDdkMsUUFBTWlmLFdBQVcsR0FBR2xiLFFBQVEsQ0FBQy9ELElBQUksQ0FBQ2tmLE9BQUwsR0FBYWxmLElBQUksQ0FBQ21mLEtBQUwsQ0FBV25FLFFBQVgsR0FBc0JvRSxTQUF0QixDQUFnQyxDQUFoQyxFQUFrQyxDQUFsQyxDQUFkLENBQTVCO0FBQ0EsU0FBUSxJQUFJbmYsSUFBSixDQUFTZ2YsV0FBVCxDQUFELENBQXdCSSxXQUF4QixFQUFQO0FBQ0gsQ0FITSxDOzs7Ozs7Ozs7OztBQ0FQL2lCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlCQUFaO0FBQXVDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSx1QkFBWjtBQUl2QztBQUNBO0FBRUF5SyxPQUFPLEdBQUcsS0FBVjtBQUNBa1MsU0FBUyxHQUFHLEtBQVo7QUFDQWxELGlCQUFpQixHQUFHLEtBQXBCO0FBQ0E2QixzQkFBc0IsR0FBRyxLQUF6QjtBQUNBblIsR0FBRyxHQUFHckssTUFBTSxDQUFDMkYsUUFBUCxDQUFnQnNkLE1BQWhCLENBQXVCQyxHQUE3QjtBQUNBeGlCLEdBQUcsR0FBR1YsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQnNkLE1BQWhCLENBQXVCRSxHQUE3QjtBQUVBQyxXQUFXLEdBQUcsQ0FBZDtBQUNBQyxpQkFBaUIsR0FBRyxDQUFwQjtBQUNBQyxVQUFVLEdBQUcsQ0FBYjtBQUNBQyxjQUFjLEdBQUcsQ0FBakI7QUFDQUMsYUFBYSxHQUFHLENBQWhCO0FBQ0FDLHFCQUFxQixHQUFHLENBQXhCO0FBQ0FDLGdCQUFnQixHQUFHLENBQW5CO0FBQ0FDLGVBQWUsR0FBRyxDQUFsQjtBQUNBQyxjQUFjLEdBQUcsQ0FBakI7QUFFQSxNQUFNQyxlQUFlLEdBQUcsd0JBQXhCOztBQUVBQyxpQkFBaUIsR0FBRyxNQUFNO0FBQ3RCOWpCLFFBQU0sQ0FBQytGLElBQVAsQ0FBWSxvQkFBWixFQUFrQyxDQUFDZ2UsS0FBRCxFQUFReGlCLE1BQVIsS0FBbUI7QUFDakQsUUFBSXdpQixLQUFKLEVBQVU7QUFDTmxqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxrQkFBWixFQUFnQ2lqQixLQUFoQztBQUNILEtBRkQsTUFHSTtBQUNBbGpCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGtCQUFaLEVBQWdDUyxNQUFoQztBQUNIO0FBQ0osR0FQRDtBQVFILENBVEQ7O0FBV0F5aUIsV0FBVyxHQUFHLE1BQU07QUFDaEJoa0IsUUFBTSxDQUFDK0YsSUFBUCxDQUFZLHFCQUFaLEVBQW1DLENBQUNnZSxLQUFELEVBQVF4aUIsTUFBUixLQUFtQjtBQUNsRCxRQUFJd2lCLEtBQUosRUFBVTtBQUNObGpCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGtCQUFaLEVBQWdDaWpCLEtBQWhDO0FBQ0gsS0FGRCxNQUdJO0FBQ0FsakIsYUFBTyxDQUFDQyxHQUFSLENBQVksa0JBQVosRUFBZ0NTLE1BQWhDO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FURDs7QUFXQTBpQixrQkFBa0IsR0FBRyxNQUFNO0FBQ3ZCamtCLFFBQU0sQ0FBQytGLElBQVAsQ0FBWSxpQ0FBWixFQUErQyxDQUFDZ2UsS0FBRCxFQUFReGlCLE1BQVIsS0FBbUI7QUFDOUQsUUFBSXdpQixLQUFKLEVBQVU7QUFDTmxqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBWixFQUFxQ2lqQixLQUFyQztBQUNILEtBRkQsTUFHSTtBQUNBbGpCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUFaLEVBQXFDUyxNQUFyQztBQUNIO0FBQ0osR0FQRDtBQVFILENBVEQ7O0FBV0EyaUIsaUJBQWlCLEdBQUcsTUFBTTtBQUN0QmxrQixRQUFNLENBQUMrRixJQUFQLENBQVkseUJBQVosRUFBdUMsQ0FBQ2dlLEtBQUQsRUFBUXhpQixNQUFSLEtBQW1CO0FBQ3RELFFBQUl3aUIsS0FBSixFQUFVO0FBQ05sakIsYUFBTyxDQUFDQyxHQUFSLENBQVksbUJBQVosRUFBaUNpakIsS0FBakM7QUFDSDtBQUNKLEdBSkQ7QUFLSCxDQU5EOztBQVFBSSxZQUFZLEdBQUcsTUFBTTtBQUNqQm5rQixRQUFNLENBQUMrRixJQUFQLENBQVksd0JBQVosRUFBc0MsQ0FBQ2dlLEtBQUQsRUFBUXhpQixNQUFSLEtBQW1CO0FBQ3JELFFBQUl3aUIsS0FBSixFQUFVO0FBQ05sakIsYUFBTyxDQUFDQyxHQUFSLENBQVksa0JBQVosRUFBZ0NpakIsS0FBaEM7QUFDSDs7QUFDRCxRQUFJeGlCLE1BQUosRUFBVztBQUNQVixhQUFPLENBQUNDLEdBQVIsQ0FBWSxrQkFBWixFQUFnQ1MsTUFBaEM7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQVREOztBQVdBNmlCLG1CQUFtQixHQUFHLE1BQU07QUFDeEJwa0IsUUFBTSxDQUFDK0YsSUFBUCxDQUFZLDhCQUFaLEVBQTRDLENBQUNnZSxLQUFELEVBQVF4aUIsTUFBUixLQUFtQjtBQUMzRCxRQUFJd2lCLEtBQUosRUFBVTtBQUNObGpCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDBCQUFaLEVBQXdDaWpCLEtBQXhDO0FBQ0g7O0FBQ0QsUUFBSXhpQixNQUFKLEVBQVc7QUFDUFYsYUFBTyxDQUFDQyxHQUFSLENBQVksMEJBQVosRUFBd0NTLE1BQXhDO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FURDs7QUFXQThpQixrQkFBa0IsR0FBRyxNQUFNO0FBQ3ZCcmtCLFFBQU0sQ0FBQytGLElBQVAsQ0FBWSx3Q0FBWixFQUFzRCxDQUFDZ2UsS0FBRCxFQUFReGlCLE1BQVIsS0FBa0I7QUFDcEUsUUFBSXdpQixLQUFKLEVBQVU7QUFDTmxqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWixFQUF1Q2lqQixLQUF2QztBQUNIOztBQUNELFFBQUl4aUIsTUFBSixFQUFXO0FBQ1BWLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFaLEVBQW9DUyxNQUFwQztBQUNIO0FBQ0osR0FQRDtBQVFILENBVEQ7O0FBV0EraUIsY0FBYyxHQUFHLE1BQU07QUFDbkJ0a0IsUUFBTSxDQUFDK0YsSUFBUCxDQUFZLDRCQUFaLEVBQTBDLENBQUNnZSxLQUFELEVBQVF4aUIsTUFBUixLQUFtQjtBQUN6RCxRQUFJd2lCLEtBQUosRUFBVTtBQUNObGpCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDJCQUFaLEVBQXlDaWpCLEtBQXpDO0FBQ0gsS0FGRCxNQUdJO0FBQ0FsakIsYUFBTyxDQUFDQyxHQUFSLENBQVksd0JBQVosRUFBc0NTLE1BQXRDO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FURDs7QUFXQWdqQixpQkFBaUIsR0FBRyxNQUFLO0FBQ3JCO0FBQ0F2a0IsUUFBTSxDQUFDK0YsSUFBUCxDQUFZLDRDQUFaLEVBQTBELEdBQTFELEVBQStELENBQUNnZSxLQUFELEVBQVF4aUIsTUFBUixLQUFtQjtBQUM5RSxRQUFJd2lCLEtBQUosRUFBVTtBQUNObGpCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHlDQUFaLEVBQXVEaWpCLEtBQXZEO0FBQ0gsS0FGRCxNQUdJO0FBQ0FsakIsYUFBTyxDQUFDQyxHQUFSLENBQVksc0NBQVosRUFBb0RTLE1BQXBEO0FBQ0g7QUFDSixHQVBEO0FBU0F2QixRQUFNLENBQUMrRixJQUFQLENBQVksd0JBQVosRUFBc0MsQ0FBQ2dlLEtBQUQsRUFBUXhpQixNQUFSLEtBQW1CO0FBQ3JELFFBQUl3aUIsS0FBSixFQUFVO0FBQ05sakIsYUFBTyxDQUFDQyxHQUFSLENBQVksMEJBQVosRUFBd0NpakIsS0FBeEM7QUFDSCxLQUZELE1BR0k7QUFDQWxqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx1QkFBWixFQUFxQ1MsTUFBckM7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQW5CRDs7QUFxQkFpakIsZUFBZSxHQUFHLE1BQUs7QUFDbkI7QUFDQXhrQixRQUFNLENBQUMrRixJQUFQLENBQVksNENBQVosRUFBMEQsR0FBMUQsRUFBK0QsQ0FBQ2dlLEtBQUQsRUFBUXhpQixNQUFSLEtBQW1CO0FBQzlFLFFBQUl3aUIsS0FBSixFQUFVO0FBQ05sakIsYUFBTyxDQUFDQyxHQUFSLENBQVksdUNBQVosRUFBcURpakIsS0FBckQ7QUFDSCxLQUZELE1BR0k7QUFDQWxqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxvQ0FBWixFQUFrRFMsTUFBbEQ7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQVZEOztBQVlBa2pCLGNBQWMsR0FBRyxNQUFLO0FBQ2xCO0FBQ0F6a0IsUUFBTSxDQUFDK0YsSUFBUCxDQUFZLDRDQUFaLEVBQTBELEdBQTFELEVBQStELENBQUNnZSxLQUFELEVBQVF4aUIsTUFBUixLQUFtQjtBQUM5RSxRQUFJd2lCLEtBQUosRUFBVTtBQUNObGpCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHNDQUFaLEVBQW9EaWpCLEtBQXBEO0FBQ0gsS0FGRCxNQUdJO0FBQ0FsakIsYUFBTyxDQUFDQyxHQUFSLENBQVksbUNBQVosRUFBaURTLE1BQWpEO0FBQ0g7QUFDSixHQVBEO0FBU0F2QixRQUFNLENBQUMrRixJQUFQLENBQVksNENBQVosRUFBMEQsQ0FBQ2dlLEtBQUQsRUFBUXhpQixNQUFSLEtBQW1CO0FBQ3pFLFFBQUl3aUIsS0FBSixFQUFVO0FBQ05sakIsYUFBTyxDQUFDQyxHQUFSLENBQVksMkNBQVosRUFBeURpakIsS0FBekQ7QUFDSCxLQUZELE1BR0s7QUFDRGxqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBWixFQUFzRFMsTUFBdEQ7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQW5CRDs7QUF1QkF2QixNQUFNLENBQUMwa0IsT0FBUCxDQUFlO0FBQUEsa0NBQWdCO0FBQzNCLFFBQUkxa0IsTUFBTSxDQUFDMmtCLGFBQVgsRUFBeUI7QUF4SzdCLFVBQUlDLG1CQUFKO0FBQXdCM2tCLFlBQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUN5UixlQUFPLENBQUN4UixDQUFELEVBQUc7QUFBQ3lrQiw2QkFBbUIsR0FBQ3prQixDQUFwQjtBQUFzQjs7QUFBbEMsT0FBdkMsRUFBMkUsQ0FBM0U7QUF5S2hCMGtCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZQyw0QkFBWixHQUEyQyxDQUEzQztBQUVBL1osWUFBTSxDQUFDQyxJQUFQLENBQVkyWixtQkFBWixFQUFpQ3BoQixPQUFqQyxDQUEwQzBELEdBQUQsSUFBUztBQUM5QyxZQUFJbEgsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQnVCLEdBQWhCLEtBQXdCNFEsU0FBNUIsRUFBdUM7QUFDbkNqWCxpQkFBTyxDQUFDbWtCLElBQVIsZ0NBQXFDOWQsR0FBckM7QUFDQWxILGdCQUFNLENBQUMyRixRQUFQLENBQWdCdUIsR0FBaEIsSUFBdUIsRUFBdkI7QUFDSDs7QUFDRDhELGNBQU0sQ0FBQ0MsSUFBUCxDQUFZMlosbUJBQW1CLENBQUMxZCxHQUFELENBQS9CLEVBQXNDMUQsT0FBdEMsQ0FBK0N5aEIsS0FBRCxJQUFXO0FBQ3JELGNBQUlqbEIsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQnVCLEdBQWhCLEVBQXFCK2QsS0FBckIsS0FBK0JuTixTQUFuQyxFQUE2QztBQUN6Q2pYLG1CQUFPLENBQUNta0IsSUFBUixnQ0FBcUM5ZCxHQUFyQyxjQUE0QytkLEtBQTVDO0FBQ0FqbEIsa0JBQU0sQ0FBQzJGLFFBQVAsQ0FBZ0J1QixHQUFoQixFQUFxQitkLEtBQXJCLElBQThCTCxtQkFBbUIsQ0FBQzFkLEdBQUQsQ0FBbkIsQ0FBeUIrZCxLQUF6QixDQUE5QjtBQUNIO0FBQ0osU0FMRDtBQU1ILE9BWEQ7QUFZSDs7QUFFRCxRQUFJamxCLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0J1ZixLQUFoQixDQUFzQkMsVUFBMUIsRUFBcUM7QUFDakM1QixvQkFBYyxHQUFHdmpCLE1BQU0sQ0FBQ29sQixXQUFQLENBQW1CLFlBQVU7QUFDMUNsQix5QkFBaUI7QUFDcEIsT0FGZ0IsRUFFZGxrQixNQUFNLENBQUMyRixRQUFQLENBQWdCa0MsTUFBaEIsQ0FBdUJ3ZCxpQkFGVCxDQUFqQjtBQUlBakMsaUJBQVcsR0FBR3BqQixNQUFNLENBQUNvbEIsV0FBUCxDQUFtQixZQUFVO0FBQ3ZDcEIsbUJBQVc7QUFDZCxPQUZhLEVBRVhoa0IsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQmtDLE1BQWhCLENBQXVCeWQsYUFGWixDQUFkO0FBSUFqQyx1QkFBaUIsR0FBR3JqQixNQUFNLENBQUNvbEIsV0FBUCxDQUFtQixZQUFVO0FBQzdDbkIsMEJBQWtCO0FBQ3JCLE9BRm1CLEVBRWpCamtCLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JrQyxNQUFoQixDQUF1QjBkLG9CQUZOLENBQXBCO0FBSUFqQyxnQkFBVSxHQUFHdGpCLE1BQU0sQ0FBQ29sQixXQUFQLENBQW1CLFlBQVU7QUFDdEN0Qix5QkFBaUI7QUFDcEIsT0FGWSxFQUVWOWpCLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JrQyxNQUFoQixDQUF1QjJkLGNBRmIsQ0FBYjs7QUFJQSxVQUFJeGxCLE1BQU0sQ0FBQzJGLFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCZ08sT0FBdkIsQ0FBK0JhLEdBQW5DLEVBQXdDO0FBQ3BDK08scUJBQWEsR0FBR3hqQixNQUFNLENBQUNvbEIsV0FBUCxDQUFtQixZQUFZO0FBQzNDakIsc0JBQVk7QUFDZixTQUZlLEVBRWJua0IsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQmtDLE1BQWhCLENBQXVCNGQsZ0JBRlYsQ0FBaEI7QUFJQWhDLDZCQUFxQixHQUFHempCLE1BQU0sQ0FBQ29sQixXQUFQLENBQW1CLFlBQVk7QUFDbkRoQiw2QkFBbUI7QUFDdEIsU0FGdUIsRUFFckJwa0IsTUFBTSxDQUFDMkYsUUFBUCxDQUFnQmtDLE1BQWhCLENBQXVCNGQsZ0JBRkYsQ0FBeEI7QUFHSDs7QUFFRC9CLHNCQUFnQixHQUFHMWpCLE1BQU0sQ0FBQ29sQixXQUFQLENBQW1CLFlBQVU7QUFDNUNmLDBCQUFrQjtBQUNyQixPQUZrQixFQUVoQnJrQixNQUFNLENBQUMyRixRQUFQLENBQWdCa0MsTUFBaEIsQ0FBdUI2ZCxvQkFGUCxDQUFuQixDQTNCaUMsQ0ErQmpDO0FBQ0E7QUFDQTs7QUFFQTlCLG9CQUFjLEdBQUc1akIsTUFBTSxDQUFDb2xCLFdBQVAsQ0FBbUIsWUFBVTtBQUMxQyxZQUFJaFYsR0FBRyxHQUFHLElBQUl4TSxJQUFKLEVBQVY7O0FBQ0EsWUFBS3dNLEdBQUcsQ0FBQ3VWLGFBQUosTUFBdUIsQ0FBNUIsRUFBK0I7QUFDM0JwQiwyQkFBaUI7QUFDcEI7O0FBRUQsWUFBS25VLEdBQUcsQ0FBQ3dWLGFBQUosTUFBdUIsQ0FBeEIsSUFBK0J4VixHQUFHLENBQUN1VixhQUFKLE1BQXVCLENBQTFELEVBQTZEO0FBQ3pEbkIseUJBQWU7QUFDbEI7O0FBRUQsWUFBS3BVLEdBQUcsQ0FBQ3lWLFdBQUosTUFBcUIsQ0FBdEIsSUFBNkJ6VixHQUFHLENBQUN3VixhQUFKLE1BQXVCLENBQXBELElBQTJEeFYsR0FBRyxDQUFDdVYsYUFBSixNQUF1QixDQUF0RixFQUF5RjtBQUNyRmxCLHdCQUFjO0FBQ2pCO0FBQ0osT0FiZ0IsRUFhZCxJQWJjLENBQWpCO0FBY0g7QUFDSixHQXBFYztBQUFBLENBQWYsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuY29uc3QgZmV0Y2hGcm9tVXJsID0gKHVybCkgPT4ge1xuICAgIHRyeXtcbiAgICAgICAgbGV0IHJlcyA9IEhUVFAuZ2V0KEFQSSArIHVybCk7XG4gICAgICAgIGlmIChyZXMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgcmV0dXJuIHJlc1xuICAgICAgICB9O1xuICAgIH1cbiAgICBjYXRjaCAoZSl7XG4gICAgICAgIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgIH1cbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdhY2NvdW50cy5nZXRBY2NvdW50RGV0YWlsJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gQVBJICsgJy9hdXRoL2FjY291bnRzLycrIGFkZHJlc3M7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBhdmFpbGFibGUgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGF2YWlsYWJsZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgLy8gcmV0dXJuIEpTT04ucGFyc2UoYXZhaWxhYmxlLmNvbnRlbnQpLmFjY291bnRcbiAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBKU09OLnBhcnNlKGF2YWlsYWJsZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgbGV0IGFjY291bnQ7XG4gICAgICAgICAgICAgICAgaWYgKChyZXNwb25zZS50eXBlID09PSAnY29zbW9zLXNkay9BY2NvdW50JykgfHwgKHJlc3BvbnNlLnR5cGUgPT09ICdjb3Ntb3Mtc2RrL0Jhc2VBY2NvdW50JykpXG4gICAgICAgICAgICAgICAgICAgIGFjY291bnQgPSByZXNwb25zZS52YWx1ZTtcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChyZXNwb25zZS50eXBlID09PSAnY29zbW9zLXNkay9EZWxheWVkVmVzdGluZ0FjY291bnQnIHx8IHJlc3BvbnNlLnR5cGUgPT09ICdjb3Ntb3Mtc2RrL0NvbnRpbnVvdXNWZXN0aW5nQWNjb3VudCcpXG4gICAgICAgICAgICAgICAgICAgIGFjY291bnQgPSByZXNwb25zZS52YWx1ZS5CYXNlVmVzdGluZ0FjY291bnQuQmFzZUFjY291bnRcblxuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgdXJsID0gQVBJICsgJy9iYW5rL2JhbGFuY2VzLycgKyBhZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBiYWxhbmNlcyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICBhY2NvdW50LmNvaW5zID0gYmFsYW5jZXM7XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGFjY291bnQgJiYgYWNjb3VudC5hY2NvdW50X251bWJlciAhPSBudWxsKVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFjY291bnRcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGxcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgIH1cbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXRCYWxhbmNlJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgYmFsYW5jZSA9IHt9XG5cbiAgICAgICAgLy8gZ2V0IGF2YWlsYWJsZSBhdG9tc1xuICAgICAgICBsZXQgdXJsID0gQVBJICsgJy9jb3Ntb3MvYmFuay92MWJldGExL2JhbGFuY2VzLycrIGFkZHJlc3M7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBhdmFpbGFibGUgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGF2YWlsYWJsZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgYmFsYW5jZS5hdmFpbGFibGUgPSBKU09OLnBhcnNlKGF2YWlsYWJsZS5jb250ZW50KS5iYWxhbmNlcztcblxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gZ2V0IGRlbGVnYXRlZCBhbW5vdW50c1xuICAgICAgICB1cmwgPSBBUEkgKyAnL2Nvc21vcy9zdGFraW5nL3YxYmV0YTEvZGVsZWdhdGlvbnMvJythZGRyZXNzO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBiYWxhbmNlLmRlbGVnYXRpb25zID0gSlNPTi5wYXJzZShkZWxlZ2F0aW9ucy5jb250ZW50KS5kZWxlZ2F0aW9uX3Jlc3BvbnNlcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gZ2V0IHVuYm9uZGluZ1xuICAgICAgICB1cmwgPSBBUEkgKyAnL2Nvc21vcy9zdGFraW5nL3YxYmV0YTEvZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy91bmJvbmRpbmdfZGVsZWdhdGlvbnMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgdW5ib25kaW5nID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmICh1bmJvbmRpbmcuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGJhbGFuY2UudW5ib25kaW5nID0gSlNPTi5wYXJzZSh1bmJvbmRpbmcuY29udGVudCkudW5ib25kaW5nX3Jlc3BvbnNlcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBnZXQgcmV3YXJkc1xuICAgICAgICB1cmwgPSBBUEkgKyAnL2Nvc21vcy9kaXN0cmlidXRpb24vdjFiZXRhMS9kZWxlZ2F0b3JzLycrYWRkcmVzcysnL3Jld2FyZHMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgcmV3YXJkcyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAocmV3YXJkcy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgLy9nZXQgc2VwZXJhdGUgcmV3YXJkcyB2YWx1ZVxuICAgICAgICAgICAgICAgIGJhbGFuY2UucmV3YXJkcyA9IEpTT04ucGFyc2UocmV3YXJkcy5jb250ZW50KS5yZXdhcmRzO1xuICAgICAgICAgICAgICAgIC8vZ2V0IHRvdGFsIHJld2FyZHMgdmFsdWVcbiAgICAgICAgICAgICAgICBiYWxhbmNlLnRvdGFsX3Jld2FyZHM9IEpTT04ucGFyc2UocmV3YXJkcy5jb250ZW50KS50b3RhbDtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBnZXQgY29tbWlzc2lvblxuICAgICAgICBsZXQgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKFxuICAgICAgICAgICAgeyRvcjogW3tvcGVyYXRvcl9hZGRyZXNzOmFkZHJlc3N9LCB7ZGVsZWdhdG9yX2FkZHJlc3M6YWRkcmVzc30sIHthZGRyZXNzOmFkZHJlc3N9XX0pXG4gICAgICAgIGlmICh2YWxpZGF0b3IpIHtcbiAgICAgICAgICAgIGxldCB1cmwgPSBBUEkgKyAnL2Nvc21vcy9kaXN0cmlidXRpb24vdjFiZXRhMS92YWxpZGF0b3JzLycrdmFsaWRhdG9yLm9wZXJhdG9yX2FkZHJlc3MrJy9jb21taXNzaW9uJztcbiAgICAgICAgICAgIGJhbGFuY2Uub3BlcmF0b3JBZGRyZXNzID0gdmFsaWRhdG9yLm9wZXJhdG9yX2FkZHJlc3M7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGxldCByZXdhcmRzID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBpZiAocmV3YXJkcy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBjb250ZW50ID0gSlNPTi5wYXJzZShyZXdhcmRzLmNvbnRlbnQpLmNvbW1pc3Npb247XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb250ZW50LmNvbW1pc3Npb24gJiYgY29udGVudC5jb21taXNzaW9uLmxlbmd0aCA+IDApXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWxhbmNlLmNvbW1pc3Npb24gPSBjb250ZW50LmNvbW1pc3Npb247XG5cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gYmFsYW5jZTtcbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXREZWxlZ2F0aW9uJyhhZGRyZXNzLCB2YWxpZGF0b3Ipe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHVybCA9IGAvY29zbW9zL3N0YWtpbmcvdjFiZXRhMS92YWxpZGF0b3JzLyR7dmFsaWRhdG9yfS9kZWxlZ2F0aW9ucy8ke2FkZHJlc3N9YDtcbiAgICAgICAgbGV0IGRlbGVnYXRpb25zID0gZmV0Y2hGcm9tVXJsKHVybCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGRlbGVnYXRpb25zKTtcbiAgICAgICAgZGVsZWdhdGlvbnMgPSBkZWxlZ2F0aW9ucyAmJiBkZWxlZ2F0aW9ucy5kYXRhLmRlbGVnYXRpb25fcmVzcG9uc2U7XG4gICAgICAgIGlmIChkZWxlZ2F0aW9ucyAmJiBkZWxlZ2F0aW9ucy5kZWxlZ2F0aW9uLnNoYXJlcylcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLmRlbGVnYXRpb24uc2hhcmVzID0gcGFyc2VGbG9hdChkZWxlZ2F0aW9ucy5kZWxlZ2F0aW9uLnNoYXJlcyk7XG5cbiAgICAgICAgdXJsID0gYC9jb3Ntb3Mvc3Rha2luZy92MWJldGExL2RlbGVnYXRvcnMvJHthZGRyZXNzfS9yZWRlbGVnYXRpb25zP2RzdF92YWxpZGF0b3JfYWRkcj0ke3ZhbGlkYXRvcn1gO1xuICAgICAgICBsZXQgcmVsZWdhdGlvbnMgPSBmZXRjaEZyb21VcmwodXJsKTtcbiAgICAgICAgcmVsZWdhdGlvbnMgPSByZWxlZ2F0aW9ucyAmJiByZWxlZ2F0aW9ucy5kYXRhLnJlZGVsZWdhdGlvbl9yZXNwb25zZXM7XG4gICAgICAgIGxldCBjb21wbGV0aW9uVGltZTtcbiAgICAgICAgaWYgKHJlbGVnYXRpb25zKSB7XG4gICAgICAgICAgICByZWxlZ2F0aW9ucy5mb3JFYWNoKChyZWxlZ2F0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgbGV0IGVudHJpZXMgPSByZWxlZ2F0aW9uLmVudHJpZXNcbiAgICAgICAgICAgICAgICBsZXQgdGltZSA9IG5ldyBEYXRlKGVudHJpZXNbZW50cmllcy5sZW5ndGgtMV0uY29tcGxldGlvbl90aW1lKVxuICAgICAgICAgICAgICAgIGlmICghY29tcGxldGlvblRpbWUgfHwgdGltZSA+IGNvbXBsZXRpb25UaW1lKVxuICAgICAgICAgICAgICAgICAgICBjb21wbGV0aW9uVGltZSA9IHRpbWVcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICBkZWxlZ2F0aW9ucy5yZWRlbGVnYXRpb25Db21wbGV0aW9uVGltZSA9IGNvbXBsZXRpb25UaW1lO1xuICAgICAgICB9XG5cbiAgICAgICAgdXJsID0gYC9jb3Ntb3Mvc3Rha2luZy92MWJldGExL3ZhbGlkYXRvcnMvJHt2YWxpZGF0b3J9L2RlbGVnYXRpb25zLyR7YWRkcmVzc30vdW5ib25kaW5nX2RlbGVnYXRpb25gO1xuICAgICAgICBsZXQgdW5kZWxlZ2F0aW9ucyA9IGZldGNoRnJvbVVybCh1cmwpO1xuICAgICAgICB1bmRlbGVnYXRpb25zID0gdW5kZWxlZ2F0aW9ucyAmJiB1bmRlbGVnYXRpb25zLmRhdGEucmVzdWx0O1xuICAgICAgICBpZiAodW5kZWxlZ2F0aW9ucykge1xuICAgICAgICAgICAgZGVsZWdhdGlvbnMudW5ib25kaW5nID0gdW5kZWxlZ2F0aW9ucy5lbnRyaWVzLmxlbmd0aDtcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLnVuYm9uZGluZ0NvbXBsZXRpb25UaW1lID0gdW5kZWxlZ2F0aW9ucy5lbnRyaWVzWzBdLmNvbXBsZXRpb25fdGltZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZGVsZWdhdGlvbnM7XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QWxsRGVsZWdhdGlvbnMnKGFkZHJlc3Mpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHVybCA9IEFQSSArICcvY29zbW9zL3N0YWtpbmcvdjFiZXRhMS9kZWxlZ2F0b3JzLycrYWRkcmVzcysnL2RlbGVnYXRpb25zJztcblxuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucyA9IEpTT04ucGFyc2UoZGVsZWdhdGlvbnMuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9ucyAmJiBkZWxlZ2F0aW9ucy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMuZm9yRWFjaCgoZGVsZWdhdGlvbiwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zW2ldICYmIGRlbGVnYXRpb25zW2ldLnNoYXJlcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMgPSBwYXJzZUZsb2F0KGRlbGVnYXRpb25zW2ldLnNoYXJlcyk7XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGRlbGVnYXRpb25zO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXRBbGxVbmJvbmRpbmdzJyhhZGRyZXNzKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB1cmwgPSBBUEkgKyAnL2Nvc21vcy9zdGFraW5nL3YxYmV0YTEvZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy91bmJvbmRpbmdfZGVsZWdhdGlvbnMnO1xuXG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCB1bmJvbmRpbmdzID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmICh1bmJvbmRpbmdzLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICB1bmJvbmRpbmdzID0gSlNPTi5wYXJzZSh1bmJvbmRpbmdzLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICByZXR1cm4gdW5ib25kaW5ncztcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QWxsUmVkZWxlZ2F0aW9ucycoYWRkcmVzcywgdmFsaWRhdG9yKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7ICAgICAgICBcbiAgICAgICAgbGV0IHVybCA9IGAvY29zbW9zL3N0YWtpbmcvdjFiZXRhMS92MWJldGExL2RlbGVnYXRvcnMvJHthZGRyZXNzfS9yZWRlbGVnYXRpb25zJnNyY192YWxpZGF0b3JfYWRkcj0ke3ZhbGlkYXRvcn1gO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgcmVzdWx0ID0gZmV0Y2hGcm9tVXJsKHVybCk7XG4gICAgICAgICAgICBpZiAocmVzdWx0ICYmIHJlc3VsdC5kYXRhKSB7XG4gICAgICAgICAgICAgICAgbGV0IHJlZGVsZWdhdGlvbnMgPSB7fVxuICAgICAgICAgICAgICAgIHJlc3VsdC5kYXRhLmZvckVhY2goKHJlZGVsZWdhdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgZW50cmllcyA9IHJlZGVsZWdhdGlvbi5lbnRyaWVzO1xuICAgICAgICAgICAgICAgICAgICByZWRlbGVnYXRpb25zW3JlZGVsZWdhdGlvbi52YWxpZGF0b3JfZHN0X2FkZHJlc3NdID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQ6IGVudHJpZXMubGVuZ3RoLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29tcGxldGlvblRpbWU6IGVudHJpZXNbMF0uY29tcGxldGlvbl90aW1lXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIHJldHVybiByZWRlbGVnYXRpb25zXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXRSZWRlbGVnYXRpb25zJyhhZGRyZXNzKSB7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gQVBJICsgJy9jb3Ntb3Mvc3Rha2luZy92MWJldGExL3YxYmV0YTEvZGVsZWdhdG9ycy8nICsgYWRkcmVzcyArJy9yZWRlbGVnYXRpb25zJztcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgbGV0IHVzZXJSZWRlbGVnYXRpb25zID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmICh1c2VyUmVkZWxlZ2F0aW9ucy5zdGF0dXNDb2RlID09IDIwMCkge1xuICAgICAgICAgICAgICAgIHVzZXJSZWRlbGVnYXRpb25zID0gSlNPTi5wYXJzZSh1c2VyUmVkZWxlZ2F0aW9ucy5jb250ZW50KS5yZXN1bHQ7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gdXNlclJlZGVsZWdhdGlvbnM7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coZS5yZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgfVxuICAgIH0sXG59KSBcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy9pbXBvcnRzL2FwaS9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IENoYWluIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2NoYWluL2NoYWluLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclNldHMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdmFsaWRhdG9yLXNldHMvdmFsaWRhdG9yLXNldHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcywgQW5hbHl0aWNzLCBWUERpc3RyaWJ1dGlvbnN9IGZyb20gJy9pbXBvcnRzL2FwaS9yZWNvcmRzL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnL2ltcG9ydHMvYXBpL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgRXZpZGVuY2VzIH0gZnJvbSAnLi4vLi4vZXZpZGVuY2VzL2V2aWRlbmNlcy5qcyc7XG5pbXBvcnQgeyBzaGEyNTYgfSBmcm9tICdqcy1zaGEyNTYnO1xuLy8gaW1wb3J0IHsgZ2V0QWRkcmVzcyB9IGZyb20gJ3RlbmRlcm1pbnQvbGliL3B1YmtleSc7XG5pbXBvcnQgKiBhcyBjaGVlcmlvIGZyb20gJ2NoZWVyaW8nO1xuXG5cbmdldFJlbW92ZWRWYWxpZGF0b3JzID0gKHByZXZWYWxpZGF0b3JzLCB2YWxpZGF0b3JzKSA9PiB7XG4gICAgLy8gbGV0IHJlbW92ZVZhbGlkYXRvcnMgPSBbXTtcbiAgICBmb3IgKHAgaW4gcHJldlZhbGlkYXRvcnMpe1xuICAgICAgICBmb3IgKHYgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICBpZiAocHJldlZhbGlkYXRvcnNbcF0uYWRkcmVzcyA9PSB2YWxpZGF0b3JzW3ZdLmFkZHJlc3Mpe1xuICAgICAgICAgICAgICAgIHByZXZWYWxpZGF0b3JzLnNwbGljZShwLDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHByZXZWYWxpZGF0b3JzO1xufVxuXG5nZXRWYWxpZGF0b3JGcm9tQ29uc2Vuc3VzS2V5ID0gKHZhbGlkYXRvcnMsIGNvbnNlbnN1c0tleSkgPT4ge1xuICAgIGZvciAodiBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGxldCBwdWJrZXlUeXBlID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5zZWNwMjU2azE/J3RlbmRlcm1pbnQvUHViS2V5U2VjcDI1NmsxJzondGVuZGVybWludC9QdWJLZXlFZDI1NTE5JztcbiAgICAgICAgICAgIGxldCBwdWJrZXkgPSBNZXRlb3IuY2FsbCgnYmVjaDMyVG9QdWJrZXknLCBjb25zZW5zdXNLZXksIHB1YmtleVR5cGUpO1xuICAgICAgICAgICAgaWYgKHZhbGlkYXRvcnNbdl0ucHViX2tleS52YWx1ZSA9PSBwdWJrZXkpe1xuICAgICAgICAgICAgICAgIHJldHVybiB2YWxpZGF0b3JzW3ZdXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJFcnJvciBjb252ZXJ0aW5nIHB1YmtleTogJW9cXG4lb1wiLCBjb25zZW5zdXNLZXksIGUpXG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG5cbmdldFZhbGlkYXRvclByb2ZpbGVVcmwgPSAoaWRlbnRpdHkpID0+IHtcbiAgICBjb25zb2xlLmxvZyhcIkdldCB2YWxpZGF0b3IgYXZhdGFyLlwiKVxuICAgIGlmIChpZGVudGl0eS5sZW5ndGggPT0gMTYpe1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldChgaHR0cHM6Ly9rZXliYXNlLmlvL18vYXBpLzEuMC91c2VyL2xvb2t1cC5qc29uP2tleV9zdWZmaXg9JHtpZGVudGl0eX0mZmllbGRzPXBpY3R1cmVzYClcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XG4gICAgICAgICAgICBsZXQgdGhlbSA9IHJlc3BvbnNlLmRhdGEudGhlbVxuICAgICAgICAgICAgcmV0dXJuIHRoZW0gJiYgdGhlbS5sZW5ndGggJiYgdGhlbVswXS5waWN0dXJlcyAmJiB0aGVtWzBdLnBpY3R1cmVzLnByaW1hcnkgJiYgdGhlbVswXS5waWN0dXJlcy5wcmltYXJ5LnVybDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlKSlcbiAgICAgICAgfVxuICAgIH0gZWxzZSBpZiAoaWRlbnRpdHkuaW5kZXhPZihcImtleWJhc2UuaW8vdGVhbS9cIik+MCl7XG4gICAgICAgIGxldCB0ZWFtUGFnZSA9IEhUVFAuZ2V0KGlkZW50aXR5KTtcbiAgICAgICAgaWYgKHRlYW1QYWdlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgIGxldCBwYWdlID0gY2hlZXJpby5sb2FkKHRlYW1QYWdlLmNvbnRlbnQpO1xuICAgICAgICAgICAgcmV0dXJuIHBhZ2UoXCIua2ItbWFpbi1jYXJkIGltZ1wiKS5hdHRyKCdzcmMnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHRlYW1QYWdlKSlcbiAgICAgICAgfVxuICAgIH1cbn1cblxuZ2V0VmFsaWRhdG9yVXB0aW1lID0gYXN5bmMgKHZhbGlkYXRvclNldCkgPT4ge1xuXG4gICAgLy8gZ2V0IHZhbGlkYXRvciB1cHRpbWVcbiAgXG4gICAgbGV0IHVybCA9IGAke0FQSX0vY29zbW9zL3NsYXNoaW5nL3YxYmV0YTEvcGFyYW1zYDtcbiAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgIGxldCBzbGFzaGluZ1BhcmFtcyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudClcblxuICAgIENoYWluLnVwc2VydCh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7XCJzbGFzaGluZ1wiOnNsYXNoaW5nUGFyYW1zfX0pO1xuXG4gICAgZm9yKGxldCBrZXkgaW4gdmFsaWRhdG9yU2V0KXtcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCJHZXR0aW5nIHVwdGltZSB2YWxpZGF0b3I6ICVvXCIsIHZhbGlkYXRvclNldFtrZXldKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiPT09IFNpZ25pbmcgSW5mbyA9PT06ICVvXCIsIHNpZ25pbmdJbmZvKVxuXG4gICAgICAgICAgICB1cmwgPSBgJHtBUEl9L2Nvc21vcy9zbGFzaGluZy92MWJldGExL3NpZ25pbmdfaW5mb3MvJHt2YWxpZGF0b3JTZXRba2V5XS5iZWNoMzJWYWxDb25zQWRkcmVzc31gXG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IHNpZ25pbmdJbmZvID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS52YWxfc2lnbmluZ19pbmZvO1xuICAgICAgICAgICAgaWYgKHNpZ25pbmdJbmZvKXtcbiAgICAgICAgICAgICAgICBsZXQgdmFsRGF0YSA9IHZhbGlkYXRvclNldFtrZXldXG4gICAgICAgICAgICAgICAgdmFsRGF0YS50b21ic3RvbmVkID0gc2lnbmluZ0luZm8udG9tYnN0b25lZDtcbiAgICAgICAgICAgICAgICB2YWxEYXRhLmphaWxlZF91bnRpbCA9IHNpZ25pbmdJbmZvLmphaWxlZF91bnRpbDtcbiAgICAgICAgICAgICAgICB2YWxEYXRhLmluZGV4X29mZnNldCA9IHBhcnNlSW50KHNpZ25pbmdJbmZvLmluZGV4X29mZnNldCk7XG4gICAgICAgICAgICAgICAgdmFsRGF0YS5zdGFydF9oZWlnaHQgPSBwYXJzZUludChzaWduaW5nSW5mby5zdGFydF9oZWlnaHQpO1xuICAgICAgICAgICAgICAgIHZhbERhdGEudXB0aW1lID0gKHNsYXNoaW5nUGFyYW1zLnBhcmFtcy5zaWduZWRfYmxvY2tzX3dpbmRvdyAtIHBhcnNlSW50KHNpZ25pbmdJbmZvLm1pc3NlZF9ibG9ja3NfY291bnRlcikpL3NsYXNoaW5nUGFyYW1zLnBhcmFtcy5zaWduZWRfYmxvY2tzX3dpbmRvdyAqIDEwMDtcbiAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLnVwc2VydCh7YmVjaDMyVmFsQ29uc0FkZHJlc3M6dmFsaWRhdG9yU2V0W2tleV0uYmVjaDMyVmFsQ29uc0FkZHJlc3N9LCB7JHNldDp2YWxEYXRhfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdldHRpbmcgc2lnbmluZyBpbmZvIG9mICVvOiAlb1wiLCB2YWxpZGF0b3JTZXRba2V5XS5iZWNoMzJWYWxDb25zQWRkcmVzcywgZSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmNhbGN1bGF0ZVZQRGlzdCA9IGFzeW5jIChhbmFseXRpY3NEYXRhLCBibG9ja0RhdGEpID0+IHtcbiAgICBjb25zb2xlLmxvZyhcIj09PT09IGNhbGN1bGF0ZSB2b3RpbmcgcG93ZXIgZGlzdHJpYnV0aW9uID09PT09XCIpO1xuICAgIGxldCBhY3RpdmVWYWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHtzdGF0dXM6J0JPTkRfU1RBVFVTX0JPTkRFRCcsamFpbGVkOmZhbHNlfSx7c29ydDp7dm90aW5nX3Bvd2VyOi0xfX0pLmZldGNoKCk7XG4gICAgbGV0IG51bVRvcFR3ZW50eSA9IE1hdGguY2VpbChhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCowLjIpO1xuICAgIGxldCBudW1Cb3R0b21FaWdodHkgPSBhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCAtIG51bVRvcFR3ZW50eTtcblxuICAgIGxldCB0b3BUd2VudHlQb3dlciA9IDA7XG4gICAgbGV0IGJvdHRvbUVpZ2h0eVBvd2VyID0gMDtcblxuICAgIGxldCBudW1Ub3BUaGlydHlGb3VyID0gMDtcbiAgICBsZXQgbnVtQm90dG9tU2l4dHlTaXggPSAwO1xuICAgIGxldCB0b3BUaGlydHlGb3VyUGVyY2VudCA9IDA7XG4gICAgbGV0IGJvdHRvbVNpeHR5U2l4UGVyY2VudCA9IDA7XG5cblxuXG4gICAgZm9yICh2IGluIGFjdGl2ZVZhbGlkYXRvcnMpe1xuICAgICAgICBpZiAodiA8IG51bVRvcFR3ZW50eSl7XG4gICAgICAgICAgICB0b3BUd2VudHlQb3dlciArPSBhY3RpdmVWYWxpZGF0b3JzW3ZdLnZvdGluZ19wb3dlcjtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgYm90dG9tRWlnaHR5UG93ZXIgKz0gYWN0aXZlVmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXI7XG4gICAgICAgIH1cblxuXG4gICAgICAgIGlmICh0b3BUaGlydHlGb3VyUGVyY2VudCA8IDAuMzQpe1xuICAgICAgICAgICAgdG9wVGhpcnR5Rm91clBlcmNlbnQgKz0gYWN0aXZlVmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXIgLyBhbmFseXRpY3NEYXRhLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgIG51bVRvcFRoaXJ0eUZvdXIrKztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGJvdHRvbVNpeHR5U2l4UGVyY2VudCA9IDEgLSB0b3BUaGlydHlGb3VyUGVyY2VudDtcbiAgICBudW1Cb3R0b21TaXh0eVNpeCA9IGFjdGl2ZVZhbGlkYXRvcnMubGVuZ3RoIC0gbnVtVG9wVGhpcnR5Rm91cjtcblxuICAgIGxldCB2cERpc3QgPSB7XG4gICAgICAgIGhlaWdodDogYmxvY2tEYXRhLmhlaWdodCxcbiAgICAgICAgbnVtVG9wVHdlbnR5OiBudW1Ub3BUd2VudHksXG4gICAgICAgIHRvcFR3ZW50eVBvd2VyOiB0b3BUd2VudHlQb3dlcixcbiAgICAgICAgbnVtQm90dG9tRWlnaHR5OiBudW1Cb3R0b21FaWdodHksXG4gICAgICAgIGJvdHRvbUVpZ2h0eVBvd2VyOiBib3R0b21FaWdodHlQb3dlcixcbiAgICAgICAgbnVtVG9wVGhpcnR5Rm91cjogbnVtVG9wVGhpcnR5Rm91cixcbiAgICAgICAgdG9wVGhpcnR5Rm91clBlcmNlbnQ6IHRvcFRoaXJ0eUZvdXJQZXJjZW50LFxuICAgICAgICBudW1Cb3R0b21TaXh0eVNpeDogbnVtQm90dG9tU2l4dHlTaXgsXG4gICAgICAgIGJvdHRvbVNpeHR5U2l4UGVyY2VudDogYm90dG9tU2l4dHlTaXhQZXJjZW50LFxuICAgICAgICBudW1WYWxpZGF0b3JzOiBhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCxcbiAgICAgICAgdG90YWxWb3RpbmdQb3dlcjogYW5hbHl0aWNzRGF0YS52b3RpbmdfcG93ZXIsXG4gICAgICAgIGJsb2NrVGltZTogYmxvY2tEYXRhLnRpbWUsXG4gICAgICAgIGNyZWF0ZUF0OiBuZXcgRGF0ZSgpXG4gICAgfVxuXG4gICAgY29uc29sZS5sb2codnBEaXN0KTtcblxuICAgIFZQRGlzdHJpYnV0aW9ucy5pbnNlcnQodnBEaXN0KTtcbn1cblxuLy8gdmFyIGZpbHRlcmVkID0gWzEsIDIsIDMsIDQsIDVdLmZpbHRlcihub3RDb250YWluZWRJbihbMSwgMiwgMywgNV0pKTtcbi8vIGNvbnNvbGUubG9nKGZpbHRlcmVkKTsgLy8gWzRdXG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnYmxvY2tzLmF2ZXJhZ2VCbG9ja1RpbWUnKGFkZHJlc3Mpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IGJsb2NrcyA9IEJsb2Nrc2Nvbi5maW5kKHtwcm9wb3NlckFkZHJlc3M6YWRkcmVzc30pLmZldGNoKCk7XG4gICAgICAgIGxldCBoZWlnaHRzID0gYmxvY2tzLm1hcCgoYmxvY2spID0+IHtcbiAgICAgICAgICAgIHJldHVybiBibG9jay5oZWlnaHQ7XG4gICAgICAgIH0pO1xuICAgICAgICBsZXQgYmxvY2tzU3RhdHMgPSBBbmFseXRpY3MuZmluZCh7aGVpZ2h0OnskaW46aGVpZ2h0c319KS5mZXRjaCgpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhibG9ja3NTdGF0cyk7XG5cbiAgICAgICAgbGV0IHRvdGFsQmxvY2tEaWZmID0gMDtcbiAgICAgICAgZm9yIChiIGluIGJsb2Nrc1N0YXRzKXtcbiAgICAgICAgICAgIHRvdGFsQmxvY2tEaWZmICs9IGJsb2Nrc1N0YXRzW2JdLnRpbWVEaWZmO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0b3RhbEJsb2NrRGlmZi9oZWlnaHRzLmxlbmd0aDtcbiAgICB9LFxuICAgICdibG9ja3MuZ2V0TGF0ZXN0SGVpZ2h0JzogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gUlBDKycvc3RhdHVzJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCBzdGF0dXMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgcmV0dXJuIChzdGF0dXMucmVzdWx0LnN5bmNfaW5mby5sYXRlc3RfYmxvY2tfaGVpZ2h0KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0JzogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgY3VyckhlaWdodCA9IEJsb2Nrc2Nvbi5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LGxpbWl0OjF9KS5mZXRjaCgpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhcImN1cnJlbnRIZWlnaHQ6XCIrY3VyckhlaWdodCk7XG4gICAgICAgIGxldCBzdGFydEhlaWdodCA9IE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhcnRIZWlnaHQ7XG4gICAgICAgIGlmIChjdXJySGVpZ2h0ICYmIGN1cnJIZWlnaHQubGVuZ3RoID09IDEpIHtcbiAgICAgICAgICAgIGxldCBoZWlnaHQgPSBjdXJySGVpZ2h0WzBdLmhlaWdodDtcbiAgICAgICAgICAgIGlmIChoZWlnaHQgPiBzdGFydEhlaWdodClcbiAgICAgICAgICAgICAgICByZXR1cm4gaGVpZ2h0XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0YXJ0SGVpZ2h0XG4gICAgfSxcbiAgICAnYmxvY2tzLmJsb2Nrc1VwZGF0ZSc6IGFzeW5jIGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgaWYgKFNZTkNJTkcpXG4gICAgICAgICAgICByZXR1cm4gXCJTeW5jaW5nLi4uXCI7XG4gICAgICAgIGVsc2UgY29uc29sZS5sb2coXCJzdGFydCB0byBzeW5jXCIpO1xuICAgICAgICAvLyBNZXRlb3IuY2xlYXJJbnRlcnZhbChNZXRlb3IudGltZXJIYW5kbGUpO1xuICAgICAgICAvLyBnZXQgdGhlIGxhdGVzdCBoZWlnaHRcbiAgICAgICAgbGV0IHVudGlsID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRMYXRlc3RIZWlnaHQnKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2codW50aWwpO1xuICAgICAgICAvLyBnZXQgdGhlIGN1cnJlbnQgaGVpZ2h0IGluIGRiXG4gICAgICAgIGxldCBjdXJyID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0Jyk7XG4gICAgICAgIGNvbnNvbGUubG9nKGN1cnIpO1xuICAgICAgICAvLyBsb29wIGlmIHRoZXJlJ3MgdXBkYXRlIGluIGRiXG4gICAgICAgIGlmICh1bnRpbCA+IGN1cnIpIHtcbiAgICAgICAgICAgIFNZTkNJTkcgPSB0cnVlO1xuXG4gICAgICAgICAgICBsZXQgdmFsaWRhdG9yU2V0ID0gW107XG4gICAgICAgICAgICAvLyBnZXQgbGF0ZXN0IHZhbGlkYXRvciBjYW5kaWRhdGUgaW5mb3JtYXRpb25cblxuICAgICAgICAgICAgbGV0IHVybCA9IEFQSSArICcvY29zbW9zL3N0YWtpbmcvdjFiZXRhMS92YWxpZGF0b3JzP3N0YXR1cz1CT05EX1NUQVRVU19CT05ERUQmcGFnaW5hdGlvbi5saW1pdD0yMDAmcGFnaW5hdGlvbi5jb3VudF90b3RhbD10cnVlJztcblxuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgbGV0IHJlc3VsdCA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkudmFsaWRhdG9ycztcbiAgICAgICAgICAgICAgICByZXN1bHQuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB2YWxpZGF0b3JTZXRbdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXkua2V5XSA9IHZhbGlkYXRvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgdXJsID0gQVBJICsgJy9jb3Ntb3Mvc3Rha2luZy92MWJldGExL3ZhbGlkYXRvcnM/c3RhdHVzPUJPTkRfU1RBVFVTX1VOQk9ORElORyZwYWdpbmF0aW9uLmxpbWl0PTIwMCZwYWdpbmF0aW9uLmNvdW50X3RvdGFsPXRydWUnO1xuICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgbGV0IHJlc3VsdCA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkudmFsaWRhdG9ycztcbiAgICAgICAgICAgICAgICByZXN1bHQuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB2YWxpZGF0b3JTZXRbdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXkua2V5XSA9IHZhbGlkYXRvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgdXJsID0gQVBJICsgJy9jb3Ntb3Mvc3Rha2luZy92MWJldGExL3ZhbGlkYXRvcnM/c3RhdHVzPUJPTkRfU1RBVFVTX1VOQk9OREVEJnBhZ2luYXRpb24ubGltaXQ9MjAwJnBhZ2luYXRpb24uY291bnRfdG90YWw9dHJ1ZSc7XG4gICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBsZXQgcmVzdWx0ID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS52YWxpZGF0b3JzO1xuICAgICAgICAgICAgICAgIHJlc3VsdC5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHZhbGlkYXRvclNldFt2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleS5rZXldID0gdmFsaWRhdG9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwidmFsaWRhb3RvciBzZXQ6ICVvXCIsIHZhbGlkYXRvclNldCk7XG4gICAgICAgICAgICBsZXQgdG90YWxWYWxpZGF0b3JzID0gT2JqZWN0LmtleXModmFsaWRhdG9yU2V0KS5sZW5ndGg7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFsbCB2YWxpZGF0b3JzOiBcIisgdG90YWxWYWxpZGF0b3JzKTtcbiAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7dG90YWxWYWxpZGF0b3JzOnRvdGFsVmFsaWRhdG9yc319KTtcblxuICAgICAgICAgICAgZm9yIChsZXQgaGVpZ2h0ID0gY3VycisxIDsgaGVpZ2h0IDw9IHVudGlsIDsgaGVpZ2h0KyspIHtcbiAgICAgICAgICAgIC8vIGZvciAobGV0IGhlaWdodCA9IGN1cnIrMSA7IGhlaWdodCA8PSBjdXJyKzEgOyBoZWlnaHQrKykge1xuICAgICAgICAgICAgICAgIGxldCBzdGFydEJsb2NrVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgLy8gYWRkIHRpbWVvdXQgaGVyZT8gYW5kIG91dHNpZGUgdGhpcyBsb29wIChmb3IgY2F0Y2hlZCB1cCBhbmQga2VlcCBmZXRjaGluZyk/XG4gICAgICAgICAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgICAgICAgICAgLy8gbGV0IHVybCA9IFJQQysnL2Jsb2NrP2hlaWdodD0nICsgaGVpZ2h0O1xuXG4gICAgICAgICAgICAgICAgdXJsID0gYCR7QVBJfS9ibG9ja3MvJHtoZWlnaHR9YDtcbiAgICAgICAgICAgICAgICBsZXQgYW5hbHl0aWNzRGF0YSA9IHt9O1xuXG4gICAgICAgICAgICAgICAgY29uc3QgYnVsa1ZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG4gICAgICAgICAgICAgICAgY29uc3QgYnVsa1VwZGF0ZUxhc3RTZWVuID0gVmFsaWRhdG9ycy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtWYWxpZGF0b3JSZWNvcmRzID0gVmFsaWRhdG9yUmVjb3Jkcy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtWUEhpc3RvcnkgPSBWb3RpbmdQb3dlckhpc3RvcnkucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgICAgICBjb25zdCBidWxrVHJhbnNhY3Rpb25zID0gVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG5cbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdldHRpbmcgYmxvY2sgYXQgaGVpZ2h0OiAlb1wiLCBoZWlnaHQpO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0R2V0SGVpZ2h0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIHN0b3JlIGhlaWdodCwgaGFzaCwgbnVtdHJhbnNhY3Rpb24gYW5kIHRpbWUgaW4gZGJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGJsb2NrRGF0YSA9IHt9O1xuICAgICAgICAgICAgICAgICAgICBsZXQgYmxvY2sgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEuaGFzaCA9IGJsb2NrLmJsb2NrX2lkLmhhc2g7XG4gICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS50cmFuc051bSA9IGJsb2NrLmJsb2NrLmRhdGEudHhzP2Jsb2NrLmJsb2NrLmRhdGEudHhzLmxlbmd0aDowO1xuICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudGltZSA9IGJsb2NrLmJsb2NrLmhlYWRlci50aW1lO1xuICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEubGFzdEJsb2NrSGFzaCA9IGJsb2NrLmJsb2NrLmhlYWRlci5sYXN0X2Jsb2NrX2lkLmhhc2g7XG4gICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5wcm9wb3NlckFkZHJlc3MgPSBibG9jay5ibG9jay5oZWFkZXIucHJvcG9zZXJfYWRkcmVzcztcbiAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnZhbGlkYXRvcnMgPSBbXTtcblxuXG4gICAgICAgICAgICAgICAgICAgIC8vIHNhdmUgdHhzIGluIGRhdGFiYXNlXG4gICAgICAgICAgICAgICAgICAgIGlmIChibG9jay5ibG9jay5kYXRhLnR4cyAmJiBibG9jay5ibG9jay5kYXRhLnR4cy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodCBpbiBibG9jay5ibG9jay5kYXRhLnR4cyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1RyYW5zYWN0aW9ucy5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBoYXNoIGhhcyB0byBiZSBpbiB1cHBlcmNhc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHhoYXNoOiBzaGEyNTYoQnVmZmVyLmZyb20oYmxvY2suYmxvY2suZGF0YS50eHNbdF0sICdiYXNlNjQnKSkudG9VcHBlckNhc2UoKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBwYXJzZUludChoZWlnaHQpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9jZXNzZWQ6IGZhbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJ1bGtUcmFuc2FjdGlvbnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1RyYW5zYWN0aW9ucy5leGVjdXRlKChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvLyBzYXZlIGRvdWJsZSBzaWduIGV2aWRlbmNlc1xuICAgICAgICAgICAgICAgICAgICBpZiAoYmxvY2suYmxvY2suZXZpZGVuY2UuZXZpZGVuY2VMaXN0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgIEV2aWRlbmNlcy5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2aWRlbmNlOiBibG9jay5ibG9jay5ldmlkZW5jZS5ldmlkZW5jZUxpc3RcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJzaWduYXR1cmVzOiAlb1wiLCBibG9jay5ibG9jay5sYXN0Q29tbWl0LnNpZ25hdHVyZXNMaXN0KVxuXG4gICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5wcmVjb21taXRzQ291bnQgPSBibG9jay5ibG9jay5sYXN0X2NvbW1pdC5zaWduYXR1cmVzLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLmhlaWdodCA9IGhlaWdodDtcblxuICAgICAgICAgICAgICAgICAgICBsZXQgZW5kR2V0SGVpZ2h0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0IGhlaWdodCB0aW1lOiBcIisoKGVuZEdldEhlaWdodFRpbWUtc3RhcnRHZXRIZWlnaHRUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG5cbiAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0R2V0VmFsaWRhdG9yc1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAvLyB1cGRhdGUgY2hhaW4gc3RhdHVzXG5cbiAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBbXVxuICAgICAgICAgICAgICAgICAgICBsZXQgcGFnZSA9IDA7XG4gICAgICAgICAgICAgICAgICAgIC8vIGxldCBuZXh0S2V5ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXN1bHQ7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGRvIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdXJsID0gUlBDK2AvdmFsaWRhdG9ycz9oZWlnaHQ9JHtoZWlnaHR9JnBhZ2U9JHsrK3BhZ2V9JnBlcl9wYWdlPTEwMGA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIj09PT09PT09PSB2YWxpZGF0b3IgcmVzdWx0ID09PT09PT09PT06ICVvXCIsIHJlc3VsdClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JzID0gWy4uLnZhbGlkYXRvcnMsIC4uLnJlc3VsdC52YWxpZGF0b3JzXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2codmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHBhcnNlSW50KHJlc3VsdC50b3RhbCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgd2hpbGUgKHZhbGlkYXRvcnMubGVuZ3RoIDwgcGFyc2VJbnQocmVzdWx0LnRvdGFsKSlcblxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJHZXR0aW5nIHZhbGlkYXRvciBzZXQgYXQgaGVpZ2h0ICVvOiAlb1wiLCBoZWlnaHQsIGUpXG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyh2YWxpZGF0b3JzKVxuXG4gICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvclNldHMuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrX2hlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yczogdmFsaWRhdG9yc1xuICAgICAgICAgICAgICAgICAgICB9KVxuXG4gICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS52YWxpZGF0b3JzQ291bnQgPSB2YWxpZGF0b3JzLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgICAgICAvLyB0ZW1wb3JhcmlseSBhZGQgYmVjaDMyIGNvbmNlbnN1cyBrZXlzIHRvIHRoZSB2YWxpZGF0b3Igc2V0IGxpc3RcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRlbXBWYWxpZGF0b3JzID0gW107XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IHYgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3JzW3ZdLmNvbnNlbnN1c19wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzJPbGQnLCB2YWxpZGF0b3JzW3ZdLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4Q29uc1B1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3JzW3ZdLnZhbGNvbnNBZGRyZXNzID0gdmFsaWRhdG9yc1t2XS5hZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yc1t2XS52YWxjb25zQWRkcmVzcyA9IE1ldGVvci5jYWxsKCdoZXhUb0JlY2gzMicsIHZhbGlkYXRvcnNbdl0uYWRkcmVzcywgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhDb25zQWRkcik7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3JzW3ZdLmFkZHJlc3MgPSBNZXRlb3IuY2FsbCgnZ2V0QWRkcmVzc0Zyb21QdWJrZXknLCB2YWxpZGF0b3JzW3ZdLnB1YktleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0ZW1wVmFsaWRhdG9yc1t2YWxpZGF0b3JzW3ZdLnB1YktleS52YWx1ZV0gPSB2YWxpZGF0b3JzW3ZdO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcFZhbGlkYXRvcnNbdmFsaWRhdG9yc1t2XS5hZGRyZXNzXSA9IHZhbGlkYXRvcnNbdl07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9ycyA9IHRlbXBWYWxpZGF0b3JzO1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiYmVmb3JlIGNvbXBhcmluZyBwcmVjb21taXRzOiAlb1wiLCB2YWxpZGF0b3JzKTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBUZW5kZXJtaW50IHYwLjMzIHN0YXJ0IHVzaW5nIFwic2lnbmF0dXJlc1wiIGluIGxhc3QgYmxvY2sgaW5zdGVhZCBvZiBcInByZWNvbW1pdHNcIlxuICAgICAgICAgICAgICAgICAgICBsZXQgcHJlY29tbWl0cyA9IGJsb2NrLmJsb2NrLmxhc3RfY29tbWl0LnNpZ25hdHVyZXM7IFxuICAgICAgICAgICAgICAgICAgICBpZiAocHJlY29tbWl0cyAhPSBudWxsKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHByZWNvbW1pdHMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaT0wOyBpPHByZWNvbW1pdHMubGVuZ3RoOyBpKyspe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmVjb21taXRzW2ldICE9IG51bGwpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudmFsaWRhdG9ycy5wdXNoKHByZWNvbW1pdHNbaV0udmFsaWRhdG9yX2FkZHJlc3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS5wcmVjb21taXRzID0gcHJlY29tbWl0cy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyByZWNvcmQgZm9yIGFuYWx5dGljc1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gUHJlY29tbWl0UmVjb3Jkcy5pbnNlcnQoe2hlaWdodDpoZWlnaHQsIHByZWNvbW1pdHM6cHJlY29tbWl0cy5sZW5ndGh9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgPiAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJlY29yZCBwcmVjb21taXRzIGFuZCBjYWxjdWxhdGUgdXB0aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBvbmx5IHJlY29yZCBmcm9tIGJsb2NrIDJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiSW5zZXJ0aW5nIHByZWNvbW1pdHNcIilcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoaSBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYWRkcmVzcyA9IHZhbGlkYXRvcnNbaV0uYWRkcmVzcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVjb3JkID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhpc3RzOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiBwYXJzZUludCh2YWxpZGF0b3JzW2ldLnZvdGluZ19wb3dlcilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGogaW4gcHJlY29tbWl0cyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmVjb21taXRzW2pdICE9IG51bGwpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZWNvbW1pdEFkZHJlc3MgPSBwcmVjb21taXRzW2pdLnZhbGlkYXRvcl9hZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGFkZHJlc3MgPT0gcHJlY29tbWl0QWRkcmVzcyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVjb3JkLmV4aXN0cyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1VwZGF0ZUxhc3RTZWVuLmZpbmQoe2FkZHJlc3M6cHJlY29tbWl0QWRkcmVzc30pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp7bGFzdFNlZW46YmxvY2tEYXRhLnRpbWV9fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlY29tbWl0cy5zcGxpY2UoaiwxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JSZWNvcmRzLmluc2VydChyZWNvcmQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZhbGlkYXRvclJlY29yZHMudXBkYXRlKHtoZWlnaHQ6aGVpZ2h0LGFkZHJlc3M6cmVjb3JkLmFkZHJlc3N9LHJlY29yZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRCbG9ja0luc2VydFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBCbG9ja3Njb24uaW5zZXJ0KGJsb2NrRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBlbmRCbG9ja0luc2VydFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkJsb2NrIGluc2VydCB0aW1lOiBcIisoKGVuZEJsb2NrSW5zZXJ0VGltZS1zdGFydEJsb2NrSW5zZXJ0VGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICBsZXQgY2hhaW5TdGF0dXMgPSBDaGFpbi5maW5kT25lKHtjaGFpbklkOmJsb2NrLmJsb2NrLmhlYWRlci5jaGFpbl9pZH0pO1xuICAgICAgICAgICAgICAgICAgICBsZXQgbGFzdFN5bmNlZFRpbWUgPSBjaGFpblN0YXR1cz9jaGFpblN0YXR1cy5sYXN0U3luY2VkVGltZTowO1xuICAgICAgICAgICAgICAgICAgICBsZXQgdGltZURpZmY7XG4gICAgICAgICAgICAgICAgICAgIGxldCBibG9ja1RpbWUgPSBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLmRlZmF1bHRCbG9ja1RpbWU7XG4gICAgICAgICAgICAgICAgICAgIGlmIChsYXN0U3luY2VkVGltZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGF0ZUxhdGVzdCA9IG5ldyBEYXRlKGJsb2NrRGF0YS50aW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkYXRlTGFzdCA9IG5ldyBEYXRlKGxhc3RTeW5jZWRUaW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBnZW5lc2lzVGltZSA9IG5ldyBEYXRlKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuZ2VuZXNpc1RpbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGltZURpZmYgPSBNYXRoLmFicyhkYXRlTGF0ZXN0LmdldFRpbWUoKSAtIGRhdGVMYXN0LmdldFRpbWUoKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBibG9ja1RpbWUgPSAoY2hhaW5TdGF0dXMuYmxvY2tUaW1lICogKGJsb2NrRGF0YS5oZWlnaHQgLSAxKSArIHRpbWVEaWZmKSAvIGJsb2NrRGF0YS5oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja1RpbWUgPSAoZGF0ZUxhdGVzdC5nZXRUaW1lKCkgLSBnZW5lc2lzVGltZS5nZXRUaW1lKCkpIC8gYmxvY2tEYXRhLmhlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGxldCBlbmRHZXRWYWxpZGF0b3JzVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0IGhlaWdodCB2YWxpZGF0b3JzIHRpbWU6IFwiKygoZW5kR2V0VmFsaWRhdG9yc1RpbWUtc3RhcnRHZXRWYWxpZGF0b3JzVGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6YmxvY2suYmxvY2suaGVhZGVyLmNoYWluSWR9LCB7JHNldDp7bGFzdFN5bmNlZFRpbWU6YmxvY2tEYXRhLnRpbWUsIGJsb2NrVGltZTpibG9ja1RpbWV9fSk7XG5cbiAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS5hdmVyYWdlQmxvY2tUaW1lID0gYmxvY2tUaW1lO1xuICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLnRpbWVEaWZmID0gdGltZURpZmY7XG5cbiAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS50aW1lID0gYmxvY2tEYXRhLnRpbWU7XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gaW5pdGlhbGl6ZSB2YWxpZGF0b3IgZGF0YSBhdCBmaXJzdCBibG9ja1xuICAgICAgICAgICAgICAgICAgICAvLyBpZiAoaGVpZ2h0ID09IDEpe1xuICAgICAgICAgICAgICAgICAgICAvLyAgICAgVmFsaWRhdG9ycy5yZW1vdmUoe30pO1xuICAgICAgICAgICAgICAgICAgICAvLyB9XG5cbiAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS52b3RpbmdfcG93ZXIgPSAwO1xuXG4gICAgICAgICAgICAgICAgICAgIGxldCBzdGFydEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHYgaW4gdmFsaWRhdG9yU2V0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxEYXRhID0gdmFsaWRhdG9yU2V0W3ZdO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWxEYXRhLnRva2VucyA9IHBhcnNlSW50KHZhbERhdGEudG9rZW5zKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbERhdGEudW5ib25kaW5nX2hlaWdodCA9IHBhcnNlSW50KHZhbERhdGEudW5ib25kaW5nX2hlaWdodClcblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbEV4aXN0ID0gVmFsaWRhdG9ycy5maW5kT25lKHtcImNvbnNlbnN1c19wdWJrZXkua2V5XCI6dn0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2codmFsRGF0YSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiPT09PT0gdm90aW5nIHBvd2VyID09PT09PTogJW9cIiwgdmFsRGF0YSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEudm90aW5nX3Bvd2VyICs9IHZhbERhdGEudm90aW5nX3Bvd2VyXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGFuYWx5dGljc0RhdGEudm90aW5nX3Bvd2VyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdmFsRXhpc3QgJiYgdmFsRGF0YS5jb25zZW5zdXNfcHVia2V5KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IHZhbCA9IGdldFZhbGlkYXRvckZyb21Db25zZW5zdXNLZXkodmFsaWRhdG9ycywgdik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZ2V0IHRoZSB2YWxpZGF0b3IgaGV4IGFkZHJlc3MgYW5kIG90aGVyIGJlY2gzMiBhZGRyZXNzZXMuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxEYXRhLmRlbGVnYXRvcl9hZGRyZXNzID0gTWV0ZW9yLmNhbGwoJ2dldERlbGVnYXRvcicsIHZhbERhdGEub3BlcmF0b3JfYWRkcmVzcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcImdldCBoZXggYWRkcmVzc1wiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbERhdGEuYWRkcmVzcyA9IGdldEFkZHJlc3ModmFsRGF0YS5jb25zZW5zdXNQdWJrZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGJlY2gzMiBjb25zZW5zdXMgcHVia2V5XCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbERhdGEuYmVjaDMyQ29uc2Vuc3VzUHViS2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsRGF0YS5jb25zZW5zdXNfcHVia2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeENvbnNQdWIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsRGF0YS5hZGRyZXNzID0gTWV0ZW9yLmNhbGwoJ2dldEFkZHJlc3NGcm9tUHVia2V5JywgdmFsRGF0YS5jb25zZW5zdXNfcHVia2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxEYXRhLmJlY2gzMlZhbENvbnNBZGRyZXNzID0gTWV0ZW9yLmNhbGwoJ2hleFRvQmVjaDMyJywgdmFsRGF0YS5hZGRyZXNzLCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeENvbnNBZGRyKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGFzc2lnbiBiYWNrIHRvIHRoZSB2YWxpZGF0b3Igc2V0IHNvIHRoYXQgd2UgY2FuIHVzZSBpdCB0byBmaW5kIHRoZSB1cHRpbWVcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JTZXRbdl0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvclNldFt2XS5iZWNoMzJWYWxDb25zQWRkcmVzcyA9IHZhbERhdGEuYmVjaDMyVmFsQ29uc0FkZHJlc3M7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRmlyc3QgdGltZSBhZGRpbmcgdmFsaWRhdG9yIHRvIHRoZSBkYXRhYmFzZS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBGZXRjaCBwcm9maWxlIHBpY3R1cmUgZnJvbSBLZXliYXNlXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsRGF0YS5kZXNjcmlwdGlvbiAmJiB2YWxEYXRhLmRlc2NyaXB0aW9uLmlkZW50aXR5KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsRGF0YS5wcm9maWxlX3VybCA9ICBnZXRWYWxpZGF0b3JQcm9maWxlVXJsKHZhbERhdGEuZGVzY3JpcHRpb24uaWRlbnRpdHkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJFcnJvciBmZXRjaGluZyBrZXliYXNlOiAlb1wiLCBlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxEYXRhLmFjY3B1YiA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbERhdGEuY29uc2Vuc3VzX3B1YmtleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NQdWIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbERhdGEub3BlcmF0b3JfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsRGF0YS5jb25zZW5zdXNfcHVia2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbFB1Yik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBpbnNlcnQgZmlyc3QgcG93ZXIgY2hhbmdlIGhpc3RvcnkgXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxEYXRhLnZvdGluZ19wb3dlciA9IHZhbGlkYXRvcnNbdmFsRGF0YS5jb25zZW5zdXNQdWJrZXkudmFsdWVdP3BhcnNlSW50KHZhbGlkYXRvcnNbdmFsRGF0YS5jb25zZW5zdXNQdWJrZXkudmFsdWVdLnZvdGluZ1Bvd2VyKTowO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbERhdGEudm90aW5nX3Bvd2VyID0gdmFsaWRhdG9yc1t2YWxEYXRhLmFkZHJlc3NdP3BhcnNlSW50KHZhbGlkYXRvcnNbdmFsRGF0YS5hZGRyZXNzXS52b3RpbmdfcG93ZXIpOjA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsRGF0YS5wcm9wb3Nlcl9wcmlvcml0eSA9IHZhbGlkYXRvcnNbdmFsRGF0YS5hZGRyZXNzXT9wYXJzZUludCh2YWxpZGF0b3JzW3ZhbERhdGEuYWRkcmVzc10ucHJvcG9zZXJfcHJpb3JpdHkpOjA7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlZhbGlkYXRvciBub3QgZm91bmQuIEluc2VydCBmaXJzdCBWUCBjaGFuZ2UgcmVjb3JkLlwiKVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJmaXJzdCB2b3RpbmcgcG93ZXI6ICVvXCIsIHZhbERhdGEudm90aW5nX3Bvd2VyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVlBIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbERhdGEuYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogdmFsRGF0YS52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdhZGQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGJsb2NrRGF0YS5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrX3RpbWU6IGJsb2NrRGF0YS50aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyh2YWxEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxEYXRhLmFkZHJlc3MgPSB2YWxFeGlzdC5hZGRyZXNzO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYXNzaWduIHRvIHZhbERhdGEgZm9yIGdldHRpbmcgc2VsZiBkZWxlZ2F0aW9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsRGF0YS5kZWxlZ2F0b3JfYWRkcmVzcyA9IHZhbEV4aXN0LmRlbGVnYXRvcl9hZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbERhdGEuYmVjaDMyVmFsQ29uc0FkZHJlc3MgPSB2YWxFeGlzdC5iZWNoMzJWYWxDb25zQWRkcmVzcztcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JTZXRbdl0pe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JTZXRbdl0uYmVjaDMyVmFsQ29uc0FkZHJlc3MgPSB2YWxFeGlzdC5iZWNoMzJWYWxDb25zQWRkcmVzcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2codmFsRXhpc3QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHZhbGlkYXRvcnNbdmFsRXhpc3QuYWRkcmVzc10pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWYgKHZhbGlkYXRvcnNbdmFsRGF0YS5jb25zZW5zdXNQdWJrZXkudmFsdWVdKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yc1t2YWxFeGlzdC5hZGRyZXNzXSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZhbGlkYXRvciBleGlzdHMgYW5kIGlzIGluIHZhbGlkYXRvciBzZXQsIHVwZGF0ZSB2b2l0bmcgcG93ZXIuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIElmIHZvdGluZyBwb3dlciBpcyBkaWZmZXJlbnQgZnJvbSBiZWZvcmUsIGFkZCB2b3RpbmcgcG93ZXIgaGlzdG9yeVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxEYXRhLnZvdGluZ19wb3dlciA9IHBhcnNlSW50KHZhbGlkYXRvcnNbdmFsRXhpc3QuYWRkcmVzc10udm90aW5nX3Bvd2VyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsRGF0YS5wcm9wb3Nlcl9wcmlvcml0eSA9IHBhcnNlSW50KHZhbGlkYXRvcnNbdmFsRXhpc3QuYWRkcmVzc10ucHJvcG9zZXJfcHJpb3JpdHkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJldlZvdGluZ1Bvd2VyID0gVm90aW5nUG93ZXJIaXN0b3J5LmZpbmRPbmUoe2FkZHJlc3M6dmFsRXhpc3QuYWRkcmVzc30sIHtoZWlnaHQ6LTEsIGxpbWl0OjF9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlZhbGlkYXRvciBhbHJlYWR5IGluIERCLiBDaGVjayBpZiBWUCBjaGFuZ2VkLlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZXZWb3RpbmdQb3dlcil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJldlZvdGluZ1Bvd2VyLnZvdGluZ19wb3dlciAhPSB2YWxEYXRhLnZvdGluZ19wb3dlcil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNoYW5nZVR5cGUgPSAocHJldlZvdGluZ1Bvd2VyLnZvdGluZ19wb3dlciA+IHZhbERhdGEudm90aW5nX3Bvd2VyKT8nZG93bic6J3VwJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY2hhbmdlRGF0YSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogdmFsRXhpc3QuYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IHByZXZWb3RpbmdQb3dlci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogdmFsRGF0YS52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IGNoYW5nZVR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogYmxvY2tEYXRhLmhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tEYXRhLnRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWUEhpc3RvcnkuaW5zZXJ0KGNoYW5nZURhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZhbGlkYXRvciBpcyBub3QgaW4gdGhlIHNldCBhbmQgaXQgaGFzIGJlZW4gcmVtb3ZlZC5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2V0IHZvdGluZyBwb3dlciB0byB6ZXJvIGFuZCBhZGQgdm90aW5nIHBvd2VyIGhpc3RvcnkuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsRGF0YS5hZGRyZXNzID0gdmFsRXhpc3QuYWRkcmVzcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsRGF0YS52b3RpbmdfcG93ZXIgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxEYXRhLnByb3Bvc2VyX3ByaW9yaXR5ID0gMDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJldlZvdGluZ1Bvd2VyID0gVm90aW5nUG93ZXJIaXN0b3J5LmZpbmRPbmUoe2FkZHJlc3M6dmFsRXhpc3QuYWRkcmVzc30sIHtoZWlnaHQ6LTEsIGxpbWl0OjF9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJldlZvdGluZ1Bvd2VyICYmIChwcmV2Vm90aW5nUG93ZXIudm90aW5nX3Bvd2VyID4gMCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJWYWxpZGF0b3IgaXMgaW4gREIgYnV0IG5vdCBpbiB2YWxpZGF0b3Igc2V0IG5vdy4gQWRkIHJlbW92ZSBWUCBjaGFuZ2UuXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZQSGlzdG9yeS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbEV4aXN0LmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IHByZXZWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3JlbW92ZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBibG9ja0RhdGEuaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrX3RpbWU6IGJsb2NrRGF0YS50aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gb25seSB1cGRhdGUgdmFsaWRhdG9yIGluZm9yIGR1cmluZyBzdGFydCBvZiBjcmF3bGluZywgZW5kIG9mIGNyYXdsaW5nIG9yIGV2ZXJ5IHZhbGlkYXRvciB1cGRhdGUgd2luZG93XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoKGhlaWdodCA9PSBjdXJyKzEpIHx8IChoZWlnaHQgPT0gTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodCsxKSB8fCAoaGVpZ2h0ID09IHVudGlsKSB8fCAoaGVpZ2h0ICUgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy52YWxpZGF0b3JVcGRhdGVXaW5kb3cgPT0gMCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICgoaGVpZ2h0ID09IE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhcnRIZWlnaHQrMSkgfHwgKGhlaWdodCAlIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMudmFsaWRhdG9yVXBkYXRlV2luZG93ID09IDApKXsgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxEYXRhLnN0YXR1cyA9PSAnQk9ORF9TVEFUVVNfQk9OREVEJyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmwgPSBgJHtBUEl9L2Nvc21vcy9zdGFraW5nL3YxYmV0YTEvdmFsaWRhdG9ycy8ke3ZhbERhdGEub3BlcmF0b3JfYWRkcmVzc30vZGVsZWdhdGlvbnMvJHt2YWxEYXRhLmRlbGVnYXRvcl9hZGRyZXNzfWBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdldHRpbmcgc2VsZiBkZWxlZ2F0aW9uXCIpO1xuICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzZWxmRGVsZWdhdGlvbiA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkuZGVsZWdhdGlvbl9yZXNwb25zZTtcbiAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsRGF0YS5zZWxmX2RlbGVnYXRpb24gPSAoc2VsZkRlbGVnYXRpb24uZGVsZWdhdGlvbiAmJiBzZWxmRGVsZWdhdGlvbi5kZWxlZ2F0aW9uLnNoYXJlcyk/cGFyc2VGbG9hdChzZWxmRGVsZWdhdGlvbi5kZWxlZ2F0aW9uLnNoYXJlcykvcGFyc2VGbG9hdCh2YWxEYXRhLmRlbGVnYXRvcl9zaGFyZXMpOjA7XG4gICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdldHRpbmcgc2VsZiBkZWxlZ2F0aW9uOiAlb1wiLCBlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxEYXRhLnNlbGZfZGVsZWdhdGlvbiA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJBZGQgdmFsaWRhdG9yIHVwc2VydCB0byBidWxrIG9wZXJhdGlvbnMuXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7XCJhZGRyZXNzXCI6IHZhbERhdGEuYWRkcmVzc30pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp2YWxEYXRhfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvLyBzdG9yZSB2YWxkaWF0b3JzIGV4aXN0IHJlY29yZHNcbiAgICAgICAgICAgICAgICAgICAgLy8gbGV0IGV4aXN0aW5nVmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7YWRkcmVzczp7JGV4aXN0czp0cnVlfX0pLmZldGNoKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gdXBkYXRlIHVwdGltZSBieSB0aGUgZW5kIG9mIHRoZSBjcmF3bCBvciB1cGRhdGUgd2luZG93XG4gICAgICAgICAgICAgICAgICAgIGlmICgoaGVpZ2h0ICUgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy52YWxpZGF0b3JVcGRhdGVXaW5kb3cgPT0gMCkgfHwgKGhlaWdodCA9PSB1bnRpbCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJVcGRhdGUgdmFsaWRhdG9yIHVwdGltZS5cIilcbiAgICAgICAgICAgICAgICAgICAgICAgIGdldFZhbGlkYXRvclVwdGltZSh2YWxpZGF0b3JTZXQpXG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvLyBmZXRjaGluZyBrZXliYXNlIGV2ZXJ5IGJhc2Ugb24ga2V5YmFzZUZldGNoaW5nSW50ZXJ2YWwgc2V0dGluZ3NcbiAgICAgICAgICAgICAgICAgICAgLy8gZGVmYXVsdCB0byBldmVyeSA1IGhvdXJzIFxuXG4gICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgPT0gY3VycisxKXtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgdGhlIGxhc3QgZmV0Y2hpbmcgdGltZVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgbm93ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBsYXN0S2V5YmFzZUZldGNoVGltZSA9IERhdGUucGFyc2UoY2hhaW5TdGF0dXMubGFzdEtleWJhc2VGZXRjaFRpbWUpIHx8IDBcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTm93OiAlb1wiLCBub3cpXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkxhc3QgZmV0Y2ggdGltZTogJW9cIiwgbGFzdEtleWJhc2VGZXRjaFRpbWUpXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghbGFzdEtleWJhc2VGZXRjaFRpbWUgfHwgKG5vdyAtIGxhc3RLZXliYXNlRmV0Y2hUaW1lKSA+IE1ldGVvci5zZXR0aW5ncy5wYXJhbXMua2V5YmFzZUZldGNoaW5nSW50ZXJ2YWwgKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnRmV0Y2hpbmcga2V5YmFzZS4uLicpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWxvb3AtZnVuY1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMuZmluZCh7fSkuZm9yRWFjaChhc3luYyAodmFsaWRhdG9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yLmRlc2NyaXB0aW9uICYmIHZhbGlkYXRvci5kZXNjcmlwdGlvbi5pZGVudGl0eSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByb2ZpbGVVcmwgPSBnZXRWYWxpZGF0b3JQcm9maWxlVXJsKHZhbGlkYXRvci5kZXNjcmlwdGlvbi5pZGVudGl0eSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJvZmlsZVVybCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHthZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzc30pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp7J3Byb2ZpbGVfdXJsJzpwcm9maWxlVXJsfX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgZmV0Y2hpbmcgS2V5YmFzZSBmb3IgJW86ICVvXCIsIHZhbGlkYXRvci5hZGRyZXNzLCBlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpibG9jay5ibG9jay5oZWFkZXIuY2hhaW5JZH0sIHskc2V0OntsYXN0S2V5YmFzZUZldGNoVGltZTpuZXcgRGF0ZSgpLnRvVVRDU3RyaW5nKCl9fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGxldCBlbmRGaW5kVmFsaWRhdG9yc05hbWVUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJHZXQgdmFsaWRhdG9ycyBuYW1lIHRpbWU6IFwiKygoZW5kRmluZFZhbGlkYXRvcnNOYW1lVGltZS1zdGFydEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gcmVjb3JkIGZvciBhbmFseXRpY3NcbiAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0QW5heXRpY3NJbnNlcnRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgQW5hbHl0aWNzLmluc2VydChhbmFseXRpY3NEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGVuZEFuYWx5dGljc0luc2VydFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkFuYWx5dGljcyBpbnNlcnQgdGltZTogXCIrKChlbmRBbmFseXRpY3NJbnNlcnRUaW1lLXN0YXJ0QW5heXRpY3NJbnNlcnRUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIGNhbGN1bGF0ZSB2b3RpbmcgcG93ZXIgZGlzdHJpYnV0aW9uIGV2ZXJ5IDYwIGJsb2NrcyB+IDVtaW5zXG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCAlIDYwID09IDEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FsY3VsYXRlVlBEaXN0KGFuYWx5dGljc0RhdGEsIGJsb2NrRGF0YSlcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGxldCBzdGFydFZVcFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoYnVsa1ZhbGlkYXRvcnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIiMjIyMjIyMjIyMjIyBVcGRhdGUgdmFsaWRhdG9ycyAjIyMjIyMjIyMjIyNcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5leGVjdXRlKChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9yIHdoaWxlIGJ1bGsgaW5zZXJ0IHZhbGlkYXRvcnM6ICVvXCIsZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtVcGRhdGVMYXN0U2Vlbi5leGVjdXRlKChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJFcnJvciB3aGlsZSBidWxrIHVwZGF0ZSB2YWxpZGF0b3IgbGFzdCBzZWVuOiAlb1wiLGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGxldCBlbmRWVXBUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJWYWxpZGF0b3IgdXBkYXRlIHRpbWU6IFwiKygoZW5kVlVwVGltZS1zdGFydFZVcFRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0VlJUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGJ1bGtWYWxpZGF0b3JSZWNvcmRzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvclJlY29yZHMuZXhlY3V0ZSgoZXJyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBsZXQgZW5kVlJUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJWYWxpZGF0b3IgcmVjb3JkcyB1cGRhdGUgdGltZTogXCIrKChlbmRWUlRpbWUtc3RhcnRWUlRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGJ1bGtWUEhpc3RvcnkubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBidWxrVlBIaXN0b3J5LmV4ZWN1dGUoKGVycikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG5cblxuICAgICAgICAgICAgICAgICAgICAvLyB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJCbG9jayBzeW5jaW5nIHN0b3BwZWQ6ICVvXCIsIGUpO1xuICAgICAgICAgICAgICAgICAgICBTWU5DSU5HID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIlN0b3BwZWRcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGV0IGVuZEJsb2NrVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJUaGlzIGJsb2NrIHVzZWQ6IFwiKygoZW5kQmxvY2tUaW1lLXN0YXJ0QmxvY2tUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgU1lOQ0lORyA9IGZhbHNlO1xuICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0sIHskc2V0OntsYXN0QmxvY2tzU3luY2VkVGltZTpuZXcgRGF0ZSgpfX0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHVudGlsO1xuICAgIH0sXG4gICAgJ2FkZExpbWl0JzogZnVuY3Rpb24obGltaXQpIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2cobGltaXQrMTApXG4gICAgICAgIHJldHVybiAobGltaXQrMTApO1xuICAgIH0sXG4gICAgJ2hhc01vcmUnOiBmdW5jdGlvbihsaW1pdCkge1xuICAgICAgICBpZiAobGltaXQgPiBNZXRlb3IuY2FsbCgnZ2V0Q3VycmVudEhlaWdodCcpKSB7XG4gICAgICAgICAgICByZXR1cm4gKGZhbHNlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiAodHJ1ZSk7XG4gICAgICAgIH1cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vYmxvY2tzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25zIH0gZnJvbSAnLi4vLi4vdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyc7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ2Jsb2Nrcy5oZWlnaHQnLCBmdW5jdGlvbihsaW1pdCl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKHt9LCB7bGltaXQ6IGxpbWl0LCBzb3J0OiB7aGVpZ2h0OiAtMX19KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoYmxvY2spe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2FkZHJlc3M6YmxvY2sucHJvcG9zZXJBZGRyZXNzfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsaW1pdDoxfVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ2Jsb2Nrcy5maW5kT25lJywgZnVuY3Rpb24oaGVpZ2h0KXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoe2hlaWdodDpoZWlnaHR9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoYmxvY2spe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OmJsb2NrLmhlaWdodH1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChibG9jayl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWRkcmVzczpibG9jay5wcm9wb3NlckFkZHJlc3N9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2xpbWl0OjF9XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5leHBvcnQgY29uc3QgQmxvY2tzY29uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2Jsb2NrcycpO1xuXG5CbG9ja3Njb24uaGVscGVycyh7XG4gICAgcHJvcG9zZXIoKXtcbiAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZE9uZSh7YWRkcmVzczp0aGlzLnByb3Bvc2VyQWRkcmVzc30pO1xuICAgIH1cbn0pO1xuXG4vLyBCbG9ja3Njb24uaGVscGVycyh7XG4vLyAgICAgc29ydGVkKGxpbWl0KSB7XG4vLyAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZCh7fSwge3NvcnQ6IHtoZWlnaHQ6LTF9LCBsaW1pdDogbGltaXR9KTtcbi8vICAgICB9XG4vLyB9KTtcblxuXG4vLyBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKSB7XG4vLyAgICAgTWV0ZW9yLmNhbGwoJ2Jsb2Nrc1VwZGF0ZScsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4vLyAgICAgICAgIGNvbnNvbGUubG9nKHJlc3VsdCk7XG4vLyAgICAgfSlcbi8vIH0sIDMwMDAwMDAwKTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgeyBDaGFpbiwgQ2hhaW5TdGF0ZXMgfSBmcm9tICcuLi9jaGFpbi5qcyc7XG5pbXBvcnQgQ29pbiBmcm9tICcuLi8uLi8uLi8uLi9ib3RoL3V0aWxzL2NvaW5zLmpzJztcblxuZmluZFZvdGluZ1Bvd2VyID0gKHZhbGlkYXRvciwgZ2VuVmFsaWRhdG9ycykgPT4ge1xuICAgIGZvciAobGV0IHYgaW4gZ2VuVmFsaWRhdG9ycyl7XG4gICAgICAgIGlmICh2YWxpZGF0b3IucHViX2tleS52YWx1ZSA9PSBnZW5WYWxpZGF0b3JzW3ZdLnB1Yl9rZXkudmFsdWUpe1xuICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KGdlblZhbGlkYXRvcnNbdl0ucG93ZXIpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2NoYWluLmdldENvbnNlbnN1c1N0YXRlJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB1cmwgPSBSUEMrJy9kdW1wX2NvbnNlbnN1c19zdGF0ZSc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgY29uc2Vuc3VzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIGNvbnNlbnN1cyA9IGNvbnNlbnN1cy5yZXN1bHQ7XG4gICAgICAgICAgICBsZXQgaGVpZ2h0ID0gY29uc2Vuc3VzLnJvdW5kX3N0YXRlLmhlaWdodDtcbiAgICAgICAgICAgIGxldCByb3VuZCA9IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS5yb3VuZDtcbiAgICAgICAgICAgIGxldCBzdGVwID0gY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnN0ZXA7XG4gICAgICAgICAgICBsZXQgdm90ZWRQb3dlciA9IE1hdGgucm91bmQocGFyc2VGbG9hdChjb25zZW5zdXMucm91bmRfc3RhdGUudm90ZXNbcm91bmRdLnByZXZvdGVzX2JpdF9hcnJheS5zcGxpdChcIiBcIilbM10pKjEwMCk7XG5cbiAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7XG4gICAgICAgICAgICAgICAgdm90aW5nSGVpZ2h0OiBoZWlnaHQsXG4gICAgICAgICAgICAgICAgdm90aW5nUm91bmQ6IHJvdW5kLFxuICAgICAgICAgICAgICAgIHZvdGluZ1N0ZXA6IHN0ZXAsXG4gICAgICAgICAgICAgICAgdm90ZWRQb3dlcjogdm90ZWRQb3dlcixcbiAgICAgICAgICAgICAgICBwcm9wb3NlckFkZHJlc3M6IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS52YWxpZGF0b3JzLnByb3Bvc2VyLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgcHJldm90ZXM6IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS52b3Rlc1tyb3VuZF0ucHJldm90ZXMsXG4gICAgICAgICAgICAgICAgcHJlY29tbWl0czogY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnZvdGVzW3JvdW5kXS5wcmVjb21taXRzXG4gICAgICAgICAgICB9fSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdjaGFpbi51cGRhdGVTdGF0dXMnOiBhc3luYyBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHVybCA9IFwiXCI7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIHVybCA9IEFQSSArICcvYmxvY2tzL2xhdGVzdCc7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IGxhdGVzdEJsb2NrID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcblxuICAgICAgICAgICAgbGV0IGNoYWluID0ge307XG4gICAgICAgICAgICBjaGFpbi5jaGFpbklkID0gbGF0ZXN0QmxvY2suYmxvY2suaGVhZGVyLmNoYWluX2lkO1xuICAgICAgICAgICAgY2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHQgPSBwYXJzZUludChsYXRlc3RCbG9jay5ibG9jay5oZWFkZXIuaGVpZ2h0KTtcbiAgICAgICAgICAgIGNoYWluLmxhdGVzdEJsb2NrVGltZSA9IGxhdGVzdEJsb2NrLmJsb2NrLmhlYWRlci50aW1lO1xuICAgICAgICAgICAgbGV0IGxhdGVzdFN0YXRlID0gQ2hhaW5TdGF0ZXMuZmluZE9uZSh7fSwge3NvcnQ6IHtoZWlnaHQ6IC0xfX0pXG4gICAgICAgICAgICBpZiAobGF0ZXN0U3RhdGUgJiYgbGF0ZXN0U3RhdGUuaGVpZ2h0ID49IGNoYWluLmxhdGVzdEJsb2NrSGVpZ2h0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGBubyB1cGRhdGVzIChnZXR0aW5nIGJsb2NrICR7Y2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHR9IGF0IGJsb2NrICR7bGF0ZXN0U3RhdGUuaGVpZ2h0fSlgXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIFNpbmNlIFRlbmRlcm1pbnQgdjAuMzMsIHZhbGlkYXRvciBwYWdlIGRlZmF1bHQgc2V0IHRvIHJldHVybiAzMCB2YWxpZGF0b3JzLlxuICAgICAgICAgICAgLy8gUXVlcnkgbGF0ZXN0IGhlaWdodCB3aXRoIHBhZ2UgMSBhbmQgMTAwIHZhbGlkYXRvcnMgcGVyIHBhZ2UuXG5cbiAgICAgICAgICAgIC8vIHZhbGlkYXRvcnMgPSB2YWxpZGF0b3JzLnZhbGlkYXRvcnNMaXN0O1xuICAgICAgICAgICAgLy8gY2hhaW4udmFsaWRhdG9ycyA9IHZhbGlkYXRvcnMubGVuZ3RoO1xuXG4gICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IFtdXG4gICAgICAgICAgICBsZXQgcGFnZSA9IDA7XG5cbiAgICAgICAgICAgIGRvIHtcbiAgICAgICAgICAgICAgICB1cmwgPSBSUEMrYC92YWxpZGF0b3JzP3BhZ2U9JHsrK3BhZ2V9JnBlcl9wYWdlPTEwMGA7XG4gICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICByZXN1bHQgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICB2YWxpZGF0b3JzID0gWy4uLnZhbGlkYXRvcnMsIC4uLnJlc3VsdC52YWxpZGF0b3JzXTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHdoaWxlICh2YWxpZGF0b3JzLmxlbmd0aCA8IHBhcnNlSW50KHJlc3VsdC50b3RhbCkpXG5cbiAgICAgICAgICAgIGNoYWluLnZhbGlkYXRvcnMgPSB2YWxpZGF0b3JzLmxlbmd0aDtcbiAgICAgICAgICAgIGxldCBhY3RpdmVWUCA9IDA7XG4gICAgICAgICAgICBmb3IgKHYgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgYWN0aXZlVlAgKz0gcGFyc2VJbnQodmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2hhaW4uYWN0aXZlVm90aW5nUG93ZXIgPSBhY3RpdmVWUDtcblxuICAgICAgICAgICAgLy8gdXBkYXRlIHN0YWtpbmcgcGFyYW1zXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHVybCA9IEFQSSArICcvY29zbW9zL3N0YWtpbmcvdjFiZXRhMS9wYXJhbXMnO1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBjaGFpbi5zdGFraW5nID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBHZXQgY2hhaW4gc3RhdGVzXG4gICAgICAgICAgICBpZiAocGFyc2VJbnQoY2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHQpID4gMCl7XG4gICAgICAgICAgICAgICAgbGV0IGNoYWluU3RhdGVzID0ge307XG4gICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuaGVpZ2h0ID0gcGFyc2VJbnQoY2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHQpO1xuICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLnRpbWUgPSBuZXcgRGF0ZShjaGFpbi5sYXRlc3RCbG9ja1RpbWUpO1xuXG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICB1cmwgPSBBUEkgKyAnL2Nvc21vcy9zdGFraW5nL3YxYmV0YTEvcG9vbCc7XG4gICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBib25kaW5nID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5wb29sO1xuICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5ib25kZWRUb2tlbnMgPSBwYXJzZUludChib25kaW5nLmJvbmRlZF90b2tlbnMpO1xuICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5ub3RCb25kZWRUb2tlbnMgPSBwYXJzZUludChib25kaW5nLm5vdF9ib25kZWRfdG9rZW5zKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmICggQ29pbi5TdGFraW5nQ29pbi5kZW5vbSApIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMubW9kdWxlcy5iYW5rKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmwgPSBBUEkgKyAnL2Nvc21vcy9iYW5rL3YxYmV0YTEvc3VwcGx5LycgKyBDb2luLlN0YWtpbmdDb2luLmRlbm9tO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN1cHBseSA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMudG90YWxTdXBwbHkgPSBwYXJzZUludChzdXBwbHkuYW1vdW50LmFtb3VudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdXBkYXRlIGJhbmsgcGFyYW1zXG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybCA9IEFQSSArICcvY29zbW9zL2JhbmsvdjFiZXRhMS9wYXJhbXMnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFpbi5iYW5rID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZiAoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5tb2R1bGVzLmRpc3RyaWJ1dGlvbil7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybCA9IEFQSSArICcvY29zbW9zL2Rpc3RyaWJ1dGlvbi92MWJldGExL2NvbW11bml0eV9wb29sJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwb29sID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5wb29sO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwb29sICYmIHBvb2wubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmNvbW11bml0eVBvb2wgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9vbC5mb3JFYWNoKChhbW91bnQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmNvbW11bml0eVBvb2wucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVub206IGFtb3VudC5kZW5vbSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IHBhcnNlRmxvYXQoYW1vdW50LmFtb3VudClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHVwZGF0ZSBkaXN0cmlidXRpb24gcGFyYW1zXG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybCA9IEFQSSArICcvY29zbW9zL2Rpc3RyaWJ1dGlvbi92MWJldGExL3BhcmFtcyc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYWluLmRpc3RyaWJ1dGlvbiA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmIChNZXRlb3Iuc2V0dGluZ3MucHVibGljLm1vZHVsZXMubWludGluZyl7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsID0gQVBJICsgJy9jb3Ntb3MvbWludC92MWJldGExL2luZmxhdGlvbic7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaW5mbGF0aW9uID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5pbmZsYXRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCBpbmZsYXRpb24gPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW5mbGF0aW9uKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuaW5mbGF0aW9uID0gcGFyc2VGbG9hdChpbmZsYXRpb24pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmwgPSBBUEkgKyAnL2Nvc21vcy9taW50L3YxYmV0YTEvYW5udWFsX3Byb3Zpc2lvbnMnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByb3Zpc2lvbnMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLmFubnVhbF9wcm92aXNpb25zO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHByb3Zpc2lvbnMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByb3Zpc2lvbnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5hbm51YWxQcm92aXNpb25zID0gcGFyc2VGbG9hdChwcm92aXNpb25zKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB1cGRhdGUgbWludCBwYXJhbXNcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsID0gQVBJICsgJy9jb3Ntb3MvbWludC92MWJldGExL3BhcmFtcyc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYWluLm1pbnQgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZiAoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5tb2R1bGVzLmdvdil7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB1cGRhdGUgbWludCBwYXJhbXNcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsID0gQVBJICsgJy9jb3Ntb3MvZ292L3YxYmV0YTEvcGFyYW1zJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hhaW4uZ292ID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgQ2hhaW5TdGF0ZXMuaW5zZXJ0KGNoYWluU3RhdGVzKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOmNoYWluLmNoYWluSWR9LCB7JHNldDpjaGFpbn0sIHt1cHNlcnQ6IHRydWV9KTtcblxuICAgICAgICAgICAgLy8gY2hhaW4udG90YWxWb3RpbmdQb3dlciA9IHRvdGFsVlA7XG5cbiAgICAgICAgICAgIC8vIHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyh2YWxpZGF0b3JzKTtcbiAgICAgICAgICAgIHJldHVybiBjaGFpbi5sYXRlc3RCbG9ja0hlaWdodDtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICByZXR1cm4gXCJFcnJvciBnZXR0aW5nIGNoYWluIHN0YXR1cy5cIjtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2NoYWluLmdldExhdGVzdFN0YXR1cyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBDaGFpbi5maW5kKCkuc29ydCh7Y3JlYXRlZDotMX0pLmxpbWl0KDEpO1xuICAgIH0sXG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBDaGFpbiwgQ2hhaW5TdGF0ZXMgfSBmcm9tICcuLi9jaGFpbi5qcyc7XG5pbXBvcnQgeyBDb2luU3RhdHMgfSBmcm9tICcuLi8uLi9jb2luLXN0YXRzL2NvaW4tc3RhdHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbk1ldGVvci5wdWJsaXNoKCdjaGFpblN0YXRlcy5sYXRlc3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIFtcbiAgICAgICAgQ2hhaW5TdGF0ZXMuZmluZCh7fSx7c29ydDp7aGVpZ2h0Oi0xfSxsaW1pdDoxfSksXG4gICAgICAgIENvaW5TdGF0cy5maW5kKHt9LHtzb3J0OntsYXN0X3VwZGF0ZWRfYXQ6LTF9LGxpbWl0OjF9KVxuICAgIF07XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnY2hhaW4uc3RhdHVzJywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gQ2hhaW4uZmluZCh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9KTtcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKGNoYWluKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczoxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOjEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3BlcmF0b3JBZGRyZXNzOjEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOi0xLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGphaWxlZDoxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb2ZpbGVfdXJsOjFcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTsiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcblxuZXhwb3J0IGNvbnN0IENoYWluID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NoYWluJyk7XG5leHBvcnQgY29uc3QgQ2hhaW5TdGF0ZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2hhaW5fc3RhdGVzJylcblxuQ2hhaW4uaGVscGVycyh7XG4gICAgcHJvcG9zZXIoKXtcbiAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZE9uZSh7YWRkcmVzczp0aGlzLnByb3Bvc2VyQWRkcmVzc30pO1xuICAgIH1cbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBDb2luU3RhdHMgfSBmcm9tICcuLi9jb2luLXN0YXRzLmpzJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnY29pblN0YXRzLmdldENvaW5TdGF0cyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgY29pbklkID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jb2luZ2Vja29JZDtcbiAgICAgICAgaWYgKGNvaW5JZCl7XG4gICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgbGV0IG5vdyA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgbm93LnNldE1pbnV0ZXMoMCk7XG4gICAgICAgICAgICAgICAgbGV0IHVybCA9IFwiaHR0cHM6Ly9hcGkuY29pbmdlY2tvLmNvbS9hcGkvdjMvc2ltcGxlL3ByaWNlP2lkcz1cIitjb2luSWQrXCImdnNfY3VycmVuY2llcz11c2QmaW5jbHVkZV9tYXJrZXRfY2FwPXRydWUmaW5jbHVkZV8yNGhyX3ZvbD10cnVlJmluY2x1ZGVfMjRocl9jaGFuZ2U9dHJ1ZSZpbmNsdWRlX2xhc3RfdXBkYXRlZF9hdD10cnVlXCI7XG4gICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGEgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICBkYXRhID0gZGF0YVtjb2luSWRdO1xuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjb2luU3RhdHMpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQ29pblN0YXRzLnVwc2VydCh7bGFzdF91cGRhdGVkX2F0OmRhdGEubGFzdF91cGRhdGVkX2F0fSwgeyRzZXQ6ZGF0YX0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcIk5vIGNvaW5nZWNrbyBJZCBwcm92aWRlZC5cIlxuICAgICAgICB9XG4gICAgfSxcbiAgICAnY29pblN0YXRzLmdldFN0YXRzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBjb2luSWQgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNvaW5nZWNrb0lkO1xuICAgICAgICBpZiAoY29pbklkKXtcbiAgICAgICAgICAgIHJldHVybiAoQ29pblN0YXRzLmZpbmRPbmUoe30se3NvcnQ6e2xhc3RfdXBkYXRlZF9hdDotMX19KSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcIk5vIGNvaW5nZWNrbyBJZCBwcm92aWRlZC5cIjtcbiAgICAgICAgfVxuXG4gICAgfVxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBDb2luU3RhdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY29pbl9zdGF0cycpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBEZWxlZ2F0aW9ucyB9IGZyb20gJy4uL2RlbGVnYXRpb25zLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2RlbGVnYXRpb25zLmdldERlbGVnYXRpb25zJzogYXN5bmMgZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB2YWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHt9KS5mZXRjaCgpO1xuICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBbXTtcbiAgICAgICAgY29uc29sZS5sb2coXCI9PT0gR2V0dGluZyBkZWxlZ2F0aW9ucyA9PT1cIik7XG4gICAgICAgIGZvciAodiBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgIGlmICh2YWxpZGF0b3JzW3ZdLm9wZXJhdG9yX2FkZHJlc3Mpe1xuICAgICAgICAgICAgICAgIGxldCB1cmwgPSBBUEkgKyAnL2Nvc21vcy9zdGFraW5nL3YxYmV0YTEvdmFsaWRhdG9ycy8nK3ZhbGlkYXRvcnNbdl0ub3BlcmF0b3JBZGRyZXNzK1wiL2RlbGVnYXRpb25zXCI7XG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRlbGVnYXRpb24gPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGRlbGVnYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMgPSBkZWxlZ2F0aW9ucy5jb25jYXQoZGVsZWdhdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlLnN0YXR1c0NvZGUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgfSAgICBcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBkYXRhID0ge1xuICAgICAgICAgICAgZGVsZWdhdGlvbnM6IGRlbGVnYXRpb25zLFxuICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIERlbGVnYXRpb25zLmluc2VydChkYXRhKTtcbiAgICB9XG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IERlbGVnYXRpb25zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2RlbGVnYXRpb25zJyk7XG4iLCJpbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAndHJhbnNhY3Rpb24uc3VibWl0JzogZnVuY3Rpb24odHhJbmZvKSB7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHtBUEl9L3R4c2A7XG4gICAgICAgIGRhdGEgPSB7XG4gICAgICAgICAgICBcInR4XCI6IHR4SW5mby52YWx1ZSxcbiAgICAgICAgICAgIFwibW9kZVwiOiBcInN5bmNcIlxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHRpbWVzdGFtcCA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgICBjb25zb2xlLmxvZyhgc3VibWl0dGluZyB0cmFuc2FjdGlvbiR7dGltZXN0YW1wfSAke3VybH0gd2l0aCBkYXRhICR7SlNPTi5zdHJpbmdpZnkoZGF0YSl9YClcblxuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLnBvc3QodXJsLCB7ZGF0YX0pO1xuICAgICAgICBjb25zb2xlLmxvZyhgcmVzcG9uc2UgZm9yIHRyYW5zYWN0aW9uJHt0aW1lc3RhbXB9ICR7dXJsfTogJHtKU09OLnN0cmluZ2lmeShyZXNwb25zZSl9YClcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XG4gICAgICAgICAgICBsZXQgZGF0YSA9IHJlc3BvbnNlLmRhdGFcbiAgICAgICAgICAgIGlmIChkYXRhLmNvZGUpXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihkYXRhLmNvZGUsIEpTT04ucGFyc2UoZGF0YS5yYXdfbG9nKS5tZXNzYWdlKVxuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGEudHhoYXNoO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAndHJhbnNhY3Rpb24uZXhlY3V0ZSc6IGZ1bmN0aW9uKGJvZHksIHBhdGgpIHtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke0FQSX0vJHtwYXRofWA7XG4gICAgICAgIGRhdGEgPSB7XG4gICAgICAgICAgICBcImJhc2VfcmVxXCI6IHtcbiAgICAgICAgICAgICAgICAuLi5ib2R5LFxuICAgICAgICAgICAgICAgIFwiY2hhaW5faWRcIjogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkLFxuICAgICAgICAgICAgICAgIFwic2ltdWxhdGVcIjogZmFsc2VcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5wb3N0KHVybCwge2RhdGF9KTtcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XG4gICAgICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ3RyYW5zYWN0aW9uLnNpbXVsYXRlJzogZnVuY3Rpb24odHhNc2csIGZyb20sIGFjY291bnROdW1iZXIsIHNlcXVlbmNlLCBwYXRoLCBhZGp1c3RtZW50PScxLjInKSB7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBjb25zdCB1cmwgPSBgJHtBUEl9LyR7cGF0aH1gO1xuICAgICAgICBjb25zb2xlLmxvZyh0eE1zZyk7XG4gICAgICAgIGRhdGEgPSB7Li4udHhNc2csXG4gICAgICAgICAgICBcImJhc2VfcmVxXCI6IHtcbiAgICAgICAgICAgICAgICBcImZyb21cIjogZnJvbSxcbiAgICAgICAgICAgICAgICBcImNoYWluX2lkXCI6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZCxcbiAgICAgICAgICAgICAgICBcImdhc19hZGp1c3RtZW50XCI6IGFkanVzdG1lbnQsXG4gICAgICAgICAgICAgICAgXCJhY2NvdW50X251bWJlclwiOiBhY2NvdW50TnVtYmVyLFxuICAgICAgICAgICAgICAgIFwic2VxdWVuY2VcIjogc2VxdWVuY2UsXG4gICAgICAgICAgICAgICAgXCJzaW11bGF0ZVwiOiB0cnVlXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLnBvc3QodXJsLCB7ZGF0YX0pO1xuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApIHtcbiAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLmdhc19lc3RpbWF0ZTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2lzVmFsaWRhdG9yJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHtkZWxlZ2F0b3JfYWRkcmVzczphZGRyZXNzfSlcbiAgICAgICAgcmV0dXJuIHZhbGlkYXRvcjtcbiAgICB9XG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IFByb3Bvc2FscyB9IGZyb20gJy4uL3Byb3Bvc2Fscy5qcyc7XG5pbXBvcnQgeyBDaGFpbiB9IGZyb20gJy4uLy4uL2NoYWluL2NoYWluLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ3Byb3Bvc2Fscy5nZXRQcm9wb3NhbHMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcblxuICAgICAgICAvLyBnZXQgZ292IHRhbGx5IHByYXJhbXNcbiAgICAgICAgbGV0IHVybCA9IEFQSSArICcvY29zbW9zL2dvdi92MWJldGExL3BhcmFtcy90YWxseWluZyc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgcGFyYW1zID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcblxuICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7XCJnb3YudGFsbHlQYXJhbXNcIjpwYXJhbXMudGFsbHlfcGFyYW1zfX0pO1xuXG4gICAgICAgICAgICB1cmwgPSBBUEkgKyAnL2Nvc21vcy9nb3YvdjFiZXRhMS9wcm9wb3NhbHMnO1xuICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IHByb3Bvc2FscyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucHJvcG9zYWxzO1xuICAgICAgICAgICAgLy8gY29uc29sZS5sb2cocHJvcG9zYWxzKTtcblxuICAgICAgICAgICAgbGV0IGZpbmlzaGVkUHJvcG9zYWxJZHMgPSBuZXcgU2V0KFByb3Bvc2Fscy5maW5kKFxuICAgICAgICAgICAgICAgIHtcInByb3Bvc2FsX3N0YXR1c1wiOnskaW46W1wiUFJPUE9TQUxfU1RBVFVTX1BBU1NFRFwiLCBcIlBST1BPU0FMX1NUQVRVU19SRUpFQ1RFRFwiLCBcIlBST1BPU0FMX1NUQVRVU19SRU1PVkVEXCJdfX1cbiAgICAgICAgICAgICkuZmV0Y2goKS5tYXAoKHApPT4gcC5wcm9wb3NhbElkKSk7XG5cbiAgICAgICAgICAgIGxldCBwcm9wb3NhbElkcyA9IFtdO1xuICAgICAgICAgICAgaWYgKHByb3Bvc2Fscy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAvLyBQcm9wb3NhbHMudXBzZXJ0KClcbiAgICAgICAgICAgICAgICBjb25zdCBidWxrUHJvcG9zYWxzID0gUHJvcG9zYWxzLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSBpbiBwcm9wb3NhbHMpe1xuICAgICAgICAgICAgICAgICAgICBsZXQgcHJvcG9zYWwgPSBwcm9wb3NhbHNbaV07XG4gICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsLnByb3Bvc2FsSWQgPSBwYXJzZUludChwcm9wb3NhbC5wcm9wb3NhbF9pZCk7XG4gICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsSWRzLnB1c2gocHJvcG9zYWwucHJvcG9zYWxJZCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wb3NhbC5wcm9wb3NhbElkID4gMCAmJiAhZmluaXNoZWRQcm9wb3NhbElkcy5oYXMocHJvcG9zYWwucHJvcG9zYWxJZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB1cmwgPSBBUEkgKyAnL2Nvc21vcy9nb3YvdjFiZXRhMS9wcm9wb3NhbHMvJytwcm9wb3NhbC5wcm9wb3NhbElkKycvcHJvcG9zZXInO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgbGV0IHByb3Bvc2VyID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIGlmIChwcm9wb3Nlci5wcm9wb3NhbF9pZCAmJiAocHJvcG9zZXIucHJvcG9zYWxfaWQgPT0gcHJvcG9zYWwuaWQpKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIHByb3Bvc2FsLnByb3Bvc2VyID0gcHJvcG9zZXIucHJvcG9zZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1Byb3Bvc2Fscy5maW5kKHtwcm9wb3NhbElkOiBwcm9wb3NhbC5wcm9wb3NhbElkfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnByb3Bvc2FsfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrUHJvcG9zYWxzLmZpbmQoe3Byb3Bvc2FsSWQ6IHByb3Bvc2FsLnByb3Bvc2FsSWR9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6cHJvcG9zYWx9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBwcm9wb3NhbElkcy5wdXNoKHByb3Bvc2FsLnByb3Bvc2FsSWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5yZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBidWxrUHJvcG9zYWxzLmZpbmQoe3Byb3Bvc2FsSWQ6eyRuaW46cHJvcG9zYWxJZHN9LCBzdGF0dXM6eyRuaW46W1wiUFJPUE9TQUxfU1RBVFVTX1ZPVElOR19QRVJJT0RcIiwgXCJQUk9QT1NBTF9TVEFUVVNfUEFTU0VEXCIsIFwiUFJPUE9TQUxfU1RBVFVTX1JFSkVDVEVEXCIsIFwiUFJPUE9TQUxfU1RBVFVTX1JFTU9WRURcIl19fSlcbiAgICAgICAgICAgICAgICAgICAgLnVwZGF0ZSh7JHNldDoge1wic3RhdHVzXCI6IFwiUFJPUE9TQUxfU1RBVFVTX1JFTU9WRURcIn19KTtcbiAgICAgICAgICAgICAgICBidWxrUHJvcG9zYWxzLmV4ZWN1dGUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0cnVlXG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAncHJvcG9zYWxzLmdldFByb3Bvc2FsUmVzdWx0cyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgcHJvcG9zYWxzID0gUHJvcG9zYWxzLmZpbmQoe1wic3RhdHVzXCI6eyRuaW46W1wiUFJPUE9TQUxfU1RBVFVTX1BBU1NFRFwiLCBcIlBST1BPU0FMX1NUQVRVU19SRUpFQ1RFRFwiLCBcIlBST1BPU0FMX1NUQVRVU19SRU1PVkVEXCJdfX0pLmZldGNoKCk7XG5cbiAgICAgICAgaWYgKHByb3Bvc2FscyAmJiAocHJvcG9zYWxzLmxlbmd0aCA+IDApKXtcbiAgICAgICAgICAgIGZvciAobGV0IGkgaW4gcHJvcG9zYWxzKXtcbiAgICAgICAgICAgICAgICBpZiAocGFyc2VJbnQocHJvcG9zYWxzW2ldLnByb3Bvc2FsSWQpID4gMCl7XG4gICAgICAgICAgICAgICAgICAgIGxldCB1cmwgPSBcIlwiO1xuICAgICAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBnZXQgcHJvcG9zYWwgZGVwb3NpdHNcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybCA9IEFQSSArICcvY29zbW9zL2dvdi92MWJldGExL3Byb3Bvc2Fscy8nK3Byb3Bvc2Fsc1tpXS5wcm9wb3NhbElkKycvZGVwb3NpdHM/cGFnaW5hdGlvbi5saW1pdD0yMDAwJnBhZ2luYXRpb24uY291bnRfdG90YWw9dHJ1ZSc7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByb3Bvc2FsID0ge3Byb3Bvc2FsSWQ6IHByb3Bvc2Fsc1tpXS5wcm9wb3NhbElkfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRlcG9zaXRzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5kZXBvc2l0cztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NhbC5kZXBvc2l0cyA9IGRlcG9zaXRzO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmwgPSBBUEkgKyAnL2Nvc21vcy9nb3YvdjFiZXRhMS9wcm9wb3NhbHMvJytwcm9wb3NhbHNbaV0ucHJvcG9zYWxJZCsnL3ZvdGVzP3BhZ2luYXRpb24ubGltaXQ9MjAwMCZwYWdpbmF0aW9uLmNvdW50X3RvdGFsPXRydWUnO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdm90ZXMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnZvdGVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsLnZvdGVzID0gZ2V0Vm90ZURldGFpbCh2b3Rlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHVybCA9IEFQSSArICcvY29zbW9zL2dvdi92MWJldGExL3Byb3Bvc2Fscy8nK3Byb3Bvc2Fsc1tpXS5wcm9wb3NhbElkKycvdGFsbHknO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdGFsbHkgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnRhbGx5O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsLnRhbGx5ID0gdGFsbHk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsLnVwZGF0ZWRBdCA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBQcm9wb3NhbHMudXBkYXRlKHtwcm9wb3NhbElkOiBwcm9wb3NhbHNbaV0ucHJvcG9zYWxJZH0sIHskc2V0OnByb3Bvc2FsfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG59KVxuXG5jb25zdCBnZXRWb3RlRGV0YWlsID0gKHZvdGVzKSA9PiB7XG4gICAgaWYgKCF2b3Rlcykge1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxuXG4gICAgbGV0IHZvdGVycyA9IHZvdGVzLm1hcCgodm90ZSkgPT4gdm90ZS52b3Rlcik7XG4gICAgbGV0IHZvdGluZ1Bvd2VyTWFwID0ge307XG4gICAgbGV0IHZhbGlkYXRvckFkZHJlc3NNYXAgPSB7fTtcbiAgICBWYWxpZGF0b3JzLmZpbmQoe2RlbGVnYXRvcl9hZGRyZXNzOiB7JGluOiB2b3RlcnN9fSkuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB7XG4gICAgICAgIHZvdGluZ1Bvd2VyTWFwW3ZhbGlkYXRvci5kZWxlZ2F0b3JfYWRkcmVzc10gPSB7XG4gICAgICAgICAgICBtb25pa2VyOiB2YWxpZGF0b3IuZGVzY3JpcHRpb24ubW9uaWtlcixcbiAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgdG9rZW5zOiBwYXJzZUZsb2F0KHZhbGlkYXRvci50b2tlbnMpLFxuICAgICAgICAgICAgZGVsZWdhdG9yU2hhcmVzOiBwYXJzZUZsb2F0KHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzKSxcbiAgICAgICAgICAgIGRlZHVjdGVkU2hhcmVzOiBwYXJzZUZsb2F0KHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzKVxuICAgICAgICB9XG4gICAgICAgIHZhbGlkYXRvckFkZHJlc3NNYXBbdmFsaWRhdG9yLm9wZXJhdG9yX2FkZHJlc3NdID0gdmFsaWRhdG9yLmRlbGVnYXRvcl9hZGRyZXNzO1xuICAgIH0pO1xuICAgIHZvdGVycy5mb3JFYWNoKCh2b3RlcikgPT4ge1xuICAgICAgICBpZiAoIXZvdGluZ1Bvd2VyTWFwW3ZvdGVyXSkge1xuICAgICAgICAgICAgLy8gdm90ZXIgaXMgbm90IGEgdmFsaWRhdG9yXG4gICAgICAgICAgICBsZXQgdXJsID0gYCR7QVBJfS9jb3Ntb3Mvc3Rha2luZy92MWJldGExL2RlbGVnYXRpb25zLyR7dm90ZXJ9YDtcbiAgICAgICAgICAgIGxldCBkZWxlZ2F0aW9ucztcbiAgICAgICAgICAgIGxldCB2b3RpbmdQb3dlciA9IDA7XG4gICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkuZGVsZWdhdGlvbnNfcmVzcG9uc2U7XG4gICAgICAgICAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9ucyAmJiBkZWxlZ2F0aW9ucy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucy5mb3JFYWNoKChkZWxlZ2F0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbi5kZWxlZ2F0aW9uLnNoYXJlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckFkZHJlc3NNYXBbZGVsZWdhdGlvbi5kZWxlZ2F0aW9uLnZhbGlkYXRvcl9hZGRyZXNzXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkZWR1Y3QgZGVsZWdhdGVkIHNoYXJlZHMgZnJvbSB2YWxpZGF0b3IgaWYgYSBkZWxlZ2F0b3Igdm90ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvciA9IHZvdGluZ1Bvd2VyTWFwW3ZhbGlkYXRvckFkZHJlc3NNYXBbZGVsZWdhdGlvbi52YWxpZGF0b3JfYWRkcmVzc11dO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVkdWN0ZWRTaGFyZXMgLT0gc2hhcmVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yLmRlbGVnYXRvclNoYXJlcyAhPSAwKXsgLy8gYXZvaWRpbmcgZGl2aXNpb24gYnkgemVyb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nUG93ZXIgKz0gKHNoYXJlcy92YWxpZGF0b3IuZGVsZWdhdG9yU2hhcmVzKSAqIHZhbGlkYXRvci50b2tlbnM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe29wZXJhdG9yQWRkcmVzczogZGVsZWdhdGlvbi52YWxpZGF0b3JfYWRkcmVzc30pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yICYmIHZhbGlkYXRvci5kZWxlZ2F0b3JTaGFyZXMgIT0gMCl7IC8vIGF2b2lkaW5nIGRpdmlzaW9uIGJ5IHplcm9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ1Bvd2VyICs9IChzaGFyZXMvcGFyc2VGbG9hdCh2YWxpZGF0b3IuZGVsZWdhdG9yU2hhcmVzKSkgKiBwYXJzZUZsb2F0KHZhbGlkYXRvci50b2tlbnMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLnJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdm90aW5nUG93ZXJNYXBbdm90ZXJdID0ge3ZvdGluZ1Bvd2VyOiB2b3RpbmdQb3dlcn07XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gdm90ZXMubWFwKCh2b3RlKSA9PiB7XG4gICAgICAgIGxldCB2b3RlciA9IHZvdGluZ1Bvd2VyTWFwW3ZvdGUudm90ZXJdO1xuICAgICAgICBsZXQgdm90aW5nUG93ZXIgPSB2b3Rlci52b3RpbmdQb3dlcjtcbiAgICAgICAgaWYgKHZvdGluZ1Bvd2VyID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgLy8gdm90ZXIgaXMgYSB2YWxpZGF0b3JcbiAgICAgICAgICAgIHZvdGluZ1Bvd2VyID0gdm90ZXIuZGVsZWdhdG9yU2hhcmVzPygodm90ZXIuZGVkdWN0ZWRTaGFyZXMvdm90ZXIuZGVsZWdhdG9yU2hhcmVzKSAqIHZvdGVyLnRva2Vucyk6MDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gey4uLnZvdGUsIHZvdGluZ1Bvd2VyfTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgUHJvcG9zYWxzIH0gZnJvbSAnLi4vcHJvcG9zYWxzLmpzJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuXG5NZXRlb3IucHVibGlzaCgncHJvcG9zYWxzLmxpc3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIFByb3Bvc2Fscy5maW5kKHt9LCB7c29ydDp7cHJvcG9zYWxJZDotMX19KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgncHJvcG9zYWxzLm9uZScsIGZ1bmN0aW9uIChpZCl7XG4gICAgY2hlY2soaWQsIE51bWJlcik7XG4gICAgcmV0dXJuIFByb3Bvc2Fscy5maW5kKHtwcm9wb3NhbElkOmlkfSk7XG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IFByb3Bvc2FscyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdwcm9wb3NhbHMnKTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcywgQW5hbHl0aWNzLCBBdmVyYWdlRGF0YSwgQXZlcmFnZVZhbGlkYXRvckRhdGEgfSBmcm9tICcuLi9yZWNvcmRzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yU2V0cyB9IGZyb20gJy9pbXBvcnRzL2FwaS92YWxpZGF0b3Itc2V0cy92YWxpZGF0b3Itc2V0cy5qcyc7XG5pbXBvcnQgeyBTdGF0dXMgfSBmcm9tICcuLi8uLi9zdGF0dXMvc3RhdHVzLmpzJztcbmltcG9ydCB7IE1pc3NlZEJsb2Nrc1N0YXRzIH0gZnJvbSAnLi4vcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBNaXNzZWRCbG9ja3MgfSBmcm9tICcuLi9yZWNvcmRzLmpzJztcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uLy4uL2Jsb2Nrcy9ibG9ja3MuanMnO1xuaW1wb3J0IHsgQ2hhaW4gfSBmcm9tICcuLi8uLi9jaGFpbi9jaGFpbi5qcyc7XG5pbXBvcnQgXyBmcm9tICdsb2Rhc2gnO1xuY29uc3QgQlVMS1VQREFURU1BWFNJWkUgPSAxMDAwO1xuXG5jb25zdCBnZXRCbG9ja1N0YXRzID0gKHN0YXJ0SGVpZ2h0LCBsYXRlc3RIZWlnaHQpID0+IHtcbiAgICBsZXQgYmxvY2tTdGF0cyA9IHt9O1xuICAgIGNvbnN0IGNvbmQgPSB7JGFuZDogW1xuICAgICAgICB7IGhlaWdodDogeyAkZ3Q6IHN0YXJ0SGVpZ2h0IH0gfSxcbiAgICAgICAgeyBoZWlnaHQ6IHsgJGx0ZTogbGF0ZXN0SGVpZ2h0IH0gfSBdfTtcbiAgICBjb25zdCBvcHRpb25zID0ge3NvcnQ6e2hlaWdodDogMX19O1xuICAgIEJsb2Nrc2Nvbi5maW5kKGNvbmQsIG9wdGlvbnMpLmZvckVhY2goKGJsb2NrKSA9PiB7XG4gICAgICAgIGJsb2NrU3RhdHNbYmxvY2suaGVpZ2h0XSA9IHtcbiAgICAgICAgICAgIGhlaWdodDogYmxvY2suaGVpZ2h0LFxuICAgICAgICAgICAgcHJvcG9zZXJBZGRyZXNzOiBibG9jay5wcm9wb3NlckFkZHJlc3MsXG4gICAgICAgICAgICBwcmVjb21taXRzQ291bnQ6IGJsb2NrLnByZWNvbW1pdHNDb3VudCxcbiAgICAgICAgICAgIHZhbGlkYXRvcnNDb3VudDogYmxvY2sudmFsaWRhdG9yc0NvdW50LFxuICAgICAgICAgICAgdmFsaWRhdG9yczogYmxvY2sudmFsaWRhdG9ycyxcbiAgICAgICAgICAgIHRpbWU6IGJsb2NrLnRpbWVcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgQW5hbHl0aWNzLmZpbmQoY29uZCwgb3B0aW9ucykuZm9yRWFjaCgoYmxvY2spID0+IHtcbiAgICAgICAgaWYgKCFibG9ja1N0YXRzW2Jsb2NrLmhlaWdodF0pIHtcbiAgICAgICAgICAgIGJsb2NrU3RhdHNbYmxvY2suaGVpZ2h0XSA9IHsgaGVpZ2h0OiBibG9jay5oZWlnaHQgfTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBibG9jayAke2Jsb2NrLmhlaWdodH0gZG9lcyBub3QgaGF2ZSBhbiBlbnRyeWApO1xuICAgICAgICB9XG4gICAgICAgIF8uYXNzaWduKGJsb2NrU3RhdHNbYmxvY2suaGVpZ2h0XSwge1xuICAgICAgICAgICAgcHJlY29tbWl0czogYmxvY2sucHJlY29tbWl0cyxcbiAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGJsb2NrLmF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICB0aW1lRGlmZjogYmxvY2sudGltZURpZmYsXG4gICAgICAgICAgICB2b3RpbmdfcG93ZXI6IGJsb2NrLnZvdGluZ19wb3dlclxuICAgICAgICB9KTtcbiAgICB9KTtcbiAgICByZXR1cm4gYmxvY2tTdGF0cztcbn1cblxuY29uc3QgZ2V0UHJldmlvdXNSZWNvcmQgPSAodm90ZXJBZGRyZXNzLCBwcm9wb3NlckFkZHJlc3MpID0+IHtcbiAgICBsZXQgcHJldmlvdXNSZWNvcmQgPSBNaXNzZWRCbG9ja3MuZmluZE9uZShcbiAgICAgICAge3ZvdGVyOnZvdGVyQWRkcmVzcywgcHJvcG9zZXI6cHJvcG9zZXJBZGRyZXNzLCBibG9ja0hlaWdodDogLTF9KTtcbiAgICBsZXQgbGFzdFVwZGF0ZWRIZWlnaHQgPSBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnN0YXJ0SGVpZ2h0O1xuICAgIGxldCBwcmV2U3RhdHMgPSB7fTtcbiAgICBpZiAocHJldmlvdXNSZWNvcmQpIHtcbiAgICAgICAgcHJldlN0YXRzID0gXy5waWNrKHByZXZpb3VzUmVjb3JkLCBbJ21pc3NDb3VudCcsICd0b3RhbENvdW50J10pO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHByZXZTdGF0cyA9IHtcbiAgICAgICAgICAgIG1pc3NDb3VudDogMCxcbiAgICAgICAgICAgIHRvdGFsQ291bnQ6IDBcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcHJldlN0YXRzO1xufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ1ZhbGlkYXRvclJlY29yZHMuY2FsY3VsYXRlTWlzc2VkQmxvY2tzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGlmICghQ09VTlRNSVNTRURCTE9DS1Mpe1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLUyA9IHRydWU7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2NhbHVsYXRlIG1pc3NlZCBibG9ja3MgY291bnQnKTtcbiAgICAgICAgICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgICAgICAgICBsZXQgbGF0ZXN0SGVpZ2h0ID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0Jyk7XG4gICAgICAgICAgICAgICAgbGV0IGV4cGxvcmVyU3RhdHVzID0gU3RhdHVzLmZpbmRPbmUoe2NoYWluSWQ6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0pO1xuICAgICAgICAgICAgICAgIGxldCBzdGFydEhlaWdodCA9IChleHBsb3JlclN0YXR1cyYmZXhwbG9yZXJTdGF0dXMubGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrSGVpZ2h0KT9leHBsb3JlclN0YXR1cy5sYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tIZWlnaHQ6TWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICAgICAgICAgICAgICBsYXRlc3RIZWlnaHQgPSBNYXRoLm1pbihzdGFydEhlaWdodCArIEJVTEtVUERBVEVNQVhTSVpFLCBsYXRlc3RIZWlnaHQpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtNaXNzZWRTdGF0cyA9IE1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZU9yZGVyZWRCdWxrT3AoKTtcblxuICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JzTWFwID0ge307XG4gICAgICAgICAgICAgICAgdmFsaWRhdG9ycy5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHZhbGlkYXRvcnNNYXBbdmFsaWRhdG9yLmFkZHJlc3NdID0gdmFsaWRhdG9yKTtcblxuICAgICAgICAgICAgICAgIC8vIGEgbWFwIG9mIGJsb2NrIGhlaWdodCB0byBibG9jayBzdGF0c1xuICAgICAgICAgICAgICAgIGxldCBibG9ja1N0YXRzID0gZ2V0QmxvY2tTdGF0cyhzdGFydEhlaWdodCwgbGF0ZXN0SGVpZ2h0KTtcblxuICAgICAgICAgICAgICAgIC8vIHByb3Bvc2VyVm90ZXJTdGF0cyBpcyBhIHByb3Bvc2VyLXZvdGVyIG1hcCBjb3VudGluZyBudW1iZXJzIG9mIHByb3Bvc2VkIGJsb2NrcyBvZiB3aGljaCB2b3RlciBpcyBhbiBhY3RpdmUgdmFsaWRhdG9yXG4gICAgICAgICAgICAgICAgbGV0IHByb3Bvc2VyVm90ZXJTdGF0cyA9IHt9XG5cbiAgICAgICAgICAgICAgICBfLmZvckVhY2goYmxvY2tTdGF0cywgKGJsb2NrLCBibG9ja0hlaWdodCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgcHJvcG9zZXJBZGRyZXNzID0gYmxvY2sucHJvcG9zZXJBZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICBsZXQgdm90ZWRWYWxpZGF0b3JzID0gbmV3IFNldChibG9jay52YWxpZGF0b3JzKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvclNldHMgPSBWYWxpZGF0b3JTZXRzLmZpbmRPbmUoe2Jsb2NrX2hlaWdodDpibG9jay5oZWlnaHR9KTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZvdGVkVm90aW5nUG93ZXIgPSAwO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvclNldHMudmFsaWRhdG9ycy5mb3JFYWNoKChhY3RpdmVWYWxpZGF0b3IpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2b3RlZFZhbGlkYXRvcnMuaGFzKGFjdGl2ZVZhbGlkYXRvci5hZGRyZXNzKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RlZFZvdGluZ1Bvd2VyICs9IHBhcnNlRmxvYXQoYWN0aXZlVmFsaWRhdG9yLnZvdGluZ19wb3dlcilcbiAgICAgICAgICAgICAgICAgICAgfSlcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JTZXRzLnZhbGlkYXRvcnMuZm9yRWFjaCgoYWN0aXZlVmFsaWRhdG9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY3VycmVudFZhbGlkYXRvciA9IGFjdGl2ZVZhbGlkYXRvci5hZGRyZXNzXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIV8uaGFzKHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvcl0pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZXZTdGF0cyA9IGdldFByZXZpb3VzUmVjb3JkKGN1cnJlbnRWYWxpZGF0b3IsIHByb3Bvc2VyQWRkcmVzcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXy5zZXQocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yXSwgcHJldlN0YXRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgXy51cGRhdGUocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yLCAndG90YWxDb3VudCddLCAobikgPT4gbisxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdm90ZWRWYWxpZGF0b3JzLmhhcyhjdXJyZW50VmFsaWRhdG9yKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF8udXBkYXRlKHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvciwgJ21pc3NDb3VudCddLCAobikgPT4gbisxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrTWlzc2VkU3RhdHMuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90ZXI6IGN1cnJlbnRWYWxpZGF0b3IsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrSGVpZ2h0OiBibG9jay5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2VyOiBwcm9wb3NlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZWNvbW1pdHNDb3VudDogYmxvY2sucHJlY29tbWl0c0NvdW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JzQ291bnQ6IGJsb2NrLnZhbGlkYXRvcnNDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZTogYmxvY2sudGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlY29tbWl0czogYmxvY2sucHJlY29tbWl0cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYmxvY2suYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZURpZmY6IGJsb2NrLnRpbWVEaWZmLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdQb3dlcjogYmxvY2sudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RlZFZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkQXQ6IGxhdGVzdEhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWlzc0NvdW50OiBfLmdldChwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3IsICdtaXNzQ291bnQnXSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsQ291bnQ6IF8uZ2V0KHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvciwgJ3RvdGFsQ291bnQnXSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIF8uZm9yRWFjaChwcm9wb3NlclZvdGVyU3RhdHMsICh2b3RlcnMsIHByb3Bvc2VyQWRkcmVzcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBfLmZvckVhY2godm90ZXJzLCAoc3RhdHMsIHZvdGVyQWRkcmVzcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnVsa01pc3NlZFN0YXRzLmZpbmQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVyOiB2b3RlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6IHByb3Bvc2VyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodDogLTFcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVyOiB2b3RlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6IHByb3Bvc2VyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodDogLTEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEF0OiBsYXRlc3RIZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWlzc0NvdW50OiBfLmdldChzdGF0cywgJ21pc3NDb3VudCcpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsQ291bnQ6IF8uZ2V0KHN0YXRzLCAndG90YWxDb3VudCcpXG4gICAgICAgICAgICAgICAgICAgICAgICB9fSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSAnJztcbiAgICAgICAgICAgICAgICBpZiAoYnVsa01pc3NlZFN0YXRzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjbGllbnQgPSBNaXNzZWRCbG9ja3MuX2RyaXZlci5tb25nby5jbGllbnQ7XG4gICAgICAgICAgICAgICAgICAgIC8vIFRPRE86IGFkZCB0cmFuc2FjdGlvbiBiYWNrIGFmdGVyIHJlcGxpY2Egc2V0KCMxNDYpIGlzIHNldCB1cFxuICAgICAgICAgICAgICAgICAgICAvLyBsZXQgc2Vzc2lvbiA9IGNsaWVudC5zdGFydFNlc3Npb24oKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gc2Vzc2lvbi5zdGFydFRyYW5zYWN0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBidWxrUHJvbWlzZSA9IGJ1bGtNaXNzZWRTdGF0cy5leGVjdXRlKG51bGwvKiwge3Nlc3Npb259Ki8pLnRoZW4oXG4gICAgICAgICAgICAgICAgICAgICAgICBNZXRlb3IuYmluZEVudmlyb25tZW50KChyZXN1bHQsIGVycikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLUyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQcm9taXNlLmF3YWl0KHNlc3Npb24uYWJvcnRUcmFuc2FjdGlvbigpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUHJvbWlzZS5hd2FpdChzZXNzaW9uLmNvbW1pdFRyYW5zYWN0aW9uKCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlID0gYCgke3Jlc3VsdC5yZXN1bHQubkluc2VydGVkfSBpbnNlcnRlZCwgYCArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCR7cmVzdWx0LnJlc3VsdC5uVXBzZXJ0ZWR9IHVwc2VydGVkLCBgICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgJHtyZXN1bHQucmVzdWx0Lm5Nb2RpZmllZH0gbW9kaWZpZWQpYDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgICAgICAgICAgICAgUHJvbWlzZS5hd2FpdChidWxrUHJvbWlzZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1MgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBTdGF0dXMudXBzZXJ0KHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7bGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrSGVpZ2h0OmxhdGVzdEhlaWdodCwgbGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrVGltZTogbmV3IERhdGUoKX19KTtcbiAgICAgICAgICAgICAgICByZXR1cm4gYGRvbmUgaW4gJHtEYXRlLm5vdygpIC0gc3RhcnRUaW1lfW1zICR7bWVzc2FnZX1gO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgcmV0dXJuIFwidXBkYXRpbmcuLi5cIjtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ1ZhbGlkYXRvclJlY29yZHMuY2FsY3VsYXRlTWlzc2VkQmxvY2tzU3RhdHMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgLy8gVE9ETzogZGVwcmVjYXRlIHRoaXMgbWV0aG9kIGFuZCBNaXNzZWRCbG9ja3NTdGF0cyBjb2xsZWN0aW9uXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3M6IFwiK0NPVU5UTUlTU0VEQkxPQ0tTKTtcbiAgICAgICAgaWYgKCFDT1VOVE1JU1NFREJMT0NLU1NUQVRTKXtcbiAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSB0cnVlO1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ2NhbHVsYXRlIG1pc3NlZCBibG9ja3Mgc3RhdHMnKTtcbiAgICAgICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgICAgICBsZXQgbGF0ZXN0SGVpZ2h0ID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0Jyk7XG4gICAgICAgICAgICBsZXQgZXhwbG9yZXJTdGF0dXMgPSBTdGF0dXMuZmluZE9uZSh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG4gICAgICAgICAgICBsZXQgc3RhcnRIZWlnaHQgPSAoZXhwbG9yZXJTdGF0dXMmJmV4cGxvcmVyU3RhdHVzLmxhc3RNaXNzZWRCbG9ja0hlaWdodCk/ZXhwbG9yZXJTdGF0dXMubGFzdE1pc3NlZEJsb2NrSGVpZ2h0Ok1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhcnRIZWlnaHQ7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhsYXRlc3RIZWlnaHQpO1xuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coc3RhcnRIZWlnaHQpO1xuICAgICAgICAgICAgY29uc3QgYnVsa01pc3NlZFN0YXRzID0gTWlzc2VkQmxvY2tzU3RhdHMucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgIGZvciAoaSBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAvLyBpZiAoKHZhbGlkYXRvcnNbaV0uYWRkcmVzcyA9PSBcIkI4NTUyRUFDMEQxMjNBNkJGNjA5MTIzMDQ3QTUxODFENDVFRTkwQjVcIikgfHwgKHZhbGlkYXRvcnNbaV0uYWRkcmVzcyA9PSBcIjY5RDk5QjJDNjYwNDNBQ0JFQUE4NDQ3NTI1QzM1NkFGQzY0MDhFMENcIikgfHwgKHZhbGlkYXRvcnNbaV0uYWRkcmVzcyA9PSBcIjM1QUQ3QTJDRDJGQzcxNzExQTY3NTgzMEVDMTE1ODA4MjI3M0Q0NTdcIikpe1xuICAgICAgICAgICAgICAgIGxldCB2b3RlckFkZHJlc3MgPSB2YWxpZGF0b3JzW2ldLmFkZHJlc3M7XG4gICAgICAgICAgICAgICAgbGV0IG1pc3NlZFJlY29yZHMgPSBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoe1xuICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOnZvdGVyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgZXhpc3RzOmZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAkYW5kOiBbIHsgaGVpZ2h0OiB7ICRndDogc3RhcnRIZWlnaHQgfSB9LCB7IGhlaWdodDogeyAkbHRlOiBsYXRlc3RIZWlnaHQgfSB9IF1cbiAgICAgICAgICAgICAgICB9KS5mZXRjaCgpO1xuXG4gICAgICAgICAgICAgICAgbGV0IGNvdW50cyA9IHt9O1xuXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJtaXNzZWRSZWNvcmRzIHRvIHByb2Nlc3M6IFwiK21pc3NlZFJlY29yZHMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICBmb3IgKGIgaW4gbWlzc2VkUmVjb3Jkcyl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBibG9jayA9IEJsb2Nrc2Nvbi5maW5kT25lKHtoZWlnaHQ6bWlzc2VkUmVjb3Jkc1tiXS5oZWlnaHR9KTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGV4aXN0aW5nUmVjb3JkID0gTWlzc2VkQmxvY2tzU3RhdHMuZmluZE9uZSh7dm90ZXI6dm90ZXJBZGRyZXNzLCBwcm9wb3NlcjpibG9jay5wcm9wb3NlckFkZHJlc3N9KTtcblxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvdW50c1tibG9jay5wcm9wb3NlckFkZHJlc3NdID09PSAndW5kZWZpbmVkJyl7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdSZWNvcmQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50c1tibG9jay5wcm9wb3NlckFkZHJlc3NdID0gZXhpc3RpbmdSZWNvcmQuY291bnQrMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY291bnRzW2Jsb2NrLnByb3Bvc2VyQWRkcmVzc10gPSAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudHNbYmxvY2sucHJvcG9zZXJBZGRyZXNzXSsrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgZm9yIChhZGRyZXNzIGluIGNvdW50cyl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBkYXRhID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdm90ZXI6IHZvdGVyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2VyOmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudDogY291bnRzW2FkZHJlc3NdXG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBidWxrTWlzc2VkU3RhdHMuZmluZCh7dm90ZXI6dm90ZXJBZGRyZXNzLCBwcm9wb3NlcjphZGRyZXNzfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OmRhdGF9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gfVxuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChidWxrTWlzc2VkU3RhdHMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgYnVsa01pc3NlZFN0YXRzLmV4ZWN1dGUoTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCgoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLU1NUQVRTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgU3RhdHVzLnVwc2VydCh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSwgeyRzZXQ6e2xhc3RNaXNzZWRCbG9ja0hlaWdodDpsYXRlc3RIZWlnaHQsIGxhc3RNaXNzZWRCbG9ja1RpbWU6IG5ldyBEYXRlKCl9fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLU1NUQVRTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImRvbmVcIik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcInVwZGF0aW5nLi4uXCI7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdBbmFseXRpY3MuYWdncmVnYXRlQmxvY2tUaW1lQW5kVm90aW5nUG93ZXInOiBmdW5jdGlvbih0aW1lKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBub3cgPSBuZXcgRGF0ZSgpO1xuXG4gICAgICAgIGlmICh0aW1lID09ICdtJyl7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZUJsb2NrVGltZSA9IDA7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZVZvdGluZ1Bvd2VyID0gMDtcblxuICAgICAgICAgICAgbGV0IGFuYWx5dGljcyA9IEFuYWx5dGljcy5maW5kKHsgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNjAgKiAxMDAwKSB9IH0pLmZldGNoKCk7XG4gICAgICAgICAgICBpZiAoYW5hbHl0aWNzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGZvciAoaSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1tpXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyICs9IGFuYWx5dGljc1tpXS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgPSBhdmVyYWdlQmxvY2tUaW1lIC8gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgPSBhdmVyYWdlVm90aW5nUG93ZXIgLyBhbmFseXRpY3MubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0seyRzZXQ6e2xhc3RNaW51dGVWb3RpbmdQb3dlcjphdmVyYWdlVm90aW5nUG93ZXIsIGxhc3RNaW51dGVCbG9ja1RpbWU6YXZlcmFnZUJsb2NrVGltZX19KTtcbiAgICAgICAgICAgICAgICBBdmVyYWdlRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBhdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXI6IGF2ZXJhZ2VWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogdGltZSxcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0aW1lID09ICdoJyl7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZUJsb2NrVGltZSA9IDA7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZVZvdGluZ1Bvd2VyID0gMDtcbiAgICAgICAgICAgIGxldCBhbmFseXRpY3MgPSBBbmFseXRpY3MuZmluZCh7IFwidGltZVwiOiB7ICRndDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDYwKjYwICogMTAwMCkgfSB9KS5mZXRjaCgpO1xuICAgICAgICAgICAgaWYgKGFuYWx5dGljcy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBmb3IgKGkgaW4gYW5hbHl0aWNzKXtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSArPSBhbmFseXRpY3NbaV0udGltZURpZmY7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciArPSBhbmFseXRpY3NbaV0udm90aW5nX3Bvd2VyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lID0gYXZlcmFnZUJsb2NrVGltZSAvIGFuYWx5dGljcy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyID0gYXZlcmFnZVZvdGluZ1Bvd2VyIC8gYW5hbHl0aWNzLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LHskc2V0OntsYXN0SG91clZvdGluZ1Bvd2VyOmF2ZXJhZ2VWb3RpbmdQb3dlciwgbGFzdEhvdXJCbG9ja1RpbWU6YXZlcmFnZUJsb2NrVGltZX19KTtcbiAgICAgICAgICAgICAgICBBdmVyYWdlRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBhdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXI6IGF2ZXJhZ2VWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogdGltZSxcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRpbWUgPT0gJ2QnKXtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlQmxvY2tUaW1lID0gMDtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlVm90aW5nUG93ZXIgPSAwO1xuICAgICAgICAgICAgbGV0IGFuYWx5dGljcyA9IEFuYWx5dGljcy5maW5kKHsgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gMjQqNjAqNjAgKiAxMDAwKSB9IH0pLmZldGNoKCk7XG4gICAgICAgICAgICBpZiAoYW5hbHl0aWNzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGZvciAoaSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1tpXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyICs9IGFuYWx5dGljc1tpXS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgPSBhdmVyYWdlQmxvY2tUaW1lIC8gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgPSBhdmVyYWdlVm90aW5nUG93ZXIgLyBhbmFseXRpY3MubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0seyRzZXQ6e2xhc3REYXlWb3RpbmdQb3dlcjphdmVyYWdlVm90aW5nUG93ZXIsIGxhc3REYXlCbG9ja1RpbWU6YXZlcmFnZUJsb2NrVGltZX19KTtcbiAgICAgICAgICAgICAgICBBdmVyYWdlRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBhdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXI6IGF2ZXJhZ2VWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogdGltZSxcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gcmV0dXJuIGFuYWx5dGljcy5sZW5ndGg7XG4gICAgfSxcbiAgICAnQW5hbHl0aWNzLmFnZ3JlZ2F0ZVZhbGlkYXRvckRhaWx5QmxvY2tUaW1lJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB2YWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHt9KS5mZXRjaCgpO1xuICAgICAgICBsZXQgbm93ID0gbmV3IERhdGUoKTtcbiAgICAgICAgZm9yIChpIGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VCbG9ja1RpbWUgPSAwO1xuXG4gICAgICAgICAgICBsZXQgYmxvY2tzID0gQmxvY2tzY29uLmZpbmQoe3Byb3Bvc2VyQWRkcmVzczp2YWxpZGF0b3JzW2ldLmFkZHJlc3MsIFwidGltZVwiOiB7ICRndDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDI0KjYwKjYwICogMTAwMCkgfX0sIHtmaWVsZHM6e2hlaWdodDoxfX0pLmZldGNoKCk7XG5cbiAgICAgICAgICAgIGlmIChibG9ja3MubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgbGV0IGJsb2NrSGVpZ2h0cyA9IFtdO1xuICAgICAgICAgICAgICAgIGZvciAoYiBpbiBibG9ja3Mpe1xuICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodHMucHVzaChibG9ja3NbYl0uaGVpZ2h0KTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBsZXQgYW5hbHl0aWNzID0gQW5hbHl0aWNzLmZpbmQoe2hlaWdodDogeyRpbjpibG9ja0hlaWdodHN9fSwge2ZpZWxkczp7aGVpZ2h0OjEsdGltZURpZmY6MX19KS5mZXRjaCgpO1xuXG5cbiAgICAgICAgICAgICAgICBmb3IgKGEgaW4gYW5hbHl0aWNzKXtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSArPSBhbmFseXRpY3NbYV0udGltZURpZmY7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSA9IGF2ZXJhZ2VCbG9ja1RpbWUgLyBhbmFseXRpY3MubGVuZ3RoO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBBdmVyYWdlVmFsaWRhdG9yRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgIHByb3Bvc2VyQWRkcmVzczogdmFsaWRhdG9yc1tpXS5hZGRyZXNzLFxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgdHlwZTogJ1ZhbGlkYXRvckRhaWx5QXZlcmFnZUJsb2NrVGltZScsXG4gICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBWYWxpZGF0b3JSZWNvcmRzLCBBbmFseXRpY3MsIE1pc3NlZEJsb2NrcywgTWlzc2VkQmxvY2tzU3RhdHMsIFZQRGlzdHJpYnV0aW9ucyB9IGZyb20gJy4uL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbk1ldGVvci5wdWJsaXNoKCd2YWxpZGF0b3JfcmVjb3Jkcy5hbGwnLCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZCgpO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCd2YWxpZGF0b3JfcmVjb3Jkcy51cHRpbWUnLCBmdW5jdGlvbihhZGRyZXNzLCBudW0pe1xuICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoe2FkZHJlc3M6YWRkcmVzc30se2xpbWl0Om51bSwgc29ydDp7aGVpZ2h0Oi0xfX0pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdhbmFseXRpY3MuaGlzdG9yeScsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIEFuYWx5dGljcy5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LGxpbWl0OjUwfSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZwRGlzdHJpYnV0aW9uLmxhdGVzdCcsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIFZQRGlzdHJpYnV0aW9ucy5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDoxfSk7XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnbWlzc2VkYmxvY2tzLnZhbGlkYXRvcicsIGZ1bmN0aW9uKGFkZHJlc3MsIHR5cGUpe1xuICAgIGxldCBjb25kaXRpb25zID0ge307XG4gICAgaWYgKHR5cGUgPT0gJ3ZvdGVyJyl7XG4gICAgICAgIGNvbmRpdGlvbnMgPSB7XG4gICAgICAgICAgICB2b3RlcjogYWRkcmVzc1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2V7XG4gICAgICAgIGNvbmRpdGlvbnMgPSB7XG4gICAgICAgICAgICBwcm9wb3NlcjogYWRkcmVzc1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBNaXNzZWRCbG9ja3NTdGF0cy5maW5kKGNvbmRpdGlvbnMpXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChzdGF0cyl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e2FkZHJlc3M6MSwgZGVzY3JpcHRpb246MSwgcHJvZmlsZV91cmw6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnbWlzc2VkcmVjb3Jkcy52YWxpZGF0b3InLCBmdW5jdGlvbihhZGRyZXNzLCB0eXBlKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gTWlzc2VkQmxvY2tzLmZpbmQoXG4gICAgICAgICAgICAgICAge1t0eXBlXTogYWRkcmVzc30sXG4gICAgICAgICAgICAgICAge3NvcnQ6IHt1cGRhdGVkQXQ6IC0xfX1cbiAgICAgICAgICAgIClcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e2FkZHJlc3M6MSwgZGVzY3JpcHRpb246MSwgb3BlcmF0b3JBZGRyZXNzOjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzJztcblxuZXhwb3J0IGNvbnN0IFZhbGlkYXRvclJlY29yZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndmFsaWRhdG9yX3JlY29yZHMnKTtcbmV4cG9ydCBjb25zdCBBbmFseXRpY3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYW5hbHl0aWNzJyk7XG5leHBvcnQgY29uc3QgTWlzc2VkQmxvY2tzU3RhdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbWlzc2VkX2Jsb2Nrc19zdGF0cycpO1xuZXhwb3J0IGNvbnN0IE1pc3NlZEJsb2NrcyA9IG5ldyAgTW9uZ28uQ29sbGVjdGlvbignbWlzc2VkX2Jsb2NrcycpO1xuZXhwb3J0IGNvbnN0IFZQRGlzdHJpYnV0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2b3RpbmdfcG93ZXJfZGlzdHJpYnV0aW9ucycpO1xuZXhwb3J0IGNvbnN0IEF2ZXJhZ2VEYXRhID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2F2ZXJhZ2VfZGF0YScpO1xuZXhwb3J0IGNvbnN0IEF2ZXJhZ2VWYWxpZGF0b3JEYXRhID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2F2ZXJhZ2VfdmFsaWRhdG9yX2RhdGEnKTtcblxuTWlzc2VkQmxvY2tzU3RhdHMuaGVscGVycyh7XG4gICAgcHJvcG9zZXJNb25pa2VyKCl7XG4gICAgICAgIGxldCB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe2FkZHJlc3M6dGhpcy5wcm9wb3Nlcn0pO1xuICAgICAgICByZXR1cm4gKHZhbGlkYXRvci5kZXNjcmlwdGlvbik/dmFsaWRhdG9yLmRlc2NyaXB0aW9uLm1vbmlrZXI6dGhpcy5wcm9wb3NlcjtcbiAgICB9LFxuICAgIHZvdGVyTW9uaWtlcigpe1xuICAgICAgICBsZXQgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMudm90ZXJ9KTtcbiAgICAgICAgcmV0dXJuICh2YWxpZGF0b3IuZGVzY3JpcHRpb24pP3ZhbGlkYXRvci5kZXNjcmlwdGlvbi5tb25pa2VyOnRoaXMudm90ZXI7XG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgU3RhdHVzIH0gZnJvbSAnLi4vc3RhdHVzLmpzJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuXG5NZXRlb3IucHVibGlzaCgnc3RhdHVzLnN0YXR1cycsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gU3RhdHVzLmZpbmQoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG59KTtcblxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgU3RhdHVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3N0YXR1cycpOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbmNvbnN0IEFkZHJlc3NMZW5ndGggPSA0MDtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdUcmFuc2FjdGlvbnMudXBkYXRlVHJhbnNhY3Rpb25zJzogYXN5bmMgZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGlmIChUWFNZTkNJTkcpXG4gICAgICAgICAgICByZXR1cm4gXCJTeW5jaW5nIHRyYW5zYWN0aW9ucy4uLlwiO1xuXG4gICAgICAgIGNvbnN0IHRyYW5zYWN0aW9ucyA9IFRyYW5zYWN0aW9ucy5maW5kKHtwcm9jZXNzZWQ6ZmFsc2V9LHtsaW1pdDogNTAwfSkuZmV0Y2goKTtcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgVFhTWU5DSU5HID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnN0IGJ1bGtUcmFuc2FjdGlvbnMgPSBUcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgaW4gdHJhbnNhY3Rpb25zKXtcbiAgICAgICAgICAgICAgICBsZXQgdXJsID0gXCJcIjtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICB1cmwgPSBBUEkrICcvY29zbW9zL3R4L3YxYmV0YTEvdHhzLycrdHJhbnNhY3Rpb25zW2ldLnR4aGFzaDtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHR4ID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcblxuICAgICAgICAgICAgICAgICAgICB0eC5oZWlnaHQgPSBwYXJzZUludCh0eC50eF9yZXNwb25zZS5oZWlnaHQpO1xuICAgICAgICAgICAgICAgICAgICB0eC5wcm9jZXNzZWQgPSB0cnVlO1xuXG4gICAgICAgICAgICAgICAgICAgIGJ1bGtUcmFuc2FjdGlvbnMuZmluZCh7dHhoYXNoOnRyYW5zYWN0aW9uc1tpXS50eGhhc2h9KS51cGRhdGVPbmUoeyRzZXQ6dHh9KTtcblxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaChlKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwidHggbm90IGZvdW5kOiAlb1wiKVxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdldHRpbmcgdHJhbnNhY3Rpb24gJW86ICVvXCIsIHRyYW5zYWN0aW9uc1tpXS50eGhhc2gsIGUpO1xuICAgICAgICAgICAgICAgICAgICBidWxrVHJhbnNhY3Rpb25zLmZpbmQoe3R4aGFzaDp0cmFuc2FjdGlvbnNbaV0udHhoYXNofSkudXBkYXRlT25lKHskc2V0Ontwcm9jZXNzZWQ6dHJ1ZSwgbWlzc2luZzp0cnVlfX0pOyAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGJ1bGtUcmFuc2FjdGlvbnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJhYWE6ICVvXCIsYnVsa1RyYW5zYWN0aW9ucy5sZW5ndGgpXG4gICAgICAgICAgICAgICAgYnVsa1RyYW5zYWN0aW9ucy5leGVjdXRlKChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIFRYU1lOQ0lORyA9IGZhbHNlO1xuICAgICAgICAgICAgcmV0dXJuIGVcbiAgICAgICAgfVxuICAgICAgICBUWFNZTkNJTkcgPSBmYWxzZTtcbiAgICAgICAgcmV0dXJuIHRyYW5zYWN0aW9ucy5sZW5ndGhcbiAgICB9LFxuICAgICdUcmFuc2FjdGlvbnMuZmluZERlbGVnYXRpb24nOiBmdW5jdGlvbihhZGRyZXNzLCBoZWlnaHQpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgLy8gZm9sbG93aW5nIGNvc21vcy1zZGsveC9zbGFzaGluZy9zcGVjLzA2X2V2ZW50cy5tZCBhbmQgY29zbW9zLXNkay94L3N0YWtpbmcvc3BlYy8wNl9ldmVudHMubWRcbiAgICAgICAgcmV0dXJuIFRyYW5zYWN0aW9ucy5maW5kKHtcbiAgICAgICAgICAgICRvcjogW3skYW5kOiBbXG4gICAgICAgICAgICAgICAge1widHhfcmVzcG9uc2UubG9ncy5ldmVudHMudHlwZVwiOiBcImRlbGVnYXRlXCJ9LFxuICAgICAgICAgICAgICAgIHtcInR4X3Jlc3BvbnNlLmxvZ3MuZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6IFwidmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcInR4X3Jlc3BvbnNlLmxvZ3MuZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19LCB7JGFuZDpbXG4gICAgICAgICAgICAgICAge1widHhfcmVzcG9uc2UubG9ncy5ldmVudHMuYXR0cmlidXRlcy5rZXlcIjogXCJhY3Rpb25cIn0sXG4gICAgICAgICAgICAgICAge1widHhfcmVzcG9uc2UubG9ncy5ldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBcInVuamFpbFwifSxcbiAgICAgICAgICAgICAgICB7XCJ0eF9yZXNwb25zZS5sb2dzLmV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcInNlbmRlclwifSxcbiAgICAgICAgICAgICAgICB7XCJ0eF9yZXNwb25zZS5sb2dzLmV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6IGFkZHJlc3N9XG4gICAgICAgICAgICBdfSwgeyRhbmQ6W1xuICAgICAgICAgICAgICAgIHtcInR4X3Jlc3BvbnNlLmxvZ3MuZXZlbnRzLnR5cGVcIjogXCJjcmVhdGVfdmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcInR4X3Jlc3BvbnNlLmxvZ3MuZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6IFwidmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcInR4X3Jlc3BvbnNlLmxvZ3MuZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19LCB7JGFuZDpbXG4gICAgICAgICAgICAgICAge1widHhfcmVzcG9uc2UubG9ncy5ldmVudHMudHlwZVwiOiBcInVuYm9uZFwifSxcbiAgICAgICAgICAgICAgICB7XCJ0eF9yZXNwb25zZS5sb2dzLmV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcInZhbGlkYXRvclwifSxcbiAgICAgICAgICAgICAgICB7XCJ0eF9yZXNwb25zZS5sb2dzLmV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6IGFkZHJlc3N9XG4gICAgICAgICAgICBdfSwgeyRhbmQ6W1xuICAgICAgICAgICAgICAgIHtcInR4X3Jlc3BvbnNlLmxvZ3MuZXZlbnRzLnR5cGVcIjogXCJyZWRlbGVnYXRlXCJ9LFxuICAgICAgICAgICAgICAgIHtcInR4X3Jlc3BvbnNlLmxvZ3MuZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6IFwiZGVzdGluYXRpb25fdmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcInR4X3Jlc3BvbnNlLmxvZ3MuZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19XSxcbiAgICAgICAgICAgIFwidHhfcmVzcG9uc2UuY29kZVwiOiAwLFxuICAgICAgICAgICAgaGVpZ2h0OnskbHQ6aGVpZ2h0fX0sXG4gICAgICAgIHtzb3J0OntoZWlnaHQ6LTF9LFxuICAgICAgICAgICAgbGltaXQ6IDF9XG4gICAgICAgICkuZmV0Y2goKTtcbiAgICB9LFxuICAgICdUcmFuc2FjdGlvbnMuZmluZFVzZXInOiBmdW5jdGlvbihhZGRyZXNzLCBmaWVsZHM9bnVsbCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICAvLyBhZGRyZXNzIGlzIGVpdGhlciBkZWxlZ2F0b3IgYWRkcmVzcyBvciB2YWxpZGF0b3Igb3BlcmF0b3IgYWRkcmVzc1xuICAgICAgICBsZXQgdmFsaWRhdG9yO1xuICAgICAgICBpZiAoIWZpZWxkcylcbiAgICAgICAgICAgIGZpZWxkcyA9IHthZGRyZXNzOjEsIGRlc2NyaXB0aW9uOjEsIG9wZXJhdG9yX2FkZHJlc3M6MSwgZGVsZWdhdG9yX2FkZHJlc3M6MX07XG4gICAgICAgIGlmIChhZGRyZXNzLmluY2x1ZGVzKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsQWRkcikpe1xuICAgICAgICAgICAgLy8gdmFsaWRhdG9yIG9wZXJhdG9yIGFkZHJlc3NcbiAgICAgICAgICAgIHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZSh7b3BlcmF0b3JfYWRkcmVzczphZGRyZXNzfSwge2ZpZWxkc30pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGFkZHJlc3MuaW5jbHVkZXMoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NBZGRyKSl7XG4gICAgICAgICAgICAvLyBkZWxlZ2F0b3IgYWRkcmVzc1xuICAgICAgICAgICAgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHtkZWxlZ2F0b3JfYWRkcmVzczphZGRyZXNzfSwge2ZpZWxkc30pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGFkZHJlc3MubGVuZ3RoID09PSBBZGRyZXNzTGVuZ3RoKSB7XG4gICAgICAgICAgICB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe2FkZHJlc3M6YWRkcmVzc30sIHtmaWVsZHN9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodmFsaWRhdG9yKXtcbiAgICAgICAgICAgIHJldHVybiB2YWxpZGF0b3I7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuXG4gICAgfVxufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uL3RyYW5zYWN0aW9ucy5qcyc7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi8uLi9ibG9ja3MvYmxvY2tzLmpzJztcblxuXG5wdWJsaXNoQ29tcG9zaXRlKCd0cmFuc2FjdGlvbnMubGlzdCcsIGZ1bmN0aW9uKGxpbWl0ID0gMzApe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZCh7aGVpZ2h0OiB7ICRleGlzdHM6IHRydWV9LCBwcm9jZXNzZWQ6IHskbmU6IGZhbHNlfX0se3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OmxpbWl0fSlcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHR4KXtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR4LmhlaWdodClcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OnR4LmhlaWdodH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7dGltZToxLCBoZWlnaHQ6MX19XG4gICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3RyYW5zYWN0aW9ucy52YWxpZGF0b3InLCBmdW5jdGlvbih2YWxpZGF0b3JBZGRyZXNzLCBkZWxlZ2F0b3JBZGRyZXNzLCBsaW1pdD0xMDApe1xuICAgIGxldCBxdWVyeSA9IHt9O1xuICAgIGlmICh2YWxpZGF0b3JBZGRyZXNzICYmIGRlbGVnYXRvckFkZHJlc3Mpe1xuICAgICAgICBxdWVyeSA9IHskb3I6W3tcInR4X3Jlc3BvbnNlLmxvZ3MuZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjp2YWxpZGF0b3JBZGRyZXNzfSwge1widHhfcmVzcG9uc2UubG9ncy5ldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOmRlbGVnYXRvckFkZHJlc3N9XX1cbiAgICB9XG5cbiAgICBpZiAoIXZhbGlkYXRvckFkZHJlc3MgJiYgZGVsZWdhdG9yQWRkcmVzcyl7XG4gICAgICAgIHF1ZXJ5ID0ge1widHhfcmVzcG9uc2UubG9ncy5ldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOmRlbGVnYXRvckFkZHJlc3N9XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIFRyYW5zYWN0aW9ucy5maW5kKHF1ZXJ5LCB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6bGltaXR9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjpbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh0eCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6dHguaGVpZ2h0fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e3RpbWU6MSwgaGVpZ2h0OjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSlcblxucHVibGlzaENvbXBvc2l0ZSgndHJhbnNhY3Rpb25zLmZpbmRPbmUnLCBmdW5jdGlvbihoYXNoKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoe3R4aGFzaDpoYXNofSlcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHR4KXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2hlaWdodDp0eC5oZWlnaHR9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7dGltZToxLCBoZWlnaHQ6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KVxuXG5wdWJsaXNoQ29tcG9zaXRlKCd0cmFuc2FjdGlvbnMuaGVpZ2h0JywgZnVuY3Rpb24oaGVpZ2h0KXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoe2hlaWdodDpoZWlnaHR9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodHgpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OnR4LmhlaWdodH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGRzOnt0aW1lOjEsIGhlaWdodDoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vYmxvY2tzL2Jsb2Nrcy5qcyc7XG5pbXBvcnQgeyBUeEljb24gfSBmcm9tICcuLi8uLi91aS9jb21wb25lbnRzL0ljb25zLmpzeCc7XG5cbmV4cG9ydCBjb25zdCBUcmFuc2FjdGlvbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndHJhbnNhY3Rpb25zJyk7XG5cblRyYW5zYWN0aW9ucy5oZWxwZXJzKHtcbiAgICBibG9jaygpe1xuICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmRPbmUoe2hlaWdodDp0aGlzLmhlaWdodH0pO1xuICAgIH1cbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uLy4uL2Jsb2Nrcy9ibG9ja3MuanMnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ1ZhbGlkYXRvcnMuZmluZENyZWF0ZVZhbGlkYXRvclRpbWUnOiBmdW5jdGlvbihhZGRyZXNzKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIC8vIGxvb2sgdXAgdGhlIGNyZWF0ZSB2YWxpZGF0b3IgdGltZSB0byBjb25zaWRlciBpZiB0aGUgdmFsaWRhdG9yIGhhcyBuZXZlciB1cGRhdGVkIHRoZSBjb21taXNzaW9uXG4gICAgICAgIGxldCB0eCA9IFRyYW5zYWN0aW9ucy5maW5kT25lKHskYW5kOltcbiAgICAgICAgICAgIHtcInR4LmJvZHkubWVzc2FnZXMuZGVsZWdhdG9yX2FkZHJlc3NcIjphZGRyZXNzfSxcbiAgICAgICAgICAgIHtcInR4LmJvZHkubWVzc2FnZXMuQHR5cGVcIjpcIi9jb3Ntb3Muc3Rha2luZy52MWJldGExLk1zZ0NyZWF0ZVZhbGlkYXRvclwifSxcbiAgICAgICAgICAgIHtcInR4X3Jlc3BvbnNlLmNvZGVcIjowfVxuICAgICAgICBdfSk7XG5cbiAgICAgICAgaWYgKHR4KXtcbiAgICAgICAgICAgIGxldCBibG9jayA9IEJsb2Nrc2Nvbi5maW5kT25lKHtoZWlnaHQ6dHguaGVpZ2h0fSk7XG4gICAgICAgICAgICBpZiAoYmxvY2spe1xuICAgICAgICAgICAgICAgIHJldHVybiBibG9jay50aW1lO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICAvLyBubyBzdWNoIGNyZWF0ZSB2YWxpZGF0b3IgdHhcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgLy8gYXN5bmMgJ1ZhbGlkYXRvcnMuZ2V0QWxsRGVsZWdhdGlvbnMnKGFkZHJlc3Mpe1xuICAgICdWYWxpZGF0b3JzLmdldEFsbERlbGVnYXRpb25zJyhhZGRyZXNzKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB1cmwgPSBBUEkgKyAnL2Nvc21vcy9zdGFraW5nL3YxYmV0YTEvdmFsaWRhdG9ycy8nK2FkZHJlc3MrJy9kZWxlZ2F0aW9ucyc7XG5cbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IGRlbGVnYXRpb25zID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9ucy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMgPSBKU09OLnBhcnNlKGRlbGVnYXRpb25zLmNvbnRlbnQpLmRlbGVnYXRpb25fcmVzcG9uc2VzO1xuICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zLmZvckVhY2goKGRlbGVnYXRpb24sIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zW2ldICYmIGRlbGVnYXRpb25zW2ldLnNoYXJlcylcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zW2ldLnNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbnNbaV0uc2hhcmVzKTtcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHJldHVybiBkZWxlZ2F0aW9ucztcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0dGluZyBlcnJvcjogJW8gd2hlbiBmZXRjaGluZyBmcm9tICVvXCIsIGUsIHVybCk7XG4gICAgICAgIH1cbiAgICB9XG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMgfSBmcm9tICcuLi8uLi9yZWNvcmRzL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vLi4vdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuXG5NZXRlb3IucHVibGlzaCgndmFsaWRhdG9ycy5hbGwnLCBmdW5jdGlvbiAoc29ydCA9IFwiZGVzY3JpcHRpb24ubW9uaWtlclwiLCBkaXJlY3Rpb24gPSAtMSwgZmllbGRzPXt9KSB7XG4gICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZCh7fSwge3NvcnQ6IHtbc29ydF06IGRpcmVjdGlvbn0sIGZpZWxkczogZmllbGRzfSk7XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgndmFsaWRhdG9ycy5maXJzdFNlZW4nLHtcbiAgICBmaW5kKCkge1xuICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKHt9KTtcbiAgICB9LFxuICAgIGNoaWxkcmVuOiBbXG4gICAgICAgIHtcbiAgICAgICAgICAgIGZpbmQodmFsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgeyBhZGRyZXNzOiB2YWwuYWRkcmVzcyB9LFxuICAgICAgICAgICAgICAgICAgICB7IHNvcnQ6IHtoZWlnaHQ6IDF9LCBsaW1pdDogMX1cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgXVxufSk7XG5cbk1ldGVvci5wdWJsaXNoKCd2YWxpZGF0b3JzLnZvdGluZ19wb3dlcicsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZCh7XG4gICAgICAgIHN0YXR1czogJ0JPTkRfU1RBVFVTX0JPTkRFRCcsXG4gICAgICAgIGphaWxlZDpmYWxzZVxuICAgIH0se1xuICAgICAgICBzb3J0OntcbiAgICAgICAgICAgIHZvdGluZ19wb3dlcjotMVxuICAgICAgICB9LFxuICAgICAgICBmaWVsZHM6e1xuICAgICAgICAgICAgYWRkcmVzczogMSxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOjEsXG4gICAgICAgICAgICB2b3RpbmdfcG93ZXI6MSxcbiAgICAgICAgICAgIHByb2ZpbGVfdXJsOjFcbiAgICAgICAgfVxuICAgIH1cbiAgICApO1xufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3ZhbGlkYXRvci5kZXRhaWxzJywgZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgbGV0IG9wdGlvbnMgPSB7YWRkcmVzczphZGRyZXNzfTtcbiAgICBpZiAoYWRkcmVzcy5pbmRleE9mKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsQWRkcikgIT0gLTEpe1xuICAgICAgICBvcHRpb25zID0ge29wZXJhdG9yX2FkZHJlc3M6YWRkcmVzc31cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChvcHRpb25zKVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodmFsKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZvdGluZ1Bvd2VySGlzdG9yeS5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2FkZHJlc3M6dmFsLmFkZHJlc3N9LFxuICAgICAgICAgICAgICAgICAgICAgICAge3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OjUwfVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHZhbCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9yUmVjb3Jkcy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBhZGRyZXNzOiB2YWwuYWRkcmVzcyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBzb3J0OiB7aGVpZ2h0OiAtMX0sIGxpbWl0OiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLnVwdGltZVdpbmRvd31cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMgfSBmcm9tICcuLi9yZWNvcmRzL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuXG5leHBvcnQgY29uc3QgVmFsaWRhdG9ycyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2YWxpZGF0b3JzJyk7XG5cblZhbGlkYXRvcnMuaGVscGVycyh7XG4gICAgZmlyc3RTZWVuKCl7XG4gICAgICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmRPbmUoe2FkZHJlc3M6dGhpcy5hZGRyZXNzfSk7XG4gICAgfSxcbiAgICBoaXN0b3J5KCl7XG4gICAgICAgIHJldHVybiBWb3RpbmdQb3dlckhpc3RvcnkuZmluZCh7YWRkcmVzczp0aGlzLmFkZHJlc3N9LCB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6NTB9KS5mZXRjaCgpO1xuICAgIH1cbn0pXG4vLyBWYWxpZGF0b3JzLmhlbHBlcnMoe1xuLy8gICAgIHVwdGltZSgpe1xuLy8gICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLmFkZHJlc3MpO1xuLy8gICAgICAgICBsZXQgbGFzdEh1bmRyZWQgPSBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoe2FkZHJlc3M6dGhpcy5hZGRyZXNzfSwge3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OjEwMH0pLmZldGNoKCk7XG4vLyAgICAgICAgIGNvbnNvbGUubG9nKGxhc3RIdW5kcmVkKTtcbi8vICAgICAgICAgbGV0IHVwdGltZSA9IDA7XG4vLyAgICAgICAgIGZvciAoaSBpbiBsYXN0SHVuZHJlZCl7XG4vLyAgICAgICAgICAgICBpZiAobGFzdEh1bmRyZWRbaV0uZXhpc3RzKXtcbi8vICAgICAgICAgICAgICAgICB1cHRpbWUrPTE7XG4vLyAgICAgICAgICAgICB9XG4vLyAgICAgICAgIH1cbi8vICAgICAgICAgcmV0dXJuIHVwdGltZTtcbi8vICAgICB9XG4vLyB9KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IFZvdGluZ1Bvd2VySGlzdG9yeSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2b3RpbmdfcG93ZXJfaGlzdG9yeScpO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgRXZpZGVuY2VzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2V2aWRlbmNlcycpO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgVmFsaWRhdG9yU2V0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2YWxpZGF0b3Jfc2V0cycpO1xuIiwiLy8gSW1wb3J0IG1vZHVsZXMgdXNlZCBieSBib3RoIGNsaWVudCBhbmQgc2VydmVyIHRocm91Z2ggYSBzaW5nbGUgaW5kZXggZW50cnkgcG9pbnRcbi8vIGUuZy4gdXNlcmFjY291bnRzIGNvbmZpZ3VyYXRpb24gZmlsZS5cbiIsImltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uLy4uL2FwaS9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IFByb3Bvc2FscyB9IGZyb20gJy4uLy4uL2FwaS9wcm9wb3NhbHMvcHJvcG9zYWxzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMsIEFuYWx5dGljcywgTWlzc2VkQmxvY2tzU3RhdHMsIE1pc3NlZEJsb2NrcywgQXZlcmFnZURhdGEsIEF2ZXJhZ2VWYWxpZGF0b3JEYXRhIH0gZnJvbSAnLi4vLi4vYXBpL3JlY29yZHMvcmVjb3Jkcy5qcyc7XG4vLyBpbXBvcnQgeyBTdGF0dXMgfSBmcm9tICcuLi8uLi9hcGkvc3RhdHVzL3N0YXR1cy5qcyc7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi9hcGkvdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JTZXRzIH0gZnJvbSAnLi4vLi4vYXBpL3ZhbGlkYXRvci1zZXRzL3ZhbGlkYXRvci1zZXRzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi9hcGkvdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZvdGluZ1Bvd2VySGlzdG9yeSB9IGZyb20gJy4uLy4uL2FwaS92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5pbXBvcnQgeyBFdmlkZW5jZXMgfSBmcm9tICcuLi8uLi9hcGkvZXZpZGVuY2VzL2V2aWRlbmNlcy5qcyc7XG5pbXBvcnQgeyBDb2luU3RhdHMgfSBmcm9tICcuLi8uLi9hcGkvY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzJztcbmltcG9ydCB7IENoYWluU3RhdGVzIH0gZnJvbSAnLi4vLi4vYXBpL2NoYWluL2NoYWluLmpzJztcblxuQ2hhaW5TdGF0ZXMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6IC0xfSx7dW5pcXVlOnRydWV9KTtcblxuQmxvY2tzY29uLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7aGVpZ2h0OiAtMX0se3VuaXF1ZTp0cnVlfSk7XG5CbG9ja3Njb24ucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlckFkZHJlc3M6MX0pO1xuXG5FdmlkZW5jZXMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6IC0xfSk7XG5cblByb3Bvc2Fscy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2FsSWQ6IDF9LCB7dW5pcXVlOnRydWV9KTtcblxuVmFsaWRhdG9yUmVjb3Jkcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FkZHJlc3M6MSxoZWlnaHQ6IC0xfSwge3VuaXF1ZToxfSk7XG5WYWxpZGF0b3JSZWNvcmRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWRkcmVzczoxLGV4aXN0czoxLCBoZWlnaHQ6IC0xfSk7XG5cbkFuYWx5dGljcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDogLTF9LCB7dW5pcXVlOnRydWV9KVxuXG5NaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlcjoxLCB2b3RlcjoxLCB1cGRhdGVkQXQ6IC0xfSk7XG5NaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlcjoxLCBibG9ja0hlaWdodDotMX0pO1xuTWlzc2VkQmxvY2tzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dm90ZXI6MSwgYmxvY2tIZWlnaHQ6LTF9KTtcbk1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3ZvdGVyOjEsIHByb3Bvc2VyOjEsIGJsb2NrSGVpZ2h0Oi0xfSwge3VuaXF1ZTp0cnVlfSk7XG5cbk1pc3NlZEJsb2Nrc1N0YXRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXI6MX0pO1xuTWlzc2VkQmxvY2tzU3RhdHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt2b3RlcjoxfSk7XG5NaXNzZWRCbG9ja3NTdGF0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyOjEsIHZvdGVyOjF9LHt1bmlxdWU6dHJ1ZX0pO1xuXG5BdmVyYWdlRGF0YS5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3R5cGU6MSwgY3JlYXRlZEF0Oi0xfSx7dW5pcXVlOnRydWV9KTtcbkF2ZXJhZ2VWYWxpZGF0b3JEYXRhLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXJBZGRyZXNzOjEsY3JlYXRlZEF0Oi0xfSx7dW5pcXVlOnRydWV9KTtcbi8vIFN0YXR1cy5yYXdDb2xsZWN0aW9uLmNyZWF0ZUluZGV4KHt9KVxuXG5UcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt0eGhhc2g6MX0se3VuaXF1ZTp0cnVlfSk7XG5UcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6LTF9KTtcblRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb2Nlc3NlZDoxfSk7XG4vLyBUcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHthY3Rpb246MX0pO1xuVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7XCJ0eF9yZXNwb25zZS5sb2dzLmV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOjF9KTtcblRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe1widHhfcmVzcG9uc2UubG9ncy5ldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOjF9KTtcblRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe1xuICAgIFwidHguYm9keS5tZXNzYWdlcy5kZWxlZ2F0b3JfYWRkcmVzc1wiOjEsXG4gICAgXCJ0eC5ib2R5Lm1lc3NhZ2VzLkB0eXBlXCI6MSxcbiAgICBcInR4X3Jlc3BvbnNlLmNvZGVcIjogMVxufSx7cGFydGlhbEZpbHRlckV4cHJlc3Npb246IHtcInR4X3Jlc3BvbnNlLmNvZGVcIjp7JGV4aXN0czogdHJ1ZX19fSlcblxuVmFsaWRhdG9yU2V0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2Jsb2NrX2hlaWdodDotMX0pO1xuXG5WYWxpZGF0b3JzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWRkcmVzczoxfSx7dW5pcXVlOnRydWUsIHBhcnRpYWxGaWx0ZXJFeHByZXNzaW9uOiB7IGFkZHJlc3M6IHsgJGV4aXN0czogdHJ1ZSB9IH0gfSk7XG4vLyBWYWxpZGF0b3JzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7Y29uc2Vuc3VzUHVia2V5OjF9LHt1bmlxdWU6dHJ1ZX0pO1xuVmFsaWRhdG9ycy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe1wiY29uc2Vuc3VzUHVia2V5LnZhbHVlXCI6MX0se3VuaXF1ZTp0cnVlLCBwYXJ0aWFsRmlsdGVyRXhwcmVzc2lvbjogeyBcImNvbnNlbnN1c1B1YmtleS52YWx1ZVwiOiB7ICRleGlzdHM6IHRydWUgfSB9fSk7XG5cblZvdGluZ1Bvd2VySGlzdG9yeS5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FkZHJlc3M6MSxoZWlnaHQ6LTF9KTtcblZvdGluZ1Bvd2VySGlzdG9yeS5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3R5cGU6MX0pO1xuXG5Db2luU3RhdHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtsYXN0X3VwZGF0ZWRfYXQ6LTF9LHt1bmlxdWU6dHJ1ZX0pO1xuIiwiLy8gSW1wb3J0IHNlcnZlciBzdGFydHVwIHRocm91Z2ggYSBzaW5nbGUgaW5kZXggZW50cnkgcG9pbnRcblxuaW1wb3J0ICcuL3V0aWwuanMnO1xuaW1wb3J0ICcuL3JlZ2lzdGVyLWFwaS5qcyc7XG5pbXBvcnQgJy4vY3JlYXRlLWluZGV4ZXMuanMnO1xuXG4vLyBpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuLy8gaW1wb3J0IHsgcmVuZGVyVG9Ob2RlU3RyZWFtIH0gZnJvbSAncmVhY3QtZG9tL3NlcnZlcic7XG4vLyBpbXBvcnQgeyByZW5kZXJUb1N0cmluZyB9IGZyb20gXCJyZWFjdC1kb20vc2VydmVyXCI7XG5pbXBvcnQgeyBvblBhZ2VMb2FkIH0gZnJvbSAnbWV0ZW9yL3NlcnZlci1yZW5kZXInO1xuLy8gaW1wb3J0IHsgU3RhdGljUm91dGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG4vLyBpbXBvcnQgeyBTZXJ2ZXJTdHlsZVNoZWV0IH0gZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCJcbmltcG9ydCB7IEhlbG1ldCB9IGZyb20gJ3JlYWN0LWhlbG1ldCc7XG5cbi8vIGltcG9ydCBBcHAgZnJvbSAnLi4vLi4vdWkvQXBwLmpzeCc7XG5cbm9uUGFnZUxvYWQoc2luayA9PiB7XG4gICAgLy8gY29uc3QgY29udGV4dCA9IHt9O1xuICAgIC8vIGNvbnN0IHNoZWV0ID0gbmV3IFNlcnZlclN0eWxlU2hlZXQoKVxuXG4gICAgLy8gY29uc3QgaHRtbCA9IHJlbmRlclRvU3RyaW5nKHNoZWV0LmNvbGxlY3RTdHlsZXMoXG4gICAgLy8gICAgIDxTdGF0aWNSb3V0ZXIgbG9jYXRpb249e3NpbmsucmVxdWVzdC51cmx9IGNvbnRleHQ9e2NvbnRleHR9PlxuICAgIC8vICAgICAgICAgPEFwcCAvPlxuICAgIC8vICAgICA8L1N0YXRpY1JvdXRlcj5cbiAgICAvLyAgICkpO1xuXG4gICAgLy8gc2luay5yZW5kZXJJbnRvRWxlbWVudEJ5SWQoJ2FwcCcsIGh0bWwpO1xuXG4gICAgY29uc3QgaGVsbWV0ID0gSGVsbWV0LnJlbmRlclN0YXRpYygpO1xuICAgIHNpbmsuYXBwZW5kVG9IZWFkKGhlbG1ldC5tZXRhLnRvU3RyaW5nKCkpO1xuICAgIHNpbmsuYXBwZW5kVG9IZWFkKGhlbG1ldC50aXRsZS50b1N0cmluZygpKTtcblxuICAgIC8vIHNpbmsuYXBwZW5kVG9IZWFkKHNoZWV0LmdldFN0eWxlVGFncygpKTtcbn0pOyIsIi8vIFJlZ2lzdGVyIHlvdXIgYXBpcyBoZXJlXG5cbmltcG9ydCAnLi4vLi4vYXBpL2xlZGdlci9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2NoYWluL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL2NoYWluL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9ibG9ja3Mvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvYmxvY2tzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS92YWxpZGF0b3JzL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL3ZhbGlkYXRvcnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3JlY29yZHMvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvcmVjb3Jkcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvcHJvcG9zYWxzL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL3Byb3Bvc2Fscy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvdm90aW5nLXBvd2VyL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvdHJhbnNhY3Rpb25zL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvc3RhdHVzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9hY2NvdW50cy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2NvaW4tc3RhdHMvc2VydmVyL21ldGhvZHMuanMnO1xuIiwiaW1wb3J0IGJlY2gzMiBmcm9tICdiZWNoMzInXG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0ICogYXMgY2hlZXJpbyBmcm9tICdjaGVlcmlvJztcbmltcG9ydCB7IHRtaGFzaCB9IGZyb20gJ3RlbmRlcm1pbnQvbGliL2hhc2gnXG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICBoZXhUb0JlY2gzMjogZnVuY3Rpb24oYWRkcmVzcywgcHJlZml4KSB7XG4gICAgICAgIGxldCBhZGRyZXNzQnVmZmVyID0gQnVmZmVyLmZyb20oYWRkcmVzcywgJ2hleCcpO1xuICAgICAgICAvLyBsZXQgYnVmZmVyID0gQnVmZmVyLmFsbG9jKDM3KVxuICAgICAgICAvLyBhZGRyZXNzQnVmZmVyLmNvcHkoYnVmZmVyKTtcbiAgICAgICAgcmV0dXJuIGJlY2gzMi5lbmNvZGUocHJlZml4LCBiZWNoMzIudG9Xb3JkcyhhZGRyZXNzQnVmZmVyKSk7XG4gICAgfSxcbiAgICBwdWJrZXlUb0JlY2gzMk9sZDogZnVuY3Rpb24ocHVia2V5LCBwcmVmaXgpIHtcbiAgICAgICAgbGV0IGJ1ZmZlcjtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgaWYgKHB1YmtleS50eXBlLmluZGV4T2YoXCJFZDI1NTE5XCIpID4gMCl7XG4gICAgICAgICAgICAvLyAnMTYyNERFNjQyMCcgaXMgZWQyNTUxOSBwdWJrZXkgcHJlZml4XG4gICAgICAgICAgICAgICAgbGV0IHB1YmtleUFtaW5vUHJlZml4ID0gQnVmZmVyLmZyb20oJzE2MjRERTY0MjAnLCAnaGV4Jyk7XG4gICAgICAgICAgICAgICAgYnVmZmVyID0gQnVmZmVyLmFsbG9jKDM3KTtcbiAgICAgICAgXG4gICAgICAgICAgICAgICAgcHVia2V5QW1pbm9QcmVmaXguY29weShidWZmZXIsIDApXG4gICAgICAgICAgICAgICAgQnVmZmVyLmZyb20ocHVia2V5LnZhbHVlLCAnYmFzZTY0JykuY29weShidWZmZXIsIHB1YmtleUFtaW5vUHJlZml4Lmxlbmd0aClcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHB1YmtleS50eXBlLmluZGV4T2YoXCJTZWNwMjU2azFcIikgPiAwKXtcbiAgICAgICAgICAgIC8vICdFQjVBRTk4NzIxJyBpcyBzZWNwMjU2azEgcHVia2V5IHByZWZpeFxuICAgICAgICAgICAgICAgIGxldCBwdWJrZXlBbWlub1ByZWZpeCA9IEJ1ZmZlci5mcm9tKCdFQjVBRTk4NzIxJywgJ2hleCcpO1xuICAgICAgICAgICAgICAgIGJ1ZmZlciA9IEJ1ZmZlci5hbGxvYygzOCk7XG4gICAgXG4gICAgICAgICAgICAgICAgcHVia2V5QW1pbm9QcmVmaXguY29weShidWZmZXIsIDApXG4gICAgICAgICAgICAgICAgQnVmZmVyLmZyb20ocHVia2V5LnZhbHVlLCAnYmFzZTY0JykuY29weShidWZmZXIsIHB1YmtleUFtaW5vUHJlZml4Lmxlbmd0aClcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUHVia2V5IHR5cGUgbm90IHN1cHBvcnRlZC5cIik7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gYmVjaDMyLmVuY29kZShwcmVmaXgsIGJlY2gzMi50b1dvcmRzKGJ1ZmZlcikpXG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJFcnJvciBjb252ZXJ0aW5nIGZyb20gcHVia2V5IHRvIGJlY2gzMjogJW9cXG4gJW9cIiwgcHVia2V5LCBlKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgICB9XG4gICAgfSxcbiAgICBwdWJrZXlUb0JlY2gzMjogZnVuY3Rpb24ocHVia2V5LCBwcmVmaXgpIHtcbiAgICAgICAgbGV0IGJ1ZmZlcjtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgaWYgKHB1YmtleVtcIkB0eXBlXCJdLmluZGV4T2YoXCJlZDI1NTE5XCIpID4gMCl7XG4gICAgICAgICAgICAvLyAnMTYyNERFNjQyMCcgaXMgZWQyNTUxOSBwdWJrZXkgcHJlZml4XG4gICAgICAgICAgICAgICAgbGV0IHB1YmtleUFtaW5vUHJlZml4ID0gQnVmZmVyLmZyb20oJzE2MjRERTY0MjAnLCAnaGV4Jyk7XG4gICAgICAgICAgICAgICAgYnVmZmVyID0gQnVmZmVyLmFsbG9jKDM3KTtcbiAgICAgICAgXG4gICAgICAgICAgICAgICAgcHVia2V5QW1pbm9QcmVmaXguY29weShidWZmZXIsIDApXG4gICAgICAgICAgICAgICAgQnVmZmVyLmZyb20ocHVia2V5LmtleSwgJ2Jhc2U2NCcpLmNvcHkoYnVmZmVyLCBwdWJrZXlBbWlub1ByZWZpeC5sZW5ndGgpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChwdWJrZXlbXCJAdHlwZVwiXS5pbmRleE9mKFwic2VjcDI1NmsxXCIpID4gMCl7XG4gICAgICAgICAgICAvLyAnRUI1QUU5ODcyMScgaXMgc2VjcDI1NmsxIHB1YmtleSBwcmVmaXhcbiAgICAgICAgICAgICAgICBsZXQgcHVia2V5QW1pbm9QcmVmaXggPSBCdWZmZXIuZnJvbSgnRUI1QUU5ODcyMScsICdoZXgnKTtcbiAgICAgICAgICAgICAgICBidWZmZXIgPSBCdWZmZXIuYWxsb2MoMzgpO1xuICAgIFxuICAgICAgICAgICAgICAgIHB1YmtleUFtaW5vUHJlZml4LmNvcHkoYnVmZmVyLCAwKVxuICAgICAgICAgICAgICAgIEJ1ZmZlci5mcm9tKHB1YmtleS5rZXksICdiYXNlNjQnKS5jb3B5KGJ1ZmZlciwgcHVia2V5QW1pbm9QcmVmaXgubGVuZ3RoKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJQdWJrZXkgdHlwZSBub3Qgc3VwcG9ydGVkLlwiKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBiZWNoMzIuZW5jb2RlKHByZWZpeCwgYmVjaDMyLnRvV29yZHMoYnVmZmVyKSlcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9yIGNvbnZlcnRpbmcgZnJvbSBwdWJrZXkgdG8gYmVjaDMyOiAlb1xcbiAlb1wiLCBwdWJrZXksIGUpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICAgIH1cbiAgICB9LFxuICAgIGJlY2gzMlRvUHVia2V5OiBmdW5jdGlvbihwdWJrZXksIHR5cGUpIHtcbiAgICAgICAgLy8gdHlwZSBjYW4gb25seSBiZSBlaXRoZXIgJ3RlbmRlcm1pbnQvUHViS2V5U2VjcDI1NmsxJyBvciAndGVuZGVybWludC9QdWJLZXlFZDI1NTE5J1xuICAgICAgICBsZXQgcHVia2V5QW1pbm9QcmVmaXgsIGJ1ZmZlcjtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgaWYgKHR5cGUuaW5kZXhPZihcImVkMjU1MTlcIikgPiAwKXtcbiAgICAgICAgICAgIC8vICcxNjI0REU2NDIwJyBpcyBlZDI1NTE5IHB1YmtleSBwcmVmaXhcbiAgICAgICAgICAgICAgICBwdWJrZXlBbWlub1ByZWZpeCA9IEJ1ZmZlci5mcm9tKCcxNjI0REU2NDIwJywgJ2hleCcpXG4gICAgICAgICAgICAgICAgYnVmZmVyID0gQnVmZmVyLmZyb20oYmVjaDMyLmZyb21Xb3JkcyhiZWNoMzIuZGVjb2RlKHB1YmtleSkud29yZHMpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGUuaW5kZXhPZihcInNlY3AyNTZrMVwiKSA+IDApe1xuICAgICAgICAgICAgLy8gJ0VCNUFFOTg3MjEnIGlzIHNlY3AyNTZrMSBwdWJrZXkgcHJlZml4XG4gICAgICAgICAgICAgICAgcHVia2V5QW1pbm9QcmVmaXggPSBCdWZmZXIuZnJvbSgnRUI1QUU5ODcyMScsICdoZXgnKVxuICAgICAgICAgICAgICAgIGJ1ZmZlciA9IEJ1ZmZlci5mcm9tKGJlY2gzMi5mcm9tV29yZHMoYmVjaDMyLmRlY29kZShwdWJrZXkpLndvcmRzKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlB1YmtleSB0eXBlIG5vdCBzdXBwb3J0ZWQuXCIpO1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgICAgICByZXR1cm4gYnVmZmVyLnNsaWNlKHB1YmtleUFtaW5vUHJlZml4Lmxlbmd0aCkudG9TdHJpbmcoJ2Jhc2U2NCcpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgY29udmVydGluZyBmcm9tIGJlY2gzMiB0byBwdWJrZXk6ICVvXFxuICVvXCIsIHB1YmtleSwgZSk7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgICAgfVxuICAgIH0sXG4gICAgZ2V0QWRkcmVzc0Zyb21QdWJrZXk6IGZ1bmN0aW9uKHB1YmtleSl7XG4gICAgICAgIHZhciBieXRlcyA9IEJ1ZmZlci5mcm9tKHB1YmtleS5rZXksICdiYXNlNjQnKTtcbiAgICAgICAgcmV0dXJuIHRtaGFzaChieXRlcykuc2xpY2UoMCwgMjApLnRvU3RyaW5nKCdoZXgnKS50b1VwcGVyQ2FzZSgpO1xuICAgIH0sXG4gICAgZ2V0RGVsZWdhdG9yOiBmdW5jdGlvbihvcGVyYXRvckFkZHIpe1xuICAgICAgICBsZXQgYWRkcmVzcyA9IGJlY2gzMi5kZWNvZGUob3BlcmF0b3JBZGRyKTtcbiAgICAgICAgcmV0dXJuIGJlY2gzMi5lbmNvZGUoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NBZGRyLCBhZGRyZXNzLndvcmRzKTtcbiAgICB9LFxuICAgIGdldEtleWJhc2VUZWFtUGljOiBmdW5jdGlvbihrZXliYXNlVXJsKXtcbiAgICAgICAgbGV0IHRlYW1QYWdlID0gSFRUUC5nZXQoa2V5YmFzZVVybCk7XG4gICAgICAgIGlmICh0ZWFtUGFnZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICBsZXQgcGFnZSA9IGNoZWVyaW8ubG9hZCh0ZWFtUGFnZS5jb250ZW50KTtcbiAgICAgICAgICAgIHJldHVybiBwYWdlKFwiLmtiLW1haW4tY2FyZCBpbWdcIikuYXR0cignc3JjJyk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGdldFZlcnNpb246IGZ1bmN0aW9uKCl7XG4gICAgICAgIGNvbnN0IHZlcnNpb24gPSBBc3NldHMuZ2V0VGV4dCgndmVyc2lvbicpO1xuICAgICAgICByZXR1cm4gdmVyc2lvbiA/IHZlcnNpb24gOiAnYmV0YSdcbiAgICB9XG59KVxuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFVuY29udHJvbGxlZFRvb2x0aXAgfSBmcm9tICdyZWFjdHN0cmFwJztcblxuZXhwb3J0IGNvbnN0IERlbm9tU3ltYm9sID0gKHByb3BzKSA9PiB7XG4gICAgc3dpdGNoIChwcm9wcy5kZW5vbSl7XG4gICAgY2FzZSBcInN0ZWFrXCI6XG4gICAgICAgIHJldHVybiAn8J+lqSc7XG4gICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuICfwn42FJztcbiAgICB9XG59XG5cblxuZXhwb3J0IGNvbnN0IFByb3Bvc2FsU3RhdHVzSWNvbiA9IChwcm9wcykgPT4ge1xuICAgIHN3aXRjaCAocHJvcHMuc3RhdHVzKXtcbiAgICBjYXNlICdQUk9QT1NBTF9TVEFUVVNfUEFTU0VEJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1jaGVjay1jaXJjbGUgdGV4dC1zdWNjZXNzXCI+PC9pPjtcbiAgICBjYXNlICdQUk9QT1NBTF9TVEFUVVNfUkVKRUNURUQnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXRpbWVzLWNpcmNsZSB0ZXh0LWRhbmdlclwiPjwvaT47XG4gICAgY2FzZSAnUFJPUE9TQUxfU1RBVFVTX1JFTU9WRUQnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXRyYXNoLWFsdCB0ZXh0LWRhcmtcIj48L2k+XG4gICAgY2FzZSAnUFJPUE9TQUxfU1RBVFVTX0RFUE9TSVRfUEVSSU9EJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1iYXR0ZXJ5LWhhbGYgdGV4dC13YXJuaW5nXCI+PC9pPjtcbiAgICBjYXNlICdQUk9QT1NBTF9TVEFUVVNfVk9USU5HX1BFUklPRCc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtaGFuZC1wYXBlciB0ZXh0LWluZm9cIj48L2k+O1xuICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiA8aT48L2k+O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IFZvdGVJY29uID0gKHByb3BzKSA9PiB7XG4gICAgc3dpdGNoIChwcm9wcy52b3RlKXtcbiAgICBjYXNlICd5ZXMnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWNoZWNrIHRleHQtc3VjY2Vzc1wiPjwvaT47XG4gICAgY2FzZSAnbm8nOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXRpbWVzIHRleHQtZGFuZ2VyXCI+PC9pPjtcbiAgICBjYXNlICdhYnN0YWluJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS11c2VyLXNsYXNoIHRleHQtd2FybmluZ1wiPjwvaT47XG4gICAgY2FzZSAnbm9fd2l0aF92ZXRvJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1leGNsYW1hdGlvbi10cmlhbmdsZSB0ZXh0LWluZm9cIj48L2k+O1xuICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiA8aT48L2k+O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IFR4SWNvbiA9IChwcm9wcykgPT4ge1xuICAgIGlmIChwcm9wcy52YWxpZCl7XG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXN1Y2Nlc3MgdGV4dC1ub3dyYXBcIj48aSBjbGFzc05hbWU9XCJmYXMgZmEtY2hlY2stY2lyY2xlXCI+PC9pPjwvc3Bhbj47XG4gICAgfVxuICAgIGVsc2V7XG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWRhbmdlciB0ZXh0LW5vd3JhcFwiPjxpIGNsYXNzTmFtZT1cImZhcyBmYS10aW1lcy1jaXJjbGVcIj48L2k+PC9zcGFuPjtcbiAgICB9XG59XG5cbmV4cG9ydCBjbGFzcyBJbmZvSWNvbiBleHRlbmRzIFJlYWN0LkNvbXBvbmVudCB7XG4gICAgY29uc3RydWN0b3IocHJvcHMpIHtcbiAgICAgICAgc3VwZXIocHJvcHMpO1xuICAgICAgICB0aGlzLnJlZiA9IFJlYWN0LmNyZWF0ZVJlZigpO1xuICAgIH1cblxuICAgIHJlbmRlcigpIHtcbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgIDxpIGtleT0naWNvbicgY2xhc3NOYW1lPSdtYXRlcmlhbC1pY29ucyBpbmZvLWljb24nIHJlZj17dGhpcy5yZWZ9PmluZm88L2k+LFxuICAgICAgICAgICAgPFVuY29udHJvbGxlZFRvb2x0aXAga2V5PSd0b29sdGlwJyBwbGFjZW1lbnQ9J3JpZ2h0JyB0YXJnZXQ9e3RoaXMucmVmfT5cbiAgICAgICAgICAgICAgICB7dGhpcy5wcm9wcy5jaGlsZHJlbj90aGlzLnByb3BzLmNoaWxkcmVuOnRoaXMucHJvcHMudG9vbHRpcFRleHR9XG4gICAgICAgICAgICA8L1VuY29udHJvbGxlZFRvb2x0aXA+XG4gICAgICAgIF1cbiAgICB9XG59IiwiLyogZXNsaW50LWRpc2FibGUgbm8tdGFicyAqL1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgbnVtYnJvIGZyb20gJ251bWJybyc7XG5cbmF1dG9mb3JtYXQgPSAodmFsdWUpID0+IHtcbiAgICBsZXQgZm9ybWF0dGVyID0gJzAsMC4wMDAwJztcbiAgICB2YWx1ZSA9IE1hdGgucm91bmQodmFsdWUgKiAxMDAwKSAvIDEwMDBcbiAgICBpZiAoTWF0aC5yb3VuZCh2YWx1ZSkgPT09IHZhbHVlKVxuICAgICAgICBmb3JtYXR0ZXIgPSAnMCwwJ1xuICAgIGVsc2UgaWYgKE1hdGgucm91bmQodmFsdWUqMTApID09PSB2YWx1ZSoxMClcbiAgICAgICAgZm9ybWF0dGVyID0gJzAsMC4wJ1xuICAgIGVsc2UgaWYgKE1hdGgucm91bmQodmFsdWUqMTAwKSA9PT0gdmFsdWUqMTAwKVxuICAgICAgICBmb3JtYXR0ZXIgPSAnMCwwLjAwJ1xuICAgIGVsc2UgaWYgKE1hdGgucm91bmQodmFsdWUqMTAwMCkgPT09IHZhbHVlKjEwMDApXG4gICAgICAgIGZvcm1hdHRlciA9ICcwLDAuMDAwJ1xuICAgIHJldHVybiBudW1icm8odmFsdWUpLmZvcm1hdChmb3JtYXR0ZXIpXG59XG5cbmNvbnN0IGNvaW5MaXN0ID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jb2lucztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ29pbiB7XG5zdGF0aWMgU3Rha2luZ0NvaW4gPSBjb2luTGlzdC5maW5kKGNvaW4gPT4gY29pbi5kZW5vbSA9PT0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5ib25kRGVub20pO1xuc3RhdGljIE1pblN0YWtlID0gMSAvIE51bWJlcihDb2luLlN0YWtpbmdDb2luLmZyYWN0aW9uKTtcblxuY29uc3RydWN0b3IoYW1vdW50LCBkZW5vbT1NZXRlb3Iuc2V0dGluZ3MucHVibGljLmJvbmREZW5vbSkge1xuICAgIGNvbnN0IGxvd2VyRGVub20gPSBkZW5vbS50b0xvd2VyQ2FzZSgpO1xuICAgIHRoaXMuX2NvaW4gPSBjb2luTGlzdC5maW5kKGNvaW4gPT5cbiAgICAgICAgY29pbi5kZW5vbS50b0xvd2VyQ2FzZSgpID09PSBsb3dlckRlbm9tIHx8IGNvaW4uZGlzcGxheU5hbWUudG9Mb3dlckNhc2UoKSA9PT0gbG93ZXJEZW5vbVxuICAgICk7XG5cbiAgICBpZiAodGhpcy5fY29pbil7XG4gICAgICAgIGlmIChsb3dlckRlbm9tID09PSB0aGlzLl9jb2luLmRlbm9tLnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgICAgICAgIHRoaXMuX2Ftb3VudCA9IE51bWJlcihhbW91bnQpO1xuICAgICAgICB9IGVsc2UgaWYgKGxvd2VyRGVub20gPT09IHRoaXMuX2NvaW4uZGlzcGxheU5hbWUudG9Mb3dlckNhc2UoKSkge1xuICAgICAgICAgICAgdGhpcy5fYW1vdW50ID0gTnVtYmVyKGFtb3VudCkgKiB0aGlzLl9jb2luLmZyYWN0aW9uO1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICB0aGlzLl9jb2luID0gXCJcIjtcbiAgICAgICAgdGhpcy5fYW1vdW50ID0gTnVtYmVyKGFtb3VudCk7XG4gICAgfVxufVxuXG5nZXQgYW1vdW50ICgpIHtcbiAgICByZXR1cm4gdGhpcy5fYW1vdW50O1xufVxuXG5nZXQgc3Rha2luZ0Ftb3VudCAoKSB7XG4gICAgcmV0dXJuICh0aGlzLl9jb2luKT90aGlzLl9hbW91bnQgLyB0aGlzLl9jb2luLmZyYWN0aW9uOnRoaXMuX2Ftb3VudDtcbn1cblxudG9TdHJpbmcgKHByZWNpc2lvbikge1xuICAgIC8vIGRlZmF1bHQgdG8gZGlzcGxheSBpbiBtaW50IGRlbm9tIGlmIGl0IGhhcyBtb3JlIHRoYW4gNCBkZWNpbWFsIHBsYWNlc1xuICAgIGxldCBtaW5TdGFrZSA9IENvaW4uU3Rha2luZ0NvaW4uZnJhY3Rpb24vKHByZWNpc2lvbj8oMTAgKiogcHJlY2lzaW9uKToxMDAwMClcbiAgICBpZiAodGhpcy5hbW91bnQgPCBtaW5TdGFrZSkge1xuICAgICAgICByZXR1cm4gYCR7bnVtYnJvKHRoaXMuYW1vdW50KS5mb3JtYXQoJzAsMC4wMDAwJyApfSAke3RoaXMuX2NvaW4uZGVub219YDtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gYCR7cHJlY2lzaW9uP251bWJybyh0aGlzLnN0YWtpbmdBbW91bnQpLmZvcm1hdCgnMCwwLicgKyAnMCcucmVwZWF0KHByZWNpc2lvbikpOmF1dG9mb3JtYXQodGhpcy5zdGFraW5nQW1vdW50KX0gJHt0aGlzLl9jb2luLmRpc3BsYXlOYW1lfWBcbiAgICB9XG59XG5cbm1pbnRTdHJpbmcgKGZvcm1hdHRlcikge1xuICAgIGxldCBhbW91bnQgPSB0aGlzLmFtb3VudFxuICAgIGlmIChmb3JtYXR0ZXIpIHtcbiAgICAgICAgYW1vdW50ID0gbnVtYnJvKGFtb3VudCkuZm9ybWF0KGZvcm1hdHRlcilcbiAgICB9XG5cbiAgICBsZXQgZGVub20gPSAodGhpcy5fY29pbiA9PSBcIlwiKT9Db2luLlN0YWtpbmdDb2luLmRpc3BsYXlOYW1lOnRoaXMuX2NvaW4uZGVub207XG4gICAgcmV0dXJuIGAke2Ftb3VudH0gJHtkZW5vbX1gO1xufVxuXG5zdGFrZVN0cmluZyAoZm9ybWF0dGVyKSB7XG4gICAgbGV0IGFtb3VudCA9IHRoaXMuc3Rha2luZ0Ftb3VudFxuICAgIGlmIChmb3JtYXR0ZXIpIHtcbiAgICAgICAgYW1vdW50ID0gbnVtYnJvKGFtb3VudCkuZm9ybWF0KGZvcm1hdHRlcilcbiAgICB9XG4gICAgcmV0dXJuIGAke2Ftb3VudH0gJHtDb2luLlN0YWtpbmdDb2luLmRpc3BsYXlOYW1lfWA7XG59XG59IiwiZXhwb3J0IGNvbnN0IGdvVGltZVRvSVNPU3RyaW5nID0gKHRpbWUpID0+IHtcbiAgICBjb25zdCBtaWxsaXNlY29uZCA9IHBhcnNlSW50KHRpbWUuc2Vjb25kcyt0aW1lLm5hbm9zLnRvU3RyaW5nKCkuc3Vic3RyaW5nKDAsMykpO1xuICAgIHJldHVybiAobmV3IERhdGUobWlsbGlzZWNvbmQpKS50b0lTT1N0cmluZygpXG59IiwiLy8gU2VydmVyIGVudHJ5IHBvaW50LCBpbXBvcnRzIGFsbCBzZXJ2ZXIgY29kZVxuXG5pbXBvcnQgJy9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyJztcbmltcG9ydCAnL2ltcG9ydHMvc3RhcnR1cC9ib3RoJztcbi8vIGltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50Jztcbi8vIGltcG9ydCAnL2ltcG9ydHMvYXBpL2Jsb2Nrcy9ibG9ja3MuanMnO1xuXG5TWU5DSU5HID0gZmFsc2U7XG5UWFNZTkNJTkcgPSBmYWxzZTtcbkNPVU5UTUlTU0VEQkxPQ0tTID0gZmFsc2U7XG5DT1VOVE1JU1NFREJMT0NLU1NUQVRTID0gZmFsc2U7XG5SUEMgPSBNZXRlb3Iuc2V0dGluZ3MucmVtb3RlLnJwYztcbkFQSSA9IE1ldGVvci5zZXR0aW5ncy5yZW1vdGUuYXBpO1xuXG50aW1lckJsb2NrcyA9IDA7XG50aW1lclRyYW5zYWN0aW9ucyA9IDA7XG50aW1lckNoYWluID0gMDtcbnRpbWVyQ29uc2Vuc3VzID0gMDtcbnRpbWVyUHJvcG9zYWwgPSAwO1xudGltZXJQcm9wb3NhbHNSZXN1bHRzID0gMDtcbnRpbWVyTWlzc2VkQmxvY2sgPSAwO1xudGltZXJEZWxlZ2F0aW9uID0gMDtcbnRpbWVyQWdncmVnYXRlID0gMDtcblxuY29uc3QgREVGQVVMVFNFVFRJTkdTID0gJy9kZWZhdWx0X3NldHRpbmdzLmpzb24nO1xuXG51cGRhdGVDaGFpblN0YXR1cyA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCgnY2hhaW4udXBkYXRlU3RhdHVzJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXBkYXRlU3RhdHVzOiAlb1wiLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXBkYXRlU3RhdHVzOiAlb1wiLCByZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSlcbn1cblxudXBkYXRlQmxvY2sgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5ibG9ja3NVcGRhdGUnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGVCbG9ja3M6ICVvXCIsIGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGVCbG9ja3M6ICVvXCIsIHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KVxufVxuXG51cGRhdGVUcmFuc2FjdGlvbnMgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ1RyYW5zYWN0aW9ucy51cGRhdGVUcmFuc2FjdGlvbnMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGVUcmFuc2FjdGlvbnM6ICVvXCIsZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInVwZGF0ZVRyYW5zYWN0aW9uczogJW9cIixyZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSlcbn1cblxuZ2V0Q29uc2Vuc3VzU3RhdGUgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ2NoYWluLmdldENvbnNlbnN1c1N0YXRlJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGNvbnNlbnN1czogJW9cIiwgZXJyb3IpXG4gICAgICAgIH1cbiAgICB9KVxufVxuXG5nZXRQcm9wb3NhbHMgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ3Byb3Bvc2Fscy5nZXRQcm9wb3NhbHMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgcHJvcG9zYWw6ICVvXCIsIGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHByb3Bvc2FsOiAlb1wiLCByZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSk7XG59XG5cbmdldFByb3Bvc2Fsc1Jlc3VsdHMgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ3Byb3Bvc2Fscy5nZXRQcm9wb3NhbFJlc3VsdHMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgcHJvcG9zYWxzIHJlc3VsdDogJW9cIiwgZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgcHJvcG9zYWxzIHJlc3VsdDogJW9cIiwgcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG51cGRhdGVNaXNzZWRCbG9ja3MgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ1ZhbGlkYXRvclJlY29yZHMuY2FsY3VsYXRlTWlzc2VkQmxvY2tzJywgKGVycm9yLCByZXN1bHQpID0+e1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJtaXNzZWQgYmxvY2tzIGVycm9yOiAlb1wiLCBlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibWlzc2VkIGJsb2NrcyBvazogJW9cIiwgcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5nZXREZWxlZ2F0aW9ucyA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCgnZGVsZWdhdGlvbnMuZ2V0RGVsZWdhdGlvbnMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgZGVsZWdhdGlvbnMgZXJyb3I6ICVvXCIsIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBkZWxlZ2F0aW9ucyBvazogJW9cIiwgcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG59XG5cbmFnZ3JlZ2F0ZU1pbnV0ZWx5ID0gKCkgPT57XG4gICAgLy8gZG9pbmcgc29tZXRoaW5nIGV2ZXJ5IG1pblxuICAgIE1ldGVvci5jYWxsKCdBbmFseXRpY3MuYWdncmVnYXRlQmxvY2tUaW1lQW5kVm90aW5nUG93ZXInLCBcIm1cIiwgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIG1pbnV0ZWx5IGJsb2NrIHRpbWUgZXJyb3I6ICVvXCIsIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBtaW51dGVseSBibG9jayB0aW1lIG9rOiAlb1wiLCByZXN1bHQpXG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIE1ldGVvci5jYWxsKCdjb2luU3RhdHMuZ2V0Q29pblN0YXRzJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGNvaW4gc3RhdHMgZXJyb3I6ICVvXCIsIGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgY29pbiBzdGF0cyBvazogJW9cIiwgcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG59XG5cbmFnZ3JlZ2F0ZUhvdXJseSA9ICgpID0+e1xuICAgIC8vIGRvaW5nIHNvbWV0aGluZyBldmVyeSBob3VyXG4gICAgTWV0ZW9yLmNhbGwoJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcicsIFwiaFwiLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgaG91cmx5IGJsb2NrIHRpbWUgZXJyb3I6ICVvXCIsIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBob3VybHkgYmxvY2sgdGltZSBvazogJW9cIiwgcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG59XG5cbmFnZ3JlZ2F0ZURhaWx5ID0gKCkgPT57XG4gICAgLy8gZG9pbmcgc29tdGhpbmcgZXZlcnkgZGF5XG4gICAgTWV0ZW9yLmNhbGwoJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcicsIFwiZFwiLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgZGFpbHkgYmxvY2sgdGltZSBlcnJvcjogJW9cIiwgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIGRhaWx5IGJsb2NrIHRpbWUgb2s6ICVvXCIsIHJlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgTWV0ZW9yLmNhbGwoJ0FuYWx5dGljcy5hZ2dyZWdhdGVWYWxpZGF0b3JEYWlseUJsb2NrVGltZScsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSB2YWxpZGF0b3JzIGJsb2NrIHRpbWUgZXJyb3I6ICVvXCIsIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgdmFsaWRhdG9ycyBibG9jayB0aW1lIG9rOiAlb1wiLCByZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSlcbn1cblxuXG5cbk1ldGVvci5zdGFydHVwKGFzeW5jIGZ1bmN0aW9uKCl7XG4gICAgaWYgKE1ldGVvci5pc0RldmVsb3BtZW50KXtcbiAgICAgICAgcHJvY2Vzcy5lbnYuTk9ERV9UTFNfUkVKRUNUX1VOQVVUSE9SSVpFRCA9IDA7XG4gICAgICAgIGltcG9ydCBERUZBVUxUU0VUVElOR1NKU09OIGZyb20gJy4uL2RlZmF1bHRfc2V0dGluZ3MuanNvbidcbiAgICAgICAgT2JqZWN0LmtleXMoREVGQVVMVFNFVFRJTkdTSlNPTikuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgICAgICBpZiAoTWV0ZW9yLnNldHRpbmdzW2tleV0gPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGBDSEVDSyBTRVRUSU5HUyBKU09OOiAke2tleX0gaXMgbWlzc2luZyBmcm9tIHNldHRpbmdzYClcbiAgICAgICAgICAgICAgICBNZXRlb3Iuc2V0dGluZ3Nba2V5XSA9IHt9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgT2JqZWN0LmtleXMoREVGQVVMVFNFVFRJTkdTSlNPTltrZXldKS5mb3JFYWNoKChwYXJhbSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChNZXRlb3Iuc2V0dGluZ3Nba2V5XVtwYXJhbV0gPT0gdW5kZWZpbmVkKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGBDSEVDSyBTRVRUSU5HUyBKU09OOiAke2tleX0uJHtwYXJhbX0gaXMgbWlzc2luZyBmcm9tIHNldHRpbmdzYClcbiAgICAgICAgICAgICAgICAgICAgTWV0ZW9yLnNldHRpbmdzW2tleV1bcGFyYW1dID0gREVGQVVMVFNFVFRJTkdTSlNPTltrZXldW3BhcmFtXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0pXG4gICAgfVxuXG4gICAgaWYgKE1ldGVvci5zZXR0aW5ncy5kZWJ1Zy5zdGFydFRpbWVyKXtcbiAgICAgICAgdGltZXJDb25zZW5zdXMgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgIGdldENvbnNlbnN1c1N0YXRlKCk7XG4gICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuY29uc2Vuc3VzSW50ZXJ2YWwpO1xuXG4gICAgICAgIHRpbWVyQmxvY2tzID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICB1cGRhdGVCbG9jaygpO1xuICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLmJsb2NrSW50ZXJ2YWwpO1xuXG4gICAgICAgIHRpbWVyVHJhbnNhY3Rpb25zID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICB1cGRhdGVUcmFuc2FjdGlvbnMoKTtcbiAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy50cmFuc2FjdGlvbnNJbnRlcnZhbCk7XG5cbiAgICAgICAgdGltZXJDaGFpbiA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgdXBkYXRlQ2hhaW5TdGF0dXMoKTtcbiAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGF0dXNJbnRlcnZhbCk7XG5cbiAgICAgICAgaWYgKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMubW9kdWxlcy5nb3YpIHtcbiAgICAgICAgICAgIHRpbWVyUHJvcG9zYWwgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGdldFByb3Bvc2FscygpO1xuICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5wcm9wb3NhbEludGVydmFsKTtcblxuICAgICAgICAgICAgdGltZXJQcm9wb3NhbHNSZXN1bHRzID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBnZXRQcm9wb3NhbHNSZXN1bHRzKCk7XG4gICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnByb3Bvc2FsSW50ZXJ2YWwpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGltZXJNaXNzZWRCbG9jayA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgdXBkYXRlTWlzc2VkQmxvY2tzKCk7XG4gICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMubWlzc2VkQmxvY2tzSW50ZXJ2YWwpO1xuXG4gICAgICAgIC8vIHRpbWVyRGVsZWdhdGlvbiA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAvLyAgICAgZ2V0RGVsZWdhdGlvbnMoKTtcbiAgICAgICAgLy8gfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5kZWxlZ2F0aW9uSW50ZXJ2YWwpO1xuXG4gICAgICAgIHRpbWVyQWdncmVnYXRlID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICBsZXQgbm93ID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgIGlmICgobm93LmdldFVUQ1NlY29uZHMoKSA9PSAwKSl7XG4gICAgICAgICAgICAgICAgYWdncmVnYXRlTWludXRlbHkoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKChub3cuZ2V0VVRDTWludXRlcygpID09IDApICYmIChub3cuZ2V0VVRDU2Vjb25kcygpID09IDApKXtcbiAgICAgICAgICAgICAgICBhZ2dyZWdhdGVIb3VybHkoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKChub3cuZ2V0VVRDSG91cnMoKSA9PSAwKSAmJiAobm93LmdldFVUQ01pbnV0ZXMoKSA9PSAwKSAmJiAobm93LmdldFVUQ1NlY29uZHMoKSA9PSAwKSl7XG4gICAgICAgICAgICAgICAgYWdncmVnYXRlRGFpbHkoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgMTAwMClcbiAgICB9XG59KTsiXX0=
